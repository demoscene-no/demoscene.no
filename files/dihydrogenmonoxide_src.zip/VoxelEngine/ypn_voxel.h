#include "../3d/ypn_vector3d.h"

#ifdef __cplusplus
   extern "C" {
#endif 

//#define GOURAUD_LINE_INVERT

//med i twister og voxel motor.
typedef struct
{
	Vector3D pos;
	Vector3D tar;
	float roll;
} Camera3D;



void textureliney(unsigned int *tb, unsigned int *tex, int px, int py1, int py2, int tx, int wy0, int wy1);
void line_gouraud(unsigned int *pixel, int x, int y0, int y1, int col, int col2);
float getfraction(float num);

#ifdef __cplusplus
   }
#endif 
