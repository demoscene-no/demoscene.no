#include "ypn_voxel.h"
#include "../commonheaders/ypn_common.h"

//void textureliney(unsigned int *tb, unsigned int *tex, int px, int py1, int py2, int tx)
void textureliney(unsigned int *tb, unsigned int *tex, int px, int py1, int py2, int tx, int wy0, int wy1)
{
	int x, y;
	int len, pyt;
	int lenw, wyt;

	len=abs(py2-py1);
	if (py1>py2)
	{
		pyt=py2;
		py2=py1;
		py1=pyt;
	}

	lenw=abs(wy0-wy1);
	if (wy0>wy1)
	{
		wyt=wy1;
		wy1=wy0;
		wy0=wyt;
	}
	
	float ty;
//	ty=200/(float)len;
//	ty=256/(float)len;
	ty=(float)(lenw+1)/(len+1);

	float wy;

//	float fy=0;
	wy=wy0;
//	for (y=0; y<len; y++, fy++)
	for (y=0; y<len; y++, wy+=ty)
	{
		if (((y+py1)<200) && ((y+py1)>=0))
//			tb[px+(y+py1)*320]=tex[((int)fy)*320+tx];
			tb[px+(y+py1)*320]=tex[((((int)wy)&0xff)<<8)+(tx&255)]; //wrapping
	}
}
//
//

//line_gouraud(sc, x, 200-1-ys, 200-1-ys2, col, col_old);

//#define GOURAUD_LINE_INVERT

void line_gouraud(unsigned int *pixel, int x, int y0, int y1, int col, int col2)
{
	int r,g,b;
	int cr,cg,cb;
	int r2,g2,b2;
	int temp,y,len=abs(y0-y1)+1;

	float fa=1.0/(float)len;
	float ff;

	r=(col&0xff0000)>>16;
	g=(col&0x00ff00)>>8;
	b=(col&0x0000ff);

	r2=(col2&0xff0000)>>16;
	g2=(col2&0x00ff00)>>8;
	b2=(col2&0x0000ff);

	if (y0>y1)
	{
		temp=y1;
		y1=y0;
		y0=temp;
	}

	ff=0;
	for (y=y0; y<y1; y++)
	{
#ifdef GOURAUD_LINE_INVERT
		cr=(int)((r*(ff))+(r2*(1-ff)));
		cg=(int)((g*(ff))+(g2*(1-ff)));
		cb=(int)((b*(ff))+(b2*(1-ff)));
#else
		cr=(int)((r*(1-ff))+(r2*(ff)));
		cg=(int)((g*(1-ff))+(g2*(ff)));
		cb=(int)((b*(1-ff))+(b2*(ff)));
#endif
		pixel[x+y*320]=RGB32(cr,cg,cb);;
		ff+=fa;
	}

}

float getfraction(float num)
{
	return (num-(float)((int)num));
}

