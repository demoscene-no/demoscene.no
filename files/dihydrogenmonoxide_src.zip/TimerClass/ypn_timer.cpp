/******************************************************************************
*
*	FIL:			YPN_TIMER.CPP
*
*	BESKRIVELSE:	Timer funksjoner hvor ftime er tiden.
*					G�r ogs� ann � lese av fps (frames per second).
*
*	TODO:			Lage timer-klasse.
*
*	SKREVET AV:		Rudi B. Stranden, linux-port: av Anders F. Pedersen
*
*******************************************************************************/
#include "ypn_timer.h"
#include <stdio.h>

#ifdef _WIN32
	#include <time.h>
	LARGE_INTEGER time_freq;
	LARGE_INTEGER time_start;
	LARGE_INTEGER time_cur;
#else
	#include <sys/time.h>
	struct timeval time_start;
	struct timeval time_cur;
	struct timeval time_prev;
#endif

// common variables
int fps_start=0;
int fps_end=0;
int fps_frames=0;

float ftime=0.0f;
float ftime_delta=0.0f;
float ftime_old=0.0f;

unsigned int itime;

float logTime[250];
int kpr;

void timer_reset()
{
	ftime=ftime_delta=ftime_old=0.0f;
	fps_start=fps_end=fps_frames=0;

#ifdef _WIN32
	QueryPerformanceFrequency(&time_freq);
	QueryPerformanceCounter(&time_start);
	fps_start=clock();
#else
	gettimeofday(&time_start, NULL);
	gettimeofday(&time_cur, NULL); // get the current time
	time_prev=time_cur;
#endif
}

void timer_update()
{
#ifdef _WIN32
	QueryPerformanceCounter(&time_cur);
	ftime_old=ftime;
	ftime=(float)((double)(time_cur.QuadPart - time_start.QuadPart) / (double)time_freq.QuadPart);
	ftime_delta=ftime - ftime_old;
	itime=(time_cur.QuadPart - time_start.QuadPart);
//	itime=(time_cur.QuadPart - time_start.QuadPart)/100000;
#else

	int diff_sec, diff_ms;
	float counter_ms;
	ftime_old=ftime;
	time_prev=time_cur;
	gettimeofday(&time_cur, NULL); // get the current time

	//hent differanse i sekunder
	diff_sec=time_cur.tv_sec - time_start.tv_sec;

	//p� samme sekund
	if(time_cur.tv_sec==time_start.tv_sec)
		diff_ms=time_cur.tv_usec - time_start.tv_usec;
	else
	//ikke p� samme sekund
		diff_ms=(1000000 - time_start.tv_usec) + time_cur.tv_usec;
	   //diff_ms=tval_current.tv_usec;

	//counter_ms=diff_ms;
	if(diff_sec>1)
		counter_ms=((diff_sec-1)*1000000) + diff_ms;
	else
		counter_ms=diff_ms;

	ftime=counter_ms / 1000000;
	ftime_delta=ftime-ftime_old;

#endif
	fps_frames++;
}

void timer_end(char *filename)
{
	#ifdef _WIN32
		fps_end=clock();

		#ifdef _LOG_FPS_
			char msg[32];
			FILE *fp=fopen(filename, "w");
			float fps=(float)(fps_frames*CLOCKS_PER_SEC) / (fps_end-fps_start);
			fprintf(fp, "%4.2f frames per second\n", fps);
			sprintf(msg,"%4.2f frames per second", fps); 
			MessageBox(NULL, msg,"YPN_TIMER", MB_ICONINFORMATION);
		#endif
	#endif
/*
   FILE *fp;
   if((fp=fopen(filename, "w"))==NULL) exit(1);
   fprintf(fp,"TIME: ");
   for(i=0; i<kpr; i++) {
      fprintf(fp, "%.2f, ", logTime[i]);
   }
   fprintf(fp, "\n\n");
*/
}

