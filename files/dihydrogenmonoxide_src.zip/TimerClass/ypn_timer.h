#ifndef __YPN_TIMER__
#define __YPN_TIMER__

#ifdef _WIN32
	#include <windows.h>
	extern LARGE_INTEGER time_freq;
	extern LARGE_INTEGER time_start;
	extern LARGE_INTEGER time_cur;
#else // assumes we have linux / freebsd / mac os x
	extern struct timeval time_start;
	extern struct timeval time_cur;
	extern struct timeval time_prev;
#endif


#ifdef __cplusplus
   extern "C" {
#endif

extern void timer_reset();
extern void timer_update();
extern void timer_end(char *filename);

// common variables
extern int fps_end;
extern int fps_start;
extern int fps_frames;

extern float ftime;
extern float ftime_delta;
extern float ftime_old;
extern unsigned int itime;

extern float logTime[250];
extern int kpr;

#ifdef __cplusplus
   }
#endif



#endif
