#include <windows.h>
#include "../commonheaders/ypn_common.h"
#include <ddraw.h>
#include "directdraw.h"

unsigned short synchronisation_counter=0;
float synchronisation_table[65536];

void synchronisation_logger(char *filename)
{
	int i;
	FILE *fp;
	fp=fopen(filename,"w");
	fprintf(fp,"antallet tastetrykk: %i\n",synchronisation_counter);
	for (i=0; i<synchronisation_counter; i++) fprintf(fp,"%.3f%s",synchronisation_table[i],(i<(synchronisation_counter-1))?", ":"");
	fclose(fp);
}

int init_windowclass(WNDPROC wndproc, HINSTANCE hinstance, const char *classname)
{
	WNDCLASS WndClass;
	ZeroMemory(&WndClass, sizeof(WndClass));

	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;

	//bg=d4d0c8;
//	WndClass.hbrBackground=(HBRUSH)GetStockObject(LTGRAY_BRUSH);
//	WndClass.hbrBackground=(HBRUSH)GetStockObject(GRAY_BRUSH);
	WndClass.hbrBackground=(HBRUSH)COLOR_WINDOW;

	WndClass.hCursor=LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon=LoadIcon(hinstance, NULL);
//	WndClass.hIcon=LoadIcon(hinstance, MAKEINTRESOURCE(IDI_ICON1));
	WndClass.hInstance=hinstance;
	WndClass.lpfnWndProc=wndproc;
	WndClass.lpszMenuName=NULL;
//	WndClass.lpszMenuName=MAKEINTRESOURCE(IDR_MAINMENU);
//	WndClass.lpszMenuName=MAKEINTRESOURCE(IDD_DIALOGBAR);
	WndClass.lpszClassName=classname;
	WndClass.style=CS_HREDRAW|CS_VREDRAW;

	if(!RegisterClass(&WndClass)) return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, unsigned int iMessage, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT paint;
	HRESULT hres;
	HGDIOBJ hObj;

	RECT rto, rfrom;
	POINT startpoint;
	
	HDC hdc=NULL;

	switch(iMessage)
	{

        case WM_KEYDOWN:
        {
			switch(wParam)
			{
				case VK_UP:
					synchronisation_counter++;
//					synchronisation_table[synchronisation_counter-1]=ftime;
				break;
			}

            // close on escape key
            if ((wParam&0xFF)!=27)
			{
				synchronisation_logger("synchronisation.ytx");
				break;
			}
        }

	case WM_CLOSE:
		exit(1);
		break;
		
	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, iMessage, wParam, lParam);
	}
	return 0;
}

LPDIRECTDRAW g_pDD;
LPDIRECTDRAWSURFACE g_pDDSPrimary;
LPDIRECTDRAWSURFACE g_pDDSBack;
LPDIRECTDRAWCLIPPER g_pDDClip;

int init_directdraw(HWND hwnd, int width, int height, int fullscreen)
{
	HRESULT hres;

//	hres=DirectDrawCreateEx(NULL, (VOID**)&g_lpDD, IID_IDirectDraw7, NULL);
//	if (hres!=DD_OK) return -1;

	hres=DirectDrawCreate(NULL, &g_pDD, NULL);
	if (hres!=DD_OK) return -1;

	if (fullscreen==WINDOWED)	hres=g_pDD->SetCooperativeLevel(hwnd, DDSCL_NORMAL);
	else
	if (fullscreen==FULLSCREEN) hres=g_pDD->SetCooperativeLevel(hwnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN);

	if (hres!=DD_OK) return -2;

	if (fullscreen==FULLSCREEN) hres=g_pDD->SetDisplayMode(width,height,32);
	if (hres!=DD_OK) return -3;

	return 0;
}

bool create_primarysurface(HWND hwnd, int width, int height)
{
	DDSURFACEDESC ddsd;
	DDSCAPS ddscaps;
	HRESULT hres;

	//create primary surface with 1 backbuffer
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS;
	ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;

	hres=g_pDD->CreateSurface(&ddsd, &g_pDDSPrimary, NULL);
	if (hres!=DD_OK)
	{
		g_pDD->Release();
		return (false);
	}

	ddsd.dwFlags=DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN;//|DDSCAPS_3DDEVICE;
	ddsd.dwWidth=width;
	ddsd.dwHeight=height;

	hres=g_pDD->CreateSurface(&ddsd, &g_pDDSBack, NULL);
	if (hres!=DD_OK)
	{
		g_pDD->Release();
		return (false);
	}

	g_pDD->CreateClipper(0, &g_pDDClip, NULL);
	g_pDDClip->SetHWnd(0, hwnd);
	g_pDDSPrimary->SetClipper(g_pDDClip);

	return true;
}
