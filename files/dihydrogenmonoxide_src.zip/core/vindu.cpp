// Define target system
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#endif

#include <windows.h>
#include <commctrl.h>
#include <math.h>
#include <wingdi.h>
#include "vindu.h"
#include "window.h"
#include "directdraw.h"
#include "resource.h"
#include "frame.h"
#include "primitiver.h"
#include "common.h"
#include "timer.h"
#pragma comment(lib,"COMCTL32.LIB")

#define RAND(c) (rand()%c)

bool drawing=FALSE;


//HFONT hFontNormal, hFontBold, hFontItalic;
//HWND hwndPrintButton;
//HWND hwndTestController;

HFONT MyCreateFont(int iWeight, DWORD dwItalic)
{
	return CreateFont(0,0,0,0,iWeight,dwItalic,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_DONTCARE,NULL);
}

void DrawText(HDC hdc, int xp)
{
	HGDIOBJ hObj;

	int yp=GetDeviceCaps(hdc, PHYSICALOFFSETY);
	int ys=GetDeviceCaps(hdc, PHYSICALHEIGHT) / GetSystemMetrics(SM_CYSCREEN);
	if (ys<=0) ys=1;
	xp+=GetDeviceCaps(hdc, PHYSICALOFFSETX);
	xp=0;
//	TextOut(hdc,xp,yp+5*ys,"Test1234..",6);
/*	hObj=SelectObject(hdc, hFontNormal);
	TextOut(hdc,xp,yp+30*ys,"Program..",9);
	SelectObject(hdc, hFontNormal);
	TextOut(hdc,xp,yp+55*ys,"Dette er kult!",14);
	SelectObject(hdc, hObj);*/
	TextOut(hdc,xp,yp+30*ys,"Program..",9);
}

int g_keys=0;

HWND hWndToolbar;
TBBUTTON buttons[10];
unsigned int *buffer;

//------------------------------------------------------------------------------------------------------------------
//INIT STUFF
//------------------------------------------------------------------------------------------------------------------
void init()
{
//	win_width=800;
//	win_height=600;
//	win_size=win_width*win_height;

	g_num_frames=32;
	g_num_lines=128;

//	frames=new Frames[g_num_frames];

//	frames=(Frames *)malloc(sizeof(Frames)*g_num_frames);
//	for (int i=0; i<g_num_frames; i++)
//		frames[i].lines=new Lines[g_num_lines];

//		frames[i].lines=(Lines *)malloc(sizeof(Lines)*g_num_lines);

//	frames=(Frames *)malloc(sizeof(int)*4*g_num_lines*g_num_frames);
/*	for (int i=0; i<g_num_frames; i++)
	{
//		for (int j=0; j<g_num_lines; j++)
		{
			frames[i].lines=(Lines *)malloc(sizeof(int)*4*g_num_lines);
		}
	}
*/
	g_cur_line=0;
	g_cur_frame=0;
}

static int carry;
static int index;
static int seed=0x12345;

float fm=0;
//------------------------------------------------------------------------------------------------------------------
//MAIN LOOP
//------------------------------------------------------------------------------------------------------------------
void process_loop(unsigned int *updatebuffer)
{
	int i, col;
	static int x0=0, y0=0, x1=0, y1=0;
	float speed=0.004;

	int bg_color,pen_color,pen_color2,prev_line_color;

	if (g_bakgrunn==0)
	{
		bg_color=0xffffff;
		pen_color=0;
		pen_color2=0xbfbfbf;
	}

	if (g_bakgrunn==1)
	{
		bg_color=0;
		pen_color2=0x575757;
		pen_color=0xffffff;
	}

	prev_line_color=0xff7f7f;
/*	for (i=0; i<win_size; i++)
	{
//		col=RAND(255);
//		col=rand()%255;
		col=seed;//
		col>>=3;
		col^=seed;
		carry=col&1;
//		col>>=1;//
		seed>>=1;
		seed|=(carry<<30);
//		col&=0xff;//
		buffer[i]=RGB(col,col,col);
	}*/

	for (i=0; i<win_size; i++) updatebuffer[i]=bg_color;

	//clear all
	if (file_new==1)
	{
		for (i=0; i<frames[0].cur_line; i++)
		{
			frames[0].lines[i].x0=0;
			frames[0].lines[i].y0=0;
			frames[0].lines[i].x1=0;
			frames[0].lines[i].y1=0;
			frames[1].lines[i].x0=0;
			frames[1].lines[i].y0=0;
			frames[1].lines[i].x1=0;
			frames[1].lines[i].y1=0;
		}
		frames[0].cur_line=0;
		frames[1].cur_line=0;
		g_cur_frame=0;
		file_new=0;
	}

	if (g_mouse_left_click)
	{
		g_mouse_left_click=0;
		frames[g_cur_frame].cur_line++;
	}

	if (g_mouse_left_press)
	{
		frames[g_cur_frame].lines[frames[g_cur_frame].cur_line-1].x1=g_mouse_x;
		frames[g_cur_frame].lines[frames[g_cur_frame].cur_line-1].y1=g_mouse_y;
	}
	else
	{
		frames[g_cur_frame].lines[frames[g_cur_frame].cur_line].x0=g_mouse_x;
		frames[g_cur_frame].lines[frames[g_cur_frame].cur_line].y0=g_mouse_y;
	}

	//show previous frames in gray
	if (vk_f4==1)	//stop
	{
		fm=0;
		if (g_cur_frame>0)
		{
			for (i=0; i<frames[g_cur_frame-1].cur_line; i++)
			{
				if (i!=frames[g_cur_frame].cur_line)
				line(updatebuffer,
					frames[g_cur_frame-1].lines[i].x0, frames[g_cur_frame-1].lines[i].y0,
					frames[g_cur_frame-1].lines[i].x1, frames[g_cur_frame-1].lines[i].y1, pen_color2);
				else
				line(updatebuffer,
					frames[g_cur_frame-1].lines[i].x0, frames[g_cur_frame-1].lines[i].y0,
					frames[g_cur_frame-1].lines[i].x1, frames[g_cur_frame-1].lines[i].y1, prev_line_color);
			}
		}

		for (i=0; i<frames[g_cur_frame].cur_line; i++)
		{
			line(updatebuffer,
				frames[g_cur_frame].lines[i].x0, frames[g_cur_frame].lines[i].y0,
				frames[g_cur_frame].lines[i].x1, frames[g_cur_frame].lines[i].y1, pen_color);
		}
	}

	if (vk_f5==1)	//play
	{
		g_cur_frame=0;
		fm+=speed;
		if (fm>=1) fm-=1;

		for (i=0; i<frames[g_cur_frame].cur_line; i++)
		{
			int mx0=frames[g_cur_frame].lines[i].x0*(1-fm)+frames[g_cur_frame+1].lines[i].x0*fm;
			int my0=frames[g_cur_frame].lines[i].y0*(1-fm)+frames[g_cur_frame+1].lines[i].y0*fm;
			int mx1=frames[g_cur_frame].lines[i].x1*(1-fm)+frames[g_cur_frame+1].lines[i].x1*fm;
			int my1=frames[g_cur_frame].lines[i].y1*(1-fm)+frames[g_cur_frame+1].lines[i].y1*fm;
			line(updatebuffer, mx0, my0, mx1, my1, pen_color);
		}
	}


	if (vk_right==1)
	{
		g_cur_frame++;
		vk_right=0;
	}

	if (vk_left==1)
	{
		g_cur_frame--;
		vk_left=0;
	}

	if (g_cur_frame<0) g_cur_frame=0;
	if (g_cur_frame>1) g_cur_frame=1;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	HWND hWnd;
	MSG Message;

	g_hInstance=hInstance;
/*
	INITCOMMONCONTROLSEX InitCtrlEx;
	InitCtrlEx.dwSize=sizeof(INITCOMMONCONTROLSEX);
	InitCtrlEx.dwICC=ICC_BAR_CLASSES;
	InitCommonControlsEx(&InitCtrlEx);
*/
	init_windowclass(WndProc, g_hInstance, g_classname);
	hWnd=CreateWindow(g_classname, g_wndname, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, app_width, app_height, NULL, NULL, g_hInstance, NULL);

	buffer=(unsigned int *)malloc(win_width*win_height*4);

	buttons[0].iBitmap=0;
	buttons[0].idCommand=IDM_FILE_NEW;
	buttons[0].fsState=TBSTATE_ENABLED;
	buttons[0].fsStyle=TBSTYLE_BUTTON;
	buttons[0].dwData=0L;
	buttons[0].iString=0;

	buttons[1].iBitmap=1;
	buttons[1].idCommand=IDM_FILE_OPEN;
//	buttons[1].fsState=TBSTATE_INDETERMINATE;
	buttons[1].fsState=TBSTATE_ENABLED;
	buttons[1].fsStyle=TBSTYLE_BUTTON;
	buttons[1].dwData=0L;
	buttons[1].iString=0;

	buttons[2].iBitmap=2;
	buttons[2].idCommand=IDM_FILE_SAVE;
//	buttons[2].fsState=TBSTATE_INDETERMINATE;
	buttons[2].fsState=TBSTATE_ENABLED;
	buttons[2].dwData=0L;
	buttons[2].iString=0;

	buttons[3].iBitmap=3;
	buttons[3].idCommand=IDM_FILE_SAVEAS;
//	buttons[3].fsState=TBSTATE_INDETERMINATE;
	buttons[3].fsState=TBSTATE_ENABLED;
	buttons[3].dwData=0L;
	buttons[3].iString=0;

	buttons[4].iBitmap=0;
	buttons[4].idCommand=0;
	buttons[4].fsState=TBSTATE_ENABLED;
	buttons[4].fsStyle=TBSTYLE_SEP;
	buttons[4].dwData=0L;
	buttons[4].iString=0;

	buttons[5].iBitmap=4;
	buttons[5].idCommand=ID_BAKGRUNN_HVIT;
	buttons[5].fsState=TBSTATE_ENABLED;
	buttons[5].fsStyle=TBSTYLE_BUTTON;
	buttons[5].dwData=0L;
	buttons[5].iString=0;

	buttons[6].iBitmap=5;
	buttons[6].idCommand=ID_BAKGRUNN_SORT;
	buttons[6].fsState=TBSTATE_ENABLED;
	buttons[6].fsStyle=TBSTYLE_BUTTON;
	buttons[6].dwData=0L;
	buttons[6].iString=0;

	buttons[7].iBitmap=0;
	buttons[7].idCommand=0;
	buttons[7].fsState=TBSTATE_ENABLED;
	buttons[7].fsStyle=TBSTYLE_SEP;
	buttons[7].dwData=0L;
	buttons[7].iString=0;

	buttons[8].iBitmap=6;
	buttons[8].idCommand=IDM_FRAME_STOP;
	buttons[8].fsState=TBSTATE_ENABLED;
	buttons[8].fsStyle=TBSTYLE_BUTTON|TBSTYLE_GROUP|TBSTYLE_CHECK;
	buttons[8].dwData=0L;
	buttons[8].iString=0;

	buttons[9].iBitmap=7;
	buttons[9].idCommand=IDM_FRAME_PLAY;
	buttons[9].fsState=TBSTATE_ENABLED;
	buttons[9].fsStyle=TBSTYLE_BUTTON|TBSTYLE_GROUP|TBSTYLE_CHECK;
	buttons[9].dwData=0L;
	buttons[9].iString=0;

//	hWndToolbar=CreateToolbarEx(hWnd, WS_VISIBLE|WS_CHILD|WS_BORDER|TBSTYLE_FLAT,
	hWndToolbar=CreateToolbarEx(hWnd, WS_VISIBLE|WS_CHILD|TBSTYLE_FLAT,
//	hWndToolbar=CreateToolbarEx(hWnd, WS_VISIBLE|WS_CHILD|WS_BORDER,
		IDB_STANDARD, 10, g_hInstance, IDB_STANDARD, buttons, 10, 16, 16, 16, 16, sizeof(TBBUTTON));

	SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_CHECKED|TBSTATE_ENABLED);

//	hFontNormal=MyCreateFont(FW_NORMAL,FALSE);
//	hFontBold=MyCreateFont(FW_BLACK,FALSE);
//	hFontItalic=MyCreateFont(FW_NORMAL,TRUE);

//	hwndPrintButton=CreateWindow("BUTTON", "Print", WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
//		10, 80, 100, 25, hWnd, (HMENU)(100), hInstance, NULL);

//	hwndTestController=CreateWindow("BUTTON", "taha", WS_CHILD|WS_VISIBLE|BS_FLAT|BS_BITMAP,
//		115, 80, 100, 25, hWnd, (HMENU)(101), hInstance, NULL);
//	hwndTestController=CreateWindow("BUTTON", "taha", WS_CHILD|WS_VISIBLE|BS_PUSHLIKE,
//		115, 80, 100, 25, hWnd, (HMENU)(101), hInstance, NULL);

//	PlotPixel(

	ShowWindow(hWnd, nShowCmd);
	g_hWnd=hWnd;

	init_directdraw(g_hWnd);
	create_primarysurface(g_hWnd);

	UpdateWindow(g_hWnd);

	//modal dialog box
//	int success=DialogBox(g_hInstance, MAKEINTRESOURCE(IDD_DIALOGBAR), g_hWnd, DialogProc);

	//modeless dialog box
//	HWND hDialog=CreateDialog(g_hInstance, MAKEINTRESOURCE(IDD_DIALOGBAR), g_hWnd, DialogProc);
//	if (hDialog==NULL) return 0;
//	ShowWindow(hDialog, SW_SHOW);


//	BOOL ret;
//	while((ret=GetMessage(&Message,0,0,0))!=0)
//	while(GetMessage(&Message,g_hWnd,0,0))

	init();

	fps_start=clock();

	while(GetMessage(&Message,NULL,0,0))
	{
//		if (ret==-1) break;
//		else
//		{
			TranslateMessage(&Message);
			DispatchMessage(&Message);
//		}
	}
//	MessageBox(NULL, "hei", "tittel", MB_OK);
//	return Message.wParam;
	return 0;
}

int xfrom, yfrom;
int xto, yto;
int b;

LRESULT CALLBACK WndProc(HWND hWnd, unsigned int iMessage, WPARAM wParam, LPARAM lParam)
{
	HWND hButton, hCombo, hEdit, hList, hScroll, hStatic;

	HMENU hSysMenu;
	PAINTSTRUCT paint;
	COLORREF color=RGB(255,25,2);
	HRESULT hres;
		static int pf=0;
	HGDIOBJ hObj;

	RECT rto, rfrom;
//	POINT startpoint={0,29};
	POINT startpoint;
/*	ClientToScreen(hWnd, &rto);
	rect.left=0+startpoint.x;
	rect.top=0+startpoint.y;
	rect.right=win_width+startpoint.x;
	rect.bottom=win_height+startpoint.y;
*/
	short xp,yp;
	static int p=0;
	static int xpos=5;

	HDC hdc=NULL;

	static float f=0;

	switch(iMessage)
	{
	case WM_CREATE:
		g_cursor=LoadCursor(g_hInstance, MAKEINTRESOURCE(IDC_CURSOR2));
		SetClassLong(hWnd, GCL_HCURSOR, (LONG)g_cursor);

//		hButton=CreateWindowEx(NULL, "Button", "push!", WS_BORDER|WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
//			220,2,48,24, hWnd, NULL, g_hInstance, NULL);

//		hCombo=CreateWindowEx(NULL, "ComboBox", "activator", WS_BORDER|WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST,
//			220,2,100,100, hWnd, NULL, g_hInstance, NULL);

//		hEdit=CreateWindowEx(NULL, "Edit", "activator", WS_BORDER|WS_CHILD|WS_VISIBLE,
//			220,3,100,24, hWnd, NULL, g_hInstance, NULL);

//		hList=CreateWindowEx(NULL, "ListBox", "db db db", WS_BORDER|WS_CHILD|WS_VISIBLE,
//			220,3,100,24, hWnd, NULL, g_hInstance, NULL);

//		hScroll=CreateWindowEx(NULL, "ScrollBar", "", WS_BORDER|WS_CHILD|WS_VISIBLE|SBS_VERT,
//			220,0,16,30, hWnd, NULL, g_hInstance, NULL);

//		hStatic=CreateWindowEx(NULL, "Static", "", WS_BORDER|WS_CHILD|WS_VISIBLE|SS_BLACKRECT,
//			220,2,100,20, hWnd, NULL, g_hInstance, NULL);


//		hSysMenu=GetSystemMenu(hWnd, FALSE);
//		RemoveMenu(hSysMenu, 1, MF_BYPOSITION);
//		return 0;
		break;

	case WM_INITDIALOG:
		break;

	case WM_ACTIVATE:
//		SendMessage(hWnd, WM_SETTEXT, 0, (LPARAM)"Generator - Untitled");
		break;

/*
	case WM_MOVE:
		hdc=GetDC(hWnd);
		DrawText(hdc, xpos);
		ReleaseDC(hWnd, hdc);
		break;*/

/*	case WM_SIZE:
		if (wParam!=SIZE_MAXHIDE && wParam!=SIZE_MINIMIZED)
		{
			xpos=LOWORD(lParam)-295;
			if (xpos<5) xpos=5;
			hdc=GetDC(hWnd);
			DrawText(hdc, xpos);
			ReleaseDC(hWnd, hdc);
		}
		break;*/

	case WM_KEYDOWN:
		switch(wParam)
		{
		case VK_RIGHT:
			vk_right=1;
			break;

		case VK_LEFT:
			vk_left=1;
			break;

/*		case VK_F1:
			vk_f1=1;
			break;*/

		case VK_F4:
			vk_f4=1;
			vk_f5=0;
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_CHECKED|TBSTATE_ENABLED);
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_PLAY, TBSTATE_ENABLED);
			break;

		case VK_F5:
			vk_f5=1;
			vk_f4=0;
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_ENABLED);
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_PLAY, TBSTATE_CHECKED|TBSTATE_ENABLED);
			break;

/*		case 'p':
			vk_p=1;
			break;*/
		}
		break;

	case WM_LBUTTONDOWN:
//		hdc=GetDC(hWnd);
//		p++;

		g_mouse_left_click=1;
		g_mouse_left_press=1;
		drawing=TRUE;
//		xfrom=LOWORD(lParam);
//		yfrom=HIWORD(lParam);
//		MoveToEx(hdc, xfrom, yfrom, NULL);

//		ReleaseDC(hWnd, hdc);
//		return 0;
		break;

	case WM_MOUSEMOVE:
//		hdc=GetDC(hWnd);

		g_mouse_x=LOWORD(lParam);
		g_mouse_y=HIWORD(lParam) - 29;

/*		if (drawing==TRUE)
		{
			xto=LOWORD(lParam);
			yto=HIWORD(lParam);
			MoveToEx(hdc, xfrom, yfrom, NULL);
			LineTo(hdc, xto, yto);

		}*/
//		ReleaseDC(hWnd, hdc);
		break;

	case WM_LBUTTONUP:
//		hdc=GetDC(hWnd);
		g_mouse_left_press=0;
		drawing=FALSE;
//		ReleaseDC(hWnd, hdc);
		break;

	case WM_PAINT:
/*		if (pf<10)
		{
//		hdc=BeginPaint(hWnd, &paint);
		if (hdc!=NULL) EndPaint(hWnd, &paint);
		pf++;
		}*/

		DDSURFACEDESC ddsd;
		ddsd.dwSize=sizeof(ddsd);

		g_pDDSBack->Lock(0, &ddsd, DDLOCK_WAIT, 0);
		buffer=(unsigned int *)ddsd.lpSurface;
		process_loop(buffer);
		g_pDDSBack->Unlock(ddsd.lpSurface);

		startpoint.x=0;
		startpoint.y=29;
		ClientToScreen(hWnd, &startpoint);

//		GetClientRect(hWnd, &rto);
		rto.left=startpoint.x;
		rto.right=startpoint.x+win_width;
		rto.top=startpoint.y;
		rto.bottom=startpoint.y+win_height;

		SetRect(&rfrom,0,0,win_width,win_height);

//		DDBLTFX ddbltfx;
//		ddbltfx.dwSize=sizeof(ddbltfx);
//		ddbltfx.dwFillColor=rand()%(255*255*255);//0x72272f;
//		g_pDDSBack->Blt(&rfrom, NULL, NULL, DDBLT_WAIT|DDBLT_COLORFILL, &ddbltfx);

		hres=g_pDDSPrimary->Blt(&rto, g_pDDSBack, &rfrom, DDBLT_WAIT, NULL);
//		IDirectDrawSurface_Blt(g_pDDSPrimary, &rto, g_pDDSBack, &rfrom, DDBLT_WAIT, 0);
//		if (hres==DD_OK) return DefWindowProc(hWnd, iMessage, wParam, lParam);

//		IDirectDrawSurface_Flip(g_pDDSPrimary,0,DDFLIP_WAIT);
/*
		// Check the primary surface
		if (g_pDDSPrimary)
		{
			if (g_pDDSPrimary->IsLost() == DDERR_SURFACELOST)
			g_pDDSPrimary->Restore();
		}
		// Check the back buffer
		if (g_pDDSBack)
		{
			if (g_pDDSBack->IsLost() == DDERR_SURFACELOST)
			g_pDDSBack->Restore();
		}*/

//		PostMessage(hWndToolbar, msg, wparam, lparam);
//		SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_CHECKED|TBSTATE_ENABLED);
		UpdateWindow(hWndToolbar); //n�r vi trykker p� knappene trengs den � oppdateres.


		//show fps
/*		fps_end=clock();
		fps=(float)(fps_frames*CLOCKS_PER_SEC) / (fps_end-fps_start);
		memset(str, 0, 10);
		memset(stri, 0, 4);
		itoa((int)fps, stri, 10);
		strncpy(str, "fps: ",5);
		strcat(str, stri);
		SetWindowText(hWnd, str);
		fps_frames++;*/

		break;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDM_FRAME_STOP: //stop
			vk_f4=1;
			vk_f5=0;
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_CHECKED|TBSTATE_ENABLED);
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_PLAY, TBSTATE_ENABLED);
			break;

		case IDM_FRAME_PLAY: //play
			vk_f4=0;
			vk_f5=1;
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_STOP, TBSTATE_ENABLED);
			SendMessage(hWndToolbar, TB_SETSTATE, IDM_FRAME_PLAY, TBSTATE_CHECKED|TBSTATE_ENABLED);
			break;

		case IDM_FILE_NEW:
			vk_f4=1;
			vk_f5=0;
			file_new=1;
			break;

		case IDM_FILE_OPEN:
			char dlgStr[20];
			if(GetDlgItemText(hEdit, IDD_EDITBOX, (LPTSTR)dlgStr, 20)) 
				MessageBox(NULL, dlgStr, "Text Message", MB_OK);
				return TRUE; 
			break;

		case IDM_FILE_EXIT:
			PostQuitMessage(WM_QUIT);
			break;

		case ID_BAKGRUNN_HVIT:
			g_bakgrunn=0;
			g_cursor=LoadCursor(g_hInstance, MAKEINTRESOURCE(IDC_CURSOR2));
			SetClassLong(hWnd, GCL_HCURSOR, (LONG)g_cursor);
			break;

		case ID_BAKGRUNN_SORT:
			g_bakgrunn=1;
			g_cursor=LoadCursor(g_hInstance, MAKEINTRESOURCE(IDC_CURSOR1));
			SetClassLong(hWnd, GCL_HCURSOR, (LONG)g_cursor);
			break;

		case ID_HJELP_OMANIDEMO:
			MessageBox(NULL, "Programmert av: Rudi B. Stranden", "Om Anidemo", MB_OK|MB_SERVICE_NOTIFICATION|MB_ICONINFORMATION);
			break;
		};
		return 0;

	case WM_CLOSE:
		PostQuitMessage(0);
		break;
		
	case WM_DESTROY:
//		DeleteObject(hFontBold);
//		DeleteObject(hFontItalic);
		PostQuitMessage(WM_QUIT);
//		DestroyWindow(hwndPrintButton);
//		DestroyWindow(hwndTestController);
		break;
//		return 0;

	default:
		return DefWindowProc(hWnd, iMessage, wParam, lParam);
	}
	return 0;
//	return TRUE;
}

BOOL CALLBACK DialogProc(HWND dlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
			return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDOK: 
					{
						char dlgStr[20];
						if(GetDlgItemText(dlg, IDD_EDITBOX, (LPTSTR)dlgStr, 20)) 
							MessageBox(dlg, dlgStr, "Text Message", MB_OK);
						return TRUE; 
					}
					return TRUE;
				} 
				return FALSE;

		case WM_CLOSE:
			EndDialog(dlg, IDOK);                 
		return TRUE;
	}
	return FALSE;
}