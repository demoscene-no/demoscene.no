#pragma comment(lib, "ddraw.lib")

int init_windowclass(WNDPROC wndproc, HINSTANCE hinstance, const char *classname);
LRESULT CALLBACK WndProc(HWND hWnd, unsigned int iMessage, WPARAM wParam, LPARAM lParam);

//globals
HWND g_hwnd;
HDC g_hdc;
HINSTANCE g_hInstance;
const char *g_classname="windowclass";
const char *g_wndname="window";

#include <ddraw.h>

extern LPDIRECTDRAW g_pDD;
extern LPDIRECTDRAWSURFACE g_pDDSPrimary;
extern LPDIRECTDRAWSURFACE g_pDDSBack;
extern LPDIRECTDRAWCLIPPER g_pDDClip;

int init_directdraw(HWND hwnd, int width, int height, int fullscreen);
bool create_primarysurface(HWND hwnd, int width, int height);
