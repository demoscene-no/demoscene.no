#include <math.h>

extern unsigned int win_width;
extern unsigned int win_height;
extern unsigned int win_size;
