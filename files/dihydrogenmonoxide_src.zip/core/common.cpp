#include "common.h"

unsigned int win_width=800;
unsigned int win_height=600;
unsigned int win_size=win_width*win_height;
