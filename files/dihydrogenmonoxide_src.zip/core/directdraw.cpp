#include "common.h"
#include "directdraw.h"

LPDIRECTDRAW g_pDD;
LPDIRECTDRAWSURFACE g_pDDSPrimary;
LPDIRECTDRAWSURFACE g_pDDSBack;
LPDIRECTDRAWCLIPPER g_pDDClip;

int init_directdraw(HWND hwnd)
{
	HRESULT hres;

//	hres=DirectDrawCreateEx(NULL, (VOID**)&g_lpDD, IID_IDirectDraw7, NULL);
//	if (hres!=DD_OK) return -1;

	hres=DirectDrawCreate(NULL, &g_pDD, NULL);
	if (hres!=DD_OK) return -1;

//	hres=g_lpDD->SetCooperativeLevel(hwnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN);
	hres=g_pDD->SetCooperativeLevel(hwnd, DDSCL_NORMAL);
	if (hres!=DD_OK) return -2;

//	hres=g_lpDD->SetDisplayMode(640,480,16,0,0);
//	if (hres!=DD_OK) return -3;

	return 0;
}

bool create_primarysurface(HWND hwnd)
{
	DDSURFACEDESC ddsd;
	DDSCAPS ddscaps;
	HRESULT hres;

	//create primary surface with 1 backbuffer
	memset(&ddsd,0,sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS;
	ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE;

	hres=g_pDD->CreateSurface(&ddsd, &g_pDDSPrimary, NULL);
	if (hres!=DD_OK)
	{
		g_pDD->Release();
		return (false);
	}

	ddsd.dwFlags=DDSD_CAPS|DDSD_WIDTH|DDSD_HEIGHT;
	ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN;//|DDSCAPS_3DDEVICE;
	ddsd.dwWidth=win_width;
	ddsd.dwHeight=win_height;

	hres=g_pDD->CreateSurface(&ddsd, &g_pDDSBack, NULL);
	if (hres!=DD_OK)
	{
		g_pDD->Release();
		return (false);
	}

	g_pDD->CreateClipper(0, &g_pDDClip, NULL);
	g_pDDClip->SetHWnd(0, hwnd);
	g_pDDSPrimary->SetClipper(g_pDDClip);

	return true;
}
/*
IDirectDrawSurface * DDLoadBitmap(IDirectDraw *pdd, LPCSTR szBitmap)
{
	HBITMAP hbm;
	BITMAP bm;

	hbm = (HBITMAP)LoadImage(NULL, szBitmap, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE|LR_CREATEDIBSECTION);
	if (hbm == NULL) return NULL;

	GetObject(hbm, sizeof(bm), &bm); // get size of bitmap

	//create a DirectDrawSurface for this bitmap
	//source to function CreateOffScreenSurface() follows immediately

	DDSURFACEDESC ddsd;
	IDirectDrawSurface *pdds;

	ZeroMemory(&ddsd, sizeof(ddsd));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwWidth=width;
	ddsd.dwHeight=height;

	if (pdd->CreateSurface(&ddsd, &pdds, NULL)!=DD_OK) return NULL;
	
	if (pdds) DDCopyBitmap(pdds, hbm, bm.bmWidth, bm.bmHeight);
	DeleteObject(hbm);

	return pdds;
}
*/
