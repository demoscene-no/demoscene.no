#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

extern int wnd_open(char *title,int width,int height,int fullscreen);
extern int wnd_update(unsigned int *pixel);	//software
extern int wnd_update();	//opengl

//globals
//int g_type;	//opengl, d3d or software?

extern HGLRC g_hrc;

