#include "wndogl.h"

#include "../../commonheaders/ypn_common.h"
#include "../window.h"

#define WIN32_LEAN_AND_MEAN
#include "ddraw.h"

static HWND hwnd;
HGLRC g_hrc;

int wnd_open(char *title,int width,int height,int fullscreen)
{
	DWORD wnd_style;

	init_windowclass(WndProc, g_hInstance, g_classname);
	if (fullscreen==WINDOWED) wnd_style=WS_OVERLAPPEDWINDOW;
	else
	if (fullscreen==FULLSCREEN)
	{
		wnd_style=WS_POPUP;
//		wnd_style=WS_POPUP | WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

#ifdef OPENGL
		DEVMODE dmSettings;	
		memset(&dmSettings,0,sizeof(dmSettings));
		if(!EnumDisplaySettings(NULL,ENUM_CURRENT_SETTINGS,&dmSettings))
		{
			MessageBox(HWND_DESKTOP, "Unable to get displaysettings", "Error", MB_OK);
			return 0;
		}
		dmSettings.dmPelsWidth=width;
		dmSettings.dmPelsHeight=height;
		dmSettings.dmFields=DM_BITSPERPEL | DM_PELSWIDTH | DM_PELSHEIGHT;
		dmSettings.dmBitsPerPel=32;
		
		// Bytter til fullscreen med settings fra over
		int result = ChangeDisplaySettings(&dmSettings,CDS_FULLSCREEN);
		if (result !=DISP_CHANGE_SUCCESSFUL)	
		{ 
			MessageBox(HWND_DESKTOP, "Unable to switch to fullscreen", "GLWindow::GLWindow", MB_OK);
			return 0;
		}
#endif
		ShowCursor(FALSE);
	}

	hwnd=CreateWindow(g_classname, g_wndname, wnd_style,
		CW_USEDEFAULT, CW_USEDEFAULT,
		width+GetSystemMetrics(SM_CYFRAME)*2,
		height+GetSystemMetrics(SM_CXFRAME)*2+GetSystemMetrics(SM_CYCAPTION),
		NULL, NULL, g_hInstance, NULL);

#ifdef OPENGL	
	g_hdc=GetDC(hwnd);

	// Setter opp pixelformatdescriptor (info om fargedybde, buffere osv)
	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),	// size of structure.
		1,								// always 1.
		PFD_DRAW_TO_WINDOW |			// support window
		PFD_SUPPORT_OPENGL |			// support OpenGl
		PFD_DOUBLEBUFFER,				// support double buffering
		PFD_TYPE_RGBA,					// support RGBA
		32,								// 32 bit color mode
		0, 0, 0, 0, 0, 0,				// ignore color bits
		0,								// no alpha buffer
		0,								// ignore shift bit
		0,								// no accumulation buffer
		0, 0, 0, 0,						// ignore accumulation bits.
		16,								// number of depth buffer bits.
		8,								// number of stencil buffer bits.
		0,								// 0 means no auxiliary buffer
		PFD_MAIN_PLANE,					// The main drawing plane
		0,								// this is reserved
		0, 0, 0 };						// layer masks ignored.

	int nPixelFormat=NULL;
	nPixelFormat=ChoosePixelFormat(g_hdc, &pfd);
	if (nPixelFormat==NULL)
	{
		MessageBox(hwnd, "Unable to find a suitable pixelformat", "Error", MB_OK);
		return 0;
	}

	if (!SetPixelFormat(g_hdc, nPixelFormat, &pfd))
	{		
		MessageBox(hwnd, "Unable to set pixel format", "Error", MB_OK);
		return 0;
	}

	g_hrc=wglCreateContext(g_hdc);
	if (g_hrc==NULL)
	{
		MessageBox(hwnd, "Unable to create HRC", "Error", MB_OK);
		return 0;
	}

	if (!wglMakeCurrent(g_hdc, g_hrc))
	{
		MessageBox(hwnd, "Unable to select HRC", "Error", MB_OK);
		return 0;
	}
#endif

	ShowWindow(hwnd, SW_SHOW);
//	ShowWindow(hwnd, SW_SHOWNORMAL);
	g_hwnd=hwnd;

#ifdef SOFTWARE
	init_directdraw(g_hwnd, width, height, fullscreen);
	create_primarysurface(g_hwnd, width, height);
#endif

	UpdateWindow(g_hwnd);

#ifdef OPENGL
//	SetForegroundWindow(hwnd);
//	SetFocus(hwnd);
	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 1.0f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_CULL_FACE);
#endif

    // success
    return 1;
}

int wnd_update(unsigned int *pixel)
{
	RECT rto, rfrom;
	POINT startpoint;
	HRESULT hres;
	DDSURFACEDESC ddsd;
	MSG msg;

	PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE);
	if(msg.message==WM_QUIT) return 0;

	TranslateMessage(&msg);
	DispatchMessage(&msg);

	ddsd.dwSize=sizeof(ddsd);

	g_pDDSBack->Lock(0, &ddsd, DDLOCK_WAIT, 0);
	unsigned int *buffer=(unsigned int *)ddsd.lpSurface;
	for (int i=0; i<640*480; i++) *buffer++=*pixel++;
	g_pDDSBack->Unlock(ddsd.lpSurface);

	startpoint.x=0;
	startpoint.y=0;//29;
	ClientToScreen(hwnd, &startpoint);

	GetClientRect(hwnd, &rto);
	rto.left=startpoint.x;
	rto.right=startpoint.x+640;
	rto.top=startpoint.y;
	rto.bottom=startpoint.y+480;//+GetSystemMetrics(SM_CYCAPTION);

	SetRect(&rfrom,0,0,640,480);
	hres=g_pDDSPrimary->Blt(&rto, g_pDDSBack, &rfrom, DDBLT_WAIT, NULL);
	return 1;
}

int wnd_update()
{
	MSG msg;

	PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE);
	if(msg.message==WM_QUIT) return 0;
	glFlush();
	SwapBuffers(g_hdc);

	TranslateMessage(&msg);
	DispatchMessage(&msg);

	return 1;
}
