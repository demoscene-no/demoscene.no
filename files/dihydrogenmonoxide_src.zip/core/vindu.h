LRESULT CALLBACK WndProc(HWND hWnd, unsigned int iMessage, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DialogProc(HWND dlg, UINT msg, WPARAM wParam, LPARAM lParam);

//
//global shit
//

const char *g_classname="windowclass";
//const char *g_wndname="Vindu #1";
const char *g_wndname="Anidemo";

HWND g_hWnd;
HINSTANCE g_hInstance;

//int app_width=800;
//int app_height=600;
int app_width=800;//1024;
int app_height=768;

HCURSOR g_cursor;

int g_mouse_x, g_mouse_y;
int g_mouse_left_press;
int g_mouse_left_click;
int g_num_frames;
int g_num_lines;
int g_cur_line;
int g_cur_frame;

//keys
int vk_left=0, vk_right=0, vk_up=0, vk_down=0;
int vk_p=0;
int vk_f1=0;
int vk_f4=1;	//stop
int vk_f5=0;	//play

//buttons
int file_new=0;

int g_bakgrunn=0;
//
//
//
