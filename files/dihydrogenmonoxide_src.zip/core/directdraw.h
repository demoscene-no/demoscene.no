#include <ddraw.h>

extern LPDIRECTDRAW g_pDD;
extern LPDIRECTDRAWSURFACE g_pDDSPrimary;
extern LPDIRECTDRAWSURFACE g_pDDSBack;
extern LPDIRECTDRAWCLIPPER g_pDDClip;

int init_directdraw(HWND hwnd);
bool create_primarysurface(HWND hwnd);
