//
//This is a part of the Yaphan DemoEngine Layer system.
//

#ifndef _common
#define _common

#if defined(_WIN32)
	#include <windows.h>
//	#include "../core/win/tinyptc.h"
	#include "../core/ogl/wndogl.h"
#else
	#include "../core/linux/tinyptc.h"
#endif

#include "../trianglefillers/ypn_guru_inc.h"
#include "../primitives/ypn_primitives.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//----------------------------------------------------------------------------------------------------

#define SOFTWARE
//#define OPENGL

//----------------------------------------------------------------------------------------------------
#define WIDTH 320
//#define HEIGHT 240
#define HEIGHT 200

//#define WIDTH 512
//#define HEIGHT 384

//#define WIDTH 640
//#define HEIGHT 400
//#define HEIGHT 480

//#define WIDTH 800
//#define HEIGHT 600

/*
#define WIDTH 256
#define HEIGHT 256
*/

#define SIZE WIDTH*HEIGHT
#define WIDTH_HALF WIDTH/2
#define HEIGHT_HALF HEIGHT/2

//----------------------------------------------------------------------------------------------------
//
//
//#define _LOADING_SCREEN_

//
//----------------------------------------------
//please uncomment the libraries we want to use.
//----------------------------------------------
//
#define _PNG_LIB_
#define _BASS_LIB_
//#define _MINIFMOD_LIB_
//
//----------------------------------------------
//please uncomment the functions we want to use.
//----------------------------------------------
//
//#define _LOG_FPS_
//
//----------------------------------------------

#define RGB32(r,g,b) ((r<<16)|(g<<8)|b)
#define ARGB32(a,r,g,b) ((a<<24)|(r<<16)|(g<<8)|b)
#define RGBA32(r,g,b,a) ((r<<24)|(g<<16)|(b<<8)|a)
#define R_(c) (c&0xff0000)
#define G_(c) (c&0xff00)
#define B_(c) (c&0xff)
#define RB_(c) (c&0xff00ff)

#define R(c) (R_(c)>>16)
#define G(c) (G_(c)>>8)
#define B(c) (B_(c))
#define RB(c) (c&0xff00ff)

#define SQR(a) ((a)*(a))
#define M_PI 3.141592654f
#define M_2PI M_PI*2
#define M_PI2 M_PI/2
#define M_PI4 M_PI/4
#define M_PI6 M_PI/6
#define SCALEFACTOR (57.2957795130823 * 256/360)  //eq.->(180/phi*256/360)
#define ROUND(f) (floor(f) + 0.5)
#define DEG2RAD(f) (f*(M_2PI/360))
#define SQR(x) ((x)*(x))	//mul floats right
//#define SQR(x) (x*x)
#define SGN(a) ((a>0) ? 1:-1)
#define EPSILON 1.0E-6 

//float spline_cos(float val1, float val2, float t) { float t2=(1-cos(t*M_PI))/2; return (val1*(1-t2)+val2*t2); }

//Channel definitions
#define CHANNEL_BLUE	0
#define CHANNEL_GREEN	1
#define CHANNEL_RED		2
#define CHANNEL_ALPHA	3
//#define CHANNEL_AVERAGE	4	//not done yet

//

#define WINDOWED 0
#define FULLSCREEN 1
//

typedef unsigned char byte;		//1 byte
typedef unsigned char uchar;	//1 byte
typedef unsigned short ushort;	//2 bytes
typedef unsigned int uint;		//4 bytes
typedef unsigned int dword;		//4 bytes
typedef unsigned long ulong;	//4 bytes

extern void wrapByte(int *c);
extern uchar getRed(uint color);
extern uchar getGreen(uint color);
extern uchar getBlue(uint color);
extern uchar getAlpha(uint color);
extern int visible(int x, int y);
extern int visible(int x, int y, int width, int height);
extern float noise1d(int x);
extern float noise2d(int x, int y);
extern void clamp(int *i, int len);
extern void clamp(float i);

struct MinMax
{
	int min, max;
};

#endif

