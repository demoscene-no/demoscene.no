#include <windows.h>
#include "ypn_fixedpoint.h"

long fixed_mul(long a, long b)
{
	return MulDiv(a, b, 65536);
}

long fixed_div(long a, long b)
{
	return MulDiv(a, 65536, b);
}
