//================================
//16.16 fixed point (2^16 = 65536)
//================================
//
//addisjon og substraksjon kan fullf�res med n�yaktighet.
//multiplikasjon og divisjon derimot vil medf�re presisjonstap.

//#ifndef _fixedpoint
//#define _fixedpoint

typedef long fixedp;
#define ITOFIX(x)	((x)<<16)
#define DTOFIX(x)	((long)(x*65536.0+0.5))
#define FIXTOI(x)	((x)>>16)
#define FIXTOD(x)	(((double)x)/65536.0)
#define ROUND_FIXTOI(x)	(((x)+0x8000)>>16)

long fixed_mul(long a, long b);
long fixed_div(long a, long b);

//#endif
//================================

