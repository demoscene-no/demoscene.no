#include "ypn_common.h"

void wrapByte(int *c)
{
	int t=*c;
	t>=255?t=255:t<0?t=0:0;
	*c=t;
};

unsigned char getRed(unsigned int color) { return ((color&0xff0000)>>16); }
unsigned char getGreen(unsigned int color) { return ((color&0xff00)>>8); }
unsigned char getBlue(unsigned int color) { return ((color&0xff)); }
unsigned char getAlpha(unsigned int color) { return ((color&0xff000000)>>24); }

int visible(int x, int y)
{
	return ((x>=0 && x<WIDTH) && (y>=0 && y<HEIGHT));
}

int visible(int x, int y, int width, int height)
{
	return ((x>=0 && x<width) && (y>=0 && y<height));
}

float noise1d(int x)
{
	x=(x<<13)^x;
	return (float)(1.0-((x*(x*x*15731+789221)+1376312589)&0x7fffffff)/1073741824.0);    
}

float noise2d(int x, int y)
{
	int n=x+y*57;
	n=(n<<13)^n;

	return (float)(1.0-((n*(n*n*15731+789221)+1376312589)&0x7fffffff)/1073741824.0);
}

void clamp(float i)
{
	i=i<0?0:i>1?1:i;
}

void clamp(int *i, int len)
{
	*i=*i<0?0:*i>len?len:*i;
}
