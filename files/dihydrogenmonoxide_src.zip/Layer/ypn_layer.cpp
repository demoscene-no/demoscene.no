#include "ypn_layer.h"
#include <math.h>
#include "../commonheaders/ypn_fixedpoint.h"
#include "../trianglefillers/ypn_flatfillers.h"

class Object;

Layer::Layer()
{
	buffer=0;
	num_buffer=0;
	strings=0;
	stringCount=0;
	particleset=0;
	num_particleset=0;
	maskMode=MASK_ALPHACHANNEL;
}

Layer::Layer(int _width, int _height)
{
	buffer=0;
	num_buffer=0;
	strings=0;
	stringCount=0;
	particleset=0;
	num_particleset=0;
	maskMode=MASK_ALPHACHANNEL;

	width=_width;
	height=_height;
	size=width*height;

	mainbuffer.Init(width, height);
	blackbuffer.Init(width, height, 0);
	whitebuffer.Init(width, height, 0xffffff);
	tempbuffer.Init(width, height, 0);
}

Layer::Layer(int _width, int _height, int color)
{
	buffer=0;
	num_buffer=0;
	strings=0;
	stringCount=0;
	particleset=0;
	num_particleset=0;
	maskMode=MASK_ALPHACHANNEL;

	width=_width;
	height=_height;
	size=width*height;

	mainbuffer.Init(width, height, color);
	blackbuffer.Init(width, height, 0);
	whitebuffer.Init(width, height, 0xffffff);
	tempbuffer.Init(width, height, 0);

//	xcos=(char *)malloc(width*height*sizeof(char));
//	ysin=(char *)malloc(width*height*sizeof(char));
}

Layer::~Layer()
{

}

void Layer::Free()
{
	for (int i=0; i<num_buffer-1; i++)
	{
//		free(buffer[num_buffer-1]);
		buffer[num_buffer-1]->Free();
	}
	mainbuffer.Free();
	blackbuffer.Free();
	whitebuffer.Free();
	tempbuffer.Free();
//	free(mainbuffer.pixel);
	free(strings);
}

void Layer::FreeTunnel()
{
/*	flut=(unsigned long *)malloc(SIZE*4);
	alpha_table=(unsigned int *)malloc(256*256*sizeof(unsigned int));
	Tsqrt=(int *)malloc(SIZE*sizeof(int));
	Tatan2=(int *)malloc(SIZE*sizeof(int));
*/
//	free(Tatan2);
//	free(Tsqrt);
//	free(alpha_table);
//	free(flut);
	free(AngTable);
	free(RadTable);
}

void Layer::Init(int _width, int _height)
{
	width=_width;
	height=_height;
	size=width*height;

	mainbuffer.Init(width, height);
	blackbuffer.Init(width, height, 0);
	whitebuffer.Init(width, height, 0xffffff);
	tempbuffer.Init(width, height, 0);
}

void Layer::Init(int _width, int _height, int color)
{
	buffer=0;
	num_buffer=0;
	strings=0;
	stringCount=0;
	maskMode=MASK_ALPHACHANNEL;
	
	width=_width;
	height=_height;
	size=width*height;

	mainbuffer.Init(width, height, color);
	blackbuffer.Init(width, height, 0);
	whitebuffer.Init(width, height, 0xffffff);
	tempbuffer.Init(width, height, 0);
}

void Layer::InitLeading()
{
	int highest=0,height,i;

	for (i=0; i<num_buffer-1; i++)
	{
		height=getHeightBuffer(i);
		if (highest<height) highest=height;
	}
	leading=highest;
}

void Layer::addBuffer()
{
	num_buffer++;
	buffer=(PixelFrameBuffer **) realloc(buffer, num_buffer*sizeof(PixelFrameBuffer *));
	buffer[num_buffer-1]=new PixelFrameBuffer();
}

void Layer::AddBuffer(int width, int height)
{
	addBuffer();
	buffer[num_buffer-1]->Init(width,height,0);
}

void Layer::AddBuffer(int width, int height, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(width,height,color);
}


int string_compare(const char *str1, const char *str2)
{
   while( *str1 && *str2 )
   {
	      if( toupper((unsigned char)*str1) != toupper((unsigned char)*str2) )
         break;
      ++str1;
      ++str2;
   }
   return (!*str1 && !*str2);
}

#define IMAGE_TGA 0
#define IMAGE_PNG 1

static struct
{
   char *type;
   int index;
} image_format[]=
{
	{"TGA",	IMAGE_TGA},
	{"PNG",	IMAGE_PNG},
};

#include "../commonheaders/ypn_fixedpoint.h"

//for png.
void Layer::AddImage(char *filename)
{
	addBuffer();

	FILE *fp;

	char *ext=strrchr(filename, '.'); /* find first occurence of . in filename */
	if(ext) ext++;/* increment one step to find file extension */
	for (int i=0; i<(sizeof(image_format)/sizeof(image_format[0])); i++)
	{
		if (string_compare(image_format[i].type, ext))
		{
			if (image_format[i].index==IMAGE_TGA)
			{
				//TGA image
				fp=fopen(filename,"rb");

				unsigned char tga_header[12];//={0,0,2,0,0,0,0,0,0,0,0,0};
				unsigned char header[6];
				int w,h,size,bpp;

				fread(tga_header, 1, sizeof(tga_header),fp);
				fread(header, 1, sizeof(header),fp);
				w=header[0]+header[1]*256;
				h=header[2]+header[3]*256;
				buffer[num_buffer-1]->Init(w,h);
				bpp=header[4]/8; //32/8 - 32 bits / 8 bits(1 byte) = 4 bytes per pixel

				size=w*h*bpp;
				fread(buffer[num_buffer-1]->pixel,1,size,fp);

				unsigned int *tempimage=(unsigned int *)malloc(size);
				for (int i=0; i<w*h; i++) tempimage[i]=buffer[num_buffer-1]->pixel[i];

				for (int x=0; x<w; x++)
				for (int y=0; y<h; y++)
					buffer[num_buffer-1]->pixel[x+(h-1-y)*width]=tempimage[x+y*w];

				fclose(fp);

				//wrapbuffer(tobuffer);

				buffer[num_buffer-1]->width=w;
				buffer[num_buffer-1]->height=h;
				buffer[num_buffer-1]->size=size;
			}

			if (image_format[i].index==IMAGE_PNG)
			{
				//PNG image
			#ifdef _PNG_LIB_
				png_structp png_ptr; // main png struct
				png_infop info_ptr; // info struct
				png_uint_32 png_width, png_height;
				int bit_depth, color_type;
				int channels;
				png_uint_32 rowbytes;
				unsigned char sig[PNG_BYTES_TO_CHECK];
				unsigned char *image_data;
				unsigned int i, size, ofs;
			//	long int *data;
				png_bytepp row_pointers=NULL;

				fp=fopen(filename, "rb");
				fread(sig, 1, PNG_BYTES_TO_CHECK, fp);
				if (!png_check_sig(sig, PNG_BYTES_TO_CHECK)) exit(1);//return NULL;

				// we don't care about passing any pointer to any custom funtions
				png_ptr=png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
				if(!png_ptr) {
					fclose(fp);
					exit(1);//return NULL;
				}

				info_ptr=png_create_info_struct(png_ptr);
				if(!info_ptr) {
					fclose(fp);
					png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
					exit(1);//return NULL;
				}

				if(setjmp(png_jmpbuf(png_ptr))) {
					png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
					fclose(fp);
					exit(1);//return NULL;
				}

				png_init_io(png_ptr, fp);
				png_set_sig_bytes(png_ptr, PNG_BYTES_TO_CHECK);
				png_read_info(png_ptr, info_ptr);
				png_get_IHDR(png_ptr, info_ptr, &png_width, &png_height, &bit_depth, &color_type, NULL, NULL, NULL);

				if(setjmp(png_jmpbuf(png_ptr)))	{
					png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
					fclose(fp);
					exit(1);//return NULL;
				}

				// expand all to RGB[a]
				if(color_type==PNG_COLOR_TYPE_PALETTE) png_set_expand(png_ptr);
				if(color_type==PNG_COLOR_TYPE_GRAY && bit_depth<8) png_set_expand(png_ptr);
				if(png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) png_set_expand(png_ptr);
				if(bit_depth==16) png_set_strip_16(png_ptr);
				if(color_type==PNG_COLOR_TYPE_GRAY || color_type==PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(png_ptr);

				//if(png_get_gAMA(png_ptr, info_ptr, &gamma)) png_set_gamma(png_ptr, display_exponent, gamma);
   
				png_read_update_info(png_ptr, info_ptr);

				rowbytes=png_get_rowbytes(png_ptr, info_ptr);
				channels=png_get_channels(png_ptr, info_ptr);
   
				if((image_data=(unsigned char *)malloc(rowbytes*png_height))==NULL) {
					png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
					exit(1);//return NULL;
				}
   
				if((row_pointers=(png_bytepp)malloc(png_height*sizeof(png_bytep)))==NULL) {
					png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
					free(image_data);
					image_data=NULL;
					exit(1);//return NULL;
				}

				for(i=0; i<png_height; i++) row_pointers[i]=image_data+i*rowbytes; // pointer to each row of image data
				png_read_image(png_ptr, row_pointers);
				free(row_pointers);
				row_pointers=NULL;

				png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
				fclose(fp);

				buffer[num_buffer-1]->Init(png_width,png_height);

				// yep, now we got the image data as unsigned chars, convert them to int
				size=png_width*png_height;
			//	data=(long int *)malloc(size*sizeof(long int));

				ofs=0;
				if(channels<3) exit(1);//return NULL;
				if(channels==3) // without alpha
				{
					for(i=0; i<size*3; i+=3)
					{
						int r=image_data[i];
						int g=image_data[i+1];
						int b=image_data[i+2];
						buffer[num_buffer-1]->pixel[ofs++]=(r<<16)|(g<<8)|b;
					}
				}
				else if(channels==4) // with alpha
				{
					for(i=0; i<size*4; i+=4)
					{
						int r=image_data[i];
						int g=image_data[i+1];
						int b=image_data[i+2];
						int a=image_data[i+3];
						buffer[num_buffer-1]->pixel[ofs++]=(a<<24)|(r<<16)|(g<<8)|b;
					}
				}
				buffer[num_buffer-1]->width=png_width;
				buffer[num_buffer-1]->height=png_height;
				buffer[num_buffer-1]->size=size;

				free(image_data);
			#endif
			}
		}
	}
}

void Layer::SaveImage(char *filename, int frombuffer)
{
	FILE *fp;
	short widthf=getWidthBuffer(frombuffer);
	short heightf=getHeightBuffer(frombuffer);
	int size=getSizeBuffer(frombuffer);
	int channels=4;
	unsigned char *pixel=(unsigned char *)getPixelBuffer(frombuffer);

	if ((fp=fopen(filename, "wb"))==NULL)
	{
		fprintf(stderr, "Failed to open outputfile\n");
		exit(-1);
	}

	unsigned char tga_header[12]={0,0,2,0,0,0,0,0,0,0,0,0};
	unsigned char header[6];
	header[0]=(widthf & 0x00ff);//(int)(widthf%256);
	header[1]=(widthf & 0xff00)/256;//(int)(widthf/256);
	header[2]=(heightf & 0x00ff);//(int)(heightf%256);
	header[3]=(heightf & 0xff00)/256;//(int)(heightf/256);
	header[4]=32;
	header[5]=0;

	fwrite(tga_header, sizeof(unsigned char), 12, fp);
	fwrite(header, sizeof(unsigned char), 6, fp);
//	fwrite(pixel, sizeof(unsigned char), size*channels, fp);
//	fwrite(pixel, sizeof(unsigned int), size, fp);

	for (int y=0; y<heightf; y++)
	{
		int addr=(heightf-1-y)*widthf;
		for (int x=0; x<widthf; x++)
		{

			//blue
			putc(pixel[(x+addr)*4+0], fp);

			//green
			putc(pixel[(x+addr)*4+1], fp);

			//red
			putc(pixel[(x+addr)*4+2], fp);

			//alpha
			putc(pixel[(x+addr)*4+3], fp);
		}
	}
	fclose(fp);
}

void Layer::AddRawFile(char *filename)
{
	int readchar;
	int i=0;
	int width=80;
	int height=25;

	addBuffer();
	buffer[num_buffer-1]->Init(width,height,0);
	ClearBuffer(num_buffer-1, 0);

	FILE *fp=fopen(filename,"rb");

	int x=0, y=0;
	while(!feof(fp))
	{
		readchar=fgetc(fp);

		if (readchar==0x0d)
		{
			if (fgetc(fp)==0x0a)
			{
				y++;
				x=0;
			}
			else
			{
				x++;
				buffer[num_buffer-1]->pixel[x+y*width]=0x0d;
				x++;
				buffer[num_buffer-1]->pixel[x+y*width]=readchar;
			}
		}
		else
		{
			buffer[num_buffer-1]->pixel[x+y*width]=readchar;
			x++;
		}
	}
	buffer[num_buffer-1]->width=width;
	buffer[num_buffer-1]->height=height;
	fclose(fp);
}

//reads x amount of characters after eachoter and returns 1 if they are in the file else 0.
//supports only 2 characters atm because we only need that for the ansi parser.
int parseread(FILE *f, int amount, unsigned char *c)
{
	int readc, int readc2;

	while(!feof(f))
	{
		readc=fgetc(f);
		if (readc==c[0])
		{
			readc2=fgetc(f);
			if (readc2==c[1])
				return 1;
			else
			{
				return readc;
			}
		}
		else return readc;
	}
}

void read_token(FILE *f, char *target)
{
	int c;
	char *p=target;
	while(EOF != (c = fgetc(f)))
	{
		*p++=c;
		if(p-target>=2 && p[-1]=='\r' && p[0]=='\n')
		{
			p[-1]=0;
			return;
		}
	}
}

//int mode13h_colors[16]={0x000000, 0x000080, 0x008000, 0x008080, 0x800000, 0x800080, 0x808000, 0xc0c0c0,
//0x808080, 0x0000ff, 0x00ff00, 0x00ffff, 0xff0000, 0xff00ff, 0xffff00, 0xffffff};
//ansi colors:
int mode13h_colors[16]={0x000000, 0x800000, 0x008000, 0x808000, 0x000080, 0x800080, 0x008080, 0xc0c0c0,
0x808080, 0xff0000, 0x00ff00, 0xffff00, 0x0000ff, 0xff00ff, 0x00ffff, 0xffffff};

//ansi *ansitable;
//ansitable=(ansi *)malloc(sizeof(ansi)*80*25);

void Layer::AddAnsi(char *filename, ansi *ansitable)
{
	int readchar;
	int readnextchar;
	int i=0;

	//init parse variables
	bool bold=false;
//	bool bg_bold=false;
//	bool fg_bold=false;
	int background_color=0;
	int foreground_color=0;

	//mode 80x25
	int width=80;
//	int height=40;
	int height=25;
	int x=0, y=0;
	int cr=0, nl=0;
	int old_number=0, number=0;
	int number_flag=0;
	int writestuff=0;

	addBuffer();
	buffer[num_buffer-1]->Init(width,height,0);
	ClearBuffer(num_buffer-1, 0);

	FILE *fp=fopen(filename,"r");
//	FILE *fpo=fopen("out2.txt", "w");

	//decrypt ansi codes and shit like that..

	int ch;
	while (!feof(fp))
	{
		ch=fgetc(fp);

		if (ch==0x1b) //ESC
		{
			ch=fgetc(fp);
			if (ch==0x5b) //[
			{
//				fprintf(fpo, "%c%c", 0x1b, 0x5b);
			}
			writestuff=0;
		} else
		if (ch>=0x30 && ch<=0x39) //0-9
		{
			char c=(char)ch;
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
				x++;
				if (x>=width*height) x=width*height-1;
			}
			else
			{
				if (number_flag==0) { number=atoi(&c); old_number=number*10; }
				if (number_flag==1)	{ number=old_number+atoi(&c); }
				number_flag++;
				if (number_flag>=2) number_flag=0;
			}
//			fprintf(fpo, "%c",ch);
		} else
		if (ch=='m')
		{
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
				x++;
				if (x>=width*height) x=width*height-1;
			}
			else
			{
				if (old_number==30)
					foreground_color=number-old_number;
				else
					background_color=number-old_number;
			}

//			fprintf(fpo, "%c", ch);
			number_flag=0;
			writestuff=1;
		} else
		if (ch=='A')
		{
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
			}
			else
			{
				x-=width;
			}

			number_flag=0;
			writestuff=1;
		} else
		if (ch==';')
		{
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
				x++;
				if (x>=width*height) x=width*height-1;
			}
			else
			{
				if (number==0) bold=false;
				if (number==1) bold=true;

				if (old_number==30)
					foreground_color=number-old_number;
				else
					background_color=number-old_number;
			}
			number_flag=0;
		} else
		if (ch=='C')	//Move cursor right
		{
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
				x++;
				if (x>=width*height) x=width*height-1;
//				fprintf(fpo, "%c", ch);
			}
			else
			{
				x+=number;
//				fprintf(fpo, "%c", ch);
				number_flag=0;
				writestuff=1;
			}
		} else
		if (ch=='\n')
		{
			int xt=x%(width);
			x-=xt;
			x+=width;

//			fprintf(fpo, "\n");
			number_flag=0;
		} else
		{
			number=0;
			if (writestuff==1)
			{
				ansitable[x].character=ch;
				ansitable[x].background_color=background_color;
				ansitable[x].foreground_color=foreground_color;
				ansitable[x].bold=bold;
				x++;
				if (x>=width*height) x=width*height-1;
			}

//			fprintf(fpo,"%c",ch);

			number_flag=0;
		}
//		fprintf(fpo, "%c", (char)ch);
	}

//	fclose(fpo);
	fclose(fp);
}

void Layer::SetMaskMode(int mode)
{
	maskMode=mode;
}

void Layer::SetMaskMode(int tobuffer, int mode)
{
	buffer[tobuffer]->SetMaskMode(mode);
}

unsigned int *Layer::getPixelBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.pixel);
	else
	if (index==BLACKBUFFER) return (blackbuffer.pixel);
	else
	if (index==WHITEBUFFER) return (whitebuffer.pixel);
	else
	if (index==TEMPBUFFER) return (tempbuffer.pixel);
	else return (buffer[index]->pixel);
}

int Layer::getWidthBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.width);
	else
	if (index==TEMPBUFFER) return (tempbuffer.width);
	else return (buffer[index]->width);
}

int Layer::getHeightBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.height);
	else
	if (index==TEMPBUFFER) return (tempbuffer.height);
	else return (buffer[index]->height);
}

int Layer::getSizeBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.size);
	else
	if (index==BLACKBUFFER) return (blackbuffer.size);
	else
	if (index==WHITEBUFFER) return (whitebuffer.size);
	else
	if (index==TEMPBUFFER) return (tempbuffer.size);
	else return (buffer[index]->size);
}

int Layer::getCSizeBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.csize);
	else
	if (index==BLACKBUFFER) return (blackbuffer.csize);
	else
	if (index==WHITEBUFFER) return (whitebuffer.csize);
	else
	if (index==TEMPBUFFER) return (tempbuffer.csize);
	else return (buffer[index]->csize);
}

int Layer::getMaskBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.maskMode);
	else return (buffer[index]->maskMode);
}

void Layer::setMaskBuffer(int index, int mode)
{
	if (index==SCREENBUFFER) mainbuffer.maskMode=mode;
	else buffer[index]->maskMode=mode;
}

unsigned int *Layer::getPaletteBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.palette);
	else return (buffer[index]->palette);
}

bool Layer::getPaletteflagBuffer(int index)
{
	if (index==SCREENBUFFER) return (mainbuffer.palette_flag);
	else return (buffer[index]->palette_flag);
}

void Layer::AddBlocksH(int scrwidth, int scrheight, int blockwidth, int distwidth, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(scrwidth,scrheight,0);
	buffer[num_buffer-1]->AddBlocksH(blockwidth,distwidth,color);
}

void Layer::AddBlocksV(int scrwidth, int scrheight, int blockheight, int distheight, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(scrwidth,scrheight,0);
	buffer[num_buffer-1]->AddBlocksV(blockheight,distheight,color);
}

void Layer::AddGradientLinear(int _width, int _height, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,color);
	buffer[num_buffer-1]->GradientLinear(color);
}

void Layer::AddGradientRadial(int _width, int _height, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,color);
	buffer[num_buffer-1]->GradientRadial(color);
}

void Layer::AddGradientReflected(int _width, int _height, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,color);
	buffer[num_buffer-1]->GradientReflected(color);
}

void Layer::AddCheckerboard(int _width, int _height, int amount)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,0);

	int i,j,x,y,flagx,flagy,sx,sy;
	int col=0xffffff;

	sx=_width/amount;
	sy=_height/amount;

	for (x=0; x<_width; x++)
	for (y=0; y<_height; y++)
	{
		if ((x%(sx*2))>=sx) flagx=1;
		else flagx=0;
		if ((y%(sy*2))>=sy) flagy=1;
		else flagy=0;

		if ((flagx==0 && flagy==1) || (flagx==1 && flagy==0))
			buffer[num_buffer-1]->pixel[x+y*_width]=col;
		else
			buffer[num_buffer-1]->pixel[x+y*_width]=0;
	}
}

void Layer::AddCheckerboard(int _width, int _height, int amount, int col1, int col2)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,0);

	int i,j,x,y,flagx,flagy,sx,sy;

	sx=_width/amount;
	sy=_height/amount;

	for (x=0; x<_width; x++)
	for (y=0; y<_height; y++)
	{
		if ((x%(sx*2))>=sx) flagx=1;
		else flagx=0;
		if ((y%(sy*2))>=sy) flagy=1;
		else flagy=0;

		if ((flagx==0 && flagy==1) || (flagx==1 && flagy==0))
			buffer[num_buffer-1]->pixel[x+y*_width]=col1;
		else
			buffer[num_buffer-1]->pixel[x+y*_width]=col2;
	}
}

void Layer::AddNoise(int _width, int _height, int col, int seed)
{
	unsigned int *pixelt;
	int widtht, heightt;
	int x,y,r,g,b,r2,g2,b2,c;

	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,0);

	widtht=getWidthBuffer(num_buffer-1);
	heightt=getHeightBuffer(num_buffer-1);
	pixelt=getPixelBuffer(num_buffer-1);

	r=(col&0xff0000)>>16;
	g=(col&0xff00)>>8;
	b=(col&0xff);

	srand((unsigned)time(NULL));

	for (y=0; y<heightt; y++)
	{
		int addr=y*widtht;
		for (x=0; x<widtht; x++)
		{
//			c=rand()%255;
			c=128+128*noise1d(x+y*width+seed);//rand()%255;
			r2=c&r;
			g2=c&g;
			b2=c&b;
			pixelt[x+addr]=RGB32(r2,g2,b2);
		}
	}
}

void Layer::AddFlower(int _width, int _height, int color)
{
	addBuffer();
	buffer[num_buffer-1]->Init(_width,_height,color);
	buffer[num_buffer-1]->Flower(color);
}

void Layer::AddColor(int color)
{
	buffer[num_buffer-1]->Add(color);
}

void Layer::AddPalette(int tobuffer, int index_from, int index_to, int col_from, int col_to)
{
	int i;
	int rf, gf, bf;
	int rt, gt, bt;
	float radd, gadd, badd;
	float rsum,gsum,bsum;
	
	unsigned int *palette=getPaletteBuffer(tobuffer);

	rf=(col_from&0xff0000)>>16;
	gf=(col_from&0x00ff00)>>8;
	bf=(col_from&0x0000ff);
	rt=(col_to&0xff0000)>>16;
	gt=(col_to&0x00ff00)>>8;
	bt=(col_to&0x0000ff);

	radd=fabs(rt-rf)/(index_to-index_from);
	gadd=fabs(gt-gf)/(index_to-index_from);
	badd=fabs(bt-bf)/(index_to-index_from);

	if (rt<rf) radd=-radd;
	if (gt<gf) gadd=-gadd;
	if (bt<bf) badd=-badd;

	rsum=rf;
	gsum=gf;
	bsum=bf;
	for (i=index_from; i<index_to; i++)
	{
		rsum+=radd;
		gsum+=gadd;
		bsum+=badd;
		palette[i]=RGB32((int)rsum, (int)gsum, (int)bsum);
	}
}

void Layer::AddPalette(int tobuffer, int index, int col)
{
	unsigned int *palette=getPaletteBuffer(tobuffer);
	palette[index]=col;
}

float smoothstep(float a, float b, float x)
{
	if (x<a) return 0;
	if (x>=b) return 1;
	x=(x-a)/(b-a);
	return ((x*x)*(3-2*x));
}

void Layer::GenerateNoise(int tobuffer, int amplitude, int frequency, int seed)
{
	unsigned int *texture=getPixelBuffer(tobuffer);
	//
	//cosine interpol.
	//
	Vector3D v;
	Vector3D v0,v1,v2,v3;
	int ax,ay,ix,iy;
	int nx0,nx1,nx2,nx3;
	int ny0,ny1,ny2,ny3;

	//
	//generate random points
	//
	int x,y;
	int connection_points_x[256];
	int connection_points_y[256];
//	for (x=0; x<frequency; x++)	connection_points_x[x]=amplitude*noise1d(seed+x);
//	for (y=0; y<frequency; y++)	connection_points_y[y]=amplitude*noise1d(seed+y+frequency);
//	for (x=0; x<frequency; x++)	connection_points_x[x]=128+amplitude*noise1d(seed+x);
//	for (y=0; y<frequency; y++)	connection_points_y[y]=128+amplitude*noise1d(seed+y+frequency);
//	for (x=0; x<frequency; x++)	connection_points_x[x]=rand()%amplitude;
//	for (y=0; y<frequency; y++)	connection_points_y[y]=rand()%amplitude;
	for (x=0; x<frequency; x++)	connection_points_x[x]=amplitude*(noise1d(seed+x)+1.0)*0.5;
	for (y=0; y<frequency; y++)	connection_points_y[y]=amplitude*(noise1d(seed+y+frequency)+1.0)*0.5;

	int area=256/frequency;

//	static float ft=0;
//	ft+=0.1;
	float divfactor=1.0/area;
//	float divfactor=fmod(ft, 1);

	for (ay=0; ay<frequency; ay++)
	{
		ny0=ay-1;
		if (ny0<0) ny0+=frequency;
		v0.y=connection_points_y[ny0];
		v1.y=connection_points_y[ay];

		for (ax=0; ax<frequency; ax++)
		{
			nx0=ax-1;
			if (nx0<0) nx0+=frequency;
			v0.x=connection_points_x[nx0];
			v1.x=connection_points_x[ax];

			for (y=0; y<area; y++)
			{
				v=v.CosineInterpolateR(v0, v1, y*divfactor);
				iy=v.y;
				for (x=0; x<area; x++)
				{
					v=v.CosineInterpolateR(v0, v1, x*divfactor);
					ix=v.x;
					int col=ix*0.5+iy*0.5;
//					int col=ix+iy;
					texture[(x+(ax*area))+(y+ay*area)*256]=col;
				}
			}
		}
	}
}

//-----------------------------------------------
//Lens Flare-effect - activator^yaphan 04.05.2003
//-----------------------------------------------
void Layer::AddLensFlare(int width, int height, int type)
{
	addBuffer();
	buffer[num_buffer-1]->Init(width,height,0);
	buffer[num_buffer-1]->SetMaskMode(MASK_TRANSPARENCY_ADD);

	unsigned int *pixelt;
	int widtht, heightt;

	widtht=getWidthBuffer(num_buffer-1);
	heightt=getHeightBuffer(num_buffer-1);
	pixelt=getPixelBuffer(num_buffer-1);
/*
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);
*/
	float colf;
	int col;
	int radius=min(widtht, heightt)/2;
	for (int x=0; x<widtht; x++)
	for (int y=0; y<heightt; y++)
	{
		int dx=radius-x;
		int dy=radius-y;
		float r=sqrt(dx*dx + dy*dy) / (float)radius;

		//(1-r)^2
		if (type==0)
		{
			colf=(1-r)*(1-r);
			if (r>1)
			{
				//colf=0;
				colf*=1-smoothstep(1-.1, 1+.1, r);
			}
			col=(int)(colf*255);
		}

		//r^6
		if (type==1)
		{
			colf=(r*r*r*r*r*r);
			if (r>1)
			{
				//colf=0;
				colf*=1-smoothstep(1-.01, 1+.01, r);
			}
			col=(int)(colf*255);
		}

		//r
		if (type==2)
		{
			colf=r;
			if (r>1)
			{
				//colf=0;
				colf*=1-smoothstep(1-.01, 1+.01, r);
			}
			col=(int)(colf*255);
		}

		//ring of width .2 and radius
		if (type==3)
		{
			colf=1-fabs(r-.9f)/.1f;
			if (colf<0) colf=0;
			colf=colf*colf*colf;
			col=(int)(colf*255);
		}

		//TODO: lightrays
		if (type==4)
		{

		}

		pixelt[x+y*widtht]=RGB32(col,col,col);
	}
}

int visible_i(int i)
{
   if(i>=0 && i<SIZE) return 1;
   else return 0;
}

int visible_i(int i, int size)
{
   if(i>=0 && i<size) return 1;
   else return 0;
}

void asm_plotadd(unsigned int *pixel, int i, int col)
{
	int srcpix;
//	if(visible_i(i))
//	{
		srcpix=pixel[i];
		_asm
		{
			movd mm0, srcpix
			paddusb mm0, col
//			psubusb mm0, col
			movd srcpix, mm0
			emms	//empty mmx state
		}
		pixel[i]=srcpix;
//	}
}

void asm_plotsub(unsigned int *pixel, int i, int col)
{
	int srcpix;
	if(visible_i(i))
	{
		srcpix=pixel[i];
		_asm
		{
			movd mm0, srcpix
			psubusb mm0, col
			movd srcpix, mm0
			emms	//empty mmx state
		}
		pixel[i]=srcpix;
	}
}

void Layer::NoiseVLine(int tobuffer, int px, int seed, int strength)
{
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	uint *pixelt=getPixelBuffer(tobuffer);
	int x,y, c, r2;

	float fl=1.0/200.0f;
//	int yr=100;//rand()%200;
//	int yr=rand()%100;
	int yr=100+sin(ftime*seed*0.3)*100;
//	int yr=100+sin(ftime+seed*0.1)*90;//rand()%200;
//	int yr=200;

//	for (y=0; y<heightt; y++)
	for (y=0; y<yr; y++)
	{
		int cc=rand()%200;

//		int addr=y*widtht;
		int addr=cc*widtht;

//		c=rand()%255;
		c=rand()%strength;//127;
//		c=255;
//		c=128+128*noise1d(px+addr+seed+1);//rand()%255;
//		c=128+128*noise1d(px+y*widtht+seed);//rand()%255;
		r2=c&127;

		if (visible_i(px+addr))
			asm_plotadd(pixelt, px+addr, RGB32(r2,r2,r2));
		//pixelt[px+addr]=RGB32(r2,r2,r2);
	}
}

void Layer::SetFontPrefs(char *_fontname, int _pointsize)
{
	fontname=_fontname;
	pointsize=_pointsize;
	flag_file=false;
}

void Layer::SetFontPrefs(char *_fontname, char *_fontfile, int _pointsize)
{
	fontname=_fontname;
	fontfile=_fontfile;
	pointsize=_pointsize;
	flag_file=true;
}

void Layer::InitFontMemDC(int width, int height)
{
	fnt=(char*)malloc(sizeof(char)*2);
	//Resolution: 640x480:
	//P.P.I: 62
	//8x12		10x16
	//80x40		64x30

	if (flag_file==true)
	{
		AddFontResource(fontfile);
		SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0);
	}

	hdc=GetDC(NULL);
	hbitmap=CreateCompatibleBitmap(hdc,width,height);
	hdc_font=CreateCompatibleDC(hdc);
	SelectObject(hdc_font, hbitmap);

	memset(&bmi,0,sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize=sizeof(bmi.bmiHeader);
	bmi.bmiHeader.biWidth=width;
	bmi.bmiHeader.biHeight=-height;
	bmi.bmiHeader.biPlanes=1;
	bmi.bmiHeader.biBitCount=32;
	bmi.bmiHeader.biCompression=BI_RGB;

	int fheight= -MulDiv(pointsize, GetDeviceCaps(hdc, LOGPIXELSY), 72);
	hFont=CreateFont(	fheight,//h�yden
						0,	//bredden
						0,
						0,
						FW_NORMAL,//bold
						FALSE,//italic
						FALSE,//underline
						FALSE,//strikeout

//						ANSI_CHARSET,
						OEM_CHARSET,

						OUT_DEFAULT_PRECIS,
//						OUT_TT_PRECIS, //klipping presisjon

//						CLIP_DEFAULT_PRECIS,
						CLIP_CHARACTER_PRECIS,

						DEFAULT_QUALITY, //ANTIALIASED_QUALITY //kvalitet ps font

//						FF_DONTCARE|DEFAULT_PITCH,
						FF_DONTCARE|FIXED_PITCH,
//						FF_DONTCARE|VARIABLE_PITCH,
						fontname);
}

void Layer::AddTTFFont(int width, int height, char font)
{
	int col=0xffffff;
	rect.top=0;
	rect.bottom=height;
	rect.left=0;
	rect.right=width;
//	rect.right=width-2;
	FillRect(hdc_font, &rect, (HBRUSH)GetStockObject(BLACK_BRUSH));
	SetBkMode(hdc_font, TRANSPARENT);

//	BGR->RGB
	SetTextColor(hdc_font, RGB(getRed(col),getGreen(col),getBlue(col)));	//grs
	SelectObject(hdc_font, hFont);

	fnt[0]=font;
	fnt[1]='\0';
	DrawText(hdc_font, fnt, strlen(fnt), &rect, DT_SINGLELINE|0|DT_EXPANDTABS|DT_TABSTOP|0x0400);

	addBuffer();
	buffer[num_buffer-1]->Init(width, height, 0);
	ClearBuffer(num_buffer-1, 0);

	GetDIBits(hdc_font, hbitmap, 0, height, buffer[num_buffer-1]->pixel, &bmi, DIB_RGB_COLORS);

	DeleteObject(hFont);
	DeleteObject(hbitmap);
	ReleaseDC(NULL, hdc_font);
	ReleaseDC(NULL, hdc);
	if (flag_file==true)
	{
		RemoveFontResource(fontfile);
//		SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0);
	}
}

void Layer::AddTTFText(int width, int height, char *text, char *fontfile, char *fontname, int pointsize)
{
	int x,y,r,g,b,i,j=0;
	RECT rect;
	HWND hwnd;
	BITMAPINFO bmi;
	HFONT hFont;
	HBITMAP hbitmap;
	HDC hdc,hdc2;
	int fheight;

	int col=0xffffff;

	//Resolution: 640x480:
	//P.P.I: 62
	//8x12		10x16
	//80x40		64x30

	AddFontResource(fontfile);
	SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0);

	hdc=GetDC(NULL);
	hbitmap=CreateCompatibleBitmap(hdc,width,height);
	hdc2=CreateCompatibleDC(hdc);
	SelectObject(hdc2, hbitmap);

	memset(&bmi,0,sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize=sizeof(bmi.bmiHeader);
	bmi.bmiHeader.biWidth=width;
	bmi.bmiHeader.biHeight=-height;
	bmi.bmiHeader.biPlanes=1;
	bmi.bmiHeader.biBitCount=32;
	bmi.bmiHeader.biCompression=BI_RGB;

	fheight = -MulDiv(pointsize, GetDeviceCaps(hdc, LOGPIXELSY), 72);

	hFont=CreateFont(	fheight,//h�yden
						0,	//bredden
						0,
						0,
						FW_NORMAL,//bold
						FALSE,//italic
						FALSE,//underline
						FALSE,//strikeout
						ANSI_CHARSET,	//sometimes for .ttf files and sometimes for .fon files
//						OEM_CHARSET,	//same here.
						OUT_DEFAULT_PRECIS,//OUT_TT_PRECIS, //klipping presisjon
						CLIP_DEFAULT_PRECIS,
						DEFAULT_QUALITY, //ANTIALIASED_QUALITY //kvalitet ps font
						FF_DONTCARE|DEFAULT_PITCH,
						//VARIABLE_PITCH,
//						"Terminal");
//						"Impact");
						fontname);
//						"Fixedsys");
	rect.top=0;
	rect.bottom=height;
	rect.left=0;
	rect.right=width;
	FillRect(hdc2, &rect, (HBRUSH)GetStockObject(BLACK_BRUSH));
	SetBkMode(hdc2, TRANSPARENT);

//	BGR->RGB
	r=((col&0xff0000)>>16);
	g=((col&0xff00)>>8);
	b=((col&0xff));

	SetTextColor(hdc2, RGB(r,g,b));	//grs
	SelectObject(hdc2, hFont);

	DrawText(hdc2, text, strlen(text), &rect, DT_SINGLELINE|0|DT_EXPANDTABS|DT_TABSTOP|0x0400);

	unsigned int *data=(unsigned int *)malloc(sizeof(unsigned int)*width*height);
	unsigned char *cdata=(unsigned char *)data;

	GetDIBits(hdc2, hbitmap, 0, height, data, &bmi, DIB_RGB_COLORS);

	addBuffer();
	buffer[num_buffer-1]->Init(width, height, 0);
	ClearBuffer(num_buffer-1, 0);

	for (i=0; i<width*height; i++, j+=4) buffer[num_buffer-1]->pixel[i]=RGB32(cdata[j+2],cdata[j+1],cdata[j]);

	DeleteObject(hFont);
	DeleteObject(hbitmap);
	ReleaseDC(NULL, hdc2);
	ReleaseDC(NULL, hdc);

	RemoveFontResource(fontfile);
	SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0);
}

void Layer::ClearBuffer(int index)
{
	if (index==SCREENBUFFER)
		mainbuffer.Clear();
	else
		buffer[index]->Clear();
}

void Layer::ClearBuffer(int index, int col)
{
	if (index==SCREENBUFFER)
		mainbuffer.Clear(col);
	else
		buffer[index]->Clear(col);
}

void Layer::CopyBuffer(int tobuffer, int frombuffer)
{
	int x,y,yaddr,yaddr2;

	unsigned int *pixelt, *pixelf;
	int widtht, heightt, widthf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	int maskmode=getMaskBuffer(frombuffer);
	setMaskBuffer(tobuffer, maskmode);
//	buffer[tobuffer]->maskMode=buffer[frombuffer]->maskMode;
	
	bool palette_flag=getPaletteflagBuffer(frombuffer);
	unsigned int *palettef=getPaletteBuffer(frombuffer);

	if (maskmode!=MASK_NONZERO)
	{
		if (palette_flag==off)
		{
			for (y=0; y<heightt; y++)
			{
				yaddr=y*widtht;
				yaddr2=y*widthf;
				for (x=0; x<widtht; x++) pixelt[x+yaddr]=pixelf[x+yaddr2];
			}
		}
		else
		{
			for (y=0; y<heightt; y++)
			{
				yaddr=y*widtht;
				yaddr2=y*widthf;
				for (x=0; x<widtht; x++) pixelt[x+yaddr]=palettef[pixelf[x+yaddr2]&0xff];
			}
		}
	}
	else
	{
		if (palette_flag==off)
		{
			for (y=0; y<heightt; y++)
			{
				yaddr=y*widtht;
				yaddr2=y*widthf;
				for (x=0; x<widtht; x++)
					if (pixelf[x+yaddr2]!=0)
						pixelt[x+yaddr]=pixelf[x+yaddr2];
			}
		}
		else
		{
			for (y=0; y<heightt; y++)
			{
				yaddr=y*widtht;
				yaddr2=y*widthf;
				for (x=0; x<widtht; x++)
					if (palettef[pixelf[x+yaddr2]]!=0)
						pixelt[x+yaddr]=palettef[pixelf[x+yaddr2]];
			}
		}
	}

/*
	if (mode==MASK_DEFAULT)
	{
		for (y=0; y<heightt; y++)
		{
			yaddr=y*widtht;
			yaddr2=y*widthf;
			for (x=0; x<widtht; x++) pixelt[x+yaddr]=pixelf[x+yaddr2];
		}
	} else
	if (mode==MASK_NONZERO)
	{
		for (y=0; y<heightt; y++)
		{
			yaddr=y*widtht;
			yaddr2=y*widthf;
			for (x=0; x<widtht; x++)
				if (pixelf[x+yaddr2]!=0)
					pixelt[x+yaddr]=pixelf[x+yaddr2];
		}
	}*/
}

void Layer::CopyBufferLayer(int tobuffer, Layer fromlayer, int frombuffer)
{
	int widthf,heightf;
	int widtht,heightt;
	unsigned int *pixelf, *pixelt;

//	widtht=getWidthBuffer(tobuffer);
//	heightt=getHeightBuffer(tobuffer);

//	widthf=getWidthBuffer(frombuffer);
//	heightf=getHeightBuffer(frombuffer);
	
	pixelt=getPixelBuffer(tobuffer);
	pixelf=fromlayer.getPixelBuffer(frombuffer);
//	pixelt=pixelf;

	int size=getSizeBuffer(tobuffer);
	for (int i=0; i<size; i++) pixelt[i]=pixelf[i];
}

void Layer::CopyBufferChannel(int tobuffer, int frombuffer, int channel_to, int channel_from)
{
	unsigned char *pixeltc, *pixelfc;
	int sizef,i;

	pixeltc=(unsigned char *)getPixelBuffer(tobuffer);
	pixelfc=(unsigned char *)getPixelBuffer(frombuffer);
	sizef=getCSizeBuffer(frombuffer);
	for (i=0; i<sizef; i+=4) pixeltc[i+channel_to]=pixelfc[i+channel_from];
}

void Layer::CopyBufferArea(int tobuffer, int frombuffer, int px, int py)
{
	int x,y,yaddr,yaddr2;//,_width,_height,iwidth;

	unsigned int *pixelt, *pixelf;
	int widtht, heightt, widthf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	int mode=buffer[frombuffer]->maskMode;

	if (mode==MASK_DEFAULT)
	{
		for (y=0; y<heightt; y++)
		{
			yaddr=y*widtht;
			yaddr2=(y+py)*widthf;
			for (x=0; x<widtht; x++) pixelt[x+yaddr]=pixelf[x+px+yaddr2];
		}
	}
}

void Layer::NoiseSpanHorisontal(int tobuffer, int frombuffer, int amount)
{
	int x,y,mul,sx;

	int heightf=getHeightBuffer(frombuffer);
	int widthf=getWidthBuffer(frombuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

	if (fft_flag==false)
	{
		for (y=0; y<heightf; y++)
		{
			mul=y*widthf;

			if (amount<=0) amount=1;
			sx=-amount/2+(rand()%amount);

			for (x=0; x<widthf; x++)
				if (visible(x+sx,y, widthf, heightf))
						pixelt[x+sx+mul]=pixelf[x+mul];
		}
	}
	else
	{
		for (y=0; y<heightf; y++)
		{
			mul=y*widthf;

			amount=fft_adapt[y];

			if (amount<=0) amount=1;
			sx=-amount/2+(rand()%amount);

			for (x=0; x<widthf; x++)
				if (visible(x+sx,y, widthf, heightf))
						pixelt[x+sx+mul]=pixelf[x+mul];
		}
	}
}

void Layer::NoiseSpanVertical(int tobuffer, int frombuffer, int amount)
{
	int x,y,mul,mul2,sy;

	int heightf=getHeightBuffer(frombuffer);
	int widthf=getWidthBuffer(frombuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

	if (fft_flag==false)
	{
		for (x=0; x<widthf; x++)
		{
			if (amount<=0) amount=1;
			sy=-amount/2+(rand()%amount);

			for (y=0; y<heightf; y++)
			{
				mul=y*widthf;
				mul2=(y+sy)*widthf;
				if (visible(x,y+sy, widthf, heightf))
						pixelt[x+mul2]=pixelf[x+mul];
			}
		}
	}
	else
	{
		for (x=0; x<widthf; x++)
		{
			amount=fft_adapt[x];

			if (amount<=0) amount=1;
			sy=-amount/2+(rand()%amount);

			for (y=0; y<heightf; y++)
			{
				mul=y*widthf;
				mul2=(y+sy)*widthf;
				if (visible(x,y+sy, widthf, heightf))
						pixelt[x+mul2]=pixelf[x+mul];
			}
		}
	}
}

void Layer::WrapBuffer(int tobuffer, int frombuffer, int offsetx, int offsety)
{
	int x,y,yaddr,yaddr2;

	unsigned int *pixelt, *pixelf;
	int widtht, heightt, widthf, heightf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	heightf=getHeightBuffer(frombuffer);
	widthf=getWidthBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	int mode=buffer[frombuffer]->maskMode;

	if (mode==MASK_DEFAULT)
	{
		for (y=0; y<heightt; y++)
		{
			yaddr=y*widtht;
			yaddr2=((y+offsety)%heightf)*widthf;
			for (x=0; x<widtht; x++) pixelt[x+yaddr]=pixelf[((x+offsetx)%widthf)+yaddr2];
		}
	}
}

Layer operator+(Layer &toLayer, Layer &fromLayer)
{
	toLayer.mainbuffer=toLayer.mainbuffer+fromLayer.mainbuffer;
	return toLayer;
}

unsigned int *Layer::showtime(float start_time, float end_time)
{
	return buffer[num_buffer-1]->pixel;
}

void Layer::BlendNormal(int index, int alpha) { mainbuffer.BlendNormal(*buffer[index], alpha); }
void Layer::BlendNormal(Layer fromLayer, uchar alpha) { mainbuffer.BlendNormal(fromLayer.mainbuffer, alpha); }

void Layer::Blend(int tobuffer, int frombuffer, uchar alpha)
{
	buffer[tobuffer]->BlendNormal(*buffer[frombuffer], alpha);
}

void Layer::CrossFade(int tobuffer, int frombuffer, int alpha)
{
	unsigned int *pixelt, *pixelf;
	int size,i,rb,g,dst,src;
	uchar alphainv;

	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	alpha=(alpha>=255)?255:(alpha<=0)?0:alpha;
	alphainv=255-alpha;

	for(i=0; i<size; i++)
	{
		dst=pixelt[i];
		src=*pixelf++;
		rb=((((dst&0xff00ff)*alphainv)+((src&0xff00ff)*alpha))>>8)&0xff00ff;
		g=((((dst&0x00ff00)*alphainv)+((src&0x00ff00)*alpha))>>8)&0x00ff00;
		pixelt[i]=rb+g;
	}
}

void Layer::CrossFade(int tobuffer, int bufferto, int frombuffer, int alpha)
{
	unsigned int *pixelt, *pixelt2, *pixelf;
	int size,i,rb,g,dst,src;
	uchar alphainv;

	pixelt=getPixelBuffer(tobuffer);
	pixelt2=getPixelBuffer(bufferto);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	alpha=(alpha>=255)?255:(alpha<=0)?0:alpha;
	alphainv=255-alpha;

	for(i=0; i<size; i++)
	{
		dst=pixelt2[i];
		src=*pixelf++;
		rb=((((dst&0xff00ff)*alphainv)+((src&0xff00ff)*alpha))>>8)&0xff00ff;
		g=((((dst&0x00ff00)*alphainv)+((src&0x00ff00)*alpha))>>8)&0x00ff00;
		pixelt[i]=rb+g;
	}
}


void Layer::CrossFadeA(int tobuffer, int bufferto, int frombuffer, int alpha)
{
	unsigned int *pixelt, *pixelt2, *pixelf;
	int size,i,rb,r,g,b,a,dst,src;
	uchar alphainv;

	pixelt=getPixelBuffer(tobuffer);
	pixelt2=getPixelBuffer(bufferto);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	alpha=(alpha>=255)?255:(alpha<=0)?0:alpha;
	alphainv=255-alpha;


	float fa=0.5+sin(ftime)*0.5;//(float)alpha*0.0039215f;//0.5+sin(ftime)*0.5;//255/alpha;
	
//	float fai=(float)(255-alpha)/255;

	for(i=0; i<size; i++)
	{
		dst=pixelt2[i];
		src=*pixelf++;
//		rb=((((dst&0xff00ff)*alphainv)+((src&0xff00ff)*alpha))>>8)&0xff00ff;
//		g=((((dst&0x00ff00)*alphainv)+((src&0x00ff00)*alpha))>>8)&0x00ff00;

//		int col=rb+g;
//		r=getRed(col);
//		g=getGreen(col);
//		b=getBlue(col);

		int da=getAlpha(dst);
		int sa=getAlpha(src);
		int dr=getRed(dst);
		int sr=getRed(src);
		int dg=getGreen(dst);
		int sg=getGreen(src);
		int db=getBlue(dst);
		int sb=getBlue(src);
//		a=col1*(alpha) + col2*(255-alpha);

		a=da * (1-fa) + sa * (fa);
		r=dr * (1-fa) + sr * (fa);
		g=dg * (1-fa) + sg * (fa);
		b=db * (1-fa) + sb * (fa);

		pixelt[i]=ARGB32(a,r,g,b);
	}
}

void Layer::BlendAdd(int tobuffer, int frombuffer)
{
	unsigned int *pixelt,*pixelf;
	int size, i,x,y;
	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
//	size=getSizeBuffer(frombuffer);
//	size=getSizeBuffer(tobuffer);
	int widthf=getWidthBuffer(frombuffer);
	int heightf=getHeightBuffer(frombuffer);

//	for (i=0; i<size; i++) asm_plotadd(pixelt++, i, *pixelf++);
	for (y=0; y<heightf; y++)
	{
		int addr=y*widthf;
		for (x=0; x<widthf; x++)
			asm_plotadd(pixelt, x+addr, *pixelf++);
	}
}

void Layer::BlendAdd(int tobuffer, int frombuffer, int alpha)
{
	int size, x,y,i, rb, g;
	unsigned int *pixelt, *pixelf;

	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	int widthf=getWidthBuffer(frombuffer);
	int heightf=getHeightBuffer(frombuffer);

	if (alpha<0) alpha=0;
	else if (alpha>=255) alpha=255;

//	for (i=0;i<size;)
	for (y=0; y<heightf; y++)
	{
		int addr=y*320;
		for (x=0; x<widthf; x++)
		{
			rb=RB_(((RB_(*pixelf)*alpha))>>8);
			g=G_(((G_(*pixelf++)*alpha))>>8);
//			asm_plotadd(pixelt, i++, rb+g);
			asm_plotadd(pixelt, x+addr, rb+g);
		}
	}
}

void Layer::BlendSub(int tobuffer, int frombuffer)
{
	unsigned int *pixelt,*pixelf;
	int size, i;
	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	for (i=0;i<size;) asm_plotsub(pixelt, i++, *pixelf++);
}

void Layer::BlendSub(int tobuffer, int frombuffer, int alpha)
{
	int size, i, rb, g;
	unsigned int *pixelt, *pixelf;

	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);

	if (alpha<0) alpha=0;
	else if (alpha>=255) alpha=255;

	for (i=0;i<size;)
	{
		rb=RB_(((RB_(*pixelf)*alpha))>>8);
		g=G_(((G_(*pixelf++)*alpha))>>8);
		asm_plotsub(pixelt, i++, rb+g);
	}
}

void Layer::BlendMask(int tobuffer, int frombuffer)
{
	unsigned int rb,r,g,dst,src,i;
	int alpha;
	unsigned char alphainv;
	unsigned int *pixel, *pixel2;

	pixel=getPixelBuffer(tobuffer);
	pixel2=getPixelBuffer(frombuffer);
	unsigned char *cpixel=(unsigned char *)pixel2;

	size=getWidthBuffer(frombuffer)*getHeightBuffer(frombuffer);

	for (i=0; i<size; i++)
	{
		alpha=255-cpixel[(i<<2)+3];	//should be +3 because theres where the alpha channel is
		alphainv=255-alpha;			//but atm im just using the blue channel.
		dst=*pixel;
		src=*pixel2++;
		rb=((((dst&0xff00ff)*alpha)+((src&0xff00ff)*alphainv))>>8)&0xff00ff;
		g=((((dst&0x0000ff00)*alpha)+((src&0x0000ff00)*alphainv))>>8)&0x0000ff00;
		*pixel++=rb+g;
	}
}

void Layer::BlendMask(int tobuffer, int frombuffer, int amount)
{
	int alpha, width, height;
	unsigned int x,y,addw,rb,r,g,dst,src,i=0;
	unsigned char alphainv;
	unsigned int *pixelt, *pixelf;

	pixelt=getPixelBuffer(tobuffer);
	pixelf=getPixelBuffer(frombuffer);
	unsigned char *cpixel=(unsigned char *)pixelf;

	amount=amount>255?255:amount;
	addw=0;
	i=0;

	width=getWidthBuffer(tobuffer);
	height=getHeightBuffer(tobuffer);
	for (y=0; y<height; y++)
	{
		for (x=0; x<width; x++)
		{
			alpha=255-(cpixel[(i<<2)+3]-(255-amount));	//+3 is where the alpha channel is
			alpha=(alpha>255)?255:alpha;
			alphainv=255-alpha;
			dst=pixelt[x+addw];
			src=*pixelf++;
			rb=((((dst&0xFF00FF)*alpha)+((src&0xff00ff)*alphainv))>>8)&0xFF00FF;
			g=((((dst&0x0000FF00)*alpha)+((src&0x0000FF00)*alphainv))>>8)&0x0000FF00;
			pixelt[x+addw]=rb+g;
			i++;
		}
		addw+=width;
	}
}

void Layer::Darken(int tobuffer, int frombuffer, float factor)
{
	int size=getSizeBuffer(tobuffer);
	uint *pixelf=getPixelBuffer(frombuffer);
	uint *pixelt=getPixelBuffer(tobuffer);
	int i,r,g,b;
	for (i=0; i<size; i++)
	{
		r=getRed(pixelf[i]);;
		g=getGreen(pixelf[i]);
		b=getBlue(pixelf[i]);
		if ( (r!=0) && (g!=0) && (b!=0) )
			pixelt[i]=RGB32((int)(r*factor),(int)(g*factor),(int)(b*factor));
	}
}

void Layer::Invert(int tobuffer, int frombuffer, int amount)
{
	int i,r1,r2,g1,g2,b1,b2,r3,g3,b3,mul;
	unsigned char *cpixelt=(unsigned char *)getPixelBuffer(tobuffer);
	unsigned char *cpixelf=(unsigned char *)getPixelBuffer(frombuffer);

	size=getWidthBuffer(frombuffer)*getHeightBuffer(frombuffer);

	for (i=0; i<size; i++)
	{
		mul=(i<<2);
		r1=(255-cpixelf[2+mul])-(255-amount);
		g1=(255-cpixelf[1+mul])-(255-amount);
		b1=(255-cpixelf[mul])-(255-amount);
		if (r1<0) r1=0;
		if (g1<0) g1=0;
		if (b1<0) b1=0;
		r2=cpixelf[2+mul]-amount;
		g2=cpixelf[1+mul]-amount;
		b2=cpixelf[mul]-amount;
		if (r2<0) r2=0;
		if (g2<0) g2=0;
		if (b2<0) b2=0;
		r3=r1+r2;
		g3=g1+g2;
		b3=b1+b2;
		if (r3>255) r3=255;
		if (g3>255) g3=255;
		if (b3>255) b3=255;
		cpixelt[2+mul]=r3;
		cpixelt[1+mul]=g3;
		cpixelt[mul]=b3;
	}
}


void Layer::Plasma(int index, float ftime)
{
//	buffer[index]->Plasma(ftime);

	unsigned int *tbuffer=getPixelBuffer(index);
	int twidth=getWidthBuffer(index);
	int theight=getHeightBuffer(index);
	int twidthhalf=twidth/2;
	int theighthalf=theight/2;
	int col,x,y;
	static float yw,yw2,yw3,yw4,xw,xw2;

	yw2=yw;
	yw4=yw3;
	for (y=0; y<theight; y++)
	{
		yw+=(M_2PI*6)/twidth;
		yw3+=(M_2PI*3)/twidth;
		ysin[y]=5*sin(yw)+10*sin(yw3)+theighthalf;
	}
	yw=yw2+(M_2PI*2)/twidth;
	yw3=yw4+(M_2PI*4)/twidth;

	xw2=xw;
	for (x=0; x<twidth; x++)
	{
		xw+=(M_2PI*2)/theight;
		xcos[x]=5*cos(xw)+twidthhalf;
	}
	xw=xw2+(M_2PI*2)/theight;

	for (y=0; y<theight; y++)
	{
		int addr=ysin[y]&0xff;
		int addr2=y*twidth;
		for (x=0; x<twidth; x++)
		{
			int xc=xcos[x]&0xff;
			col=(addr+xc);
//			if (col>=255) col=255;
//			if (col>=255) col=255;
			tbuffer[x+addr2]=RGB32(col,col,col);
		}
	}
}
//void Layer::Plasma(int index, int rgba, float ftime) { buffer[index]->Plasma(rgb, ftime); }

void Layer::BumpMap(int tobuffer, int mapbuffer, int bumpbuffer, int lightbuffer, int xpos, int ypos)
{
	int x,y;
	int col,dx,dy,rx,ry;
	int cadd,rt,gt,bt;
	int radd,gadd,badd;
	int nx,ny;
	unsigned int *pixelt=getPixelBuffer(tobuffer);
	unsigned char *pixelm=(unsigned char *)getPixelBuffer(mapbuffer);
	unsigned char *pixelb=(unsigned char *)getPixelBuffer(bumpbuffer);
	unsigned char *pixell=(unsigned char *)getPixelBuffer(lightbuffer);
	int widtht, heightt;
	int widthb;
	int widthl,heightl;
	int widthlh,heightlh;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	widthb=getWidthBuffer(bumpbuffer);
	widthl=getWidthBuffer(lightbuffer);
	heightl=getHeightBuffer(lightbuffer);
	widthlh=widthl/2;
	heightlh=heightl/2;

	int xh,yh;

	xh=widtht/2;
	yh=heightt/2;

	xpos+=xh;
	ypos+=yh;
	for (y=0; y<heightt; y++)
	{
		int yb=y*widthb;
		int addr=y*widtht;
		for (x=0; x<widtht; x++)
		{
			nx=pixelb[((x+1 + yb)<<2)] - pixelb[((x-1 + yb)<<2)];
			ny=pixelb[((x + (y+1)*widthb)<<2)] - pixelb[((x + (y-1)*widthb)<<2)];
			nx=nx+widthlh - xpos-x;
			ny=ny+heightlh - ypos-y;
			nx&=0xff;
			ny&=0xff;
			int yl=(ny*widthl);
			radd=buffer[lightbuffer]->cpixel[((yl+nx)<<2)+2];
			gadd=buffer[lightbuffer]->cpixel[((yl+nx)<<2)+1];
			badd=buffer[lightbuffer]->cpixel[((yl+nx)<<2)+0];

			col=sqrt(SQR(xpos-x)+SQR(ypos-y));

			rt=pixelm[((x+addr)<<2)+2] + radd;// - col;
			gt=pixelm[((x+addr)<<2)+1] + gadd;// - col;
			bt=pixelm[((x+addr)<<2)] + badd;// - col;

			(rt>255)?(rt=255):(rt<0)?(rt=0):rt;
			(gt>255)?(gt=255):(gt<0)?(gt=0):gt;
			(bt>255)?(bt=255):(bt<0)?(bt=0):bt;
	
			pixelt[x+addr]=RGB32(rt,gt,bt);
		}
	}
}

void Layer::Flower(int tobuffer, int frombuffer, float time)
{
	int x,y,col,_width,_height,fwidth,fheight,yaddr,yaddr2;

	if (tobuffer==SCREENBUFFER)
	{
		_width=mainbuffer.width;
		_height=mainbuffer.height;
	}
	else
	{
		_width=buffer[tobuffer]->width;
		_height=buffer[tobuffer]->height;
	}

	fwidth=buffer[frombuffer]->width;
	fheight=buffer[frombuffer]->height;

	float xo=(float)(_width/2)+120*(float)sin(time*1.1f+1.5f);
	float yo=(float)(_height/2)+90*(float)cos(time*0.8f+1.1f);
	int offset1=(int)xo+((int)yo)*fwidth;

	float xo2=(float)(_width/2)+120*(float)sin(time*0.9f+4.2f);
	float yo2=(float)(_height/2)+90*(float)cos(time*0.7f+6.9f);
	int offset2=(int)xo2+((int)yo2)*fwidth;

	float xo3=(float)(_width/2)+120*(float)sin(time*0.9f+3.1f);
	float yo3=(float)(_height/2)+90*(float)cos(time*1.1f+1.2f);
	int offset3=(int)xo3+((int)yo3)*fwidth;

	yaddr=0;
	yaddr2=0;
	if (tobuffer==SCREENBUFFER)
	{
		for (y=0; y<_height; y++)
		{
			for (x=0; x<_width; x++)
			{
				col=buffer[frombuffer]->pixel[x+yaddr2+offset1]+
					buffer[frombuffer]->pixel[x+yaddr2+offset2]+
					buffer[frombuffer]->pixel[x+yaddr2+offset3];
//				mainbuffer.pixel[x+yaddr]=RGB32(col,col,col);
				mainbuffer.pixel[x+yaddr]=buffer[tobuffer]->palette[col&0xff];//RGB32(col,col,col);
			}
			yaddr+=_width;
			yaddr2+=fwidth;
		}
	}
	else
	{
	    for (y=0; y<_height; y++)
		{
			for (x=0; x<_width; x++)
			{
				col=buffer[frombuffer]->pixel[x+yaddr2+offset1]+
					buffer[frombuffer]->pixel[x+yaddr2+offset2]+
					buffer[frombuffer]->pixel[x+yaddr2+offset3];
				col=col<0?0:col>255?255:col;
//				buffer[tobuffer]->pixel[x+yaddr]=RGB32(col,cl,col);
				buffer[tobuffer]->pixel[x+yaddr]=buffer[frombuffer]->palette[col&0xff];//RGB32(col,col,col);
//				buffer[tobuffer]->pixel[x+yaddr]=buffer[tobuffer]->palette[col&0xff];//RGB32(col,col,col);
			}
			yaddr+=_width;
			yaddr2+=fwidth;
		}
	}
}

void Layer::FilterEdgeDetection(int tobuffer, int frombuffer)
{
	int x,y,widthf,heightf,yaddr,yaddr2;
	int rc,gc,bc;	//current pixel
	int rr,gr,br;	//right neighbour pixel
	int rb,gb,bb;	//bottom neighbour pixel

	unsigned char *cpixelf=(unsigned char *)getPixelBuffer(frombuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);
	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);

	for (y=0; y<heightf-1; y++)
	{
		yaddr=y*widthf;
		yaddr2=(y+1)*widthf;
		for (x=0; x<widthf-1; x++)
		{
			rc=cpixelf[((x+yaddr)<<2)+2];
			gc=cpixelf[((x+yaddr)<<2)+1];
			bc=cpixelf[((x+yaddr)<<2)];
			rr=cpixelf[((1+x+yaddr)<<2)+2];
			gr=cpixelf[((1+x+yaddr)<<2)+1];
			br=cpixelf[((1+x+yaddr)<<2)];
			rb=cpixelf[((x+yaddr2)<<2)+2];
			gb=cpixelf[((x+yaddr2)<<2)+1];
			bb=cpixelf[((x+yaddr2)<<2)];

			//improve speed by removing the sqrt (todo)
			if ( (sqrt(SQR(rc-rr)+SQR(gc-gr)+SQR(bc-br))>=bb) ||
				(sqrt(SQR(rc-rb)+SQR(gc-gb)+SQR(bc-bb))>=bb) )
			pixelt[x+yaddr]=0xffffff;
//			else
//			buffer[tobuffer]->pixel[x+yaddr]=0;
		}
	}
}

void Layer::Blur(int tobuffer, int frombuffer)
{
	int r,g,b,i,i1,i2,i3,i4;
	int widtht, heightt;
	int addr,addr2;
	unsigned char *cpixel=(unsigned char *)getPixelBuffer(frombuffer);
	unsigned int *pixel=getPixelBuffer(tobuffer);
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	size=widtht*heightt;

	for (i=widtht; i<size; i++)
	{
		i1=((i-1)<<2);
		i2=((i+1)<<2);
		i3=((i-widtht)<<2);
		i4=((i+widtht)<<2);
		r=cpixel[i1+2];
		g=cpixel[i1+1];
		b=cpixel[i1];
		r+=cpixel[i2+2];
		g+=cpixel[i2+1];
		b+=cpixel[i2];
		r+=cpixel[i3+2];
		g+=cpixel[i3+1];
		b+=cpixel[i3];
		r+=cpixel[i4+2];
		g+=cpixel[i4+1];
		b+=cpixel[i4];
		r>>=2;
		g>>=2;
		b>>=2;
		pixel[i]=RGB32(r,g,b);
	}
}

// quick vertical & horizontal blur guru / yaphan (port by activator)
void Layer::BlurH(int tobuffer, int frombuffer, int amount)
{
	int x,y, r,g,b;
	int ir,ig,ib;
	int widthf, heightf,size;
	int col;
	const int mul=(1<<16)/(amount*2+1);
	unsigned int t[3];

	unsigned int *pixelt=getPixelBuffer(tobuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
/*
	for(y=0; y<heightf; y++)
	{
		int addr1=y*widthf;
		for(x=0; x<widthf; x++)
		{
			r=getRed(pixelf[x-amount+addr1])+getRed(pixelf[x+amount+addr1]);
			g=getGreen(pixelf[x-amount+addr1])+getGreen(pixelf[x+amount+addr1]);
			b=getBlue(pixelf[x-amount+addr1])+getBlue(pixelf[x+amount+addr1]);
			r>>=1;
			g>>=1;
			b>>=1;
			pixelt[x+addr1]=RGB32(r,g,b);
		}
	}
*/
	if (amount>1)
	{
		for(y=0; y<heightf; y++)
		{
			t[0]=t[1]=t[2]=0;
			for(x=0; x<amount; x++)
			{
				col=pixelf[x];
				t[0]=getRed(col);
				t[1]=getGreen(col);
				t[2]=getBlue(col);
			}
			for(x=0; x<widthf; x++)
			{
				if(x>amount)
				{
					col=pixelf[1-amount];
					t[0]-=(col&0xff0000);
					t[1]-=(col&0xff00);
					t[2]-=(col&0xff);
				}
				if((x+amount)<widthf)
				{
					col=pixelf[amount];
					t[0]+=(col&0xff0000);
					t[1]+=(col&0xff00);
					t[2]+=(col&0xff);
				}
	
				r=((t[0]>>16)*mul)&0xff0000;
				g=(((t[1]>>8)*mul)>>8)&0xff00;
				b=((t[2]*mul)>>16)&0xff;
				*pixelt++=r|g|b;
				pixelf++;
			}
		}
	}
	else
		CopyBuffer(tobuffer, frombuffer);
}

void Layer::BlurHorisontal(int tobuffer)
{
	int x,y,r,g,b;
	int widtht,heightt;

	unsigned int *pixelt=getPixelBuffer(tobuffer);
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);

	for(y=0; y<heightt; y++)
	{
		int addr1=y*widtht;
		for(x=0; x<widtht; x++)
		{
			r=getRed(pixelt[x-1+addr1])+getRed(pixelt[x+1+addr1]);
			g=getGreen(pixelt[x-1+addr1])+getGreen(pixelt[x+1+addr1]);
			b=getBlue(pixelt[x-1+addr1])+getBlue(pixelt[x+1+addr1]);
			r>>=1;
			g>>=1;
			b>>=1;
			pixelt[x+addr1]=RGB32(r,g,b);
		}
	}
}

void Layer::geff_blur_fast_horiz(int tobuffer, int frombuffer, int xsize, int ysize, int amount)
{
	int *src=(int *)getPixelBuffer(tobuffer);
	int *dst=(int *)getPixelBuffer(frombuffer);
	int x, y;
	int t[3];
	int r, g, b;
	const int mul=(1<<16)/(amount*2+1);
	int col;
	for(y=0; y<ysize; y++)
	{
		t[0]=t[1]=t[2]=0;
		for(x=0; x<amount; x++)
		{
			col=src[x];
			t[0]+=(col&0x00FF0000);
			t[1]+=(col&0x0000FF00);
			t[2]+=(col&0x000000FF);
		}
		for(x=0; x<xsize; x++)
		{
			if(x>amount)
			{
//				col=src[-amount-1];
				col=src[(amount-1)-amount];
				t[0]-=(col&0x00FF0000);
				t[1]-=(col&0x0000FF00);
				t[2]-=(col&0x000000FF);
			}
			if((x+amount)<xsize)
			{
				col=src[amount];
				t[0]+=(col&0x00FF0000);
				t[1]+=(col&0x0000FF00);
				t[2]+=(col&0x000000FF);
			}
			r=((t[0]>>16)*mul)&0xFF0000;
			g=(((t[1]>>8)*mul)>>8)&0xFF00;
			b=((t[2]*mul)>>16)&0xFF;
			*dst++=r|g|b;
			src++;
		}
	}
}

//void Layer::geff_blur_fast_vert(int *src, int *dst, int xsize, int ysize, int amount)
void Layer::geff_blur_fast_vert(int tobuffer, int frombuffer, int xsize, int ysize, int amount)
{
	int *src=(int *)getPixelBuffer(tobuffer);
	int *dst=(int *)getPixelBuffer(frombuffer);
	int x, y;
	int t[3];
	int r, g, b;
	const int mul=(1<<16)/(amount*2+1);
	const int v1=-(amount-1)*xsize;
	const int v2=amount*xsize;
	int v3;
	int col;
	int *dst_ptr, *src_ptr;

	for(x=0; x<xsize; x++)
	{
		t[0]=t[1]=t[2]=0;

		src_ptr=&src[x];
		dst_ptr=&dst[x];
		// v3=0;
		for(y=0; y<amount; y++)
		{
			// col=src_ptr[v3];
			col=src_ptr[y*xsize];
			t[0]+=(col&0x00FF0000);
			t[1]+=(col&0x0000FF00);
			t[2]+=(col&0x000000FF);
			// v3+=xsize;
		}
		for(y=0; y<ysize; y++)
		{
			if(y>amount)
			{
				// col=*(src_ptr+v1);
				col=src_ptr[v1];
				t[0]-=(col&0x00FF0000);
				t[1]-=(col&0x0000FF00);
				t[2]-=(col&0x000000FF);
			}
			if((y+amount)<ysize)
			{
				// col=src_ptr[amount*xsize];
				// col=*(src_ptr+v2);
				col=src_ptr[v2];
				t[0]+=(col&0x00FF0000);
				t[1]+=(col&0x0000FF00);
				t[2]+=(col&0x000000FF);
			}
			r=((t[0]>>16)*mul)&0xFF0000;
			g=(((t[1]>>8)*mul)>>8)&0x00FF00;
			b=((t[2]*mul)>>16)&0x0000FF;
			*dst_ptr=r|g|b;
			dst_ptr+=xsize;
			src_ptr+=xsize;
		}
	}
}

//impl by act (original by guru)
void Layer::Mosaic(int tobuffer, int frombuffer, int ratio)
{
	int x,y,i,j,tot,totc,mul;
	g_irgb sum;
	
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	unsigned int *buffert=getPixelBuffer(tobuffer);
	unsigned int *bufferf=getPixelBuffer(frombuffer);

	unsigned char *cbufferf=(unsigned char *)bufferf;

	for(y=0; y<heightt; y+=ratio)
	for(x=0; x<widtht; x+=ratio)
	{
		totc=0;
		sum.r=0;
		sum.g=0;
		sum.b=0;
		for(j=y; j<(y+ratio); j++)
		for(i=x; i<(x+ratio); i++)
		{
			mul=((i+(j*widtht))<<2);
			sum.r+=cbufferf[2+mul];
			sum.g+=cbufferf[1+mul];
			sum.b+=cbufferf[mul];
		}
		tot=SQR(ratio);
		sum.r/=tot;
		sum.g/=tot;
		sum.b/=tot;
		for(j=y; j<(y+ratio); j++)
		for(i=x; i<(x+ratio); i++)
			buffert[i+(j)*widtht]=RGB32(sum.r,sum.g,sum.b);
    }
/*	for(x=0; x<widtht; x++)
	{
		buffert[x+yaddr[0]]=0;
		buffert[x+yaddr[HEIGHT-1]]=0;
	}
	for(y=0; y<heightt; y++)
	{
		buffert[0+yaddr[y]]=0;
		buffert[WIDTH-1+yaddr[y]]=0;
	}*/
}

void Layer::Stretch(int tobuffer, int frombuffer, int posx, int posy, int s)
{
	int x,y,r,g,b;
	int widtht,heightt;
	int widthf,heightf;
	int col;

	unsigned int *pixelt=getPixelBuffer(tobuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);
	unsigned char *pixelc=(unsigned char *)pixelf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);

	long c=0;
	int totpix=s+1;
	int totpix2=totpix*2;

	int addr;
	for (y=0; y<200; y++)
	{
		addr=y*320;
		for (x=0; x<320; x++)
		{
			for (int i=0; i<totpix; i++)
			{
//				col=*(pixelf+addr+x+i-s);
				int mul=((addr+x+i-s)<<2);
				int mul2=((addr+x+s-i)<<2);
				r+=*(pixelc+mul+2);
				g+=*(pixelc+mul+1);
				b+=*(pixelc+mul);
				r+=*(pixelc+mul2+2);
				g+=*(pixelc+mul2+1);
				b+=*(pixelc+mul2);
			}
			r/=totpix2;
			g/=totpix2;
			b/=totpix2;
			pixelt[posx+x+addr]=RGB32(r,g,b);
			r=g=b=0;
		}
	}
}

void Layer::Bounce(int tobuffer, int frombuffer)
{
	int x,y;
	int widtht;
	int size,sizec;

	unsigned int *pixelt=getPixelBuffer(tobuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);
	unsigned char *pixeltc=(unsigned char *)pixelt;
	unsigned char *pixelfc=(unsigned char *)pixelf;

	widtht=getWidthBuffer(frombuffer);
	size=getSizeBuffer(frombuffer);
	sizec=getCSizeBuffer(frombuffer);

	x=rand()*30/sizec;
	y=rand()*30/sizec;
	int i=((x+y*widtht)*4);//<<2);
	memcpy(pixeltc, pixelfc+i, sizec-(widtht*(y+1)));
	g_line((int*)pixelt,0,HEIGHT-1,WIDTH,HEIGHT-1,0);
	g_line((int*)pixelt,0,HEIGHT-2,WIDTH,HEIGHT-2,0);
}

void Layer::MotionBlur(int tobuffer, int frombuffer, int amount)
{
	int i,j,size;
	unsigned int mask=0xfefefe;

	if (tobuffer==SCREENBUFFER)
	{
		size=(mainbuffer.width*mainbuffer.height);
		for (j=0; j<amount; j++)
		for (i=0; i<size; i++)
			mainbuffer.pixel[i]=((buffer[frombuffer]->pixel[i]&mask)+(mainbuffer.pixel[i]&mask))>>1;
		for (i=0; i<size; i++) buffer[frombuffer]->pixel[i]=mainbuffer.pixel[i];
	}
	else
	{
		size=(buffer[tobuffer]->width*buffer[tobuffer]->height);
		for (j=0; j<amount; j++)
		for (i=0; i<size; i++)
//			frombuffer.buffer[i]=((tobuffer.buffer[i]&0xfefefe)+(frombuffer.buffer[i]&0xfefefe))>>1;
//		s_copy(tobuffer, frombuffer);
			buffer[tobuffer]->pixel[i]=((buffer[frombuffer]->pixel[i]&mask)+(buffer[tobuffer]->pixel[i]&mask))>>1;
		for (i=0; i<size; i++) buffer[frombuffer]->pixel[i]=buffer[tobuffer]->pixel[i];
	}
}

void Layer::InitTunnel(int tobuffer, int perspective)
{
	float f;
	int x,y;

//	flut=(unsigned long *)malloc(SIZE*4);
//	alpha_table=(unsigned int *)malloc(256*256*sizeof(unsigned int));
//	Tsqrt=(int *)malloc(SIZE*sizeof(int));
//	Tatan2=(int *)malloc(SIZE*sizeof(int));

//	perspective:
//	u = r / sqrt(x*x+y*y)
//	v = atan(y/x)

//	squish:
//	u = sqrt(x*x+y*y)
//	v = atan(y/x)
/*

//	int MAPSIZE=256;
	for (y=-HEIGHT_HALF; y<HEIGHT_HALF; y++)
	for (x=-WIDTH_HALF; x<WIDTH_HALF; x++)
	{
//		int col=perspective/(255-sqrt(x*x+y*y));
		int col=perspective/(sqrt(SQR(x)+SQR(y))+1);
//		int col=perspective/(sqrt(x*x+y*y)+sin(y*0.25)*2+cos(x*0.1)*8+1);
		Tsqrt[x+WIDTH_HALF+(y+HEIGHT_HALF)*WIDTH]=col;//unsigned char((float)PER/(sqrt(x*x+y*y))) % 256;//6000/
//		Tsqrt[x+160][y+120]=unsigned char((float)(sqrt(x*x+y*y))) % 256;//6000/
//		Tatan2[x+160][y+120]=unsigned char((float)(atan2(y,x)*MAPSIZE/PI)) % 256;
		Tatan2[x+WIDTH_HALF+(y+HEIGHT_HALF)*WIDTH]=unsigned char((float)(atan2(y,x)*SCALEFACTOR));

		col=400-col;
		if (col<0) col=0;
		if (col>255) col=255;
//		flut[x+WIDTH_HALF+(y+HEIGHT_HALF)*WIDTH]=col;
	}

	for (x=0; x<256; x++)
	for (y=0; y<256; y++)
	{
		f=ROUND(((float)x/255)*(float)y);
//		alpha_table[x*256+y]=(int)f;
	}
	*/

//	int x,y;
	long r;
	float x2, y2, angle;

	int widtht,heightt, widthth, heightth;
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);

	widthth=widtht/2;
	heightth=heightt/2;

	int size=widtht*heightt;
	AngTable=(uchar *)malloc(size*sizeof(uchar));
	RadTable=(uchar *)malloc(size*sizeof(uchar));

	for (y=-heightth; y<heightth; y++)
	for (x=-widthth; x<widthth; x++)
	{
		x2=x;
		y2=y;
		angle=atan2(y2,x2);
		angle*=(256/M_2PI);
		AngTable[(y+heightth)*widtht+x+widthth]=((long)angle)&0xff;
//		RadTable[(y+HEIGHT_HALF)*WIDTH+x+WIDTH_HALF]=((long)sqrt(SQR(y)+SQR(x)))&255;

//Adding perspective... 
/*		r=sqrt(SQR(x)+SQR(y));
		r=256*pow((float)(256*1024*r),0.1);
		RadTable[x+widthth+(y+heightth)*widtht]=r&255;
		*/
/*
		r=sqrt(SQR(x)+SQR(y));
//		r=256*pow((float)(256*1024*r),0.1);
//		r=r+256*sin(r*1.284/64);
//		r=r+64*sin(r*1.284/64);
//		r=r+256*sin(r*1.284/64);
		r=r+128*sin(r*1.284/32);
		RadTable[x+widthth+(y+heightth)*widtht]=r&255;
*/
/*		r=sqrt(SQR(x)+SQR(y));
		r=256*pow((float)(256*1024*r),0.1);
		RadTable[x+widthth+(y+heightth)*widtht]=r&255;
*/
/*		r=sqrt((x*x)+(y*y));
		r=r+256*sin(r*1.284/64);
		RadTable[x+widthth+(y+heightth)*widtht]=r&255;
*/
		r=sqrt((x*x)+(y*y));
		r=64*pow((float)(256*1024*r),0.1);
		RadTable[x+widthth+(y+heightth)*widtht]=(r&255);
/*
		r=r+64*sin(r*1.284/64);
		RadTable[x+widthth+(y+heightth)*widtht]=r&0xff;*/
	}
}

void Layer::InitTunnel2(int perspective)
{
/*	int x,y;
	long r;
	float x2, y2, angle;
	int width=mainbuffer.width;
	int height=mainbuffer.height;
	int whalf=width/2;
	int hhalf=height/2;
	int size=width*height;

	AngTable=(uchar *)malloc(size*sizeof(uchar));
	RadTable=(uchar *)malloc(size*sizeof(uchar));

	for (y=-hhalf; y<hhalf; y++)
	for (x=-whalf; x<whalf; x++)
	{
		x2=x;
		y2=y;
		angle=atan2(y2,x2);
		angle*=(256/M_2PI);
		AngTable[(y+hhalf)*width+x+whalf]=((long)angle)&255;
//		RadTable[(y+hhalf)*width+x+whalf]=((long)sqrt(SQR(y)+SQR(x)))&255;

//Adding perspective... 
//		r=sqrt(SQR(x)+SQR(y));
//		r=256*pow((float)(256*1024*r),0.1);
//		RadTable[x+whalf+(y+hhalf)*width]=r&255;

		r=sqrt(SQR(x)+SQR(y));
//		r=256*pow((float)(256*1024*r),0.1);
//		r=1024*pow((float)(256*1024*r),0.1);
		r=1024*pow((float)(256*1024*r),0.04);
//		r=r+256*sin(r*1.284/64);
//		r=r+128*sin(r*1.284/32);
//		r=r+64*sin(r*1.284/64);
		RadTable[x+whalf+(y+hhalf)*width]=r&255;
	}*/
}

void Layer::Tunnel2D(int tobuffer, int texture, int radius, int angle)
{
	int x,y,xt,yt,addr,addr2;
	int widtht,heightt,texwidth,texheight;
	unsigned int *pixel;

	texwidth=buffer[texture]->width;
	texheight=buffer[texture]->height;
	
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixel=getPixelBuffer(tobuffer);

	for (y=0; y<heightt; y++)
	{
		addr=y*widtht;
		for (x=0; x<widtht; x++)
		{
			yt=(radius+RadTable[x+addr]&0xff);
			xt=(angle+AngTable[x+addr]&0xff);
			addr2=yt*texwidth;
			pixel[x+addr]=buffer[texture]->pixel[addr2+xt];
		}
	}
}

//void Layer::Water2D(int tobuffer, int buffer1, int buffer2, int frombuffer)
void Layer::Water2D(int tobuffer, int buffer1, int buffer2, int frombuffer, int shadefactor)
{
	int x,y;
	int r,g,b;

	unsigned int *pixel, *pbuffer1, *pbuffer2, *image;
	unsigned char *cpbuffer1, *cpbuffer2, *cimage;
	int widtht, heightt, widthf;

	widtht=getWidthBuffer(tobuffer);
	widthf=getWidthBuffer(buffer2);
	heightt=getHeightBuffer(tobuffer);

	pixel=getPixelBuffer(tobuffer);
	pbuffer1=getPixelBuffer(buffer1);
	pbuffer2=getPixelBuffer(buffer2);
	image=getPixelBuffer(frombuffer);


	cpbuffer1=(unsigned char *)pbuffer1;
	cpbuffer2=(unsigned char *)pbuffer2;
//	ctemp=(unsigned char *)temp;


	//swap buffers
	for (int i=0; i<widtht*heightt; i++)
	{
		int col=pbuffer2[i];
		pbuffer2[i]=pbuffer1[i];
		pbuffer1[i]=col;
	}
	
//	float damping=1.0;
	float damping=0.99;
//	float damping=0.9;

	for (x=1; x<widtht-1; x++)
	for (y=1; y<heightt-1; y++)
	{

		int c = (getBlue(pbuffer1[x - 1 + y*widthf]) +
			getBlue(pbuffer1[x + 1 + y*widthf]) +
			getBlue(pbuffer1[x + (y + 1)*widthf]) +
			getBlue(pbuffer1[x + (y - 1)*widthf])) / 2 - getBlue(pbuffer2[x+y*widthf]);

		if (c>=255) c=255;
		if (c<0) c=0;
		pbuffer2[x+y*widtht]=c;

		c = (int)((float)getBlue(pbuffer2[x+y*widtht])*damping);

		if (c>=255) c=255;
		if (c<0) c=0;
		pbuffer2[x+y*widtht]=c;//RGB32(r,g,b);
	}

	//display buffer2
	for (x=1; x<widtht-1; x++)
	for (y=1; y<heightt-1; y++)
	{
		int xoffset = getBlue(pbuffer1[x-1 + y*widthf]) - getBlue(pbuffer1[x+1 + y*widthf]);
		int yoffset = getBlue(pbuffer1[x + (y-1)*widthf]) - getBlue(pbuffer1[x + (y+1)*widthf]);

		if (xoffset>319) xoffset=319;
		if (xoffset<0) xoffset=0;
		if (yoffset>199) yoffset=199;
		if (yoffset<0) yoffset=0;

//		int shading=xoffset*2;
//		int shading=xoffset*4;
		int shading=xoffset*shadefactor; //shadefactor should always be > 0
//		int shading=xoffset*8;

		r = getRed(image[x+xoffset+(y+yoffset)*widthf])+shading;
		g = getGreen(image[x+xoffset+(y+yoffset)*widthf])+shading;
		b = getBlue(image[x+xoffset+(y+yoffset)*widthf])+shading;

		if (r>=255) r=255;
		if (r<0) r=0;
		if (g>=255) g=255;
		if (g<0) g=0;
		if (b>=255) b=255;
		if (b<0) b=0;

		pixel[x+y*widtht]=RGB32(r,g,b);
	}
}

void Layer::DrawBox(int tobuffer, int x1, int y1, int x2, int y2, int col)
{
	unsigned int *tbuffer=getPixelBuffer(tobuffer);
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	g_line((int *)tbuffer, x1, y1, x2, y1, widtht, heightt, col);
	g_line((int *)tbuffer, x2, y1, x2, y2, widtht, heightt, col);
	g_line((int *)tbuffer, x2, y2, x1, y2, widtht, heightt, col);
	g_line((int *)tbuffer, x1, y2, x1, y1, widtht, heightt, col);
}

void Layer::InvertRectangle(int tobuffer, int px1, int py1, int px2, int py2, int frombuffer, int amount)
{
	int x,y;
	int r1,r2,g1,g2,b1,b2,r3,g3,b3;
	int addr, mul;

	int width=getWidthBuffer(tobuffer);
	unsigned char *fpixel=(unsigned char *)getPixelBuffer(frombuffer);
	unsigned char *tpixel=(unsigned char *)getPixelBuffer(tobuffer);
	for (y=py1; y<py2; y++)
	{
		addr=y*width;
		for (x=px1; x<px2; x++)
		{
			mul=((x+addr)<<2);
			r1=(255-fpixel[2+mul])-(255-amount);
			g1=(255-fpixel[1+mul])-(255-amount);
			b1=(255-fpixel[mul])-(255-amount);
			if (r1<0) r1=0;
			if (g1<0) g1=0;
			if (b1<0) b1=0;
			r2=tpixel[2+mul]-amount;
			g2=tpixel[1+mul]-amount;
			b2=tpixel[mul]-amount;
			if (r2<0) r2=0;
			if (g2<0) g2=0;
			if (b2<0) b2=0;
			r3=r1+r2;
			g3=g1+g2;
			b3=b1+b2;
			if (r3>255) r3=255;
			if (g3>255) g3=255;
			if (b3>255) b3=255;
			tpixel[2+mul]=r3;
			tpixel[1+mul]=g3;
			tpixel[mul]=b3;
		}
	}
}

void Layer::InvertRectangleAnim(int tobuffer, int px1, int py1, int px2, int py2, int col, float zero_to_one, int frombuffer, int amount)
{
	int x1,y1,x2,y2;
	int center_x, center_y;
	int mx1, my1, mx2, my2;
	float zero_to_one2=zero_to_one*2.0f;

	//calculate centers:
	center_x=px1+(px2-px1)/2.0;
	center_y=py1+(py2-py1)/2.0;

	if (zero_to_one<0.0f) zero_to_one=0.0f;
	if (zero_to_one>1.0f) zero_to_one=1.0f;

	if (zero_to_one>=0.0f && zero_to_one<=0.5f)
	{
		mx1=(zero_to_one2*px1)+((1-zero_to_one2)*center_x);
		my1=center_y;
		mx2=(zero_to_one2*px2)+((1-zero_to_one2)*center_x);
		my2=center_y;
	}
	else
	if (zero_to_one>=0.5f && zero_to_one<=1.0f)
	{
		mx1=px1;
		my1=(py1*(zero_to_one-0.5)*2)+(1-((zero_to_one-0.5)*2))*center_y;
		mx2=px2;
		my2=(py2*(zero_to_one-0.5)*2)+(1-((zero_to_one-0.5)*2))*center_y;
	}

/*
//	this one is for center_coords to ordinary_coords motion.
	mx1=(zero_to_one*px1)+((1-zero_to_one)*center_x);
	my1=(zero_to_one*py1)+((1-zero_to_one)*center_y);
	mx2=(zero_to_one*px2)+((1-zero_to_one)*center_x);
	my2=(zero_to_one*py2)+((1-zero_to_one)*center_y);
*/
	DrawBox(tobuffer, mx1, my1, mx2, my2, col);
	InvertRectangle(tobuffer, mx1+1, my1+1, mx2, my2, frombuffer, amount);
}



void Layer::InitTables()
{
	int i,col;

	light_radius=(int *)malloc(64*sizeof(int));
	light_radius_temp=(int *)malloc(64*sizeof(int));
//	for (i=0; i<36; i++) light_radius[i]=rand()%40;
//	for (i=0; i<36; i++) light_radius[i]=i%2?(rand()%20):8;
	for (i=0; i<48; i++) light_radius[i]=i%2?(rand()%40):8;
}

void Layer::PerformLight(int tobuffer, int px, int py)
{
	int widtht,heightt;
	unsigned int *pixelt;
	int nx, ny, nx2, ny2, i;
	float fa;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	if (heightt==180) fa=0.5;
	else fa=1;

//	bool palette_flag=getPaletteflagBuffer(tobuffer);
//	unsigned int *palettet=getPaletteBuffer(tobuffer);

	g_irgb c[3];
	c[1].r=255;
	c[1].g=255;
	c[1].b=255;

	c[2].r=0;
	c[2].g=0;
	c[2].b=0;

/*	c[1].r=0xff;
	c[1].g=0xff;
//	c[1].b=0x4b;
	c[1].b=0x7b;
//	c[1].b=0xff;

//	c[2].r=0x39;
//	c[2].g=0x16;
	c[2].r=0x09;
	c[2].g=0x06;
	c[2].b=0x0d;
*/
	nx=px + (int)((float)light_radius[0]*cos(0));
	ny=py + (int)((float)light_radius[0]*sin(0));

	//radius & degrees
	for (i=0; i<49; i++)
	{
		light_radius_temp[i%48]=light_radius[i%48];

//		float r=50 + sin(ftime*4)*light_radius_temp[i%36];
//		float r=50 + sin(i*9+ftime*4) * light_radius_temp[i%36];
		float r=50 + sin(i+ftime*8) * light_radius_temp[i%48];
//		float r=50 + light_radius_temp[i];


		float deg=DEG2RAD(i*7.5);
//		nx2=px + (int)((float)r*cos(deg));
//		ny2=py + (int)((float)r*sin(deg)*fa);

//		nx2=px + (int)((float)r*cos(deg)*0.5);
//		ny2=py + (int)((float)r*sin(deg)*fa*0.5);
		nx2=px + (int)((float)r*cos(deg+ftime*1.5));
		ny2=py + (int)((float)r*sin(deg+ftime*1.5)*fa*0.75);

/*		if (palette_flag==off)
		{*/
			g_tri_gouraud((int *)pixelt, widtht,
				nx, ny, c[0],
				px, py, c[1], 
				nx2, ny2, c[2]);
/*		}	
		else
		{
			g_tri_gouraud_palette((int *)pixelt, widtht,
				nx, ny, c[0],
				px, py, c[1], 
				nx2, ny2, c[2], palettet);
		}*/


		nx=nx2;
		ny=ny2;

		c[0]=c[2];

//		g_line((int *)pixelt, px, py, nx, ny, 0xffffff);
	}
}
void Layer::BorderHorisontal(int tobuffer, int upperpos, int lowerpos, int col)
{
	int x,y,yaddr;
	unsigned int *pixel;

	if (tobuffer==SCREENBUFFER) pixel=mainbuffer.pixel;
	else pixel=buffer[tobuffer]->pixel;

	for (y=0; y<upperpos; y++)
	{
		yaddr=y*width;
		for (x=0; x<width; x++) pixel[x+yaddr]=col;
	}

	for (y=lowerpos; y<height; y++)
	{
		yaddr=y*width;
		for (x=0; x<width; x++) pixel[x+yaddr]=col;
	}
}

void Layer::Run()
{
	//the effect

//	mainbuffer.Clear();

//	mainbuffer.pixel=buffer[0]->pixel;

//	mainbuffer.BlendNormal(mainbuffer, *buffer[0], 255);
//	mainbuffer.BlendNormal(*buffer[0], 127+sin(ftime)*127);
}

/*
PixelFrameBuffer *Layer::get_buffer(int index)
{
	if ((index<0) || (index>=num_buffer)) return 0;
	return buffer[index];
}
*/

void Layer::DrawBoxFilled(int tobuffer, int px, int py, int sx, int sy, int col)
{
	int x,y,addr,widtht, heightt;
	unsigned int *pixelt;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	for (y=0; y<sy; y++)
	{
		addr=(y+py)*widtht;
		for (x=0; x<sx; x++)
			if (visible(x+px, y+py, widtht, heightt))
				asm_plotadd(pixelt, (x+px)+addr, col);
	}
}

void Layer::PutBuffer(int tobuffer, int frombuffer, int posx, int posy, bool inv)
{
	int x,y,addr,addr2;
	unsigned int *pixelt,*pixelf;
	int widtht, heightt, widthf, heightf;
	int mode=buffer[frombuffer]->maskMode;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	if (mode==MASK_DEFAULT)
	{
		for (y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
//			for (x=0; x<widthf; x++) pixelt[(x+posx)+addr]=pixelf[x+addr2];
			for (x=0; x<widthf; x++)
				if (visible(x+posx,y+posy, widtht, heightt))
				{
					if (inv==true)
					{
						int r=getRed(pixelf[x+addr2]);
						int g=getGreen(pixelf[x+addr2]);
						int b=getBlue(pixelf[x+addr2]);
						pixelt[(x+posx)+addr]=RGB32(255-r,255-g,255-b);
					}
					else
						pixelt[(x+posx)+addr]=pixelf[x+addr2];
				}
		}
	}
	else
	if (mode==MASK_NONZERO)
	{
		for (y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
//			for (x=0; x<widthf; x++) if (pixelf[x+addr2]!=0) pixelt[(x+posx)+addr]=pixelf[x+addr2];
			for (x=0; x<widthf; x++)
				if (visible(x+posx,y+posy, widtht, heightt))
//					if (pixelf[x+addr2]!=0xff000000) pixelt[(x+posx)+addr]=pixelf[x+addr2];
					if ((pixelf[x+addr2]&0x00ffffff)!=0) pixelt[(x+posx)+addr]=pixelf[x+addr2];
		}
	}
}

void Layer::PutBuffer(int tobuffer, int frombuffer, int posx, int posy)
{
	int x,y,addr,addr2;
	unsigned int *pixelt,*pixelf;
	int widtht, heightt, widthf, heightf;
	int mode=buffer[frombuffer]->maskMode;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	unsigned int *palette=getPaletteBuffer(tobuffer);
	bool palette_flag=getPaletteflagBuffer(tobuffer);

	if (palette_flag==true)
	{
		for (y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
			for (x=0; x<widthf; x++)
				if (visible(x+posx,y+posy, widtht, heightt))
					pixelt[(x+posx)+addr]=palette[pixelf[x+addr2]];
		}
	}
	else
	if (mode==MASK_DEFAULT)
	{
		for (y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
//			for (x=0; x<widthf; x++) pixelt[(x+posx)+addr]=pixelf[x+addr2];
			for (x=0; x<widthf; x++)
				if (visible(x+posx,y+posy, widtht, heightt))
						pixelt[(x+posx)+addr]=pixelf[x+addr2];
		}
	}
	else
	if (mode==MASK_NONZERO)
	{
		for (y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
//			for (x=0; x<widthf; x++) if (pixelf[x+addr2]!=0) pixelt[(x+posx)+addr]=pixelf[x+addr2];
			for (x=0; x<widthf; x++)
				if (visible(x+posx,y+posy, widtht, heightt))
//					if (pixelf[x+addr2]!=0xff000000) pixelt[(x+posx)+addr]=pixelf[x+addr2];
					if ((pixelf[x+addr2]&0x00ffffff)!=0) pixelt[(x+posx)+addr]=pixelf[x+addr2];
		}
	}
}

void Layer::PutBufferPalette(int tobuffer, int frombuffer, int posx, int posy, int pall_for_black, int pall_for_white)
{
	int x,y,addr,addr2;
	unsigned int *pixelt,*pixelf;
	int widtht, heightt, widthf, heightf;
	int mode=buffer[frombuffer]->maskMode;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	unsigned int *palette=getPaletteBuffer(tobuffer);

	for (x=0; x<widthf; x++)
	for (y=0; y<heightf; y++)
	{
		addr=(y+posy)*widtht;
		addr2=y*widthf;
		if (visible(x+posx,y+posy, widtht, heightt))
		{
			if (pixelf[x+addr2]==0x00000000) pixelt[(x+posx)+addr]=palette[pall_for_black];
				else
			if (pixelf[x+addr2]==0x00ffffff) pixelt[(x+posx)+addr]=palette[pall_for_white];
		}
	}
}

void Layer::PutBuffer(int tobuffer, int frombuffer, int posx, int posy, int amount)
{
	int x,y,addr,addr2;
	int a,rb,r,g,b,i,dst,src,alpha,ishift;
	unsigned char alphainv;

	unsigned int *pixelt,*pixelf;
	unsigned char *pixelfc;
	int widtht, heightt, widthf, heightf;
	int mode=buffer[frombuffer]->maskMode;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);
	int sizet=getSizeBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);
	pixelfc=(unsigned char *)pixelf;

	if (mode==MASK_ALPHACHANNEL)
	{
		for(y=0; y<heightf; y++)
		{
			addr=(y+posy)*widtht;
			addr2=y*widthf;
			for(x=0; x<widthf; x++)
			{
//				if (visible(widthf,heightf,x,addr2))
				if (visible(x+posx,y+posy,widtht,heightt))
				{
					alpha=255-pixelfc[((x+addr2)<<2)+3];	//should be +3 because theres where the alpha channel is
					alphainv=255-alpha;
					dst=pixelt[x+posx+addr];
//					src=*pixelf++;
					src=pixelf[x+addr2];
					rb=((((dst&0xff00ff)*alpha)+((src&0xff00ff)*alphainv))>>8)&0xff00ff;
					g=((((dst&0x0000ff00)*alpha)+((src&0x0000ff00)*alphainv))>>8)&0x0000ff00;
					pixelt[x+posx+addr]=rb+g;
				}
			}
		}
	}
	else
	if (mode==MASK_TRANSPARENCY_ADD)
	{
		amount=amount>255?255:amount;
		i=0;
		addr=posy*widtht;
		addr2=0;
		for (y=0; y<heightf; y++)
		{
			for (x=0; x<widthf; x++)
			{
//				if (visible_i(x+posx+addr+addr2,sizet))
				if (visible(x+posx,y+posy,widtht,heightt))
				{
					ishift=(i<<2);

					a=(pixelfc[ishift+3]+amount)-255;
					a=a<0?0:a;
//					a=(pixelfc[ishift+3]);

					r=(pixelfc[ishift+2]+amount)-255;
					r=r<0?0:r;
					g=(pixelfc[ishift+1]+amount)-255;
					g=g<0?0:g;
					b=(pixelfc[ishift]+amount)-255;
					b=b<0?0:b;

//					r=amount&(pixelfc[ishift+2]);
//					g=amount&(pixelfc[ishift+1]);
//					b=amount&(pixelfc[ishift]);
//					asm_plotadd(pixelt, x+posx+addr+addr2, RGB32(r,g,b));
					asm_plotadd(pixelt, x+posx+addr+addr2, ARGB32(a,r,g,b));
				}
				i++;
			}
			addr2+=widtht;
		}
	}
	else
	if (mode==MASK_TRANSPARENCY_SUB)
	{
		amount=amount>255?255:amount;
		i=0;
		addr=posy*widtht;
		addr2=0;
		for (y=0; y<heightf; y++)
		{
			for (x=0; x<widthf; x++)
			{
				if (visible_i(x+posx+addr+addr2,sizet))
				{
					ishift=(i<<2);
					r=(pixelfc[ishift+2]+amount)-255;
					r=r<0?0:r;
					g=(pixelfc[ishift+1]+amount)-255;
					g=g<0?0:g;
					b=(pixelfc[ishift]+amount)-255;
					b=b<0?0:b;
//					r=amount&(pixelfc[ishift+2]);
//					g=amount&(pixelfc[ishift+1]);
//					b=amount&(pixelfc[ishift]);
					asm_plotsub(pixelt, x+posx+addr+addr2, RGB32(r,g,b));
				}
				i++;
			}
			addr2+=widtht;
		}
	}
}

void Layer::PutBuffer(int tobuffer, int frombuffer, int posx, int posy, float posz, int amount)
{
	int x,y,addr,addr2;
	int a,rb,r,g,b,i,dst,src,alpha,ishift,jshift;
	unsigned char alphainv;

	unsigned int *pixelt,*pixelf;
	unsigned char *pixelfc;
	int widtht, heightt, widthf, heightf;
	int mode=buffer[frombuffer]->maskMode;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);
	int size=getSizeBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);
	pixelfc=(unsigned char *)pixelf;

	posx-=widthf*0.5f;
	posy-=heightf*0.5f;
	//
	float hz = heightf+posz;	//64+16 = 80
	float wz = widthf+(posz*(float)widthf/heightf);		//64+16 = 80
	float ystep=(float)heightf/hz;	//64/80 = 0.8
	float xstep=(float)widthf/wz;	//64/80 = 0.8
	float xinc,yinc;
	int xz2=-(int)((float)posz*0.5*(float)widthf/heightf);
	int yz2=-(int)((float)posz*0.5) *widtht;

	if (mode==MASK_TRANSPARENCY_ADD)
	{
		amount=amount>255?255:amount;
		i=0;
		addr=posy*widtht;
		addr2=0;
		yinc=0;
		for (y=0; y<hz; y++)
		{
			xinc=0;
			jshift=((int)(yinc)*widthf)<<2;
			for (x=0; x<wz; x++)
			{
//				if (visible(x+posx, y+posy, 320, 200))
				if (visible_i(posx+x+xz2+addr+addr2+yz2,size))
				{
					ishift=(int)(xinc)<<2;
					r=(pixelfc[ishift+jshift]+amount)-255;
					r=r<0?0:r;
					g=(pixelfc[ishift+jshift+1]+amount)-255;
					g=g<0?0:g;
					b=(pixelfc[ishift+jshift+2]+amount)-255;
					b=b<0?0:b;
					asm_plotadd(pixelt, posx+x+xz2+addr+addr2+yz2, RGB32(r,g,b));
				}
				xinc+=xstep;
			}
			addr2+=widtht;
			yinc+=ystep;
		}
	}
}

void Layer::ScrollHorisontal(int tobuffer, int frombuffer, int py, int offset)
{
	int x,y,addr,addr2;
	unsigned int *pixelt, *pixelf;
	int widtht, heightt, widthf, heightf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	for (y=0; y<heightf; y++)
	{
		addr=(y+py)*widtht;
		addr2=y*widthf;
		for (x=0; x<widthf; x++) pixelt[x+addr]=pixelf[((x+offset)%widthf)+addr2];
	}
}

//void Layer::MoveLensFlare(int tobuffer, int frombuffer_start, int frombuffer_end, scrbuffer alpha, int lx, int ly)
void Layer::MoveLensFlares(int tobuffer, int frombufferstart, int frombufferend, int lx, int ly, int alpha)
{
	unsigned int *pixelt, *pixelf;
//	unsigned int *flares[5];
	int widtht, heightt, widthf, heightf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	widthf=getWidthBuffer(frombufferstart);
	heightf=getHeightBuffer(frombufferstart);
/*
	flares[0]=getPixelBuffer(frombufferstart);
	flares[1]=getPixelBuffer(frombufferstart+1);
	flares[2]=getPixelBuffer(frombufferstart+2);
	flares[3]=getPixelBuffer(frombufferstart+3);
	flares[4]=getPixelBuffer(frombufferstart+4);*/
/*
	for (int i=0; i<(frombufferend-frombufferstart+1); i++)
		flares[i]=getPixelBuffer(frombufferstart+i);
*/

	int hx=widthf/2.0;
	int hy=heightf/2.0;

	//cartesian coordinate system:
	//origin x and y
	int ox=widtht/2.0;
	int oy=heightt/2.0;

	//set position for the main flare
	int px=lx;
	int py=ly;

	//secondary flare
	float px1=-px;
	float py1=-py;
	float px2=-px/2.0f;
	float py2=-py/2.0f;
	float px3=-px/1.2f;
	float py3=-py/1.2f;
	float px4=px/3.2f;
	float py4=py/3.2f;

	//read alphavalues from main flare position from the alpha screenbuffer
//	int a=alpha.cbuffer[((px+ox+(py+oy)*backbuffer.xsize)<<2)+3];

	PutBuffer(tobuffer, frombufferstart, px+ ox-hx, py+ oy-hy, alpha);
	PutBuffer(tobuffer, frombufferstart+1, (int)(px1)+ ox-hx, (int)(py1)+ oy-hy, alpha);
	PutBuffer(tobuffer, frombufferstart+2, (int)(px2)+ ox-hx, (int)(py2)+ oy-hy, alpha);
	PutBuffer(tobuffer, frombufferstart+3, (int)(px3)+ ox-hx, (int)(py3)+ oy-hy, alpha);
	PutBuffer(tobuffer, frombufferstart+4, (int)(px4)+ ox-hx, (int)(py4)+ oy-hy, alpha);
/*
	add_blend_pos_alpha(backbuffer, flares[0], px+ox -hx, py+oy -hy, a);
	add_blend_pos_alpha(backbuffer, flares[1], (int)(px1)+ox -hx, (int)(py1)+oy -hy, a);
	add_blend_pos_alpha(backbuffer, flares[2], (int)(px2)+ox -hx, (int)(py2)+oy -hy, a);
	add_blend_pos_alpha(backbuffer, flares[3], (int)(px3)+ox -hx, (int)(py3)+oy -hy, a);
	add_blend_pos_alpha(backbuffer, flares[4], (int)(px4)+ox -hx, (int)(py4)+oy -hy, a);*/
//	PutBufferAlpha(backbuffer, lens[0], px+ox -hx, py+oy -hy);
//	PutBufferAlpha(backbuffer, lens[1], (int)(px1)+ox -hx, (int)(py1)+oy -hy);
//	PutBufferAlpha(backbuffer, lens[2], (int)(px2)+ox -hx, (int)(py2)+oy -hy);
//	PutBufferAlpha(backbuffer, lens[3], (int)(px3)+ox -hx, (int)(py3)+oy -hy);
//	PutBufferAlpha(backbuffer, lens[4], (int)(px4)+ox -hx, (int)(py4)+oy -hy);
}



#define RAND(i) rand()%i

void Layer::Noise(int tobuffer, int col)
{
	unsigned int *pixelt;
	int widtht, heightt;
	int r,g,b,r2,g2,b2,s,c;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);

	s=widtht*heightt;

	r=(col&0xff0000)>>16;
	g=(col&0xff00)>>8;
	b=(col&0xff);

	for (;s--;)
	{
		c=RAND(255);
		r2=c&r;
		g2=c&g;
		b2=c&b;
		pixelt[s]=RGB32(r2,g2,b2);
	}
	/*
	for (;s-=2;)
	{
		c=RAND(255);
		r2=c&r;
		g2=c&g;
		b2=c&b;
		pixelt[s]=RGB32(r2,g2,b2);
		pixelt[s-1]=RGB32(r2,g2,b2);
	}*/
}

void Layer::InitFonts(char *text, int col, int maskmode)
{
	maskMode=maskmode;
	font.Init(text, col);
}

void Layer::InitFonts(char *filename)
{
	font.Init(filename);
}

void Layer::PutFont(char *c, int posx, int posy)
{
	int x,y,yaddr,yaddr2,bin;
	int _width=mainbuffer.width;
	int bwidth=font.width;
	int bheight=font.height;

	if (maskMode==MASK_NONZERO)
	{
		if ( ((posx>=0) && ((posx+bwidth)<WIDTH)) && ((posy>=0) && ((posy+bheight)<HEIGHT)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			for (x=0; x<bwidth; x++) mainbuffer.pixel[(x+posx)+yaddr]=font.buffer[*c-32][x+yaddr2];
		}
	}
	else
	{
		if ( ((posx>=0) && ((posx+bwidth)<WIDTH)) && ((posy>=0) && ((posy+bheight)<HEIGHT)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			for (x=0; x<bwidth; x++)
			{
				bin=font.buffer[*c-32][x+yaddr2];
				(bin!=0)?(mainbuffer.pixel[(x+posx)+yaddr]=bin):0;
			}
		}
	}
}

//regulere fargen
void Layer::PutFont(char *c, int posx, int posy, int col)
{
	int x,y,yaddr,yaddr2,bin;
	int _width=mainbuffer.width;
	int bwidth=font.width;
	int bheight=font.height;

	//layer sizes
	int lwidth=width;
	int lheight=height;
/*
	if (maskMode==MASK_NONZERO)
	{
		if ( ((posx>=0) && ((posx+bwidth)<WIDTH)) && ((posy>=0) && ((posy+bheight)<HEIGHT)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			
			for (x=0; x<bwidth; x++)
				if (font.buffer[*c-32][x+yaddr2]!=0)
					mainbuffer.pixel[(x+posx)+yaddr]=col;
		}
	}
	else*/
	{
		if ( ((posx>=0) && ((posx+bwidth)<lwidth)) && ((posy>=0) && ((posy+bheight)<lheight)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			for (x=0; x<bwidth; x++)
			{
				bin=font.buffer[*c-32][x+yaddr2];
				(bin!=0)?(mainbuffer.pixel[(x+posx)+yaddr]=col):0;
			}
		}
	}
}

//regulere fargen
void Layer::PutFont(char c, int posx, int posy, int col)
{
	int x,y,yaddr,yaddr2,bin;
	int _width=mainbuffer.width;
	int bwidth=font.width;
	int bheight=font.height;

	if (maskMode==MASK_NONZERO)
	{
		if ( ((posx>=0) && ((posx+bwidth)<WIDTH)) && ((posy>=0) && ((posy+bheight)<HEIGHT)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			
			for (x=0; x<bwidth; x++)
				if (font.buffer[c-32][x+yaddr2]!=0)
					mainbuffer.pixel[(x+posx)+yaddr]=col;
		}
	}
	else
	{
		if ( ((posx>=0) && ((posx+bwidth)<WIDTH)) && ((posy>=0) && ((posy+bheight)<HEIGHT)) )
		for (y=0; y<bheight; y++)
		{
			yaddr=(y+posy)*_width;
			yaddr2=y*bwidth;
			for (x=0; x<bwidth; x++)
			{
				bin=font.buffer[c-32][x+yaddr2];
				(bin!=0)?(mainbuffer.pixel[(x+posx)+yaddr]=col):0;
			}
		}
	}
}

void Layer::TransitionThreshold(int tobuffer, int frombuffer, int maskbuffer, float amount)
{
	int i,mul,r,g,b;
	unsigned int *pixelt, *pixelf;
	int widtht, heightt, widthf, heightf;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixelt=getPixelBuffer(tobuffer);
	size=getSizeBuffer(frombuffer);
	pixelf=getPixelBuffer(frombuffer);

	unsigned char *tpixelc=(unsigned char *)pixelt;
	unsigned char *fpixelc=(unsigned char *)pixelf;
	unsigned char *maskc=(unsigned char *)getPixelBuffer(maskbuffer);

	for (i=0; i<size; i++)
	{
		mul=(i<<2);

//		r=((float)maskc[mul+2]/255) * fpixelc[mul+2] + (1-((float)maskc[mul+2]/255))*tpixelc[mul];
//		g=((float)maskc[mul+1]/255) * fpixelc[mul+1] + (1-((float)maskc[mul+1]/255))*tpixelc[mul];
//		b=((float)maskc[mul]/255) * fpixelc[mul] + (1-((float)maskc[mul]/255))*tpixelc[mul];

		(255-amount<maskc[mul])?pixelt[i]=pixelf[i]:0;
	}

}

void Layer::FilterHexagon(int tobuffer, int frombuffer, int spritebuffer)
{
	int x,y,sx,sy,col1,col2;
	int widtht, heightt, widthf, heightf;
	int addr,addr2,sx_widths,y_widths,sy_heights;
	unsigned int *pixel;

	pixel=getPixelBuffer(tobuffer);
	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);

	int widths=buffer[spritebuffer]->width;
	int heights=buffer[spritebuffer]->height;
	int wh=widths/2;
	int hh=heights/2;

//	for (sx=0; sx<12; sx++)
//	for (sy=0; sy<21; sy++)
//	for (sx=0; sx<28; sx++)

	for (sy=0; sy<33; sy++) //200
//	for (sy=0; sy<39; sy++) //240

//	for (sy=0; sy<62; sy++)
//	for (sy=0; sy<79; sy++)
	{
		sy_heights=sy*heights;
		for (sx=0; sx<26; sx++) //320
//		for (sx=0; sx<42; sx++)
//		for (sx=0; sx<53; sx++)
		{
			//9,5
			col1=buffer[frombuffer]->pixel[wh+sx*widths+(hh+sy*heights)*widthf];
			col2=buffer[frombuffer]->pixel[wh+wh+sx*widths+(hh+hh+sy*heights)*widthf];
			for (y=0; y<heights; y++)
			{
				y_widths=y*widths;
				addr=(sy_heights+y)*widtht;
				addr2=(sy_heights+hh+y)*widtht;
				for (x=0; x<widths; x++)
				{
					sx_widths=sx*widths;
					if (buffer[spritebuffer]->pixel[x+y_widths]!=0)
					{
						pixel[x+sx_widths+addr]=col1;
						pixel[wh+x+sx_widths+addr2]=col2;
					}
				}
			}
		}
	}
	g_line((int*)pixel, 0, 198,320, 198, widtht, heightt, 0);
	g_line((int*)pixel, 0, 199,320, 199, widtht, heightt, 0);
}

void lerp(Coord2Df &dest, Coord2Df &a, Coord2Df &b, float t)
{
	dest.x=a.x+(b.x-a.x)*t;
	dest.y=a.y+(b.y-a.y)*t;
}

void lerp(Coord2Df *dest, Coord2Df a, Coord2Df b, float t)
{
	dest->x=a.x+(b.x-a.x)*t;
	dest->y=a.y+(b.y-a.y)*t;
}

void bezier(Coord2Df &topoint, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, float t)
{
	Coord2Df pa[3],pb[2];
	lerp(pa[0], p1,p2, t);
	lerp(pa[1], p2,p3, t);
	lerp(pa[2], p3,p4, t);
	lerp(pb[0], pa[0],pa[1], t);
	lerp(pb[1], pa[1],pa[2], t);
	lerp(topoint, pb[0],pb[1], t);
}

void bezier(Coord2Df &topoint, Quad2D p, float t)
{
	Coord2Df pa[3],pb[2];
	lerp(pa[0], p.p[0],p.p[1], t);
	lerp(pa[1], p.p[1],p.p[2], t);
	lerp(pa[2], p.p[2],p.p[3], t);
	lerp(pb[0], pa[0],pa[1], t);
	lerp(pb[1], pa[1],pa[2], t);
	lerp(topoint, pb[0],pb[1], t);
}

/*
// ansl� et punkt p� en bezier-kurve. t g�r fra 0 til 1.0
//void Layer::Bezier(int tobuffer, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, int color)
void Layer::Bezier(int tobuffer, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, int npoints, int color)
{
	int x,y;
	int widtht, heightt;
	Coord2Df pa[3],pb[2],pf,fold;
	unsigned int *pixel;
	float f, step;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixel=getPixelBuffer(tobuffer);

	bezier(pf, p1, p2, p3, p4, 0);
//	int npoints=6;
//	npoints=12+sin(ftime)*11;
//	npoints=12+sin(ftime*22)*11;
//	npoints=1;

	float sf=1.0f/npoints;

	step=0;

	for (int i=0; i<npoints; i++)
	{
		step+=sf;
		fold.x=pf.x;
		fold.y=pf.y;
		bezier(pf, p1, p2, p3, p4, step);
		g_line((int*)pixel, (int)fold.x, (int)fold.y, (int)pf.x, (int)pf.y, color);
	}
}
*/

void Layer::Bezier(int tobuffer, Quad2D p, int npoints, int color)
{
	int x,y;
	int widtht, heightt;
	Coord2Df pa[3],pb[2],pf,fold;
	unsigned int *pixel;
	float step;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixel=getPixelBuffer(tobuffer);

	bezier(pf, p.p[0], p.p[1], p.p[2], p.p[3], 0);

//	int npoints=6;
//	npoints=12+sin(ftime)*11;
//	npoints=12+sin(ftime*22)*11;
//	npoints=1;

	float sf=1.0f/npoints;

	step=0;

	for (int i=0; i<npoints; i++)
	{
		fold.x=pf.x;
		fold.y=pf.y;
		step+=sf;
		bezier(pf, p.p[0], p.p[1], p.p[2], p.p[3], step);
		g_line((int*)pixel, (int)fold.x, (int)fold.y, (int)pf.x, (int)pf.y, widtht, heightt, color);
	}
}

float fraction(float num)
{
	return (num-(float)(int)num);
}

void Layer::ResizeBilinear(int tobuffer, int frombuffer, int width, int height)
{
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	int widthf=getWidthBuffer(frombuffer);
	int heightf=getHeightBuffer(frombuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);
	unsigned int *pixelf=getPixelBuffer(frombuffer);

	double xfactor=(double)widthf/(double)widtht;
	double yfactor=(double)heightf/(double)heightt;
	float fraction_u, fraction_v;
	float uf, vf;
	int u, v, u1, v1;
	int r1, r2, r3, r4;
	int g1, g2, g3, g4;
	int b1, b2, b3, b4;
	int r, g, b;
	float u_coeff, v_coeff;

	unsigned char *cpixelf=(unsigned char *)pixelf;

	for (int x=0; x<width; x++)
	for (int y=0; y<height; y++)
	{
		uf=(x*xfactor);
		vf=(y*yfactor);

		fraction_u=fraction(uf);
		fraction_v=fraction(vf);
		u_coeff=1-fraction_u;
		v_coeff=1-fraction_v;

		u=uf;
		v=vf;
		u1=uf+1;
		v1=vf+1;

		u=u%widthf;
		u1=u1%widthf;
		v=v%heightf;
		v1=v1%heightf;

		int uv=((u+v*widthf)<<2);
		int u1v=((u1+v*widthf)<<2);
		int uv1=((u+v1*widthf)<<2);
		int u1v1=((u1+v1*widthf)<<2);

		r1=cpixelf[2+uv];
		r2=cpixelf[2+u1v];
		r3=cpixelf[2+uv1];
		r4=cpixelf[2+u1v1];
		r = (r1*u_coeff*v_coeff)+
			(r2*(1-u_coeff)*v_coeff)+
			(r3*u_coeff*(1-v_coeff))+
			(r4*(1-u_coeff)*(1-v_coeff));

		g1=cpixelf[1+uv];
		g2=cpixelf[1+u1v];
		g3=cpixelf[1+uv1];
		g4=cpixelf[1+u1v1];
		g = (g1*u_coeff*v_coeff)+
			(g2*(1-u_coeff)*v_coeff)+
			(g3*u_coeff*(1-v_coeff))+
			(g4*(1-u_coeff)*(1-v_coeff));

		b1=cpixelf[uv];
		b2=cpixelf[u1v];
		b3=cpixelf[uv1];
		b4=cpixelf[u1v1];
		b = (b1*u_coeff*v_coeff)+
			(b2*(1-u_coeff)*v_coeff)+
			(b3*u_coeff*(1-v_coeff))+
			(b4*(1-u_coeff)*(1-v_coeff));

		pixelt[x+y*widtht]=RGB32(r,g,b);
	}
}

//
//2d metaballs
//
void Layer::Metaballs2D(int tobuffer, int antall, float motion, int style)
{
	int x,y,i,addr,c,col;
	int width=getWidthBuffer(tobuffer);
	int height=getHeightBuffer(tobuffer);
	uint *pixel=getPixelBuffer(tobuffer);
	uint *palette=getPaletteBuffer(tobuffer);

	int widthh=width/2;
	int heighth=height/2;
	FVector2D v[32];

	float energy;
//	long energy;

	addr=0;
	for (i=0; i<antall; i++)
	{
//		v[i].x=320+sin(motion+i*0.35)*sin(motion*i*0.1)*280;
//		v[i].y=240+cos(motion*i*0.15)*cos(motion+i*0.23)*200;
//		v[i].x=widthh+sin(motion+i*0.35)*sin(motion*i*0.1)*100;
//		v[i].y=heighth+cos(motion*i*0.15)*cos(motion+i*0.23)*100;
		v[i].x=widthh+sin(motion+i*0.35)*sin(motion*(i+1)*0.1)*130;
		v[i].y=heighth+cos(motion*(i+1)*0.15)*cos(motion+i*0.23)*130;
	}


	if (style==0)
	{
		for (y=0; y<height; y++, addr+=width)
		{
			for (x=0; x<width; x++)
			{
				energy=0;
				for (i=0; i<antall; i++) energy+=1/(SQR(x-v[i].x)+SQR(y-v[i].y));
				c=energy*65536+sqrt(SQR(x-widthh)+SQR(y-heighth));
				c=c>=255?255:c<0?0:c;
				pixel[x+addr]=palette[c];
			}
		}
	} else
	if (style==1)
	{
		for (y=0; y<height; y++, addr+=width)
		{
			for (x=0; x<width; x++)
			{
				energy=0;
				for (i=0; i<antall; i++) energy+=1/(SQR(x-v[i].x)+SQR(y-v[i].y));

//				c=energy*65536+sqrt(x*x+y*y);
//				c=energy*65536+sqrt(SQR(x-widthh)+SQR(y-heighth));
//				c=energy*0x0f0f7f+sqrt(SQR(x-widthh)+SQR(y-heighth));
//				c=energy*0x040000+sqrt(SQR(x-widthh)+SQR(y-heighth));
//				c=energy*0x02ffff;
				c=energy*0x070000;

//				pixel[x+addr]=c<0x2f ? 0:0xffffff;
			
//				c&=0xff;
				c=c>=255?255:c<0?0:c;

				pixel[x+addr]=palette[c];
//				pixel[x+addr]=(c&0x20)>0x10?0x7f7fff:0xc0ffc0;
//				pixel[x+addr]=c;
			}
		}
	}
}

//
//
//




//
//Radial Blur by activator (needs optimization)
//for each pixel we calculate a vector that point towards the center of the radial blur
//scale this vector
//get pixel P at that position relative to A
//mix this pixel color with the one at A (A=(A+P)/2) and write that into A
//
typedef struct
{
	int r,g,b;
} Color3i;

typedef struct
{
	int x,y;
} iVector;

//fixedpoint optimalisert.
//void block(scrbuffer tobuffer, int cx, int cy, int dx, int dy, double scalefactor)
void block(unsigned int *pixel, int width, int height, int cx, int cy, int dx, int dy, double scalefactor)
{
	int x,y,fx,fy;
	iVector cv;
	int ax,ay,ax1,ay1;
	int px,py,px1,py1;
	int paddr,aaddr;
	g_irgb p,p1,p8,p9,a,a1;
	unsigned char *cpixel=(unsigned char *)pixel;

	//Fixedpoint
	fixedp fx_scale;
	iVector fx_cv, fr_cv;
	fx_scale=DTOFIX(scalefactor);

	//finn ut hvilket fortegn variabelen skal bruke i loopen
	if (cx<dx) fx=1; else fx=-1;
	if (cy<dy) fy=1; else fy=-1;

	for (y=cy; fy<0?y>=dy:y<dy; y+=fy)
	for (x=cx; fx<0?x>=dx:x<dx; x+=fx)
	{
		//vektoren som peker mot midten av radial bluren kaller vi cv
		cv.x=cx-x;
		cv.y=cy-y;
		fx_cv.x=ITOFIX(cv.x);
		fx_cv.y=ITOFIX(cv.y);
	
		//skaler vektoren
//		cv.x=(int)(((double)cv.x)*scalefactor);
//		cv.y=(int)(((double)cv.y)*scalefactor);
		fx_cv.x=fixed_mul(fx_cv.x, fx_scale);
		fx_cv.y=fixed_mul(fx_cv.y, fx_scale);
		cv.x=FIXTOI(fx_cv.x);
		cv.y=FIXTOI(fx_cv.y);

		//finn fraksjonsdelen til vektoren (NY)
		fr_cv.x=(((fx_cv.x)>>8)&0xff);
		fr_cv.y=(((fx_cv.y)>>8)&0xff);
			
		//pixelen vi vil skrive til kaller vi for a.
		//og dens koordinater kaller vi ax og ay.
		ax=x;
		ay=y;
		ax1=x-1;
		ay1=y-1;

		//
		// blend de to nederste med de to �verste med
		// blendfactor (de 8 �verste av de 16 laveste)
		//
		// altss, du blender mellom de to �verste pixelene og
		// de to nederste pixelene med fractionalparten fra x-koordinaten
		// ss blender du mellom resultatet med fractionalparten fra y-koordinaten

		//her henter vi fargen til pixel p relativt til pixel a's koordinater.
		//P(ax-cv.x; ay-cv.y)
		px=ax-cv.x;
		py=ay-cv.y;
		px1=ax1-cv.x;
		py1=ay1-cv.y;

		//blend p(x,y) -> p(x+1,y) med fraksjonsparten til x
		if (px>=0 && px<width && py>=0 && py<height) paddr=((px+(py)*width)<<2);
		p.r=cpixel[2+paddr];
		p.g=cpixel[1+paddr];
		p.b=cpixel[paddr];
		if (px1>=0 && px1<width && py>=0 && py<height) paddr=((px1+(py)*width)<<2);
		p1.r=cpixel[2+paddr];
		p1.g=cpixel[1+paddr];
		p1.b=cpixel[paddr];
		p8.r=p.r+(((p1.r-p.r)*fr_cv.x)>>8);
		p8.g=p.g+(((p1.g-p.g)*fr_cv.x)>>8);
		p8.b=p.b+(((p1.b-p.b)*fr_cv.x)>>8);

		//blend p(x,y+1) -> p(x+1,y+1) med fraksjonsparten til x
		if (px>=0 && px<width && py1>=0 && py1<height) paddr=((px+(py1)*width)<<2);
		p.r=cpixel[2+paddr];
		p.g=cpixel[1+paddr];
		p.b=cpixel[paddr];
		if (px1>=0 && px1<width && py1>=0 && py1<height) paddr=((px1+(py1)*width)<<2);
		p1.r=cpixel[2+paddr];
		p1.g=cpixel[1+paddr];
		p1.b=cpixel[paddr];
		p9.r=p.r+(((p1.r-p.r)*fr_cv.x)>>8);
		p9.g=p.g+(((p1.g-p.g)*fr_cv.x)>>8);
		p9.b=p.b+(((p1.b-p.b)*fr_cv.x)>>8);

		//blend ss p8 og p9 med fraksjonsparten til y
		p.r=p8.r+(((p9.r-p8.r)*fr_cv.y)>>8);
		p.g=p8.g+(((p9.g-p8.g)*fr_cv.y)>>8);
		p.b=p8.b+(((p9.b-p8.b)*fr_cv.y)>>8);

		pixel[ax+(ay)*width]=RGB32(p.r, p.g, p.b);
	}
}

void Layer::RadialBlurSubpixel(int tobuffer, int px, int py, double scalefactor)
{
	int widtht, heightt;
	unsigned int *pixel;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	pixel=getPixelBuffer(tobuffer);

	if (fft_flag==false)
	{
		//moving
		block(pixel, widtht, heightt, px, -1+py, width-1, 0, scalefactor);
		block(pixel, widtht, heightt, -1+px, -1+py, 0, 0, scalefactor);
		block(pixel, widtht, heightt, px, py, width-1, height-1, scalefactor);
		block(pixel, widtht, heightt, -1+px, py, 0, height-1, scalefactor);
	}
	else
	{
//		-0.01 -> -0.02
//		scalefactor=fft_adapt[(int)(ftime)%512] * -0.005;
		scalefactor=fft_adapt[(int)(ftime*5)%512] * -0.005;
//		scalefactor=fft_adapt[(int)(ftime)%256] * -0.0075; //crashmusicstuff
//		scalefactor=fft_adapt[(int)(ftime)%256] * -0.0005;
		//moving
		block(pixel, widtht, heightt, px, -1+py, width-1, 0, scalefactor);
		block(pixel, widtht, heightt, -1+px, -1+py, 0, 0, scalefactor);
		block(pixel, widtht, heightt, px, py, width-1, height-1, scalefactor);
		block(pixel, widtht, heightt, -1+px, py, 0, height-1, scalefactor);
	}
}

void Layer::RadialBlur(int tobuffer, float scale)
{
	Color3i c[2];
	int x,y,addr;
	int widtht, heightt, widthth, heightth;
	unsigned int *pixel;
	unsigned char *cpixel;

	Coord2D p[2];
	float sx, sy, vxf, vyf;
	int vxi, vyi;

	widtht=getWidthBuffer(tobuffer);
	heightt=getHeightBuffer(tobuffer);
	float aspect=heightt/widtht;
	widthth=widtht/2;
	heightth=heightt/2;
	pixel=getPixelBuffer(tobuffer);
	cpixel=(unsigned char *)pixel;

	sx=scale;
	sy=sx*aspect;	//aspect ratio

	for (y=(heightth-1); y>0; y--)
	{
		vyf=-(heightth-y)*sx;
		vyi=(int)vyf;
		p[0].y=y-vyi;
		p[1].y=(heightt-1)-(y-vyi);//(((heightth-1)-y)+vyi)*sx;
		int addr1=p[0].y*widtht;
		int addr2=p[1].y*widtht;

		for (x=widthth; x<(widtht-1); x++)
		{
			int yaddr=((heightt-1)-y)*widtht;
			vxf=(x-(widthth-1))*sx;
			vxi=(int)vxf;

			p[0].x=x-vxi;
			p[1].x=(widtht-1)-x+vxi;

			c[0].r=cpixel[2+((p[0].x+addr1)<<2)];
			c[0].g=cpixel[1+((p[0].x+addr1)<<2)];
			c[0].b=cpixel[((p[0].x+addr1)<<2)];
			addr=((x+y*widtht)<<2);
			c[1].r=((cpixel[2+addr]+c[0].r)>>1);
			c[1].g=((cpixel[1+addr]+c[0].g)>>1);
			c[1].b=((cpixel[addr]+c[0].b)>>1);
			pixel[x+y*widtht]=RGB32(c[1].r,c[1].g,c[1].b);

			c[0].r=cpixel[2+((p[1].x+addr1)<<2)];
			c[0].g=cpixel[1+((p[1].x+addr1)<<2)];
			c[0].b=cpixel[((p[1].x+addr1)<<2)];
			addr=(((widtht-1)-x+y*widtht)<<2);
			c[1].r=((cpixel[2+addr]+c[0].r)>>1);
			c[1].g=((cpixel[1+addr]+c[0].g)>>1);
			c[1].b=((cpixel[addr]+c[0].b)>>1);
			pixel[(widtht-1)-x+y*widtht]=RGB32(c[1].r,c[1].g,c[1].b);

			c[0].r=cpixel[2+((p[1].x+addr2)<<2)];
			c[0].g=cpixel[1+((p[1].x+addr2)<<2)];
			c[0].b=cpixel[((p[1].x+addr2)<<2)];
			addr=(((widtht-1)-x+yaddr)<<2);
			c[1].r=((cpixel[2+addr]+c[0].r)>>1);
			c[1].g=((cpixel[1+addr]+c[0].g)>>1);
			c[1].b=((cpixel[addr]+c[0].b)>>1);
			pixel[(widtht-1)-x+yaddr]=RGB32(c[1].r,c[1].g,c[1].b);

			c[0].r=cpixel[2+((p[0].x+addr2)<<2)];
			c[0].g=cpixel[1+((p[0].x+addr2)<<2)];
			c[0].b=cpixel[((p[0].x+addr2)<<2)];
			addr=((x+yaddr)<<2);
			c[1].r=((cpixel[2+addr]+c[0].r)>>1);
			c[1].g=((cpixel[1+addr]+c[0].g)>>1);
			c[1].b=((cpixel[addr]+c[0].b)>>1);
			pixel[x+yaddr]=RGB32(c[1].r,c[1].g,c[1].b);
		}
	}
}

void Layer::SetFFTSynch(bool flag)
{
	fft_flag=flag;
	if (flag)
//		for (int x=0; x<width; x++) fft_adapt[x]=(int)(fft[x]*32000*0.06)%height;
		for (int x=0; x<width; x++) fft_adapt[x]=(int)(fft[x]*32000*0.1)%height;
//		for (int x=0; x<width; x++) fft_adapt[x]=(int)(fft[x]*32000*0.2)%height;
}

void Layer::AddString(char *text)
{
	stringCount++;
	strings=(String**) realloc(strings, stringCount*sizeof(String *));
	strings[stringCount-1]=new String();
	strings[stringCount-1]->SetText(text);
}

void Layer::AddString(char *text, int posx, int posy)
{
	stringCount++;
	strings=(String**) realloc(strings, stringCount*sizeof(String *));
	strings[stringCount-1]=new String();
	strings[stringCount-1]->SetText(text);
	strings[stringCount-1]->posx=posx;
	strings[stringCount-1]->posy=posy;
}

String *Layer::GetString(int index)
{
	if ((index<0) || (index>=stringCount)) return 0;
	return strings[index];
}


void Layer::PutStringWithBezier(int index, Quad2D p, float time, int mode, float step)
{
	int shade;

	String *string=GetString(index);
	char *text=string->GetText();
	Coord2Df *position=string->GetPos();
	int len=string->GetLength();
	int lenh=(len-1)/2;
	lenh*=10;	//font spaces

	int *blink=string->GetBlink();
	int *blinkstep=string->GetBlinkStep();
	float *factor=string->GetFactor();

	if (time>=1) time=1.0;

	for (int i=(len-1); i>=0; i--)
	{
		if (mode==0) factor[i]=time;	//straight
		else
		if (mode==1) factor[i]=time+((len-1)-i)*step;	//F�rste bokstav stopper f�rst.
		else
		if (mode==2) factor[i]=time+i*step;//	*0.04;	//Siste bokstav stopper f�rst.

		if (factor[i]>=1)
		{
			factor[i]=1;
			blink[i]=1;
		}

		bezier(position[i], p, factor[i]);

		if (blink[i]==1)
		{
			shade=255-blinkstep[i];
//			if (shade<=96) { blink[i]=0; shade=96; }
			if (shade<=96) { blink[i]=0; shade=255; }
//			blinkstep[i]+=2;
//			blinkstep[i]+=3;
//			blinkstep[i]+=4;
			blinkstep[i]+=6;
		}
		else shade=0x9f;//0x7f;
//		else shade=255;
//		else shade=0;

//		Bezier(SCREENBUFFER, p, 16, 0x9f9f9f);//0x2f2f7f);

		int midtref=(i*8)-lenh; //320
//		int midtref=(i*10)-lenh; //640
		PutFont(&text[i], position[i].x+midtref, position[i].y, RGB32(shade,shade,shade));
//		PutFont(&text[i], position[i].x+midtref, position[i].y, 0xffffff);//0x6070df);
	}
}

void Layer::PutStringWithScroller(int index, float time)
{
	String *string=GetString(index);
	char *text=string->GetText();
	Coord2Df *position=string->GetPos();
	int len=string->GetLength();

	int x_tracking,speed,x_pos;
//	x_tracking=10;
	x_tracking=7;
	
	speed=10*2;

//	if (time>=1) time=1.0;

	x_pos=fmod(-time*speed, -(len-1)*x_tracking - 320*2);

	for (int i=(len-1); i>=0; i--)
	{
		position[i].x=x_pos;
//		position[i].y=sin(ftime*2+i*0.2)*20+cos(1+ftime+i*0.1)*25;
//		position[i].y=sin(position[i].x)*30;
		position[i].y=200-24;

//		int midtref=(i*10)+WIDTH;
//		PutFont(&text[i], position[i].x+midtref, position[i].y+HEIGHT_HALF, 0xffffff);
		int midtref=(i*x_tracking)+320;
		PutFont(&text[i], position[i].x+midtref, position[i].y, 0xffffff);
	}
}

void Layer::PutStringWithCursor(int tobuffer, int stringlinefrom, int stringlineto, int fontinc, float timedelta, float delay)
{
	int posx,posy,frombuffer, i, width=0;
	static int flag=0;
	static int fontinc_old=timedelta;
	static int textadd=0;

//	if (textline>=stringlineto) textline=stringlineto;
	int max=stringlineto-stringlinefrom;

	String *string=GetString(textadd);
	char *text=string->GetText();
	int len=string->GetLength();

	posx=string->posx;
	posy=string->posy;

	int len2=fontinc-fontinc_old;

	if (len2>=len)
	{
		len2=len;

		static float ftime2=ftime;
		if (flag==0)
		{
			ftime2=ftime;
			flag=1;
		}

		if (ftime>=(ftime2+delay))
		{
			fontinc_old=fontinc;
//			if (textadd<(stringCount-1))
			if (textadd<max)
//			if ((textadd<stringlineto) || (textadd<(stringCount-1)))
			{
				flag=0;
				textadd++;
			}
		}
	}

	for (i=0; i<len2; i++)
	{
		int ch=(int)((char*)text[i]);
		if (ch<0x61) frombuffer=0; //space(bar)
		else
			frombuffer=ch-(0x61-1);
		PutBuffer(tobuffer, frombuffer, posx+width, leading-getHeightBuffer(frombuffer)+posy);
		width+=getWidthBuffer(frombuffer);
	}

	//blink!
	if (fmod(ftime, 0.5)>=0.25)
//	if (fmod(ftime, 1.0)>=0.5)
		DrawBoxFilled(tobuffer, posx+width, posy, 7, leading, 0xffffffff);
}

void Layer::PutStringWithCursor(int tobuffer, int posx, int posy, int stringlinefrom, int stringlineto, int fontinc, float delay)
{
	int frombuffer, i, width=0;
	static int flag=0;
	static int fontinc_old=0;
	static int textadd=0;

//	if (textline>=stringlineto) textline=stringlineto;
	int max=stringlineto-stringlinefrom;

	String *string=GetString(textadd+stringlinefrom);
	char *text=string->GetText();
	int len=string->GetLength();

	int len2=fontinc-fontinc_old;

	if (len2>=len)
	{
		len2=len;

		static float ftime2=ftime;
		if (flag==0)
		{
			ftime2=ftime;
			flag=1;
		}

		if (ftime>=(ftime2+delay))
		{
			fontinc_old=fontinc;
//			if (textadd<(stringCount-1))
			if (textadd<max)
//			if ((textadd<stringlineto) || (textadd<(stringCount-1)))
			{
				flag=0;
				textadd++;
			}
		}
	}

	for (i=0; i<len2; i++)
	{
		int ch=(int)((char*)text[i]);
		if (ch<0x61) frombuffer=0; //space(bar)
		else
			frombuffer=ch-(0x61-1);
		PutBuffer(tobuffer, frombuffer, posx+width, leading-getHeightBuffer(frombuffer)+posy);
		width+=getWidthBuffer(frombuffer);
	}

	//blink!
	if (fmod(ftime, 0.5)>=0.25)
//	if (fmod(ftime, 1.0)>=0.5)
		DrawBoxFilled(tobuffer, posx+width, posy, 7, leading, 0xffffffff);
}

void Layer::ParticleGenerateFromImage(int frombuffer)
{
	int i,size=getSizeBuffer(frombuffer);
	int widthf,heightf,x,y;
	unsigned int *pixel=getPixelBuffer(frombuffer);
	widthf=getWidthBuffer(frombuffer);
	heightf=getHeightBuffer(frombuffer);

	num_particleset++;
	particleset=(Particle **) realloc(particleset, num_particleset*sizeof(Particle *));
	particleset[num_particleset-1]=new Particle();

	for (x=0; x<widthf; x++)
	for (y=0; y<heightf; y++)
	{
//		if (pixel[x+y*widthf]!=0xff000000)
		if (pixel[x+y*widthf]!=0x000000)
			particleset[num_particleset-1]->AddParticle(x,y,0);
//			particleset[num_particleset-1]->AddParticle(&Vector3D((float)x,(float)y,0));
//			particleset[num_particleset-1]->AddParticle(&Vector3D((float)x,0,(float)y));
	}
}

void Layer::ParticleNormalize(int index1, int index2)
{
	int x,y,i,r,size=320*200;
	float yf,yk;
	int num1=particleset[index1]->num_particles;
	int num2=particleset[index2]->num_particles;

	//swap
	if (num1>num2)
	{
		i=num2;
		while (i<num1)
		{
			particleset[index2]->AddParticle(particleset[index2]->particles_real[rand()%num2]);
			i++;
		}
		particleset[index2]->num_particles=particleset[index1]->num_particles;
	}
	else
	{
		i=num1;
		while (i<num2)
		{
			particleset[index1]->AddParticle(particleset[index1]->particles_real[rand()%num1]);
			i++;
		}
		particleset[index1]->num_particles=particleset[index2]->num_particles;
	}
}


void Layer::ParticleGenerateRandom(int amount)
{
	int i;

	num_particleset++;
	particleset=(Particle **) realloc(particleset, num_particleset*sizeof(Particle *));
	particleset[num_particleset-1]=new Particle();

	for (i=0; i<amount; i++)
		particleset[num_particleset-1]->AddParticle(&Vector3D(rand()%width,rand()%height,0));
}

void Layer::ParticleGenerateRandom(int amount, Vector3D pos, Vector3D volume)
{
	float rf;
	int ri;
	int i;
	float x,y,z;

	num_particleset++;
	particleset=(Particle **) realloc(particleset, num_particleset*sizeof(Particle *));
	particleset[num_particleset-1]=new Particle();

	for (i=0; i<amount; i++)
	{
/*		rf=volume.x*1000;
		ri=rand()%((int)rf);
		x=pos.x+ri/1000;

		rf=volume.y*1000;
		ri=rand()%((int)rf);
		y=pos.y+ri/1000;

		rf=volume.z*1000;
		ri=rand()%((int)rf);
		z=pos.z+ri/1000;*/

//		x=pos.x-(volume.x*0.5)+rand()%(int)(volume.x);
//		y=pos.y-(volume.y*0.5)+rand()%(int)(volume.y);
//		z=pos.z-(volume.z*0.5)+rand()%(int)(volume.z);

		x=pos.x-(volume.x*0.5)+(rand()%(int)(volume.x*100))*0.01;
		y=pos.y-(volume.y*0.5)+(rand()%(int)(volume.y*100))*0.01;
		z=pos.z-(volume.z*0.5)+(rand()%(int)(volume.z*100))*0.01;

		particleset[num_particleset-1]->AddParticle(x,y,z);
	}
}

void Layer::ParticleSetGravity(int index, Vector3D vel, Vector3D acc, float energy)
{
	int i;
	int num_particles=particleset[index]->num_particles;

	for (i=0; i<num_particles; i++)
	{
/*		particleset[index]->particles_physics[i]->vel.x=vel.x;
		particleset[index]->particles_physics[i]->vel.y=vel.y;
		particleset[index]->particles_physics[i]->vel.z=vel.z;
		particleset[index]->particles_physics[i]->acc.x=acc.x;
		particleset[index]->particles_physics[i]->acc.y=acc.y;
		particleset[index]->particles_physics[i]->acc.z=acc.z;
		particleset[index]->particles_physics[i]->energy=energy;
*/
/*		particleset[index]->particles_transform[i]->vel.x=vel.x;
		particleset[index]->particles_transform[i]->vel.y=vel.y;
		particleset[index]->particles_transform[i]->vel.z=vel.z;
		particleset[index]->particles_transform[i]->acc.x=acc.x;
		particleset[index]->particles_transform[i]->acc.y=acc.y;
		particleset[index]->particles_transform[i]->acc.z=acc.z;
		particleset[index]->particles_transform[i]->energy=energy;*/

		particleset[index]->particles_real[i]->vel.x=vel.x;
		particleset[index]->particles_real[i]->vel.y=vel.y;
		particleset[index]->particles_real[i]->vel.z=vel.z;
		particleset[index]->particles_real[i]->acc.x=acc.x;
		particleset[index]->particles_real[i]->acc.y=acc.y;
		particleset[index]->particles_real[i]->acc.z=acc.z;
		particleset[index]->particles_real[i]->energy=energy;
	}
}

void Layer::ParticleLoadFromObject(Object object)
{
	int i;
	int amount=object.num_vertices;

	num_particleset++;
	particleset=(Particle **) realloc(particleset, num_particleset*sizeof(Particle *));
	particleset[num_particleset-1]=new Particle();

	for (i=0; i<amount; i++) particleset[num_particleset-1]->AddParticle(&object.vertices_world[i]);
}

void Layer::ParticleAddSet(int amount)
{
	int i;

	num_particleset++;
	particleset=(Particle **) realloc(particleset, num_particleset*sizeof(Particle *));
	particleset[num_particleset-1]=new Particle();

	for (i=0; i<amount; i++) particleset[num_particleset-1]->AddParticle(0,0,0);
}

void Layer::ParticleShow(int tobuffer, int index)
{
	int i,nump=particleset[index]->num_particles;
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

	for (i=0; i<nump; i++)
	{
		int x=(int)particleset[index]->particles_transform[i]->pos.x;
		int y=(int)particleset[index]->particles_transform[i]->pos.y;
		if (visible(x,y, widtht, heightt))
			pixelt[x+y*widtht]=0xffffff;
	}
}

void Layer::ParticleShow(int tobuffer, int index, int spritebuffer)
{
	int i,nump=particleset[index]->num_particles;
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

	for (i=0; i<nump; i++)
	{
		float x=particleset[index]->particles_transform[i]->pos.x;
		float y=particleset[index]->particles_transform[i]->pos.y;
//		PutBuffer(tobuffer, spritebuffer, x, y, 255);
		PutBuffer(tobuffer, spritebuffer, (int)x, (int)y, (int)(127+sin(ftime*3+i*3)*126));
	}
}

void Layer::ParticleShow3D(int tobuffer, int index, float zper, int wh, int hh)
{
	float x,y,z;
	int sx,sy;
	int i,nump=particleset[index]->num_particles;
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

	float z_delta=(float)fabs((float)widtht/((float)tan(zper*(M_PI/180)/2)*2));

	for (i=0; i<nump; i++)
	{
		x=particleset[index]->particles_transform[i]->pos.x;
		y=particleset[index]->particles_transform[i]->pos.y;
		z=particleset[index]->particles_transform[i]->pos.z;

		sx=(int)(wh+(x*z_delta)/z);
		sy=(int)(hh+(y*z_delta)/z);

		if (visible(sx,sy, widtht, heightt))
			pixelt[sx+sy*widtht]=0xffffff;
	}
}

void Layer::ParticleShow3D(int tobuffer, int index, int spritebuffer, float zper, int wh, int hh)
{
	float x,y,z;
	int sx,sy;
	int i,nump=particleset[index]->num_particles;
	int widtht=getWidthBuffer(tobuffer);
	int heightt=getHeightBuffer(tobuffer);
	unsigned int *pixelt=getPixelBuffer(tobuffer);

//	float z_delta=(float)fabs((float)widtht/((float)tan(zper*(M_PI/180)/2)*2));
	float z_delta=(float)fabs((float)WIDTH/((float)tan(zper*(M_PI/180)/2)*2));

	for (i=0; i<nump; i++)
	{
		x=particleset[index]->particles_transform[i]->pos.x;
		y=particleset[index]->particles_transform[i]->pos.y;
		z=particleset[index]->particles_transform[i]->pos.z;

		sx=(int)(wh+(x*z_delta)/z);
		sy=(int)(hh+(y*z_delta)/z);

		if (visible(sx,sy, widtht, heightt))
//			pixelt[sx+sy*widtht]=0xffffff;
//			PutBuffer(tobuffer, spritebuffer, sx, sy, (int)(192+sin(ftime*3+i*3)*63));
			PutBuffer(tobuffer, spritebuffer, sx, sy, 255);
//			PutBuffer(tobuffer, spritebuffer, sx, sy, (int)(127+sin(ftime*3+i*3)*126));
//			PutBuffer(tobuffer, spritebuffer, sx, sy, 255-(int)(abs(z)));
//			PutBuffer(tobuffer, spritebuffer, sx, sy, (int)(abs(z)));
	}
}

void Layer::ParticlePhysicsGravityFall(int index)
{
	int i;
	int amount=particleset[index]->num_particles;
	static int flag=0;
/*
	LARGE_INTEGER counter;
	QueryPerformanceCounter(&counter);

	DWORD co1=abs(counter.LowPart);
	static DWORD co2=counter.LowPart;
//	co1-=co2;
	printf("%d\n",co1);*/
/*
	double timeline=0.0001;
	double timeline2=timeline*0.5;
	double ftime2=(double)ftime;
	double decfactor=timeline*0.1;
	double timenorm=fmod(ftime2,timeline);
	if ((flag==0) && (timenorm<timeline2)) flag=1;
	if ((flag==1) && (timenorm>timeline2)) 
	{*/

//	if ((rand()%10)==1)
/*	if ((rand()%50)==1)
	{
//		for (i=0; i<amount; i++)
//			particleset[index]->particles_physics[i]->vel.y=1+sin(ftime*3)*1;
		for (i=0; i<amount; i++)
		{
			particleset[index]->particles_physics[i]->dead=false;
//			particleset[index]->particles_physics[i]->pos.x=cos(ftime*10+i*0.001)*20;
//			particleset[index]->particles_physics[i]->pos.y=i*0.01;
//			particleset[index]->particles_physics[i]->pos.z=sin(ftime*10+i*0.001)*20;

//			particleset[index]->particles_physics[i]->pos.x=particleset[index]->particles_real[i]->pos.x;
//			particleset[index]->particles_physics[i]->pos.y=particleset[index]->particles_real[i]->pos.y;
//			particleset[index]->particles_physics[i]->pos.z=particleset[index]->particles_real[i]->pos.z;

//			particleset[index]->particles_physics[i]->pos.x=cos(amount*M_2PI/i)*(20+sin(amount*M_PI/i)*20);
//			particleset[index]->particles_physics[i]->pos.y=amount*M_PI2/i;
//			particleset[index]->particles_physics[i]->pos.z=sin(amount*M_2PI/i)*(20+sin(amount*M_PI/i)*20);

//			particleset[index]->particles_physics[i]->pos.y=sin(ftime+i*0.01)*20;
//			particleset[index]->particles_physics[i]->pos.z=25+sin(ftime+i*0.01)*25;

			particleset[index]->particles_physics[i]->vel.y=0.2;
			particleset[index]->particles_physics[i]->acc.y=1.2+rand()%10;//(4-rand()%9)*0.3;
		}
	}
	else*/
	{
		for (i=0; i<amount; i++)
			particleset[index]->particles_physics[i]->vel.y=particleset[index]->particles_real[i]->vel.y;
	}

		for (i=0; i<amount; i++)
		{
			Vector3D floor(0,-40+4.5,0);
//			static Vector3D pos(0,50,-120);
//			static Vector3D vel(0,0,0);
//			Vector3D acc(0,-0.1,0);
//			float energy=0.85;

			if ((particleset[index]->particles_physics[i]->pos.y<=floor.y) &&
				(fabs(particleset[index]->particles_physics[i]->vel.y)<0.1)) particleset[index]->particles_physics[i]->dead=true;

			if (particleset[index]->particles_physics[i]->dead==false)
			{
				if (particleset[index]->particles_physics[i]->pos.y < floor.y)
					particleset[index]->particles_physics[i]->vel.y = -particleset[index]->particles_physics[i]->vel.y * particleset[index]->particles_physics[i]->energy;
				particleset[index]->particles_physics[i]->pos.y = particleset[index]->particles_physics[i]->pos.y + particleset[index]->particles_physics[i]->vel.y;
				particleset[index]->particles_physics[i]->vel.y = particleset[index]->particles_physics[i]->vel.y + particleset[index]->particles_physics[i]->acc.y;


				//move particles
//				particleset[index]->particles_physics[i]->pos.x=cos(ftime*1.2+i*0.003)*30;
//				particleset[index]->particles_physics[i]->pos.z=sin(ftime*1.2+i*0.004)*30;
			}
		}
//		flag=0;
//	}
}

void Layer::ParticleMorph(int index, int indexfrom, int indexto, float factor)
{
	int i;
	int amount=particleset[index]->num_particles;

	for (i=0; i<amount; i++)
	{
		particleset[index]->particles_transform[i]->pos.x=(particleset[indexto]->particles_transform[i]->pos.x*factor)+(particleset[indexfrom]->particles_transform[i]->pos.x*(1-factor));
		particleset[index]->particles_transform[i]->pos.y=(particleset[indexto]->particles_transform[i]->pos.y*factor)+(particleset[indexfrom]->particles_transform[i]->pos.y*(1-factor));
	}
}

void Layer::Test()
{
	if (static int g=1)
	{
		FILE *fp=fopen("__out.txt","w");
		fprintf(fp,"text = %s\n",GetString(0)->GetText());
		fprintf(fp,"length=%d",GetString(0)->GetLength());
		fclose(fp);
		g=0;
	}
}

/*
void Layer::SetStringMode()
{
}*/

int Layer::SaveTGA(char *filename)
{
	FILE *fp;
	if ((fp=fopen(filename,"wb"))==NULL) return 1;

	//tga header for (uncompressed) .tgas
	unsigned char tga_header[12]={0,0,2,0,0,0,0,0,0,0,0,0};
	//width  => header[0]+header[1]*256;
	//height => header[2]+header[3]*256;
	//bits per pixel => header[4]
	//? => header[5]

	unsigned char header[6];
	header[0]=(int)(mainbuffer.width%256);
	header[1]=(int)(mainbuffer.width/256);
	header[2]=(int)(mainbuffer.height%256);
	header[3]=(int)(mainbuffer.height/256);
	header[4]=32;
	header[5]=0;

	fwrite(tga_header, sizeof(unsigned char), 12, fp);
	fwrite(header, sizeof(unsigned char), 6, fp);
//	fwrite(mainbuffer.pixel, sizeof(unsigned int), mainbuffer.size, fp);
	fwrite(mainbuffer.cpixel, sizeof(unsigned char), mainbuffer.csize, fp);
	fclose(fp);
	return 0;
}

Layer loading;
void loading_incrementer(float step, int length)
{
	int x,y,px;
	int posx=121;
	int posy=242;
	static float loading_counterf=0;
	int loading_counteri;

	//length: 323
	//length/323

//	loading_counterf+=(float)318/length;
	loading_counterf+=(float)320/length;
//	loading_counterf+=(float)320/6/length;
	loading_counteri=(int)loading_counterf;

	if ((fmod(loading_counterf, 2))<0.01)
	{
		for (px=0; px<loading_counteri+2; px++)
		for (y=0; y<10; y++)
//		for (y=4-(px/16); y<(6+px/16); y++)
		{
			int addr=(y+posy)*640;
//			for (x=0; x<5; x++)
			{
//				loading.mainbuffer.pixel[x+px+posx+addr]=0xffffff;
//				loading.mainbuffer.pixel[x+px+posx+addr]=0x5f8faf;//lysbl�
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=0x5f8faf;//lysbl�
//				loading.mainbuffer.pixel[x+px+posx+addr]=0x8faf5f;//gr�nn
//				loading.mainbuffer.pixel[x+px+posx+addr]=0x7f8f4f;//gr�nn m�rk
//				loading.mainbuffer.pixel[x+px*5+posx+addr]=0x7f8f4f;//gr�nn m�rk
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=0x7fbf4f;//gr�nn m�rk
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=RGB32(0x7f, 255-(0x2f+px*2), 0x4f);//gr�nn m�rk
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=(px%3)==0?0xff7f7f:(px%3)==1?0x7fff7f:0x7f7fff;//gr�nn m�rk
//				loading.mainbuffer.pixel[x+px+posx+addr]=0xaf8f5f;//brun
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=0xaf8f5f;//brun

//				loading.mainbuffer.pixel[px+posx+addr]=0xaf8f5f;//brun
				loading.mainbuffer.pixel[px+posx+addr]=0x8faf5f;//ligreen
//				loading.mainbuffer.pixel[px+posx+addr]=0x5f8faf;//lysbl�
//				loading.mainbuffer.pixel[px+posx+addr]=0xdf5f5f;//lysr�d

//				loading.mainbuffer.pixel[x+px*6+posx+addr]=RGB32(0xaf+(px),0x8f+(px*2),0x5f);//brun
//				loading.mainbuffer.pixel[x+px*6+posx+addr]=RGB32(127-(0xaf+(px)),127-(0x8f+(px*2)),0x5f);//brun
			}
		}
//		ptc_update(loading.mainbuffer.pixel);
	}
}




//
//AVI HACK by activator.. thanks to nehe.gamedev.net
//
#include <vfw.h>
#pragma comment(lib, "vfw32.lib")

//avi-player variables:
int next;
int aviframe=0;
AVISTREAMINFO psi;
PAVISTREAM pavi;
PGETFRAME pgf;
BITMAPINFOHEADER bmih;
long lastframe;
int	avi_width, avi_height;
char *pdata; // texturedata pointer
int	mpf; // milliseconds per frame
int milliseconds, lasttickCount, tickCount;

HDRAWDIB hdd;	//handle to dib
HBITMAP hBitmap;
HDC hdcCompatible = CreateCompatibleDC(0);
unsigned char *avidata = 0; // pointer to resized image
//*********

//flip red and blue bytes in size(bsize)
void flipIt(void* buffer, int bsize)
{
	void* b = buffer;
	__asm
	{
		mov ecx, bsize
		mov ebx, b
		label:
			mov al,[ebx+0]
			mov ah,[ebx+2]
			mov [ebx+2],al
			mov [ebx+0],ah
			add ebx,3
			dec ecx
		jnz label
	}
}

void Layer::makeAVIbuffer(LPCSTR szFile)
{
	TCHAR	title[100];
	AVIFileInit();
	if (AVIStreamOpenFromFile(&pavi, szFile, streamtypeVIDEO, 0, OF_READ, NULL) !=0)
		MessageBox (HWND_DESKTOP, "Failed to open avi stream", "Error", MB_OK | MB_ICONEXCLAMATION);

	AVIStreamInfo(pavi, &psi, sizeof(psi));
	avi_width=psi.rcFrame.right-psi.rcFrame.left;
	avi_height=psi.rcFrame.bottom-psi.rcFrame.top;
	
	AddBuffer(avi_width, avi_height, 0);
//	scrbuffer tobuffer=s_make(avi_width, avi_height, 0);

	lastframe=AVIStreamLength(pavi);
	mpf=AVIStreamSampleToTime(pavi,lastframe)/lastframe;
	bmih.biSize		= sizeof (BITMAPINFOHEADER);
	bmih.biPlanes		= 1;
	bmih.biBitCount		= 24; // bits (24 Bit, 3 Bytes)
	bmih.biWidth		= avi_width;
	bmih.biHeight		= avi_height;
	bmih.biCompression	= BI_RGB;

	hBitmap = CreateDIBSection (hdcCompatible, (BITMAPINFO*)(&bmih), DIB_RGB_COLORS, (void**)(&avidata), NULL, NULL);
	SelectObject (hdcCompatible, hBitmap);
	pgf=AVIStreamGetFrameOpen(pavi, NULL);
	if (pgf==NULL) MessageBox (HWND_DESKTOP, "Failed to open AVI frame", "Error", MB_OK | MB_ICONEXCLAMATION);
//	return tobuffer;
}

unsigned char *colorbuf;
void Layer::GrabAVIFrame(int tobuffer, int frame)						// Grabs A Frame From The Stream
{
	int size=getSizeBuffer(tobuffer);
	unsigned int *buffert=getPixelBuffer(tobuffer);
	RECT r;
	LPBITMAPINFOHEADER lpbi;
	lpbi = (LPBITMAPINFOHEADER)AVIStreamGetFrame(pgf, frame);
	pdata=(char *)lpbi+lpbi->biSize+lpbi->biClrUsed * sizeof(RGBQUAD);

//	convert data to req. bitmap format
//	DrawDibDraw (hdd, hdcCompatible, 0, 0, 512, 288, lpbi, pdata, 0, 0, avi_width, avi_height, 0);
	flipIt(avidata, avi_width*avi_height);

	colorbuf=(unsigned char *)pdata;
	for (int i=0; i<size; i++)
		buffert[size-1-i]=colorbuf[i*3]+(colorbuf[i*3+1]<<8)+(colorbuf[i*3+2]<<16);
}

void CloseAVI(void)							// Properly Closes The Avi File
{
	DeleteObject(hBitmap);						// Delete The Device Dependant Bitmap Object
	DrawDibClose(hdd);						// Closes The DrawDib Device Context
	AVIStreamGetFrameClose(pgf);					// Deallocates The GetFrame Resources
	AVIStreamRelease(pavi);						// Release The Stream
	AVIFileExit();							// Release The File
}
