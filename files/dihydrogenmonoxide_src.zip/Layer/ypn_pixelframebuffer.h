#include "../commonheaders/ypn_common.h"

#define MASK_DEFAULT 0
#define MASK_NONZERO 1
#define MASK_ALPHACHANNEL 2
#define MASK_TRANSPARENCY_ADD 3
#define MASK_TRANSPARENCY_SUB 4

#define on TRUE
#define off FALSE

class PixelFrameBuffer
{
public:
	PixelFrameBuffer();
	PixelFrameBuffer(int _width, int _height, int _color);
	~PixelFrameBuffer();

	void Init(int _width, int _height);
	void Init(int _width, int _height, int _color);

	void Free();

	void Clear();
	void Clear(int _color);

	void SetMaskMode(int mode);

//	void PutBuffer(PixelFrameBuffer frombuffer, int posx, int posy);
//	void PutBuffer(PixelFrameBuffer frombuffer, int posx, int posy);

	//Blend Modes: Normal, Multiply Lighten, Screen, Difference,
	//void BlendNormal(PixelFrameBuffer frombuffer, uchar alpha);
	void BlendNormal(PixelFrameBuffer frombuffer, int alpha);

	void Add(int color);

	void operator+=(int _color) { color+=_color; Clear(); }
	void operator-=(int _color) { color-=_color; Clear(); }
	friend PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, int _color);
	friend PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, PixelFrameBuffer &frombuffer);
	friend PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, PixelFrameBuffer *frombuffer);

	//works
	PixelFrameBuffer operator+=(PixelFrameBuffer &frombuffer);
	PixelFrameBuffer operator-=(PixelFrameBuffer &frombuffer);
	PixelFrameBuffer operator&=(PixelFrameBuffer &frombuffer);
	PixelFrameBuffer operator|=(PixelFrameBuffer &frombuffer);
	PixelFrameBuffer operator^=(PixelFrameBuffer &frombuffer);

	void operator+=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		int t=frombuffer->size;
		for (;temp-=4;t--)
		{
			if (frombuffer->pixel[t]!=0)
			{
				int r=cpixel[temp+2]+frombuffer->cpixel[temp+2];
				int g=cpixel[temp+1]+frombuffer->cpixel[temp+1];
				int b=cpixel[temp]+frombuffer->cpixel[temp];
				wrapByte(&r);
				wrapByte(&g);
				wrapByte(&b);
				pixel[s--]=RGB32(r,g,b);
			}
			else s--;
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]+=frombuffer->pixel[temp];
	}

	void operator-=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		for (;temp-=4;)
		{
			int r=cpixel[temp+2]-frombuffer->cpixel[temp+2];
			int g=cpixel[temp+1]-frombuffer->cpixel[temp+1];
			int b=cpixel[temp]-frombuffer->cpixel[temp];
			wrapByte(&r);
			wrapByte(&g);
			wrapByte(&b);
			pixel[s--]=RGB32(r,g,b);
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]-=frombuffer->pixel[temp];
	}

	void operator*=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		for (;temp-=4;)
		{
			int r=cpixel[temp+2]*frombuffer->cpixel[temp+2];
			int g=cpixel[temp+1]*frombuffer->cpixel[temp+1];
			int b=cpixel[temp]*frombuffer->cpixel[temp];
//			wrapByte(&r);
//			wrapByte(&g);
//			wrapByte(&b);
			pixel[s--]=RGB32(r,g,b);
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]*=frombuffer->pixel[temp];
	}

	void operator/=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		for (;temp-=4;)
		{
			int r=cpixel[temp+2]/frombuffer->cpixel[temp+2];
			int g=cpixel[temp+1]/frombuffer->cpixel[temp+1];
			int b=cpixel[temp]/frombuffer->cpixel[temp];
//			wrapByte(&r);
//			wrapByte(&g);
//			wrapByte(&b);
			pixel[s--]=RGB32(r,g,b);
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]/=frombuffer->pixel[temp];
	}

	void operator^=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		for (;temp-=4;)
		{
			int r=cpixel[temp+2]^frombuffer->cpixel[temp+2];
			int g=cpixel[temp+1]^frombuffer->cpixel[temp+1];
			int b=cpixel[temp]^frombuffer->cpixel[temp];
			wrapByte(&r);
			wrapByte(&g);
			wrapByte(&b);
			pixel[s--]=RGB32(r,g,b);
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]^=frombuffer->pixel[temp];
	}

	void operator&=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		int t=frombuffer->size;
		for (;temp-=4;t--)
		{
			if (frombuffer->pixel[t]!=0)
			{
				int r=cpixel[temp+2]&frombuffer->cpixel[temp+2];
				int g=cpixel[temp+1]&frombuffer->cpixel[temp+1];
				int b=cpixel[temp]&frombuffer->cpixel[temp];
				wrapByte(&r);
				wrapByte(&g);
				wrapByte(&b);
				pixel[s--]=RGB32(r,g,b);
			}
			else s--;
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]&=frombuffer->pixel[temp];
	}

	void operator|=(PixelFrameBuffer *frombuffer)
	{
		int s=size;
		temp=frombuffer->csize;
		for (;temp-=4;)
		{
			int r=cpixel[temp+2]|frombuffer->cpixel[temp+2];
			int g=cpixel[temp+1]|frombuffer->cpixel[temp+1];
			int b=cpixel[temp]|frombuffer->cpixel[temp];
			wrapByte(&r);
			wrapByte(&g);
			wrapByte(&b);
			pixel[s--]=RGB32(r,g,b);
		}
//		temp=frombuffer->size; for (;temp--;) pixel[temp]|=frombuffer->pixel[temp];
	}

	void InitPlasma();
	void Plasma(float time);
	void Noise(int col);
	void AddBlocksH(int blockwidth, int distwidth, int color);
	void AddBlocksV(int blockheight, int distheight, int color);
	void GradientLinear(int color);
	void GradientRadial(int color);
	void GradientReflected(int color);
	void Flower(int color);
//	void BlurGaussian(

	int temp;	//for temporary purposes (don't remove)

	//plasma
	uchar *sine_table;
//	uchar sine_table[256];
	int pf[4];

	int color,maskMode;
	int width,height;
	int size,csize;

	unsigned int *palette;
//	unsigned int palette[256];
	bool palette_flag;

	unsigned int *pixel;
	unsigned char *cpixel;
};
