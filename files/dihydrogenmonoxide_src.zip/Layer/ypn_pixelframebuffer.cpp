#include "ypn_pixelframebuffer.h"
#include "../timerclass/ypn_timer.h"

PixelFrameBuffer::PixelFrameBuffer()
{
	maskMode=MASK_ALPHACHANNEL;
	color=0;	//black color (default)
}

PixelFrameBuffer::PixelFrameBuffer(int _width, int _height, int _color)
{
	maskMode=MASK_ALPHACHANNEL;
	Init(_width, _height, _color);
}

PixelFrameBuffer::~PixelFrameBuffer()
{

}

void PixelFrameBuffer::Init(int _width, int _height)
{
	width=_width;
	height=_height;
	size=_width*_height;
	csize=size*4;	//4 channels (bytes)
	pixel=(unsigned int *)malloc(csize);
	cpixel=(unsigned char *)pixel;
	Clear();

	maskMode=MASK_DEFAULT;

	palette=(unsigned int *)malloc(sizeof(unsigned int)*256);
	palette_flag=off;

	//init other stuff
	InitPlasma();
}

void PixelFrameBuffer::Init(int _width, int _height, int _color)
{
	color=_color;
	Init(_width,_height);
}

void PixelFrameBuffer::Free()
{
	free(sine_table);
	free(palette);
	free(pixel);
}

void PixelFrameBuffer::Clear()
{
	for (int i=0; i<size; i++) pixel[i]=color;
}

void PixelFrameBuffer::Clear(int _color)
{
	color=_color;
	Clear();
}

void PixelFrameBuffer::SetMaskMode(int mode)
{
	maskMode=mode;
}

void PixelFrameBuffer::Add(int color)
{
	for (int i=0; i<size; i++) pixel[i]+=color;
}

PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, int _color)
{
	int size=tobuffer.size;
	for (int i=0; i<size; i++) tobuffer.pixel[i]+=_color;
	return tobuffer;
}

PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, PixelFrameBuffer &frombuffer)
{
	int size=tobuffer.size;
	for (int i=0; i<size; i++) tobuffer.pixel[i]+=frombuffer.pixel[i];
	return tobuffer;
}

PixelFrameBuffer operator+(PixelFrameBuffer &tobuffer, PixelFrameBuffer *frombuffer)
{
	int size=tobuffer.size;
	for (int i=0; i<size; i++) tobuffer.pixel[i]+=frombuffer->pixel[i];
	return tobuffer;
}

//works
PixelFrameBuffer PixelFrameBuffer::operator +=(PixelFrameBuffer &frombuffer)
{
	int i,r,g,b,size;
	uchar rf,gf,bf,rt,gt,bt;
	PixelFrameBuffer *tobuffer=this;
	size=tobuffer->size;
	for (i=0; i<size; i++)
	{
		rf=frombuffer.cpixel[2+(i<<2)];
		gf=frombuffer.cpixel[1+(i<<2)];
		bf=frombuffer.cpixel[(i<<2)];
		rt=tobuffer->cpixel[2+(i<<2)];
		gt=tobuffer->cpixel[1+(i<<2)];
		bt=tobuffer->cpixel[(i<<2)];
		r=rt+rf;
		g=gt+gf;
		b=bt+bf;
		r=(r<0)?0:(r>255)?255:r;
		g=(g<0)?0:(g>255)?255:g;
		b=(b<0)?0:(b>255)?255:b;
		tobuffer->pixel[i]=RGB32(r,g,b);
	}
	return *tobuffer;
}

PixelFrameBuffer PixelFrameBuffer::operator -=(PixelFrameBuffer &frombuffer)
{
	int i,r,g,b,size;
	uchar rf,gf,bf,rt,gt,bt;
	PixelFrameBuffer *tobuffer=this;
	size=tobuffer->size;
	for (i=0; i<size; i++)
	{
		rf=frombuffer.cpixel[2+(i<<2)];
		gf=frombuffer.cpixel[1+(i<<2)];
		bf=frombuffer.cpixel[(i<<2)];
		rt=tobuffer->cpixel[2+(i<<2)];
		gt=tobuffer->cpixel[1+(i<<2)];
		bt=tobuffer->cpixel[(i<<2)];
		r=rt-rf;
		g=gt-gf;
		b=bt-bf;
		r=(r<0)?0:(r>255)?255:r;
		g=(g<0)?0:(g>255)?255:g;
		b=(b<0)?0:(b>255)?255:b;
		tobuffer->pixel[i]=RGB32(r,g,b);
	}
	return *tobuffer;
}

PixelFrameBuffer PixelFrameBuffer::operator &=(PixelFrameBuffer &frombuffer)
{
	int i,r,g,b,size;
	uchar rf,gf,bf,rt,gt,bt;
	PixelFrameBuffer *tobuffer=this;
	size=tobuffer->size;
	for (i=0; i<size; i++)
	{
		rf=frombuffer.cpixel[2+(i<<2)];
		gf=frombuffer.cpixel[1+(i<<2)];
		bf=frombuffer.cpixel[(i<<2)];
		rt=tobuffer->cpixel[2+(i<<2)];
		gt=tobuffer->cpixel[1+(i<<2)];
		bt=tobuffer->cpixel[(i<<2)];
		r=rt&rf;
		g=gt&gf;
		b=bt&bf;
		r=(r<0)?0:(r>255)?255:r;
		g=(g<0)?0:(g>255)?255:g;
		b=(b<0)?0:(b>255)?255:b;
		tobuffer->pixel[i]=RGB32(r,g,b);
	}
	return *tobuffer;
}

PixelFrameBuffer PixelFrameBuffer::operator |=(PixelFrameBuffer &frombuffer)
{
	int i,r,g,b,size;
	uchar rf,gf,bf,rt,gt,bt;
	PixelFrameBuffer *tobuffer=this;
	size=tobuffer->size;
	for (i=0; i<size; i++)
	{
		rf=frombuffer.cpixel[2+(i<<2)];
		gf=frombuffer.cpixel[1+(i<<2)];
		bf=frombuffer.cpixel[(i<<2)];
		rt=tobuffer->cpixel[2+(i<<2)];
		gt=tobuffer->cpixel[1+(i<<2)];
		bt=tobuffer->cpixel[(i<<2)];
		r=rt|rf;
		g=gt|gf;
		b=bt|bf;
		r=(r<0)?0:(r>255)?255:r;
		g=(g<0)?0:(g>255)?255:g;
		b=(b<0)?0:(b>255)?255:b;
		tobuffer->pixel[i]=RGB32(r,g,b);
	}
	return *tobuffer;
}

PixelFrameBuffer PixelFrameBuffer::operator ^=(PixelFrameBuffer &frombuffer)
{
	int i,r,g,b,size;
	uchar rf,gf,bf,rt,gt,bt;
	PixelFrameBuffer *tobuffer=this;
	size=tobuffer->size;
	for (i=0; i<size; i++)
	{
		rf=frombuffer.cpixel[2+(i<<2)];
		gf=frombuffer.cpixel[1+(i<<2)];
		bf=frombuffer.cpixel[(i<<2)];
		rt=tobuffer->cpixel[2+(i<<2)];
		gt=tobuffer->cpixel[1+(i<<2)];
		bt=tobuffer->cpixel[(i<<2)];
		r=rt^rf;
		g=gt^gf;
		b=bt^bf;
		r=(r<0)?0:(r>255)?255:r;
		g=(g<0)?0:(g>255)?255:g;
		b=(b<0)?0:(b>255)?255:b;
		tobuffer->pixel[i]=RGB32(r,g,b);
	}
	return *tobuffer;
}

/*
void PixelFrameBuffer::PutBuffer(PixelFrameBuffer frombuffer, int posx, int posy)
{
	int yaddr,yaddr2;
	int bwidth=frombuffer.width;
	int bheight=frombuffer.height;
	for (int y=0; y<bheight; y++)
	{
		yaddr=(y+posy)*width;
		yaddr2=y*bwidth;
		for (int x=0; x<bwidth; x++)
			pixel[(x+posx)+yaddr]=frombuffer.pixel[x+yaddr2];
	}
}
*/
/*
void PixelFrameBuffer::PutBuffer(PixelFrameBuffer frombuffer, int posx, int posy)
{
	int bwidth=frombuffer.width;
	int bheight=frombuffer.height;
	for (int y=0; y<bheight; y++)
	{
		for (int x=0; x<bwidth; x++)
		{
			pixel[(x+posx)+(y+posy)*width]=frombuffer.pixel[x+y*bwidth];
		}
	}
}
*/


//void PixelFrameBuffer::BlendNormal(PixelFrameBuffer frombuffer, uchar alpha)
void PixelFrameBuffer::BlendNormal(PixelFrameBuffer frombuffer, int alpha)
{
	int i,rb,g,dst,src;
	uchar alphainv;

	alpha=(alpha>=255)?255:(alpha<=0)?0:alpha;
	alphainv=255-alpha;

	for(i=0; i<size; i++)
	{
//		dst=pixel[size-temp];
		dst=pixel[i];
		src=*frombuffer.pixel++;
		rb=((((dst&0xff00ff)*alpha)+((src&0xff00ff)*alphainv))>>8)&0xff00ff;
		g=((((dst&0x00ff00)*alpha)+((src&0x00ff00)*alphainv))>>8)&0x00ff00;
//		pixel[size-temp]=rb+g;
		pixel[i]=rb+g;
	}
}

void PixelFrameBuffer::InitPlasma()
{
	sine_table=(uchar *)malloc(sizeof(uchar)*256);
	for (int i=0; i<256; i++)
	{
		int col=32+(int)(sin(i*(6.28318531/256))*32);
		if (col<0) col=0;
//		if (col>63) col=63;
		if (col>255) col=255;
		sine_table[i]=col;
	}
	pf[0]=563;
	pf[1]=233;
	pf[2]=4325;
	pf[3]=312556;
}

void PixelFrameBuffer::Plasma(float time)
{
	int pt[4],offs=0;

	pf[0]=(time*100*6);
	pf[1]=(time*100*5);
	pf[2]=(time*100*4);
	pf[3]=(time*100*5);
	pt[0]=pf[0];
	pt[1]=pf[1];
	pt[2]=pf[2];
	pt[3]=pf[3];
	for (int y=0; y<height; y++)
	{
//		pt[0]=pf[0];
//		pt[1]=pf[1];
		for (int x=0; x<width; x++)
		{
			int col=(sine_table[pt[0]&255]+sine_table[pt[1]&255]+sine_table[pt[2]&255]+sine_table[pt[3]&255]);
			(col>=255)?(col=255):(col<0)?(col=0):0;
			//cpixel[channel+((offs++)<<2)]=col;
//			pixel[offs++]=RGB32(col,col,col);
			pixel[offs++]=palette[col&0xff];//RGB32(col,col,col);
//			pt[0]+=2;
//			pt[1]-=5;
			pt[0]=2*x+ ftime*200  +pf[0];
			pt[1]=-(5*x) +ftime*400 - pf[1];
//			pt[0]=2*(x+ftime)*200;
//			pt[1]=-5*(x+ftime)*400;
		}
//		pt[2]+=2;
//		pt[3]+=4;
		pt[2]=y*2+ ftime*160 + pf[2];
		pt[3]=y*4+ ftime*320 + pf[3];
	}
}

void PixelFrameBuffer::Noise(int col)
{
	int c,s=size;
	for (int i=0; i<s; i++)
	{
		c=rand()%col;
		pixel[i]=RGB32(c,c,c);
	}
}


void PixelFrameBuffer::AddBlocksH(int blockwidth, int distwidth, int color)
{
	int x,y,xs;
	int xstep=blockwidth+distwidth;

	for (xs=0; xs<width; xs+=xstep)
	for (x=0; x<blockwidth; x++)
	for (y=0; y<height; y++)
		pixel[x + xs + y*width]=color;
}

void PixelFrameBuffer::AddBlocksV(int blockheight, int distheight, int color)
{
	int x,y,ys;
	int ystep=blockheight+distheight;

	for (ys=0; ys<height; ys+=ystep)
	for (x=0; x<width; x++)
	for (y=0; y<blockheight; y++)
		pixel[x + (y+ys)*width]=color;
}

//
//Gradient Tool:
//
//Gradient Styles: Linear Gradient, Radial Gradient, Angle Gradient, Reflected Gradient, Diamond Gradient.
//
void PixelFrameBuffer::GradientLinear(int color)
{
	int x,y;
	float fr=getRed(color)/height;
	float fg=getGreen(color)/height;
	float fb=getBlue(color)/height;
	for (y=0; y<height; y++)
	{
		int cr=y*fr;
		int cg=y*fg;
		int cb=y*fb;
		int yaddr=y*width;
		for (x=0; x<width; x++)
		{
			pixel[x+yaddr]=RGB32(cr,cg,cb);
		}
	}
}

void PixelFrameBuffer::GradientRadial(int color)
{
	int x,y,r,g,b,yaddr;
	float dx,dy,i;
	int wh=width/2;
	int hh=height/2;
	float fx=1.0/wh;
	float fy=1.0/hh;
	for (y=0; y<height; y++)
	{
		yaddr=y*width;
		dy=(y-hh)*fy;
		for (x=0; x<width; x++)
		{
			dx=(x-wh)*fx;
			i=1-sqrt(SQR(dx)+SQR(dy));
			if (i<0) i=0;
			r=(color&0xff0000)>>16;
			g=(color&0x00ff00)>>8;
			b=(color&0x0000ff);
			pixel[x+yaddr]=RGB32((int)(i*r),(int)(i*g),(int)(i*b));
		}
	}
}

void PixelFrameBuffer::GradientReflected(int color)
{
	int x,y;
	float h_height=height/2.0f;
//	float fr=((color&0xff0000)>>16)/h_height;
	float fr=getRed(color)/h_height;
	float fg=getGreen(color)/h_height;
	float fb=getBlue(color)/h_height;
	for (y=0; y<h_height; y++)
	{
		int cr=y*fr;
		int cg=y*fg;
		int cb=y*fb;
		int yaddr=y*width;
		int yaddr2=((height-1)-y)*width;
		for (x=0; x<width; x++)
		{
			pixel[x+yaddr]=RGB32(cr,cg,cb);
			pixel[x+yaddr2]=RGB32(cr,cg,cb);
		}
	}
}

void PixelFrameBuffer::Flower(int color)
{
	int x,y,r,g,b;
    int wh=width/2;
    int hh=height/2;
	float factor;

	//generate flower image
	for (y=0; y<height; y++)
	for (x=0; x<width; x++)
	{
		factor=(
			1.0*cos(18*atan2((y-hh),(x-wh)))*255/M_2PI+
			0.3*sin(15*atan2((y-hh),(x-wh)))*255/M_2PI+
			sqrt((y-hh)*(y-hh)+(x-wh)*(x-wh)))/255;

		r=(color&0xff0000)>>16;
		g=(color&0x00ff00)>>8;
		b=(color&0x0000ff);

		pixel[x+y*width]=RGB32((int)(factor*r),(int)(factor*g),(int)(factor*b));
	}

    // You might want to move the 1.0 and 0.3 and the 18 and the 15
    // to parameters passed to the generate function...
    // the 1.0 and the 0.3 define the 'height' of the flower, while the
    // 18 and 15 control the number of 'petals'
}