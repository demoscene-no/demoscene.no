#ifndef _layer
#define _layer

#include "../timerclass/ypn_timer.h"
#include "../layer/ypn_pixelframebuffer.h"
#include "../Unassorted/ypn_font.h"
#include "../Unassorted/ypn_string.h"
#include "../particleengine/ypn_particle.h"
#include "../3d/ypn_object.h"
#include <string>
#include <iostream>
using namespace std;

#define MAINBUFFER -1
#define SCREENBUFFER -1
#define BLACKBUFFER -2
#define WHITEBUFFER -3
#define TEMPBUFFER -4

typedef struct
{
	float x,y;
} FVector2D;

typedef struct
{
	int background_color;
	int foreground_color;
	bool bold;	//bold on or off.
	int character;
} ansi;

extern int mode13h_colors[16];

typedef struct
{
//	int x0,y0,x1,y1,x2,y2,x3,y3;
	Coord2Df p[4];
} Quad2D;

class Object;
class Layer
{
public:
	Layer();
	Layer(int _width, int _height);
	Layer(int _width, int _height, int color);
	~Layer();

	void Free();
	void FreeTunnel();

	void Init(int _width, int _height);
	void Init(int _width, int _height, int color);
	void InitLeading();

	void addBuffer();
	void AddBuffer(int _width, int _height);
	void AddBuffer(int _width, int _height, int color);
	void AddImage(char *filename);
	void SaveImage(char *filename, int frombuffer);
	void AddRawFile(char *filename);

	void SetMaskMode(int mode);
	void SetMaskMode(int tobuffer, int mode);
	int maskMode;

	unsigned int *getPixelBuffer(int index);
	int getWidthBuffer(int index);
	int getHeightBuffer(int index);
	int getCSizeBuffer(int index);
	int getSizeBuffer(int index);
	int getMaskBuffer(int index);
	void setMaskBuffer(int index, int mode);
	unsigned int *getPaletteBuffer(int index);
	bool getPaletteflagBuffer(int index);

	//Generere buffre (texgen, osv osv.)
	void AddBlocksH(int scrwidth, int scrheight, int blockwidth, int distwidth, int color);
	void AddBlocksV(int scrwidth, int scrheight, int blockheight, int distheight, int color);
	void AddGradientLinear(int _width, int _height, int color);
	void AddGradientRadial(int _width, int _height, int color);
	void AddGradientReflected(int _width, int _height, int color);
	void AddCheckerboard(int _width, int _height, int size);
	void AddCheckerboard(int _width, int _height, int amount, int col1, int col2);
	void AddNoise(int _width, int _height, int col, int seed);
	void GenerateNoise(int tobuffer, int amplitude, int frequency, int seed);
	void AddFlower(int _width, int _height, int col);
	void AddColor(int color);
	void AddPalette(int tobuffer, int index_from, int index_to, int col_from, int col_to);
	void AddPalette(int tobuffer, int index, int col);
	void AddLensFlare(int width, int height, int type);

	void NoiseVLine(int tobuffer, int px, int seed, int strength);

	void SetFontPrefs(char *_fontname, int _pointsize);
	void SetFontPrefs(char *_fontname, char *_fontfile, int _pointsize);
	void InitFontMemDC(int width, int height);
//	void AddTTFFont(int width, int height, char font, char *fontfile);
	void AddTTFFont(int width, int height, char font);

/*
//	void AddTTFFont(char font);
//	void AddTTFFont(char font, char *fontfile, char *fontname);
	void AddTTFFont(int width, int height, char font, char *fontfile, char *fontname, int pointsize);
//	void AddTTFText(int width, int height, char *text, char *fontfile, char *fontname, int fwidth, int fheight);
*/

	void AddTTFText(int width, int height, char *text, char *fontfile, char *fontname, int pointsize);
//	void AddAnsi(char *filename);
	void AddAnsi(char *filename, ansi *ansitable);

	void ClearBuffer(int index);
	void ClearBuffer(int index, int col);
	void CopyBuffer(int tobuffer, int frombuffer);
	void CopyBufferLayer(int tobuffer, Layer fromlayer, int frombuffer);
	void CopyBufferChannel(int tobuffer, int frombuffer, int channel_to, int channel_from);
	void CopyBufferArea(int tobuffer, int frombuffer, int px, int py);
	void NoiseSpanHorisontal(int tobuffer, int frombuffer, int amount);
	void NoiseSpanVertical(int tobuffer, int frombuffer, int amount);
	void WrapBuffer(int tobuffer, int frombuffer, int offsetx, int offsety);

	friend Layer operator+(Layer &toLayer, Layer &fromLayer);
	void operator+=(PixelFrameBuffer *frombuffer) { mainbuffer+=frombuffer; }
//	void operator+=(Layer &fromLayer) { mainbuffer+=&fromLayer.mainbuffer; }
	void operator-=(Layer &fromLayer) { mainbuffer-=&fromLayer.mainbuffer; }
	void operator*=(Layer &fromLayer) { mainbuffer*=&fromLayer.mainbuffer; }
	void operator/=(Layer &fromLayer) { mainbuffer/=&fromLayer.mainbuffer; }
	void operator^=(Layer &fromLayer) { mainbuffer^=&fromLayer.mainbuffer; }
	void operator&=(Layer &fromLayer) { mainbuffer&=&fromLayer.mainbuffer; }
	void operator|=(Layer &fromLayer) { mainbuffer|=&fromLayer.mainbuffer; }

	unsigned int *showtime(float start_time, float end_time);

	void BlendNormal(int index, int alpha);
	void BlendNormal(Layer fromLayer, uchar alpha);
	void Blend(int tobuffer, int frombuffer, uchar alpha);
	void CrossFade(int tobuffer, int frombuffer, int alpha);
	void CrossFade(int tobuffer, int bufferto, int frombuffer, int alpha);
	void CrossFadeA(int tobuffer, int bufferto, int frombuffer, int alpha);

	void BlendAdd(int tobuffer, int frombuffer);
	void BlendAdd(int tobuffer, int frombuffer, int alpha);
	void BlendSub(int tobuffer, int frombuffer);
	void BlendSub(int tobuffer, int frombuffer, int alpha);

	void BlendMask(int tobuffer, int frombuffer);
	void BlendMask(int tobuffer, int frombuffer, int amount);
	void Darken(int tobuffer, int frombuffer, float factor);
	void Invert(int tobuffer, int frombuffer, int amount);

	void Plasma(int index, float ftime);
//	void Plasma(int index, int rgba, float ftime);
	void BumpMap(int tobuffer, int mapbuffer, int bumpbuffer, int lightbuffer, int xpos, int ypos);
	void Flower(int tobuffer, int frombuffer, float time);
	void FilterEdgeDetection(int tobuffer, int frombuffer);
	void Blur(int tobuffer, int frombuffer);
	void BlurH(int tobuffer, int frombuffer, int amount);
	void BlurHorisontal(int tobuffer);
	void geff_blur_fast_horiz(int tobuffer, int frombuffer, int xsize, int ysize, int amount);
	void geff_blur_fast_vert(int tobuffer, int frombuffer, int xsize, int ysize, int amount);
	//void geff_blur_fast_vert(int *src, int *dst, int xsize, int ysize, int amount);
	void Mosaic(int tobuffer, int frombuffer, int ratio);
	void Stretch(int tobuffer, int frombuffer, int posx, int posy, int s);
	void Bounce(int tobuffer, int frombuffer);
	void MotionBlur(int tobuffer, int frombuffer, int amount);

//	void InitTunnel(int perspective);
	void InitTunnel(int tobuffer, int perspective);
	void InitTunnel2(int perspective);
	void Tunnel2D(int tobuffer, int texture, int radius, int angle);
//	void Water2D(int tobuffer, int buffer1, int buffer2, int frombuffer);
	void Water2D(int tobuffer, int buffer1, int buffer2, int frombuffer, int shadefactor);

	void DrawBox(int tobuffer, int x1, int y1, int x2, int y2, int col);
	void InvertRectangle(int tobuffer, int px1, int py1, int px2, int py2, int frombuffer, int amount);
	void InvertRectangleAnim(int tobuffer, int px1, int py1, int px2, int py2, int col, float zero_to_one, int frombuffer, int amount);


	void InitTables();
	void PerformLight(int tobuffer, int px, int py);
	void BorderHorisontal(int tobuffer, int upperpos, int lowerpos, int col);

	void Run();

	void DrawBoxFilled(int tobuffer, int px, int py, int sx, int sy, int col);

	void PutBuffer(int tobuffer, int frombuffer, int posx, int posy, bool inv);
	void PutBuffer(int tobuffer, int frombuffer, int posx, int posy);
	void PutBuffer(int tobuffer, int frombuffer, int posx, int posy, int amount);
	void PutBuffer(int tobuffer, int frombuffer, int posx, int posy, float posz, int amount);
	void PutBufferPalette(int tobuffer, int frombuffer, int posx, int posy, int pall_for_black, int pall_for_white);
	void ScrollHorisontal(int tobuffer, int frombuffer, int py, int offset);
	void MoveLensFlares(int tobuffer, int frombufferstart, int frombufferend, int lx, int ly, int alpha);

	void Noise(int tobuffer, int col);

	Font font;
	void InitFonts(char *text, int col, int maskmode);
	void InitFonts(char *filename);
//	void PutFont(int num, int posx, int posy);
	void PutFont(char *c, int posx, int posy);
	void PutFont(char *c, int posx, int posy, int col);
	void PutFont(char c, int posx, int posy, int col);

	void TransitionThreshold(int tobuffer, int frombuffer, int maskbuffer, float amount);
	void FilterHexagon(int tobuffer, int frombuffer, int spritebuffer);
	void ResizeBilinear(int tobuffer, int frombuffer, int width, int height);
//	void Bezier(int tobuffer, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, int color);
//	void Bezier(int tobuffer, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, int npoints, int color);
	void Bezier(int tobuffer, Quad2D p, int npoints, int color);
	void Metaballs2D(int tobuffer, int antall, float motion, int style);
	void RadialBlurSubpixel(int tobuffer, int px, int py, double scalefactor);
	void RadialBlur(int tobuffer, float scale);

	void SetFFTSynch(bool flag);
	bool fft_flag;

	void PutStringWithBezier(int index, Quad2D p, float time, int mode, float step);
	void PutStringWithScroller(int index, float time);
	void PutStringWithCursor(int tobuffer, int stringlinefrom, int stringlineto, int fontinc, float timedelta, float delay);
	void PutStringWithCursor(int tobuffer, int posx, int posy, int stringlinefrom, int stringlineto, int fontinc, float delay);

	void ParticleGenerateFromImage(int frombuffer);
	void ParticleNormalize(int index1, int index2);
	void ParticleGenerateRandom(int amount);
	void ParticleGenerateRandom(int amount, Vector3D pos, Vector3D volume);
	void ParticleAddSet(int amount);
	void ParticleSetGravity(int index, Vector3D vel, Vector3D acc, float energy);
	void ParticleLoadFromObject(Object object);
	void ParticleShow(int tobuffer, int index);
	void ParticleShow(int tobuffer, int index, int spritebuffer);
	void ParticleShow3D(int tobuffer, int index, float zper, int wh, int hh);
	void ParticleShow3D(int tobuffer, int index, int spritebuffer, float zper, int wh, int hh);
	void ParticlePhysicsGravityFall(int index);
	void ParticleMorph(int index, int indexfrom, int indexto, float factor);

	Particle **particleset;
	int num_particleset;

//	PixelFrameBuffer *get_buffer(int index);
//	protected:
	PixelFrameBuffer **buffer;
	PixelFrameBuffer mainbuffer;
	PixelFrameBuffer blackbuffer;
	PixelFrameBuffer whitebuffer;
	PixelFrameBuffer tempbuffer;
	int num_buffer;


	//tunnels
//	int *Tsqrt;
//	int *Tatan2;
//	unsigned int *alpha_table;
//	unsigned long *flut;
	uchar *AngTable, *RadTable;
	char ysin[HEIGHT], xcos[WIDTH]; //plasma
	int *light_radius, *light_radius_temp;

	//Layer props:
	int width;
	int height;
	int size;

	void AddString(char *text);
	void AddString(char *text, int posx, int posy);

	String **strings;
	int stringCount;

	String *GetString(int index);
	int GetStringLength(int index);

	void Test();
	int SaveTGA(char *filename);

	void makeAVIbuffer(LPCSTR szFile);
	void GrabAVIFrame(int tobuffer, int frame);						// Grabs A Frame From The Stream


	// Music Syncronisation (for Eq and stuff like that)
	float fft[512]; // get the FFT data
	float fft_adapt[512]; //adapted

	//fonts
	int leading;


	//font engine
	char *fnt;
	RECT rect;
	BITMAPINFO bmi;
	HFONT hFont;
	HBITMAP hbitmap;
	HDC hdc,hdc_font;

	int pointsize;
	char *fontname;
	char *fontfile;
	bool flag_file;
};

void bezier(Coord2Df &topoint, Coord2Df p1, Coord2Df p2, Coord2Df p3, Coord2Df p4, float t);
void bezier(Coord2Df &topoint, Quad2D p, float t);


extern Layer loading;
extern void loading_incrementer(float step, int length);

/*
[10:32] <juhnu> sameladd, std::vector<PixelFrameBuffer*> buffers;   buffers.push_back(new PixelFrameBuffer(blabla) );         int number_of_buffers=int( buffers.size() );
[10:32] <juhnu> #include <vector>
[10:32] <sameladd> hmm. i should learn the basics first. what it all means
[10:32] <juhnu> buffers[0]->AccessingTheFirstElementInBuffer
*/


//avi-player variables:
extern int next;
extern int aviframe;
extern long lastframe;
extern int	avi_width, avi_height;
extern char *pdata; // texturedata pointer
extern int	mpf; // milliseconds per frame
extern int milliseconds, lasttickCount, tickCount;


#endif