//
//An GIF89a parser class, written by activator/yaphan.
//
//Tatt ut i fra GIF89a spesifikasjonsdokumentet som er Copyrighta CompuServe Incorporated, Columbus, Ohio
//
//NOTE!! NOT FINISHED!! NOT EVEN STARTED:PP

#include "../layer/ypn_layer.h"

class GIF89a: public Layer
{
public:
	void LoadGIF(char *filename);
};