	#include "../commonheaders/ypn_common.h"
	#include "zlib.h"
	#include "png.h"
#ifdef _PNG_LIB_
	#pragma comment(lib, "libpng.lib")
	#define PNG_BYTES_TO_CHECK 4 // number of bytes in png header to verify
#endif