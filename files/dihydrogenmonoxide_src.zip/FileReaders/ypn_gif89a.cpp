#include "ypn_gif89a.h"

void GIF89a::LoadGIF(char *filename)
{

}
