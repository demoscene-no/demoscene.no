#include "../layer/ypn_layer.h"

class TextureGenerator: public Layer
{
public:
	void GenerateClouds(int width, int height, int seed);
	void GeneratePerlinClouds(int width, int height, int seed);
};