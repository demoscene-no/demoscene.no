#include "ypn_texgen.h"

void TextureGenerator::GenerateClouds(int width, int height, int seed)
{
	//init memory mainbuffer to zero (black).
	Init(width, height, 0);

	//temporary buffer
	AddBuffer(width, height, 0);

	for (int i=0; i<8; i++)
	{
		int col=128/(i+1);	//need to reduce color per pass.

		//add some noise-buffers
		AddNoise(8*(i+1),8*(i+1), col, seed);
	}

	for (i=0; i<8; i++)
	{
		//skale em with bilinear filtering
		ResizeBilinear(0, i+1, width, height);	//resize into temporary buffer (and perform interpolation).
		mainbuffer+=buffer[0];	//add temporary buffer to mainbuffer (per pixel).
	}
}

void TextureGenerator::GeneratePerlinClouds(int width, int height, int seed)
{
	//init memory mainbuffer to zero (black).
	Init(width, height, 0);

	//temporary buffer
	AddBuffer(width, height, 0);

	int nx0,col;
	int x,y;
	int ax=0;
	int area, freq;

	//8 = noise functions
	int connection_points_x[6][128];
	int connection_points_y[6][128];
	int i,ix,n;
	int fx,fy;
	int amplitude;

	freq=4;
	amplitude=128;

	area=(float)256/freq;

	Vector3D v,a,b;

	int f=freq;
	for (n=0; n<6; n++)
	{
		for (x=0; x<f; x++)
			connection_points_x[n][x]=128+amplitude*(noise1d(seed+x+f))*0.5;
		f*=2;
	}
//	for (y=0; y<freq; y++)	connection_points_y[y]=128+amplitude*(noise1d(seed+y+freq))*0.5;

	f=freq;
	for (n=0; n<6; n++)
	for (y=0; y<256; y++)
	{
		for (fx=0; fx<f; fx++)
		{
			nx0=fx-1;
			if (nx0<0) nx0+=f;
			a.x=connection_points_x[n][nx0];
			b.x=connection_points_x[n][fx];

			for (x=0; x<area; x++)
			{
				v=v.CosineInterpolateR(a, b, x*(1.0/area));
				ix=v.x;

				col=ix;
				mainbuffer.pixel[(x+(fx*area))+y*256]=col;
			}
		}
		f*=2;
	}
}