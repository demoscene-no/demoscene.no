
// {{{ void g_i2swap(int *a, int *b)
void g_i2swap(int *a, int *b) {
   int tmp=(int)*a;
   *a=(int)*b;
   *b=tmp;
}
// }}} 

