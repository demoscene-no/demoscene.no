
#include "ypn_guru_inc.h"

#ifdef __cplusplus
   extern "C" {
#endif 

extern void g_clearz(int sizei);
extern void init_g_zbuffer(int width_, int height_);

extern void g_tri_flat(int *dst, int width, int height, int x1, int y1, int x2, int y2, int x3, int y3, int col);
extern void g_tri_flat_z(int *dst, int width, int height, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int col);
extern void g_tri_tmap(int *dst, int width, int x1, int y1, int u1, int v1, int x2, int y2, int u2, int v2, int x3, int y3, int u3, int v3, int *tmap, int mapsize);
extern void g_tri_tmap_z(int *dst, int width, int x1, int y1, int z1, int u1, int v1, int x2, int y2, int z2, int u2, int v2, int x3, int y3, int z3, int u3, int v3, int *tmap, int mapsize);
extern void g_tri_gouraud(int *dst, int width, int x1, int y1, g_irgb c1, int x2, int y2, g_irgb c2, int x3, int y3, g_irgb c3);
extern void g_tri_gouraud_z(int *dst, int width, int x1, int y1, int z1, g_irgb c1, int x2, int y2, int z2, g_irgb c2, int x3, int y3, int z3, g_irgb c3);
extern void g_tri_tmap_gouraud_z(int *pixel, int width, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int u1, int v1, int u2, int v2, int u3, int v3, g_irgb c1, g_irgb c2, g_irgb c3, int mapwidth, int *texture);
extern void g_tri_gouraud_palette(int *dst, int width, int x1, int y1, g_irgb c1, int x2, int y2, g_irgb c2, int x3, int y3, g_irgb c3, unsigned int *palette);
extern void drawtpolyperspsubtri(unsigned int *pixel, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float u1, float v1, float u2, float v2, float u3, float v3, unsigned int *texture);

#ifdef __cplusplus
	}
#endif 
