
#ifndef __GURUINC__
#define __GURUINC__

typedef struct {
   int r, g, b;
} g_irgb;

typedef struct {
   unsigned char r, g, b;
} g_crgb;

#endif

/*
#ifdef __cplusplus
   extern "C" {
#endif 
*/
	extern void g_i2swap(int *a, int *b);
/*
#ifdef __cplusplus
   }
#endif 
*/


