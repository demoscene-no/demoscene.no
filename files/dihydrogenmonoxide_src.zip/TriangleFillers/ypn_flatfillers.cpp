#include "ypn_flatfillers.h"
#include "../layer/ypn_layer.h"
#include <limits.h>

int *g_zbuffer;

void g_clearz(int sizei)
{
	while(sizei--) g_zbuffer[sizei]=INT_MIN; // change this to something silly 
}

void init_g_zbuffer(int width_, int height_)
{
	int size=width_*height_;
	int isize=size;
	g_zbuffer=(int *)malloc(isize*sizeof(int)); 
	while(isize--)
	{
		g_zbuffer[isize]=INT_MIN;
#ifdef _LOADING_SCREEN_
		loading_incrementer(1.0/size, size);
#endif
	}
}

//guru sin flat-filler (mod by activator)
void g_tri_flat(int *dst, int width, int height, int x1, int y1, int x2, int y2, int x3, int y3, int col)
{
	int dxdy1,dxdy2,dxdy3;
	int dxdy1_x,dxdy2_x,dxdy3_x;
	int xspan1, xspan2;
	int i,x,temp;

//	int *dst=layer.getPixelBuffer(tobuffer);
//	int width=layer.getWidthBuffer(tobuffer);
//	int width=WIDTH;

	if(y1>y2) {
      temp=y1;
      y1=y2;
      y2=temp;
      temp=x1;
      x1=x2;
      x2=temp;
   }

   if(y1>y3) {
      temp=y1;
      y1=y3;
      y3=temp;
      temp=x1;
      x1=x3;
      x3=temp;
   }

   if(y2>y3) {
      temp=y2;
      y2=y3;
      y3=temp;
      temp=x2;
      x2=x3;
      x3=temp;
   }

   if(x1==x2==x3 || y1==y2==y3) return; // no area covered at all
   if(y2-y1!=0) dxdy1=((x2-x1)<<16)/(y2-y1);
   else dxdy1=0;

   if(y3-y1!=0) dxdy2=((x3-x1)<<16)/(y3-y1);
   else dxdy2=0;

   if(y3-y2!=0) dxdy3=((x3-x2)<<16)/(y3-y2);
   else dxdy3=0;

   dxdy1_x=dxdy2_x=x1<<16;
   dxdy3_x=x2<<16;

   for(i=y1;i<y2;i++) {
      xspan1=(dxdy2_x>>16);
      xspan2=(dxdy1_x>>16);
      if(xspan1>xspan2) {
         temp=xspan2;
         xspan2=xspan1;
         xspan1=temp;
      }

      for(x=xspan1; x<xspan2; x++)
	  {
		  if (visible(x,i,width,height))
		  dst[x+i*width]=col;
	  }
      dxdy1_x+=dxdy1;
      dxdy2_x+=dxdy2;

   }

   for(;i<y3;i++) {
      xspan1=(dxdy2_x>>16);
      xspan2=(dxdy3_x>>16);
      if(xspan1>xspan2) {
         temp=xspan2;
         xspan2=xspan1;
         xspan1=temp;
      }
      for(x=xspan1; x<xspan2; x++) 
  	  {
		  if (visible(x,i,width,height))
			dst[x+i*width]=col;
	  }
      dxdy2_x+=dxdy2;
      dxdy3_x+=dxdy3;
   }
}

void g_tri_flat_hline_z(int *dst, int width, int height, int x1, int x2, int z1, int z2, int y, int col) {
   int dz, x;
   int *dstz;
   if(x2<x1) {
      g_i2swap(&x1, &x2);
      g_i2swap(&z1, &z2);
   }

   if(x2-x1!=0) dz=(z2-z1) / (x2-x1);
   else dz=0;

   dst=&dst[x1+y*width];
   dstz=&g_zbuffer[x1+y*width];
   for(x=x1; x<x2; x++, dst++, dstz++)
   {
	  if (visible(x,y,width,HEIGHT))
	  {
		if(*dstz!=INT_MIN)
		{
			if(z1>=*dstz)
			{
	            *dst=col;
				*dstz=z1;
			}
		}
		else
		{ // never touched before, just plot it to the zbuffer
			*dst=col;
			*dstz=z1;
		}
//		z1+=dz; //here
	  }
	  z1+=dz; //or here?
	}
}
// }}}

// {{{ void g_tri_flat_z(int *dst, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int col)
void g_tri_flat_z(int *dst, int width, int height, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int col) {
   int dxdy1,dxdy2,dxdy3;
   int dxdy1_x,dxdy2_x,dxdy3_x;

   int dzdy1, dzdy2, dzdy3;
   int dzdy1_z, dzdy2_z, dzdy3_z;

   int i,temp;
   if(y1>y2) {
      temp=y1;
      y1=y2;
      y2=temp;
      temp=x1;
      x1=x2;
      x2=temp;
      temp=z1;
      z1=z2;
      z2=temp;
   }

   if(y1>y3) {
      temp=y1;
      y1=y3;
      y3=temp;
      temp=x1;
      x1=x3;
      x3=temp;
      temp=z1;
      z1=z3;
      z3=temp;
   }

   if(y2>y3) {
      temp=y2;
      y2=y3;
      y3=temp;
      temp=x2;
      x2=x3;
      x3=temp;
      temp=z2;
      z2=z3;
      z3=temp;
   }

   if(x1==x2==x3 || y1==y2==y3) return; // no area covered at all
   if(y2-y1!=0) {
      dxdy1=((x2-x1)<<16)/(y2-y1);
      dzdy1=((z2-z1)<<8)/(y2-y1);
   } else {
      dxdy1=0;
      dzdy1=0;
   }

   if(y3-y1!=0) {
      dxdy2=((x3-x1)<<16)/(y3-y1);
      dzdy2=((z3-z1)<<8)/(y3-y1);
   } else {
      dxdy2=0;
      dzdy2=0;
   }

   if(y3-y2!=0) {
      dxdy3=((x3-x2)<<16)/(y3-y2);
      dzdy3=((z3-z2)<<8)/(y3-y2);
   } else {
      dxdy3=0;
      dzdy3=0;
   }

   

   dxdy1_x=dxdy2_x=x1<<16;
   dxdy3_x=x2<<16;

   dzdy1_z=dzdy2_z=z1<<8;
   dzdy3_z=z2<<8;

   for(i=y1;i<y2;i++) {
      g_tri_flat_hline_z(dst, width, height, dxdy1_x>>16, dxdy2_x>>16, dzdy1_z, dzdy2_z, i, col);
      dxdy1_x+=dxdy1;
      dxdy2_x+=dxdy2;
      dzdy1_z+=dzdy1;
      dzdy2_z+=dzdy2;
   }

   for(;i<y3;i++) {
      g_tri_flat_hline_z(dst, width, height, dxdy2_x>>16, dxdy3_x>>16, dzdy2_z, dzdy3_z, i, col);
      dxdy2_x+=dxdy2;
      dxdy3_x+=dxdy3;
      dzdy2_z+=dzdy2;
      dzdy3_z+=dzdy3;
   }
}
// }}}


/*
// original by guru.
// modification by activator on 29th of july 2003
// and also wrapping fixed.
void s_tri_tmap(unsigned int *tobuffer, int x1, int y1, int u1, int v1,
                          int x2, int y2, int u2, int v2,
                          int x3, int y3, int u3, int v3, unsigned int *texture) {
   int mapsize=256;//width
   int wrapx=mapsize-1;
   int wrapy=256-1;
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int _u1, _u2, _u3;
   int dudy1, dudy2, dudy3;
   int _v1, _v2, _v3;
   int dvdy1, dvdy2, dvdy3;
   int y2y1, y3y1, y3y2;
   int dudx, dvdx, u, v;
   int sx, ex;
   int x, y;

   if(y1>y2) {
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   if(y1>y3) {
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&u1, &u3);
      g_i2swap(&v1, &v3);
   }

   if(y2>y3) {
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&u2, &u3);
      g_i2swap(&v2, &v3);
   }

   y2y1=y2-y1; // middle
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dudy1=((u2-u1) << 16) / y2y1;
      dvdy1=((v2-v1) << 16) / y2y1;
   } else {
      dxdy1=dudy1=dvdy1=0;
   }

   y3y1=y3-y1; // long
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dudy2=((u3-u1) << 16) / y3y1;
      dvdy2=((v3-v1) << 16) / y3y1;
   } else {
      dxdy2=dudy2=dvdy2=0;
   }

   y3y2=y3-y2; // bottom
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dudy3=((u3-u2) << 16) / y3y2;
      dvdy3=((v3-v2) << 16) / y3y2;
   } else {
      dxdy3=dudy3=dvdy3=0;
   }

   // setup initial vars
   _x1=x1<<16; _u1=u1<<16; _v1=v1<<16; // long
   _x2=x1<<16; _u2=u1<<16; _v2=v1<<16; // middle
   _x3=x2<<16; _u3=u2<<16; _v3=v2<<16; // bottom

   // int dudx, dvdx, u, v; sx / ex
   for(y=y1; y<y2; y++) {
      if(_x2<_x1) {
         sx=_x2>>16;
         ex=_x1>>16;
         if(ex-sx!=0) {
            dudx=(_u1-_u2) / (ex-sx);
            dvdx=(_v1-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      } else {
         sx=_x1>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u1) / (ex-sx);
            dvdx=(_v2-_v1) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u1;
         v=_v1;
      }
      for(x=sx; x<ex; x++) {
         tobuffer[x+y*WIDTH]=texture[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x1+=dxdy1;
      _u1+=dudy1;
      _v1+=dvdy1;

      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;
   }

   for(; y<y3; y++) {
      if(_x3<_x2) {
         sx=_x3>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u3) / (ex-sx);
            dvdx=(_v2-_v3) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u3;
         v=_v3;
      } else {
         sx=_x2>>16;
         ex=_x3>>16;
         if(ex-sx!=0) {
            dudx=(_u3-_u2) / (ex-sx);
            dvdx=(_v3-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      }
      for(x=sx; x<ex; x++) {
         tobuffer[x+y*WIDTH]=texture[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;

      _x3+=dxdy3;
      _u3+=dudy3;
      _v3+=dvdy3;
   }
}

*/
// {{{ void g_tri_tmap_hline_z(int *dst, int x1, int x2, int z1, int z2, int u1, int v1, int u2, int v2, int mapsize)
void g_tri_tmap_hline_z(int *dst, int width, int x1, int x2, int z1, int z2, int y, int u1, int v1, int u2, int v2, int *tmap, int mapsize) {
   int x2x1, x, dz, color;
   int dudx, dvdx;
   int *dstz;

   if(x1>x2) { // swap
      g_i2swap(&x1, &x2);
      g_i2swap(&z1, &z2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   x2x1=x2-x1;
   if(x2x1!=0) {
      dz=(z2-z1)/x2x1;
      dudx=(u2-u1)/x2x1;
      dvdx=(v2-v1)/x2x1;
   } else {
      dz=dudx=dvdx=0;
   }	

   dst=&dst[x1+y*width];
   dstz=&g_zbuffer[x1+y*width];
   // go through the line
   for(x=x1; x<x2; x++, dst++, dstz++)
   {
	  if (visible(x,y,width,200))
	  {
		color=tmap[(u1>>16) + (v1>>16)*mapsize];
		if(*dstz!=INT_MIN)
		{
			if(z1>=*dstz)
			{
	            *dst=color;
				*dstz=z1;
			}
		} else
		{
			*dst=color;
			*dstz=z1;
		}
	  }
	u1+=dudx;
	v1+=dvdx;
	z1+=dz;
   }
}
// }}}

// {{{ void g_tri_tmap_z(int *dst, int x1, int y1, int z1, int u1, int v1, int x2, int y2, int z2, int u2, int v2, int x3, int y3, int z3, int u3, int v3, int *tmap, int mapsize)
void g_tri_tmap_z(int *dst, int width, int x1, int y1, int z1, int u1, int v1,
                            int x2, int y2, int z2, int u2, int v2,
                            int x3, int y3, int z3, int u3, int v3, int *tmap, int mapsize) {
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int _z1, _z2, _z3;
   int dzdy1, dzdy2, dzdy3;
   int _u1, _u2, _u3;
   int dudy1, dudy2, dudy3;
   int _v1, _v2, _v3;
   int dvdy1, dvdy2, dvdy3;
   int y2y1, y3y1, y3y2;
   int y;

   if(y1>y2) {
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&z1, &z2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   if(y1>y3) {
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&z1, &z3);
      g_i2swap(&u1, &u3);
      g_i2swap(&v1, &v3);
   }

   if(y2>y3) {
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&z2, &z3);
      g_i2swap(&u2, &u3);
      g_i2swap(&v2, &v3);
   }

   y2y1=y2-y1; // middle
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dzdy1=((z2-z1) << 8) / y2y1;
      dudy1=((u2-u1) << 16) / y2y1;
      dvdy1=((v2-v1) << 16) / y2y1;
   } else {
      dxdy1=dzdy1=dudy1=dvdy1=0;
   }

   y3y1=y3-y1; // long
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dzdy2=((z3-z1) <<8) / y3y1;
      dudy2=((u3-u1) << 16) / y3y1;
      dvdy2=((v3-v1) << 16) / y3y1;
   } else {
      dxdy2=dzdy2=dudy2=dvdy2=0;
   }

   y3y2=y3-y2; // bottom
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dzdy3=((z3-z2) << 8) / y3y2;
      dudy3=((u3-u2) << 16) / y3y2;
      dvdy3=((v3-v2) << 16) / y3y2;
   } else {
      dxdy3=dzdy3=dudy3=dvdy3=0;
   }

   // setup initial vars
   _x1=x1<<16; _z1=z1<<8; _u1=u1<<16; _v1=v1<<16; // long
   _x2=x1<<16; _z2=z1<<8; _u2=u1<<16; _v2=v1<<16; // middle
   _x3=x2<<16; _z3=z2<<8; _u3=u2<<16; _v3=v2<<16; // bottom

   for(y=y1; y<y2; y++) {
      g_tri_tmap_hline_z(dst, width, _x1>>16, _x2>>16, _z1, _z2, y, _u1, _v1, _u2, _v2, tmap, mapsize);
      _x1+=dxdy1;
      _z1+=dzdy1;
      _u1+=dudy1;
      _v1+=dvdy1;

      _x2+=dxdy2;
      _z2+=dzdy2;
      _u2+=dudy2;
      _v2+=dvdy2;
   }

   for(; y<y3; y++) {
      g_tri_tmap_hline_z(dst, width, _x2>>16, _x3>>16, _z2, _z3, y, _u2, _v2, _u3, _v3, tmap, mapsize);
      _x2+=dxdy2;
      _z2+=dzdy2;
      _u2+=dudy2;
      _v2+=dvdy2;

      _x3+=dxdy3;
      _z3+=dzdy3;
      _u3+=dudy3;
      _v3+=dvdy3;
   }
}
// }}} 

// tmapfillers

// {{{ void g_tri_tmap(int *dst, int x1, int y1, int u1, int v1, int x2, int y2, int u2, int v2, int x3, int y3, int u3, int v3, int *tmap, int mapsize)
// standard affine tmap shitty thing..
void g_tri_tmap(int *dst, int width, int x1, int y1, int u1, int v1,
                          int x2, int y2, int u2, int v2,
                          int x3, int y3, int u3, int v3, int *tmap, int mapsize) {
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int _u1, _u2, _u3;
   int dudy1, dudy2, dudy3;
   int _v1, _v2, _v3;
   int dvdy1, dvdy2, dvdy3;
   int y2y1, y3y1, y3y2;
   int dudx, dvdx, u, v;
   int sx, ex;
   int x, y, yaddr;

   if(y1>y2) {
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   if(y1>y3) {
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&u1, &u3);
      g_i2swap(&v1, &v3);
   }

   if(y2>y3) {
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&u2, &u3);
      g_i2swap(&v2, &v3);
   }

   y2y1=y2-y1; // middle
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dudy1=((u2-u1) << 16) / y2y1;
      dvdy1=((v2-v1) << 16) / y2y1;
   } else {
      dxdy1=dudy1=dvdy1=0;
   }

   y3y1=y3-y1; // long
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dudy2=((u3-u1) << 16) / y3y1;
      dvdy2=((v3-v1) << 16) / y3y1;
   } else {
      dxdy2=dudy2=dvdy2=0;
   }

   y3y2=y3-y2; // bottom
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dudy3=((u3-u2) << 16) / y3y2;
      dvdy3=((v3-v2) << 16) / y3y2;
   } else {
      dxdy3=dudy3=dvdy3=0;
   }

   // setup initial vars
   _x1=x1<<16; _u1=u1<<16; _v1=v1<<16; // long
   _x2=x1<<16; _u2=u1<<16; _v2=v1<<16; // middle
   _x3=x2<<16; _u3=u2<<16; _v3=v2<<16; // bottom

   // int dudx, dvdx, u, v; sx / ex
   for(y=y1; y<y2; y++) {
      if(_x2<_x1) {
         sx=_x2>>16;
         ex=_x1>>16;
         if(ex-sx!=0) {
            dudx=(_u1-_u2) / (ex-sx);
            dvdx=(_v1-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      } else {
         sx=_x1>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u1) / (ex-sx);
            dvdx=(_v2-_v1) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u1;
         v=_v1;
      }
	  yaddr=y*width;
      for(x=sx; x<ex; x++) {
//         dst[x+y*g_xres]=tmap[(u>>16) + (v>>16)*mapsize];
	  if (visible(x,y,width,HEIGHT))
         dst[x+yaddr]=tmap[((u>>16)&0xff) + (((v>>16)&0xff)*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x1+=dxdy1;
      _u1+=dudy1;
      _v1+=dvdy1;

      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;
   }

   for(; y<y3; y++) {
      if(_x3<_x2) {
         sx=_x3>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u3) / (ex-sx);
            dvdx=(_v2-_v3) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u3;
         v=_v3;
      } else {
         sx=_x2>>16;
         ex=_x3>>16;
         if(ex-sx!=0) {
            dudx=(_u3-_u2) / (ex-sx);
            dvdx=(_v3-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      }
	  yaddr=y*width;
      for(x=sx; x<ex; x++) {
//         dst[x+y*g_xres]=tmap[(u>>16) + (v>>16)*mapsize];
	  if (visible(x,y,width,HEIGHT))
         dst[x+yaddr]=tmap[((u>>16)&0xff) + (((v>>16)&0xff)*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;

      _x3+=dxdy3;
      _u3+=dudy3;
      _v3+=dvdy3;
   }
}
// }}}


//The fabulous texturemappedgouruadshadedzbuffered hline :t
void g_hline_tmap_gouraud_z(int *pixel, int width, int x1, int x2, int z1, int z2, int y, int u1, int u2, int v1, int v2, g_irgb colstart, g_irgb colend, int texwidth, int *texture)
{
	g_irgb colstep,col,tempc;
	int temp,color;
	int uinc,vinc;
	int u,v,x;
	int deltaZ,Z,tmap_ofs;
	int x2x1;
	g_irgb total,rgb_col;
	int mul;

	unsigned char *ctexture=(unsigned char *)texture;

	if(x1>x2)
	{
		temp=x1; x1=x2; x2=temp;
		temp=z1; z1=z2; z2=temp;
		temp=u1; u1=u2; u2=temp;
		temp=v1; v1=v2; v2=temp;
		tempc=colend;
		colend=colstart;
		colstart=tempc;
	}
	colstart.r=colstart.r>>16;
	colstart.g=colstart.g>>16;
	colstart.b=colstart.b>>16;
	colend.r=colend.r>>16;
	colend.g=colend.g>>16;
	colend.b=colend.b>>16;

	x2x1=x2-x1;
	if(x2x1!=0)
	{
		colstep.r=((colend.r-colstart.r)<<16) / (x2x1);
		colstep.g=((colend.g-colstart.g)<<16) / (x2x1);
		colstep.b=((colend.b-colstart.b)<<16) / (x2x1);
		uinc=((u2-u1)<<16) / (x2x1);
		vinc=((v2-v1)<<16) / (x2x1);
		deltaZ  =((z2-z1) << 16) / (x2x1);
	}
	else
	{
		colstep.r=0;
		colstep.g=0;
		colstep.b=0;
		uinc=0;
		vinc=0;
		deltaZ=0;
	}
	Z=z1<<16;
	col.r=colstart.r<<16;
	col.g=colstart.g<<16;
	col.b=colstart.b<<16;
	u=u1<<16;
	v=v1<<16;
	for(x=x1; x<x2; x++)
	{
//		mul=(((u>>16)&0xff)+(((v>>16)&0xff)*texwidth))<<2;
		mul=(((u>>16)&0xff)+(((v>>16)&0xff)<<8))<<2;
		if(g_zbuffer[x+y*width]!=INT_MIN)
		{
			if( (Z>>16) >= g_zbuffer[x+y*width])
			{
				total.r=ctexture[2+mul];
				total.g=ctexture[1+mul];
				total.b=ctexture[mul];
				rgb_col.r=col.r>>16;
				rgb_col.g=col.g>>16;
				rgb_col.b=col.b>>16;
/*				total.r+=rgb_col.r;
				total.g+=rgb_col.r;
				total.b+=rgb_col.r;
				if(total.r>255) total.r=255;
				if(total.g>255) total.g=255;
				if(total.b>255) total.b=255;*/
				total.r-=rgb_col.r;
				total.g-=rgb_col.r;
				total.b-=rgb_col.r;
				if(total.r<0) total.r=0;
				if(total.g<0) total.g=0;
				if(total.b<0) total.b=0;
				pixel[x+y*width]=RGB32(total.r,total.g,total.b);
//				color=RGB32(total.r,total.g,total.b);
//				tobuffer.buffer[x+y*width]=color;
				g_zbuffer[x+y*width]=Z>>16;
			}
		}
		else
		{
/*			tmap_ofs=(u>>16)+((v>>16)<<8);
			total.r=(tmap.buffer[tmap_ofs]&0xff0000)>>16;
			total.g=(tmap.buffer[tmap_ofs]&0x00ff00)>>8;
			total.b=(tmap.buffer[tmap_ofs]&0x0000ff);
			rgb_col.r=col.r>>16;
			rgb_col.g=col.g>>16;
			rgb_col.b=col.b>>16;
			total.r+=rgb_col.r;
			total.g+=rgb_col.g;
			total.b+=rgb_col.b;
			if(total.r>255) total.r=255;
			if(total.g>255) total.g=255;
			if(total.b>255) total.b=255;
			color=RGB32(total.r,total.g,total.b);*/
			//mul=(((u>>16)&0xff)+(((v>>16)&0xff)*texwidth))<<2;
			//mul=(((u>>16)&0xff)+(((v>>16)&0xff)<<8))<<2;
			total.r=ctexture[2+mul];
			total.g=ctexture[1+mul];
			total.b=ctexture[mul];
			rgb_col.r=col.r>>16;
			rgb_col.g=col.g>>16;
			rgb_col.b=col.b>>16;
/*			total.r+=rgb_col.r;
			total.g+=rgb_col.r;
			total.b+=rgb_col.r;
			if(total.r>255) total.r=255;
			if(total.g>255) total.g=255;
			if(total.b>255) total.b=255;*/
			total.r-=rgb_col.r;
			total.g-=rgb_col.r;
			total.b-=rgb_col.r;
			if(total.r<0) total.r=0;
			if(total.g<0) total.g=0;
			if(total.b<0) total.b=0;
			pixel[x+y*width]=RGB32(total.r,total.g,total.b);
//			tobuffer.buffer[x+y*width]=color;
			g_zbuffer[x+y*width]=Z>>16;
		}
		Z+=deltaZ;
		col.r+=colstep.r;
		col.g+=colstep.g;
		col.b+=colstep.b;
		u+=uinc;
		v+=vinc;
	}
}

void g_tri_tmap_gouraud_z(int *pixel, int width, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int u1, int v1, int u2, int v2, int u3, int v3, g_irgb c1, g_irgb c2, g_irgb c3, int mapwidth, int *texture)
{
	int dlongx,dmiddlex,dbottomx; // x-value
	int dlong_dx,dmiddle_dx,dbottom_dx; // dx/dy

	int dlong_z,dmiddle_z,dbottom_z;
	int dlong_zx,dmiddle_zx,dbottom_zx;
	int deltaZ,Z;

	int tlongu,tlongv,tmiddleu,tmiddlev,tbottomu,tbottomv;  // u/v-value
	int tlong_du,tlong_dv, tmiddle_du,tmiddle_dv,tbottom_du,tbottom_dv; // du/dy & dv/dy

	g_irgb dlongc;
	g_irgb dmiddlec;
	g_irgb dbottomc;

	g_irgb longinc;
	g_irgb middleinc;
	g_irgb bottominc;
	//
	g_irgb temp;
	int tempi;
	int y3y1,y2y1,y3y2,um,vm,u,v,startx,endx,i;
	//-y1 TOP
	//-y2 MIDDLE
	//-y3 BOTTOM

	if(y1>y2)
	{
		tempi=x1; x1=x2; x2=tempi;
		tempi=y1; y1=y2; y2=tempi;
		tempi=z1; z1=z2; z2=tempi;
		tempi=u1; u1=u2; u2=tempi;
		tempi=v1; v1=v2; v2=tempi;
		temp=c1;
		c1=c2;
		c2=temp;
	}

	if(y1>y3)
	{
		tempi=x1; x1=x3; x3=tempi;
		tempi=y1; y1=y3; y3=tempi;
		tempi=z1; z1=z3; z3=tempi;
		tempi=u1; u1=u3; u3=tempi;
		tempi=v1; v1=v3; v3=tempi;
		temp=c1;
		c1=c3;
		c3=temp;
	}

	if(y2>y3)
	{
		tempi=x2; x2=x3; x3=tempi;
		tempi=y2; y2=y3; y3=tempi;
		tempi=z2; z2=z3; z3=tempi;
		tempi=u2; u2=u3; u3=tempi;
		tempi=v2; v2=v3; v3=tempi;
		temp=c2;
		c2=c3;
		c3=temp;
	}
	y3y1=y3-y1;
	if(y3y1!=0)
	{
		dlong_dx  =((x3-x1) << 16) / (y3y1);
		dlong_z  =((z3-z1) << 16) / (y3-y1);
		tlong_du =((u3-u1) << 16) / (y3y1);
		tlong_dv =((v3-v1) << 16) / (y3y1);
		longinc.r =((c3.r-c1.r) << 16) / (y3y1);
		longinc.g =((c3.g-c1.g) << 16) / (y3y1);
		longinc.b =((c3.b-c1.b) << 16) / (y3y1);
	} else {dlong_dx=0;dlong_z=0;tlong_du=0;tlong_dv=0;longinc.r=0;longinc.g=0;longinc.b=0;}
	y2y1=y2-y1;
	if(y2y1!=0)
	{
		dmiddle_dx =((x2-x1) << 16) / (y2y1);
		dmiddle_z=((z2-z1) << 16) / (y2-y1);
		tmiddle_du=((u2-u1) << 16) / (y2y1);
		tmiddle_dv=((v2-v1) << 16) / (y2y1);
		middleinc.r =((c2.r-c1.r) << 16) / (y2y1);
		middleinc.g =((c2.g-c1.g) << 16) / (y2y1);
		middleinc.b =((c2.b-c1.b) << 16) / (y2y1);
	} else {dmiddle_dx=0;dmiddle_z=0;tmiddle_du=0;tmiddle_dv=0;middleinc.r=0;middleinc.g=0;middleinc.b=0;}

	y3y2=y3-y2;
	if(y3y2!=0)
	{
		dbottom_dx =((x3-x2) << 16) / (y3y2);
		dbottom_z=((z3-z2) << 16) / (y3-y2);
		tbottom_du=((u3-u2) << 16) / (y3y2);
		tbottom_dv=((v3-v2) << 16) / (y3y2);
		bottominc.r =((c3.r-c2.r) << 16) / (y3y2);
		bottominc.g =((c3.g-c2.g) << 16) / (y3y2);
		bottominc.b =((c3.b-c2.b) << 16) / (y3y2);
	} else {dbottom_dx=0;dbottom_z=0;tbottom_du=0;tbottom_dv=0;bottominc.r=0;bottominc.g=0;bottominc.b=0;}

	dlongx  =(x1<<16);  tlongu  =(u1<<16);  tlongv  =(v1<<16);dlong_zx=z1<<16;
	dmiddlex=(x1<<16);  tmiddleu=(u1<<16);  tmiddlev=(v1<<16);dmiddle_zx=z1<<16;
	dbottomx=(x2<<16);  tbottomu=(u2<<16);  tbottomv=(v2<<16);dbottom_zx=z2<<16;
	dlongc.r=c1.r<<16;dlongc.g=c1.g<<16;dlongc.b=c1.b<<16;
	dmiddlec.r=c1.r<<16;dmiddlec.g=c1.g<<16;dmiddlec.b=c1.b<<16;
	dbottomc.r=c2.r<<16;dbottomc.g=c2.g<<16;dbottomc.b=c2.b<<16;

	for(i=y1;i<y2;i++)
	{
		if(dmiddlex<dlongx)
		{
			startx=dmiddlex>>16;endx=dlongx>>16;
			g_hline_tmap_gouraud_z(pixel, width,startx,endx,dmiddle_zx>>16,dlong_zx>>16,
			i,tmiddleu>>16,tlongu>>16,tmiddlev>>16,tlongv>>16,dmiddlec,dlongc, mapwidth, texture);
		}
		else
		{
			startx=dlongx>>16;endx=dmiddlex>>16;
			g_hline_tmap_gouraud_z(pixel, width,startx,endx,dlong_zx>>16,dmiddle_zx>>16,
			i,tlongu>>16,tmiddleu>>16,tlongv>>16,tmiddlev>>16,dlongc,dmiddlec, mapwidth, texture);
		}
		dlongx+=dlong_dx;
		dmiddlex+=dmiddle_dx;
		dlong_zx+=dlong_z;
		dmiddle_zx+=dmiddle_z;
		tlongu+=tlong_du;tlongv+=tlong_dv;
		tmiddleu+=tmiddle_du;tmiddlev+=tmiddle_dv;
		dlongc.r+=longinc.r;
		dlongc.g+=longinc.g;
		dlongc.b+=longinc.b;
		dmiddlec.r+=middleinc.r;
		dmiddlec.g+=middleinc.g;
		dmiddlec.b+=middleinc.b;
	}
//---------------------------------------------------------
	for(i=y2;i<y3;i++)
	{
		if(dbottomx<dlongx)
		{
			startx=dbottomx>>16;endx=dlongx>>16;
			g_hline_tmap_gouraud_z(pixel, width,startx,endx,dbottom_zx>>16,dlong_zx>>16,
			i,tbottomu>>16,tlongu>>16,tbottomv>>16,tlongv>>16,dbottomc,dlongc,mapwidth,texture);
		}
		else
		{
			startx=dlongx>>16;endx=dbottomx>>16;
			g_hline_tmap_gouraud_z(pixel, width,startx,endx,dlong_zx>>16,dbottom_zx>>16,
			i,tlongu>>16,tbottomu>>16,tlongv>>16,tbottomv>>16,dlongc,dbottomc,mapwidth,texture);
		}
		dlongx+=dlong_dx;
		dbottomx+=dbottom_dx;
		dlong_zx+=dlong_z;
		dbottom_zx+=dbottom_z;
		tlongu+=tlong_du;tlongv+=tlong_dv;
		tbottomu+=tbottom_du;tbottomv+=tbottom_dv;
		dlongc.r+=longinc.r;
		dlongc.g+=longinc.g;
		dlongc.b+=longinc.b;
		dbottomc.r+=bottominc.r;
		dbottomc.g+=bottominc.g;
		dbottomc.b+=bottominc.b;
	}
}

//
//guru stuff
//

// gouraudfillers

// {{{ void g_tri_gouraud_hline(int *dst, int x1, int x2, g_irgb c1, g_irgb c2, int y)
void g_tri_gouraud_hline(int *dst, int width, int x1, int x2, g_irgb c1, g_irgb c2, int y) {
   int x2x1, x;
   g_irgb dc;
   if(x1>x2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      tmp=c2;
      c2=c1;
      c1=tmp;
   }

   x2x1=x2-x1;
   if(x2x1!=0) {
      dc.r=(c2.r-c1.r)/x2x1;
      dc.g=(c2.g-c1.g)/x2x1;
      dc.b=(c2.b-c1.b)/x2x1;
   } else {
      dc.r=dc.g=dc.b=0;
   }

   int addr=y*width;
   dst=&dst[x1+addr];
   // go through the line
   for(x=x1; x<x2; x++, dst++) {
      // int color=(c1.r>>16)<<16 | (c1.g>>16)<<8|(c1.b>>16);
      int color=(c1.r&0xFF0000) | ((c1.g>>8)&0x00FF00) | (c1.b>>16); // XXX => not quite sure about this
      *dst=color;
      c1.r+=dc.r;
      c1.g+=dc.g;
      c1.b+=dc.b;
   }
}
// }}}

// {{{ void g_tri_gouraud(int *dst, int x1, int y1, g_irgb c1, int x2, int y2, g_irgb c2, int x3, int y3, g_irgb c3)
void g_tri_gouraud(int *dst, int width, int x1, int y1, g_irgb c1, 
                             int x2, int y2, g_irgb c2, 
                             int x3, int y3, g_irgb c3) {
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int y3y1, y2y1, y3y2;

   g_irgb _c1, _c2, _c3;
   g_irgb dcdy1, dcdy2, dcdy3;

   int y;

   // gouraud runs the same way as the flat trifiller, but with interpolated colors across in addition
   if(y1>y2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      tmp=c1;
      c1=c2;
      c2=tmp;
   }

   if(y1>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      tmp=c1;
      c1=c3;
      c3=tmp;
   }

   if(y2>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      tmp=c2;
      c2=c3;
      c3=tmp;
   }

   if(x1==x2==x3 || y1==y2==y3) return; // no area covered at all

   y2y1=y2-y1;
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / (y2y1);
      dcdy1.r=((c2.r-c1.r) << 16) / (y2y1);
      dcdy1.g=((c2.g-c1.g) << 16) / (y2y1);
      dcdy1.b=((c2.b-c1.b) << 16) / (y2y1);
   } else {
      dxdy1=0;
      dcdy1.r=dcdy1.g=dcdy1.b=0;
   }

   y3y1=y3-y1;
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / (y3y1);
      dcdy2.r=((c3.r-c1.r) << 16) / (y3y1);
      dcdy2.g=((c3.g-c1.g) << 16) / (y3y1);
      dcdy2.b=((c3.b-c1.b) << 16) / (y3y1);
   } else {
      dxdy2=0;
      dcdy2.r=dcdy2.g=dcdy2.b=0;
   }

   y3y2=y3-y2;
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / (y3y2);
      dcdy3.r=((c3.r-c2.r) << 16) / (y3y2);
      dcdy3.g=((c3.g-c2.g) << 16) / (y3y2);
      dcdy3.b=((c3.b-c2.b) << 16) / (y3y2);
   } else {
      dxdy3=0;
      dcdy3.r=dcdy3.g=dcdy3.b=0;
   }

   _x1=x1<<16;
   _c1.r=c1.r<<16;
   _c1.g=c1.g<<16;
   _c1.b=c1.b<<16;

   _x2=x1<<16;
   _c2=_c1;

   _x3=x2<<16;
   _c3.r=c2.r<<16;
   _c3.g=c2.g<<16;
   _c3.b=c2.b<<16;

   for(y=y1; y<y2; y++) {
      g_tri_gouraud_hline(dst, width, _x1>>16, _x2>>16, _c1, _c2, y);
      _x1+=dxdy1;
      _x2+=dxdy2;

      _c1.r+=dcdy1.r;
      _c1.g+=dcdy1.g;
      _c1.b+=dcdy1.b;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;
   }

   for(y=y2;y<y3; y++) {
      g_tri_gouraud_hline(dst, width, _x2>>16, _x3>>16, _c2, _c3, y);
      _x2+=dxdy2;
      _x3+=dxdy3;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;

      _c3.r+=dcdy3.r;
      _c3.g+=dcdy3.g;
      _c3.b+=dcdy3.b;
   }
}
// }}} 


// {{{ void g_tri_gouraud_hline(int *dst, int x1, int x2, g_irgb c1, g_irgb c2, int y)
void g_tri_gouraud_hline_palette(int *dst, int width, int x1, int x2, g_irgb c1, g_irgb c2, int y, unsigned int *palette) {
   int x2x1, x;
   g_irgb dc;
   if(x1>x2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      tmp=c2;
      c2=c1;
      c1=tmp;
   }

   x2x1=x2-x1;
   if(x2x1!=0) {
      dc.r=(c2.r-c1.r)/x2x1;
      dc.g=(c2.g-c1.g)/x2x1;
      dc.b=(c2.b-c1.b)/x2x1;
   } else {
      dc.r=dc.g=dc.b=0;
   }

   int addr=y*width;
   dst=&dst[x1+addr];
   // go through the line
   for(x=x1; x<x2; x++, dst++) {
      // int color=(c1.r>>16)<<16 | (c1.g>>16)<<8|(c1.b>>16);
//      int color=(c1.r&0xFF0000) | ((c1.g>>8)&0x00FF00) | (c1.b>>16); // XXX => not quite sure about this
	   int color=palette[(c1.b>>16)];
      *dst=color;
      c1.r+=dc.r;
      c1.g+=dc.g;
      c1.b+=dc.b;
   }
}
// }}}


// {{{ void g_tri_gouraud_hline_z(int *dst, int x1, int x2, int z1, int z2, g_irgb c1, g_irgb c2, int y)
void g_tri_gouraud_hline_z(int *dst, int width, int x1, int x2, int z1, int z2, g_irgb c1, g_irgb c2, int y) {
   int x2x1, x, dz, color;
   int *dstz;
   g_irgb dc;
   if(x1>x2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      g_i2swap(&z1, &z2);
      tmp=c2;
      c2=c1;
      c1=tmp;
   }

   x2x1=x2-x1;
   if(x2x1!=0) {
      dz=(z2-z1)/x2x1;
      dc.r=(c2.r-c1.r)/x2x1;
      dc.g=(c2.g-c1.g)/x2x1;
      dc.b=(c2.b-c1.b)/x2x1;
   } else {
      dz=0;
      dc.r=dc.g=dc.b=0;
   }

   dst=&dst[x1+y*width];
   dstz=&g_zbuffer[x1+y*width];
   // go through the line
   for(x=x1; x<x2; x++, dst++, dstz++) {
      // int color=(c1.r>>16)<<16 | (c1.g>>16)<<8|(c1.b>>16);
      color=(c1.r&0xFF0000) | ((c1.g>>8)&0x00FF00) | (c1.b>>16); // XXX => not quite sure about this
      if(*dstz!=INT_MIN) {
         if(z1>=*dstz) {
            *dst=color;
            *dstz=z1;
         }
      } else {
         *dst=color;
         *dstz=z1;
      }
      z1+=dz;
      c1.r+=dc.r;
      c1.g+=dc.g;
      c1.b+=dc.b;
   }
}
// }}}

// {{{ void g_tri_gouraud_z(int *dst, int x1, int y1, int z1, g_irgb c1, int x2, int y2, int z2, g_irgb c2, int x3, int y3, int z3, g_irgb c3)
void g_tri_gouraud_z(int *dst, int width, int x1, int y1, int z1, g_irgb c1, 
                               int x2, int y2, int z2, g_irgb c2, 
                               int x3, int y3, int z3, g_irgb c3) {
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int y3y1, y2y1, y3y2;

   int _z1, _z2, _z3;
   int dzdy1, dzdy2, dzdy3;

   g_irgb _c1, _c2, _c3;
   g_irgb dcdy1, dcdy2, dcdy3;

   int y;

   // gouraud runs the same way as the flat trifiller, but with interpolated colors across in addition
   if(y1>y2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&z1, &z2);
      tmp=c1;
      c1=c2;
      c2=tmp;
   }

   if(y1>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&z1, &z3);
      tmp=c1;
      c1=c3;
      c3=tmp;
   }

   if(y2>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&z2, &z3);
      tmp=c2;
      c2=c3;
      c3=tmp;
   }

   if(x1==x2==x3 || y1==y2==y3) return; // no area covered at all

   y2y1=y2-y1;
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dzdy1=((z2-z1) << 8) / y2y1;
      dcdy1.r=((c2.r-c1.r) << 16) / y2y1;
      dcdy1.g=((c2.g-c1.g) << 16) / y2y1;
      dcdy1.b=((c2.b-c1.b) << 16) / y2y1;
   } else {
      dxdy1=0;
      dzdy1=0;
      dcdy1.r=dcdy1.g=dcdy1.b=0;
   }

   y3y1=y3-y1;
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dzdy2=((z3-z1) << 8) / y3y1;
      dcdy2.r=((c3.r-c1.r) << 16) / y3y1;
      dcdy2.g=((c3.g-c1.g) << 16) / y3y1;
      dcdy2.b=((c3.b-c1.b) << 16) / y3y1;
   } else {
      dxdy2=0;
      dzdy2=0;
      dcdy2.r=dcdy2.g=dcdy2.b=0;
   }

   y3y2=y3-y2;
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dzdy3=((z3-z2) << 8) / y3y2;
      dcdy3.r=((c3.r-c2.r) << 16) / y3y2;
      dcdy3.g=((c3.g-c2.g) << 16) / y3y2;
      dcdy3.b=((c3.b-c2.b) << 16) / y3y2;
   } else {
      dxdy3=0;
      dzdy3=0;
      dcdy3.r=dcdy3.g=dcdy3.b=0;
   }

   _x1=x1<<16;
   _z1=z1<<8;
   _c1.r=c1.r<<16;
   _c1.g=c1.g<<16;
   _c1.b=c1.b<<16;

   _x2=x1<<16;
   _z2=z1<<8;
   _c2=_c1;

   _x3=x2<<16;
   _z3=z2<<8;
   _c3.r=c2.r<<16;
   _c3.g=c2.g<<16;
   _c3.b=c2.b<<16;

   for(y=y1; y<y2; y++) {
      g_tri_gouraud_hline_z(dst, width, _x1>>16, _x2>>16, _z1, _z2, _c1, _c2, y);
      _x1+=dxdy1;
      _x2+=dxdy2;

      _z1+=dzdy1;
      _z2+=dzdy2;

      _c1.r+=dcdy1.r;
      _c1.g+=dcdy1.g;
      _c1.b+=dcdy1.b;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;
   }

   for(y=y2;y<y3; y++) {
      g_tri_gouraud_hline_z(dst, width, _x2>>16, _x3>>16, _z2, _z3, _c2, _c3, y);
      _x2+=dxdy2;
      _x3+=dxdy3;

      _z2+=dzdy2;
      _z3+=dzdy3;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;

      _c3.r+=dcdy3.r;
      _c3.g+=dcdy3.g;
      _c3.b+=dcdy3.b;
   }
}
// }}}
 

// {{{ void g_tri_gouraud(int *dst, int x1, int y1, g_irgb c1, int x2, int y2, g_irgb c2, int x3, int y3, g_irgb c3)
void g_tri_gouraud_palette(int *dst, int width, int x1, int y1, g_irgb c1, 
                             int x2, int y2, g_irgb c2, 
                             int x3, int y3, g_irgb c3, unsigned int *palette) {
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int y3y1, y2y1, y3y2;

   g_irgb _c1, _c2, _c3;
   g_irgb dcdy1, dcdy2, dcdy3;

   int y;

   // gouraud runs the same way as the flat trifiller, but with interpolated colors across in addition
   if(y1>y2) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      tmp=c1;
      c1=c2;
      c2=tmp;
   }

   if(y1>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      tmp=c1;
      c1=c3;
      c3=tmp;
   }

   if(y2>y3) { // swap
      g_irgb tmp;
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      tmp=c2;
      c2=c3;
      c3=tmp;
   }

   if(x1==x2==x3 || y1==y2==y3) return; // no area covered at all

   y2y1=y2-y1;
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / (y2y1);
      dcdy1.r=((c2.r-c1.r) << 16) / (y2y1);
      dcdy1.g=((c2.g-c1.g) << 16) / (y2y1);
      dcdy1.b=((c2.b-c1.b) << 16) / (y2y1);
   } else {
      dxdy1=0;
      dcdy1.r=dcdy1.g=dcdy1.b=0;
   }

   y3y1=y3-y1;
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / (y3y1);
      dcdy2.r=((c3.r-c1.r) << 16) / (y3y1);
      dcdy2.g=((c3.g-c1.g) << 16) / (y3y1);
      dcdy2.b=((c3.b-c1.b) << 16) / (y3y1);
   } else {
      dxdy2=0;
      dcdy2.r=dcdy2.g=dcdy2.b=0;
   }

   y3y2=y3-y2;
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / (y3y2);
      dcdy3.r=((c3.r-c2.r) << 16) / (y3y2);
      dcdy3.g=((c3.g-c2.g) << 16) / (y3y2);
      dcdy3.b=((c3.b-c2.b) << 16) / (y3y2);
   } else {
      dxdy3=0;
      dcdy3.r=dcdy3.g=dcdy3.b=0;
   }

   _x1=x1<<16;
   _c1.r=c1.r<<16;
   _c1.g=c1.g<<16;
   _c1.b=c1.b<<16;

   _x2=x1<<16;
   _c2=_c1;

   _x3=x2<<16;
   _c3.r=c2.r<<16;
   _c3.g=c2.g<<16;
   _c3.b=c2.b<<16;

   for(y=y1; y<y2; y++) {
      g_tri_gouraud_hline_palette(dst, width, _x1>>16, _x2>>16, _c1, _c2, y, palette);
      _x1+=dxdy1;
      _x2+=dxdy2;

      _c1.r+=dcdy1.r;
      _c1.g+=dcdy1.g;
      _c1.b+=dcdy1.b;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;
   }

   for(y=y2;y<y3; y++) {
      g_tri_gouraud_hline_palette(dst, width, _x2>>16, _x3>>16, _c2, _c3, y, palette);
      _x2+=dxdy2;
      _x3+=dxdy3;

      _c2.r+=dcdy2.r;
      _c2.g+=dcdy2.g;
      _c2.b+=dcdy2.b;

      _c3.r+=dcdy3.r;
      _c3.g+=dcdy3.g;
      _c3.b+=dcdy3.b;
   }
}
// }}} 

//http://www.lysator.liu.se/~mikaelk/doc/perspectivetexture/

// Texturemapper with full perspective correction, subpixels and subtexels,
//uses floats all the way through
struct TPolytri
{
	float x1, y1, z1;
	float x2, y2, z2;
	float x3, y3, z3;
	float u1, v1;
	float u2, v2;
	float u3, v3;
	unsigned int *texture;
};

static float dizdx, duizdx, dvizdx, dizdy, duizdy, dvizdy;
static float xa, xb, iza, uiza, viza;
static float dxdya, dxdyb, dizdya, duizdya, dvizdya;

static void drawtpolyperspsubtriseg(unsigned int *pixel, int y1, int y2, unsigned int *texture);

void drawtpolyperspsubtri(unsigned int *pixel, float x1, float y1, float z1, float x2, float y2, float z2, float x3, float y3, float z3, float u1, float v1, float u2, float v2, float u3, float v3, unsigned int *texture)
{
	float iz1, uiz1, viz1, iz2, uiz2, viz2, iz3, uiz3, viz3;
	float dxdy1, dxdy2, dxdy3;
	float tempf;
	float denom;
	float dy;
	int y1i, y2i, y3i;
	int side;

	TPolytri poly;

	poly.x1=x1;
	poly.y1=y1;
	poly.z1=z1;
	poly.x2=x2;
	poly.y2=y2;
	poly.z2=z2;
	poly.x3=x3;
	poly.y3=y3;
	poly.z3=z3;
	poly.u1=u1;
	poly.v1=v1;
	poly.u2=u2;
	poly.v2=v2;
	poly.u3=u3;
	poly.v3=v3;


// Shift XY coordinate system (+0.5, +0.5) to match the subpixeling
//  technique

x1 = poly.x1 + 0.5;
y1 = poly.y1 + 0.5;
x2 = poly.x2 + 0.5;
y2 = poly.y2 + 0.5;
x3 = poly.x3 + 0.5;
y3 = poly.y3 + 0.5;

// Calculate alternative 1/Z, U/Z and V/Z values which will be
//  interpolated

iz1 = 1 / poly.z1;
iz2 = 1 / poly.z2;
iz3 = 1 / poly.z3;
uiz1 = poly.u1 * iz1;
viz1 = poly.v1 * iz1;
uiz2 = poly.u2 * iz2;
viz2 = poly.v2 * iz2;
uiz3 = poly.u3 * iz3;
viz3 = poly.v3 * iz3;

//texture = poly.texture;
// Sort the vertices in ascending Y order

#define swapfloat(x, y) tempf = x; x = y; y = tempf;
if (y1 > y2)
{
swapfloat(x1, x2);
swapfloat(y1, y2);
swapfloat(iz1, iz2);
swapfloat(uiz1, uiz2);
swapfloat(viz1, viz2);
}
if (y1 > y3)
{
swapfloat(x1, x3);
swapfloat(y1, y3);
swapfloat(iz1, iz3);
swapfloat(uiz1, uiz3);
swapfloat(viz1, viz3);
}
if (y2 > y3)
{
swapfloat(x2, x3);
swapfloat(y2, y3);
swapfloat(iz2, iz3);
swapfloat(uiz2, uiz3);
swapfloat(viz2, viz3);
}
#undef swapfloat

y1i = y1;
y2i = y2;
y3i = y3;

// Skip poly if it's too thin to cover any pixels at all

if ((y1i == y2i && y1i == y3i)
    || ((int) x1 == (int) x2 && (int) x1 == (int) x3))
return;

// Calculate horizontal and vertical increments for UV axes (these
//  calcs are certainly not optimal, although they're stable
//  (handles any dy being 0)

denom = ((x3 - x1) * (y2 - y1) - (x2 - x1) * (y3 - y1));

if (!denom)// Skip poly if it's an infinitely thin line
return;

denom = 1 / denom;// Reciprocal for speeding up
dizdx = ((iz3 - iz1) * (y2 - y1) - (iz2 - iz1) * (y3 - y1)) * denom;
duizdx = ((uiz3 - uiz1) * (y2 - y1) - (uiz2 - uiz1) * (y3 - y1)) * denom;
dvizdx = ((viz3 - viz1) * (y2 - y1) - (viz2 - viz1) * (y3 - y1)) * denom;
dizdy = ((iz2 - iz1) * (x3 - x1) - (iz3 - iz1) * (x2 - x1)) * denom;
duizdy = ((uiz2 - uiz1) * (x3 - x1) - (uiz3 - uiz1) * (x2 - x1)) * denom;
dvizdy = ((viz2 - viz1) * (x3 - x1) - (viz3 - viz1) * (x2 - x1)) * denom;

// Calculate X-slopes along the edges

if (y2 > y1)
dxdy1 = (x2 - x1) / (y2 - y1);
if (y3 > y1)
dxdy2 = (x3 - x1) / (y3 - y1);
if (y3 > y2)
dxdy3 = (x3 - x2) / (y3 - y2);

// Determine which side of the poly the longer edge is on

side = dxdy2 > dxdy1;

if (y1 == y2)
side = x1 > x2;
if (y2 == y3)
side = x3 > x2;

if (!side)// Longer edge is on the left side
{
// Calculate slopes along left edge

dxdya = dxdy2;
dizdya = dxdy2 * dizdx + dizdy;
duizdya = dxdy2 * duizdx + duizdy;
dvizdya = dxdy2 * dvizdx + dvizdy;

// Perform subpixel pre-stepping along left edge

dy = 1 - (y1 - y1i);
xa = x1 + dy * dxdya;
iza = iz1 + dy * dizdya;
uiza = uiz1 + dy * duizdya;
viza = viz1 + dy * dvizdya;

if (y1i < y2i)// Draw upper segment if possibly visible
{
// Set right edge X-slope and perform subpixel pre-
//  stepping

xb = x1 + dy * dxdy1;
dxdyb = dxdy1;

drawtpolyperspsubtriseg(pixel, y1i, y2i, texture);
}
if (y2i < y3i)// Draw lower segment if possibly visible
{
// Set right edge X-slope and perform subpixel pre-
//  stepping

xb = x2 + (1 - (y2 - y2i)) * dxdy3;
dxdyb = dxdy3;

drawtpolyperspsubtriseg(pixel, y2i, y3i, texture);
}
}
else// Longer edge is on the right side
{
// Set right edge X-slope and perform subpixel pre-stepping

dxdyb = dxdy2;
dy = 1 - (y1 - y1i);
xb = x1 + dy * dxdyb;

if (y1i < y2i)// Draw upper segment if possibly visible
{
// Set slopes along left edge and perform subpixel
//  pre-stepping

dxdya = dxdy1;
dizdya = dxdy1 * dizdx + dizdy;
duizdya = dxdy1 * duizdx + duizdy;
dvizdya = dxdy1 * dvizdx + dvizdy;
xa = x1 + dy * dxdya;
iza = iz1 + dy * dizdya;
uiza = uiz1 + dy * duizdya;
viza = viz1 + dy * dvizdya;

drawtpolyperspsubtriseg(pixel, y1i, y2i, texture);
}
if (y2i < y3i)// Draw lower segment if possibly visible
{
// Set slopes along left edge and perform subpixel
//  pre-stepping

dxdya = dxdy3;
dizdya = dxdy3 * dizdx + dizdy;
duizdya = dxdy3 * duizdx + duizdy;
dvizdya = dxdy3 * dvizdx + dvizdy;
dy = 1 - (y2 - y2i);
xa = x2 + dy * dxdya;
iza = iz2 + dy * dizdya;
uiza = uiz2 + dy * duizdya;
viza = viz2 + dy * dvizdya;

drawtpolyperspsubtriseg(pixel, y2i, y3i, texture);
}
}
}

static void drawtpolyperspsubtriseg(unsigned int *pixel, int y1, int y2, unsigned int *texture)
{
//unsigned int *scr;
int x1, x2;
float z, u, v, dx;
float iz, uiz, viz;

while (y1 < y2)// Loop through all lines in the segment
{
x1 = xa;
x2 = xb;

// Perform subtexel pre-stepping on 1/Z, U/Z and V/Z

dx = 1 - (xa - x1);
iz = iza + dx * dizdx;
uiz = uiza + dx * duizdx;
viz = viza + dx * dvizdx;

//scr = &pixel[y1 * 320 + x1];

while (x1++ < x2)// Draw horizontal line
{
// Calculate U and V from 1/Z, U/Z and V/Z

z = 1 / iz;
u = uiz * z;
v = viz * z;

// Copy pixel from texture to screen

//if (visible_i(scr))
if (visible(x1,y1,WIDTH,HEIGHT))
	pixel[y1 * WIDTH + x1] = texture[((((int) v) & 0xff) << 8) + (((int) u) & 0xff)];

//if (visible(x1,y1,320,200))
//	pixel[y1 * 320 + x1] = texture[((((int) v) & 0xff) << 8) + (((int) u) & 0xff)];
//scr++;
// Step 1/Z, U/Z and V/Z horizontally

iz += dizdx;
uiz += duizdx;
viz += dvizdx;
}

// Step along both edges

xa += dxdya;
xb += dxdyb;
iza += dizdya;
uiza += duizdya;
viza += dvizdya;

y1++;
}
}