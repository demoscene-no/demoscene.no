#ifndef _vector2d
#define _vector2d

#include <math.h>

class Vector2D
{
public:
	Vector2D();
	Vector2D(float _x, float _y);
	~Vector2D();

	void SetPos(float _x, float _y);
	float GetPosX();
	float GetPosY();
	float DistanceSqr();
	float Length();
	void Normalize();

//private:
	float length;
	float x;
	float y;
};

float cross_product_2d(Vector2D a, Vector2D b);

#endif