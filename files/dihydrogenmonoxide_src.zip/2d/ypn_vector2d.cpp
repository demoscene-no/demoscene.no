#include "../commonheaders/ypn_common.h"
#include "ypn_vector2d.h"

Vector2D::Vector2D()
{

}

Vector2D::Vector2D(float _x, float _y)
{
	x=_x;
	y=_y;
}

Vector2D::~Vector2D()
{

}

void Vector2D::SetPos(float _x, float _y)
{
	x=_x;
	y=_y;
}

float Vector2D::GetPosX()
{
	return x;
}

float Vector2D::GetPosY()
{
	return y;
}

float Vector2D::DistanceSqr()
{
	return (float)(SQR(x)+SQR(y));
}

float Vector2D::Length()
{
	return (float)sqrt(DistanceSqr());
}

void Vector2D::Normalize()
{
	float unit_length=1.f/Length();
	x*=unit_length;
	y*=unit_length;
//	length=sqrt(x*x+y*y);
//	x/=length;
//	y/=length;
}

float cross_product_2d(Vector2D a, Vector2D b)
{
	float f=(a.x*b.y)-(a.y*b.x);
	return f;
}
