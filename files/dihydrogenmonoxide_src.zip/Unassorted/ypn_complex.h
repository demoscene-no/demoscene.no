#include "../commonheaders/ypn_common.h"

class Complex
{
public:
	Complex();
	Complex(float _real, float _imaginary);
	~Complex();

	Complex operator+(Complex &n);
	Complex operator-(Complex &n);
	Complex operator*(Complex &n);
	float Absolute();

//private:
	//The plane with all the representations of the complex numbers
	//is called the Gauss plane.
	//With the complex number a + bi corresponds just one vector OP or P.
	float real;			//real numbers 'a' are on the x-axis
	float imaginary;	//imaginary numbers 'bi' are on the y-axis (imaginary-axis).
};
