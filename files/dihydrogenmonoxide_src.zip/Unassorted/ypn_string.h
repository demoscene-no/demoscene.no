#include "../commonheaders/ypn_common.h"

class String
{
public:
	String();
	~String();

	void SetText(char *_text);
	char *GetText();
	int GetLength();

	Coord2Df *GetPos();
	int *GetBlink();
	int *GetBlinkStep();
	float *GetFactor();

	int posx, posy; //start posisjoner for hele strengen.
private:

	char *text;
	int length;
	Coord2Df *pos;	//fontenes posisjoner (x,y) per bokstav
	int *blink;
	int *blinkstep;
	float *factor;
};
