#include "ypn_complex.h"

Complex::Complex()
{

}

Complex::Complex(float _real, float _imaginary)
{
	real=_real;
	imaginary=_imaginary;
}

Complex::~Complex()
{

}

Complex Complex::operator +(Complex &n)
{
	return Complex(real+n.real, imaginary+n.imaginary);
}

Complex Complex::operator -(Complex &n)
{
	return Complex(real-n.real, imaginary-n.imaginary);
}

Complex Complex::operator *(Complex &n)
{
	return Complex((real*n.real)-(imaginary*n.imaginary), (real*n.imaginary)+(imaginary+n.real));
}

//magnitude
float Complex::Absolute()
{
	return sqrt(SQR(real)+SQR(imaginary));
}