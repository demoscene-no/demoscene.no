#include "ypn_voronoi.h"

Voronoi::Voronoi()
{

}

Voronoi::~Voronoi()
{

}
