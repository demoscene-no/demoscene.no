//
//Vi har punktene Pi, 0<i<=n i et n-dimensjonalt rom P.
//Ett sett av punkter hvor egenskapen til hvert punkt inni en celle er n�rmest
//punktet Pi enn noe annet punkt i P, representerer en Voronoi-celle.
//
//Voronoi-cellene til sammen kalles for et Voronoi-diagram.
//

class Voronoi
{
public:
	Voronoi();
	~Voronoi();

	void AddPoint(int x, int y);
	int numPoints;	// 0 < i <= n
};

