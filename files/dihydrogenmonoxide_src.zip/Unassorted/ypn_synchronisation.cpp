#include "ypn_synchronisation.h"

Synchronisation::Synchronisation()
{
	trig=0;
	trigCount=0;
}

Synchronisation::~Synchronisation()
{

}

void Synchronisation::AddTrigger(float time)
{
	trigCount++;
	trig=(float*) realloc(trig, trigCount*sizeof(float));
	trig[trigCount-1]=time;
}

int Synchronisation::Trigger(int trigfrom)
{
	return (ftime>=trig[trigfrom])?1:0;
}

int Synchronisation::Trigger(int trigfrom, int trigto)
{
	return ((ftime>=trig[trigfrom]) && (ftime<trig[trigto]))?1:0;
}

float Synchronisation::GetTrigger(int index)
{
	if ((index<0) || (index>=trigCount)) return 0;
	return trig[index];
}
