#include "../filereaders/ypn_png.h"

class Font
{
public:
	Font();
	Font(char *filename);
	~Font();

	void Init(char *text, int col);
	void Init(char *filename);

	int num_fonts;
	int width,height;
	int size,csize;
	int iwidth,iheight;
	int isize,icsize;

//	int flags;

	//each font stored.
	unsigned int *buffer[95];

	unsigned int *pixel;
	unsigned char *cpixel;
};
