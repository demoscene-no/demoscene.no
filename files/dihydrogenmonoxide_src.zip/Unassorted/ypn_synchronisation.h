#include "../commonheaders/ypn_common.h"
#include "../timerclass/ypn_timer.h"

class Synchronisation
{
public:
	Synchronisation();
	~Synchronisation();
	
	void AddTrigger(float time);
	float *trig;
	int trigCount;

	int Trigger(int trigfrom);
	int Trigger(int trigfrom, int trigto);
	float GetTrigger(int index);
};
