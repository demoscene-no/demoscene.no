#include <windows.h>
#include "ypn_font.h"

Font::Font()
{

}

Font::Font(char *filename)
{
	Init(filename);
}

Font::~Font()
{
}

void Font::Init(char *text, int col)
{
//	void RenderFont(scrbuffer buffer, char *text, int col, char *fontfile, char *fontname, int xsize, DWORD fweight, DWORD fitalic, DWORD underline, DWORD strikeout, DWORD charset, DWORD fquality, unsigned int uformat)
	int x,y,xsize,i,j=0;
	RECT r;	HWND hwnd; BITMAPINFO bmi;
	HFONT hFont; HBITMAP hbitmap; HDC hdc,hdc2;

	int bwidth=1000;
	int bheight=14;
	unsigned int *data;

	width=8;
	xsize=width;
	height=14;
	size=width*height; csize=size*4;	//4 channels (bytes)
	num_fonts=95;


	//init mem
	pixel=(unsigned int *)malloc(bwidth*bheight*4);
	cpixel=(unsigned char *)pixel;



	hdc=GetDC(NULL);
	hbitmap=CreateCompatibleBitmap(hdc,bwidth,bheight);
	hdc2=CreateCompatibleDC(hdc);
	SelectObject(hdc2, hbitmap);

	data=(unsigned int *)malloc(sizeof(unsigned int)*bwidth*bheight);

	memset(&bmi,0,sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize=sizeof(bmi.bmiHeader);
	bmi.bmiHeader.biWidth=bwidth;
	bmi.bmiHeader.biHeight=-bheight;
	bmi.bmiHeader.biPlanes=1;
	bmi.bmiHeader.biBitCount=32;
	bmi.bmiHeader.biCompression=BI_RGB;

	hFont=CreateFont(	bheight,	//h�yden
						xsize,	//bredden
						0,
						0,
						FW_NORMAL,//bold
						FALSE,//italic
						FALSE,//underline
						FALSE,//strikeout
						ANSI_CHARSET,
//						OEM_CHARSET,
						OUT_DEFAULT_PRECIS,//OUT_TT_PRECIS, //klipping presisjon
						CLIP_DEFAULT_PRECIS,
						DEFAULT_QUALITY, //ANTIALIASED_QUALITY //kvalitet ps font
						FF_DONTCARE|DEFAULT_PITCH,
						//VARIABLE_PITCH,
						"Fixedsys");
	r.top=0;
	r.bottom=bheight;
	r.left=0;
	r.right=bwidth;
	FillRect(hdc2, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));
	SetBkMode(hdc2, TRANSPARENT);

//	BGR->RGB
	int rc=((col&0xff0000)>>16);
	int gc=((col&0xff00)>>8);
	int bc=((col&0xff));
	int c=RGB(rc,gc,bc);

	SetTextColor(hdc2, c);	//grs

	SelectObject(hdc2, hFont);
	DrawText(hdc2, text, strlen(text), &r, DT_SINGLELINE|0|DT_EXPANDTABS|DT_TABSTOP|0x0400);

	GetDIBits(hdc2,hbitmap,0,bheight,data,&bmi,DIB_RGB_COLORS);

	unsigned char *cpeker=(unsigned char *)data;
	for (i=0; i<bwidth*bheight; i++,j+=4) pixel[i]=RGB32(cpeker[j+2],cpeker[j+1],cpeker[j]);
	pixel=(unsigned int *)data;

	DeleteObject(hFont);
	DeleteObject(hbitmap);
	ReleaseDC(NULL, hdc2);
	ReleaseDC(NULL, hdc);

//	RemoveFontResource(fontfile);
//	SendMessage(HWND_BROADCAST, WM_FONTCHANGE, 0, 0);



	//init mem for all fonts
	for (i=0; i<num_fonts; i++) buffer[i]=(unsigned int *)malloc(csize);

	//init the fonts
	for (i=0; i<num_fonts; i++)
	for (x=0; x<width; x++)
	for (y=0; y<height; y++)
		buffer[i][x+y*width]=pixel[(x+i*8)+y*bwidth];
}

void Font::Init(char *filename)
{
	int x,y;
	width=8;
	height=14;
	size=width*height;
	csize=size*4;	//4 channels (bytes)
	num_fonts=95;

	//load png
#ifdef _PNG_LIB_
	png_structp png_ptr; // main png struct
	png_infop info_ptr; // info struct
	png_uint_32 png_width, png_height;
	int bit_depth, color_type;
	int channels;
	FILE *fp;
	png_uint_32 rowbytes;
	unsigned char sig[PNG_BYTES_TO_CHECK];
	unsigned char *image_data;
	unsigned int i, size, ofs;
	long int *data;

	//init mem for all fonts
	for (i=0; i<num_fonts; i++) buffer[i]=(unsigned int *)malloc(csize);

	png_bytepp row_pointers=NULL;

	fp=fopen(filename, "rb");
	fread(sig, 1, PNG_BYTES_TO_CHECK, fp);
	if (!png_check_sig(sig, PNG_BYTES_TO_CHECK)) exit(1);//return NULL;

	// we don't care about passing any pointer to any custom funtions
	png_ptr=png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(!png_ptr) {
		fclose(fp);
		exit(1);//return NULL;
	}

	info_ptr=png_create_info_struct(png_ptr);
	if(!info_ptr) {
		fclose(fp);
		png_destroy_read_struct(&png_ptr, (png_infopp)NULL, (png_infopp)NULL);
		exit(1);//return NULL;
	}

	if(setjmp(png_jmpbuf(png_ptr))) {
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		fclose(fp);
		exit(1);//return NULL;
	}

	png_init_io(png_ptr, fp);
	png_set_sig_bytes(png_ptr, PNG_BYTES_TO_CHECK);
	png_read_info(png_ptr, info_ptr);
	png_get_IHDR(png_ptr, info_ptr, &png_width, &png_height, &bit_depth, &color_type, NULL, NULL, NULL);

	if(setjmp(png_jmpbuf(png_ptr)))	{
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		fclose(fp);
		exit(1);//return NULL;
	}

	// expand all to RGB[a]
	if(color_type==PNG_COLOR_TYPE_PALETTE) png_set_expand(png_ptr);
	if(color_type==PNG_COLOR_TYPE_GRAY && bit_depth<8) png_set_expand(png_ptr);
	if(png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS)) png_set_expand(png_ptr);
	if(bit_depth==16) png_set_strip_16(png_ptr);
	if(color_type==PNG_COLOR_TYPE_GRAY || color_type==PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(png_ptr);

	//if(png_get_gAMA(png_ptr, info_ptr, &gamma)) png_set_gamma(png_ptr, display_exponent, gamma);
   
	png_read_update_info(png_ptr, info_ptr);

	rowbytes=png_get_rowbytes(png_ptr, info_ptr);
	channels=png_get_channels(png_ptr, info_ptr);
   
	if((image_data=(unsigned char *)malloc(rowbytes*png_height))==NULL) {
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		exit(1);//return NULL;
	}
   
	if((row_pointers=(png_bytepp)malloc(png_height*sizeof(png_bytep)))==NULL) {
		png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
		free(image_data);
		image_data=NULL;
		exit(1);//return NULL;
	}

	for(i=0; i<png_height; i++) row_pointers[i]=image_data+i*rowbytes; // pointer to each row of image data
	png_read_image(png_ptr, row_pointers);
	free(row_pointers);
	row_pointers=NULL;

	png_destroy_read_struct(&png_ptr, &info_ptr, (png_infopp)NULL);
	fclose(fp);

	//init mem
	pixel=(unsigned int *)malloc(png_width*png_height*4);
	cpixel=(unsigned char *)pixel;

	// yep, now we got the image data as unsigned chars, convert them to int
	isize=png_width*png_height;
	data=(long int *)malloc(size*sizeof(long int));

	ofs=0;
	if(channels<3) exit(1);//return NULL;
	if(channels==3) // without alpha
	{
		for(i=0; i<isize*3; i+=3)
		{
			int r=image_data[i];
			int g=image_data[i+1];
			int b=image_data[i+2];
			pixel[ofs++]=(r<<16)|(g<<8)|b;
		}
	}
	else if(channels==4) // with alpha
	{
		for(i=0; i<isize*4; i+=4)
		{
			int r=image_data[i];
			int g=image_data[i+1];
			int b=image_data[i+2];
			int a=image_data[i+3];
			pixel[ofs++]=(r<<16)|(g<<8)|b;
		}
	}
	iwidth=png_width;
	iheight=png_height;

	free(image_data);

	//init the fonts
	for (i=0; i<num_fonts; i++)
	for (x=0; x<width; x++)
	for (y=0; y<height; y++)
		buffer[i][x+y*width]=pixel[(x+i*8)+y*iwidth];
#endif
}
