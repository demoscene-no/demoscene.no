#include "../3d/ypn_vector3d.h"
#include "../layer/ypn_pixelframebuffer.h"

void raytracer(PixelFrameBuffer *buffer)
{
	Vector3D origin, direction;
	Vector3D ray;
	float t;

	origin.x=origin.y=0;
	origin.z=-256;

	direction.x=
	direction.y=
	direction.z=256;

	direction.Normalize();

	//ray equation
	ray.x=origin.x+direction.x*t;
	ray.y=origin.y+direction.y*t;
	ray.z=origin.z+direction.z*t;
}
