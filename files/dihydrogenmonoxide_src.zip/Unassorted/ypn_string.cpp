/******************************************************************************
*
*	FIL:			YPN_STRING.CPP
*
*	BESKRIVELSE:	Streng-klasse som har mulighet for posisjonering og
*					blinking per bokstav.
*
*	SKREVET AV:		Rudi B. Stranden
*
*******************************************************************************/

#include "ypn_string.h"

String::String()
{
	text=0;
	pos=0;
	blink=0;
	blinkstep=0;
	factor=0;
}

String::~String()
{

}

void String::SetText(char *_text)
{
	text=_text;
	length=strlen(_text);

	pos=(Coord2Df *)malloc(length*sizeof(Coord2Df));
	blink=(int *)malloc(length*sizeof(int));
	blinkstep=(int *)malloc(length*sizeof(int));
	factor=(float *)malloc(length*sizeof(float));

	//reset values
	for (int i=0; i<length; i++)
	{
		blink[i]=0;
		blinkstep[i]=0;
	}
}

char *String::GetText()
{
	return text;
}

int String::GetLength()
{
	return length;
}

Coord2Df *String::GetPos()
{
	return pos;
}

int *String::GetBlink()
{
	return blink;
}

int *String::GetBlinkStep()
{
	return blinkstep;
}

float *String::GetFactor()
{
	return factor;
}
