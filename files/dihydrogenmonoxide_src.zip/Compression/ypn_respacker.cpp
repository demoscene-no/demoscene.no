#include "ypn_datapacker.h"
#include <stdio.h>

Resource::Resource()
{
	tempfile=0;
	num_files=0;
}

Resource::~Resource()
{
	FreeResources();
}

void Resource::GetResource(char *resource_name)
{
	BYTE *data;
	HANDLE hres,hfile;
	DWORD len,c;
	char temppath[MAX_PATH];

	num_files++;
	tempfile=(char **)realloc(tempfile, num_files*sizeof(char)*MAX_PATH);
	//tempfile[num_files-1]=(char *)malloc(MAX_PATH*sizeof(char));//new char[MAX_PATH];
//	tempfile[num_files-1]=new char[MAX_PATH];

//	num_buffer++;
//	buffer=(PixelFrameBuffer **) realloc(buffer, num_buffer*sizeof(PixelFrameBuffer *));
//	buffer[num_buffer-1]=new PixelFrameBuffer();

	if (!(hres=FindResource(GetModuleHandle(NULL),resource_name,RT_RCDATA))
		|| !(len=SizeofResource(NULL, (HRSRC__ *)hres))
		|| !(hres=LoadResource(NULL, (HRSRC__ *)hres))
		|| !(data=(unsigned char *)LockResource(hres)))
	{
		printf("Error: Can't get the %s resource\n", resource_name);
		ExitProcess(0);
	}

	GetTempPath(MAX_PATH, temppath);
	GetTempFileName(temppath,"bas",0,tempfile[num_files-1]);

	// write (filename) the temporary file
	if (INVALID_HANDLE_VALUE==(hfile=CreateFile(tempfile[num_files-1],GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_TEMPORARY,NULL)))
	{
		printf("Error: Can't write (file)\n");
		ExitProcess(0);
	}
	WriteFile(hfile, data, len, &c, NULL);
	CloseHandle(hfile);
}

char *Resource::GetTempfile(int index)
{
	return tempfile[index];
}

void Resource::FreeResources()
{
	for (int i=0; i<num_files; i++)
		DeleteFile(tempfile[i]);
}