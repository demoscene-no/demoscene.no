
class LZW
{
public:
	void CompressData(char *buffer, int len);
	void DecompressData(char *buffer, int len);

	//lzw compression variables
	char *data;
};