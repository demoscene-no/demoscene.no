#include "windows.h"

class Resource
{
public:
	Resource();
	~Resource();

	void GetResource(char *resource_name);
	char *GetTempfile(int index);
	void FreeResources();

	char **tempfile;//[MAX_PATH];	// temporary (filename)
	int num_files;
};