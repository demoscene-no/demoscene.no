#include "windows.h"
#include <stdio.h>

class Datapacker
{
public:
	Datapacker();
	~Datapacker();

	void SetName(char *filnavn);
	void Pack(char *filnavn);
	void UnPack(char *filnavn);
	void DeleteDatas();

	FILE *fut;
	char *filut;
	char *files[128];
	int file_num;
};