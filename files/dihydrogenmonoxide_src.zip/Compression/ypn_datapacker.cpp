#include "ypn_datapacker.h"
#include <stdio.h>
#include <io.h>
//#include <stdlib.h>
//#include <iostream.h>
//#include <conio.h>

//#define HEADER "ShitPackerV1.0Activator"
#define HEADER "ShitPack!_activator"

Datapacker::Datapacker()
{
}

Datapacker::~Datapacker()
{
}

void Datapacker::SetName(char *filnavn)
{
	fut=fopen(filnavn, "wb");
	fprintf(fut, "%s", HEADER);
	filut=filnavn;
	fclose(fut);
}

void Datapacker::Pack(char *filnavn)
{
	//Feskhau!
	FILE *fin;
	char *buffer=0;
	char c;
	unsigned int teller=0;
	fin=fopen(filnavn,"rb");

	//
	//finn lengda p� fila
	//
	int lengde=0;
	while (!feof(fin))
	{
		lengde++;
		getc(fin);
	}
	lengde-=1;

	fseek(fin, 0, SEEK_SET);

	//les data
	while (!feof(fin))
	{
		teller++;
		buffer=(char *)realloc(buffer, teller*sizeof(char));
		buffer[teller-1]=getc(fin);
	}
	fclose(fin);

	fut=fopen(filut, "ab");

	//
	//setter lengda i en 32 bits verdi
	//
	char b[4];
	b[0]=(lengde & 0xff);
	b[1]=(lengde & 0xff00)>>8;
	b[2]=(lengde & 0xff0000)>>16;
	b[3]=(lengde & 0xff000000)>>24;
	fputc(b[0], fut);
	fputc(b[1], fut);
	fputc(b[2], fut);
	fputc(b[3], fut);
	//
	//skriv katalog- og filnavn
	//
	teller=0;
	while (filnavn[teller]!='\0') teller++;
	fprintf(fut, "%c%s",teller,filnavn);

	//
	//skriv all data
	//
	for (int i=0; i<lengde; i++) fputc(buffer[i], fut);
	fclose(fut);
}
#include <direct.h>
void Datapacker::UnPack(char *filnavn)
{
	int fillengde, teller;
	char filnavnlengde;
	char ch;
	char *filnavn_ut;
	char *buffer;
	FILE *fu, *fp=fopen(filnavn, "rb");
	
	file_num=0;

	int jump=strlen(HEADER);
	fseek(fp, jump, SEEK_SET);

//	_mkdir("text");
	_mkdir("data");	//plasser alle datafilene her.

	while (!feof(fp))
	{
		fread(&fillengde, sizeof(int), 1, fp);
		if (feof(fp)) break; //hvis vi har n�dd slutten av fila, s� avslutter vi.

		fread(&filnavnlengde, sizeof(char), 1, fp);
		filnavn_ut=(char *)malloc((filnavnlengde+1)*sizeof(char));
		files[file_num]=(char *)malloc((filnavnlengde+1)*sizeof(char));

		teller=0;
		while (teller<(int)filnavnlengde)
		{
			filnavn_ut[teller]=fgetc(fp);
			files[file_num][teller]=filnavn_ut[teller];	//globale filenavn.
			teller++;
		}
		filnavn_ut[teller]='\0';
		files[file_num][teller]='\0';

		buffer=0;
		teller=0;

		buffer=(char *)malloc(fillengde*sizeof(char));
		for (int i=0; i<fillengde; i++) buffer[i]=fgetc(fp);

		fu=fopen(filnavn_ut, "wb");
		for (i=0; i<fillengde; i++) fputc(buffer[i], fu);
		fclose(fu);

		free(buffer);
		free(filnavn_ut);
		file_num++;
	}

	//23
/*	int t=strlen(HEADER);
//	fread(&fillengde, sizeof(int), 1, fp);
	FILE *ft=fopen("data2.pac", "w");
	fprintf(ft, "%i", t);
	fclose(ft);
*/

	fclose(fp);
}

void Datapacker::DeleteDatas()
{
	for (int i=0; i<file_num; i++) remove(files[i]);
	_rmdir("data");
}