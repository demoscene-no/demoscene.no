#include "ypn_lzw.h"

//Variable-Length-Code LZW Compression.

void LZW::CompressData(char *buffer, int len)
{

}

void LZW::DecompressData(char *buffer, int len)
{

}
