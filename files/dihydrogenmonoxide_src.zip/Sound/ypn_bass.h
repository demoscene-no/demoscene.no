#include "../commonheaders/ypn_common.h"

#ifdef _BASS_LIB_
	#include "../core/libs/bass/bass.h"
	#pragma comment(lib, "winmm.lib")
	#pragma comment(lib, "core/libs/bass/bass.lib")

extern DWORD starttime;
extern void CALLBACK LoopSync(HSYNC handle, DWORD channel, DWORD data, DWORD user);

class Bass
{
public:
	Bass();
	~Bass();

	void Load(char *filename);
	void LoadStr(char *filename);
	void Play();
	void Free();


	HMUSIC mod;
	HSTREAM str;
	DWORD act,time,level;
	QWORD pos;
	int a;

	//LoopSync
	int flag_end;

private:
	void Error(char *text);
};

#endif
