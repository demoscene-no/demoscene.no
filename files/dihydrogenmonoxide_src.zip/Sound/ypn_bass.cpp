#include "ypn_bass.h"

#ifdef _BASS_LIB_

Bass::Bass()
{

}


Bass::~Bass()
{
	Free();
}

void Bass::Error(char *text) 
{
	printf("Error(%d): %s\n",BASS_ErrorGetCode(),text);
	BASS_Free();
	ExitProcess(0);
}

void Bass::Load(char *filename)
{
	//obs: all printf functions are commented out because we do not work in console mode
	flag_end=1;

	if (BASS_GetVersion()!=MAKELONG(2,0))
	{
//		printf("BASS version 2.0 was not loaded\n");
		return;
	}

	if (!BASS_Init(1,44100,0,0,NULL))
		Error("Can't initialize device");

//BASS_MP3_SETPOS 
//	if (str=BASS_StreamCreateFile(FALSE,filename,0,0,0))
	if (str=BASS_StreamCreateFile(FALSE,filename,0,0,BASS_MP3_SETPOS ))
	{
		BASS_ChannelSetSync(str,BASS_SYNC_END,0,&LoopSync,0);
		
		pos=BASS_StreamGetLength(str);
	}
	else
	{
		// try loading the MOD (with looping, sensitive ramping, and calculate the duration)
//		if (!(mod=BASS_MusicLoad(FALSE,filename,0,0,BASS_MUSIC_LOOP|BASS_MUSIC_RAMPS|BASS_MUSIC_CALCLEN,0))) Error("Can't play the file");

		//No Loop!
		if (!(mod=BASS_MusicLoad(FALSE,filename,0,0,0|BASS_MUSIC_RAMPS|BASS_MUSIC_CALCLEN,0))) Error("Can't play the file");

		// set a synchronizer for when the MOD reaches the end
		BASS_ChannelSetSync(mod,BASS_SYNC_END,0,&LoopSync,0);

		// count channels 
		for (a=0; BASS_MusicGetVolume(mod,a)!=-1; a++);
//		printf("playing MOD music \"%s\" [%d chans, %d orders]",BASS_MusicGetName(mod),a,BASS_MusicGetLength(mod,FALSE));
		pos=BASS_MusicGetLength(mod,TRUE);
	}

	// display the time length
	if (pos)
	{
		time=(DWORD)BASS_ChannelBytes2Seconds(str?str:mod,pos);
//		printf(" %d:%02d\n",time/60,time%60);
	}
//	else printf("\n");
}

void Bass::LoadStr(char *filename)
{
	//obs: all printf functions are commented out because we do not work in console mode
	flag_end=1;

	if (BASS_GetVersion()!=MAKELONG(2,0))
	{
//		printf("BASS version 2.0 was not loaded\n");
		return;
	}

	if (!BASS_Init(1,44100,0,0,NULL))
		Error("Can't initialize device");

	if (str=BASS_StreamCreateFile(FALSE,filename,0,0,0))
	{
		BASS_ChannelSetSync(str,BASS_SYNC_END,0,&LoopSync,0);
		pos=BASS_StreamGetLength(str);
	}

	// display the time length
	if (pos)
	{
		time=(DWORD)BASS_ChannelBytes2Seconds(str?str:mod,pos);
//		printf(" %d:%02d\n",time/60,time%60);
	}
//	else printf("\n");
}

void Bass::Play()
{
	if (str) BASS_StreamPlay(str,0,BASS_SAMPLE_LOOP);
//	if (str) BASS_StreamPlay(str,0,0);
	else BASS_MusicPlay(mod);

/*	starttime=timeGetTime();

	// NOTE: some compilers don't support _kbhit
	while (!_kbhit() && (act=BASS_ChannelIsActive(str?str:mod)))
	{
		// display some stuff and wait a bit
		time=timeGetTime()-starttime;
		level=BASS_ChannelGetLevel(str?str:mod);
		pos=BASS_ChannelGetPosition(str?str:mod);
		if (str) printf("pos %09I64d",pos);
		else printf("pos %03d:%03d",LOWORD(pos),HIWORD(pos));
		printf(" - time %d:%02d - L ",time/60000,(time/1000)%60);
		if (act==BASS_ACTIVE_STALLED)
		{
			printf("-- buffering : %05d --",BASS_StreamGetFilePosition(str,BASS_FILEPOS_DOWNLOAD)-BASS_StreamGetFilePosition(str,BASS_FILEPOS_DECODE));
		}
		else
		{
			for (a=93;a;a=a*2/3) putchar(LOWORD(level)>=a?'*':'-');
			putchar(' ');
			for (a=1;a<128;a+=a-(a>>1)) putchar(HIWORD(level)>=a?'*':'-');
		}
		printf(" R - cpu %.2f%%  \r",BASS_GetCPU());
		Sleep(50);
	}*/
}

void Bass::Free()
{
	//
	BASS_ChannelSlideAttributes(str?str:mod,1000,-1,-101,500);
	Sleep(300);
	// ...and fade-out to avoid a "click"
	BASS_ChannelSlideAttributes(str?str:mod,-1,-2,-101,200);
	while (BASS_ChannelIsSliding(str?str:mod)) Sleep(1);

	BASS_Free();
}

void CALLBACK LoopSync(HSYNC handle, DWORD channel, DWORD data, DWORD user);

#endif