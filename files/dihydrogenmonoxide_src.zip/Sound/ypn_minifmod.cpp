#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>

#include "../CommonHeaders/ypn_common.h"
#include "ypn_minifmod.h"

//#define USEMEMLOAD
//#define USEMEMLOADRESOURCE

#ifdef _MINIFMOD_LIB_
	#include "../core/libs/minifmod/minifmod.h"
	#pragma comment(lib, "winmm.lib")
	#pragma comment(lib, "core/libs/minifmod/minifmod.lib")
#endif




#ifndef USEMEMLOAD

unsigned int fileopen(char *name)
{
	return (unsigned int)fopen(name, "rb");
}

void fileclose(unsigned int handle)
{
	fclose((FILE *)handle);
}

int fileread(void *buffer, int size, unsigned int handle)
{
	return fread(buffer, 1, size, (FILE *)handle);
}

void fileseek(unsigned int handle, int pos, signed char mode)
{
	fseek((FILE *)handle, pos, mode);
}

int filetell(unsigned int handle)
{
	return ftell((FILE *)handle);
}

#else

typedef struct 
{
	int length;
	int pos;
	void *data;
} MEMFILE;

#endif


#ifdef _MINIFMOD_LIB_
FMUSIC_MODULE *mod;

void initMinifmod(char *filename)
{
#ifndef USEMEMLOAD
	FSOUND_File_SetCallbacks(fileopen, fileclose, fileread, fileseek, filetell);
#else
//	FSOUND_File_SetCallbacks(memopen, memclose, memread, memseek, memtell);
#endif

#ifdef _MINIFMOD_LIB_
	// ==========================================================================================
	// INITIALIZE
	// ==========================================================================================
	if (!FSOUND_Init(44100, 0))
	{
		printf("Error upon initialization\n");
		return;
	}

	// ==========================================================================================
	// LOAD SONG
	// ==========================================================================================
	mod = FMUSIC_LoadSong(filename, NULL);
	if (!mod)
	{
		printf("Error loading song\n");
		return;
	}
#endif
}

void playMinifmod()
{
#ifdef _MINIFMOD_LIB_
	FMUSIC_PlaySong(mod);
#endif
}

void closeMinifmod()
{
#ifdef _MINIFMOD_LIB_
	FMUSIC_FreeSong(mod);
	FSOUND_Close();
#endif
}

int ord = 0, row = 0;
float mytime = 0;

void timeMinifmod()
{
#ifdef _MINIFMOD_LIB_
	ord = FMUSIC_GetOrder(mod);
	row = FMUSIC_GetRow(mod);
	mytime = (float)FMUSIC_GetTime(mod) / 1000.0f;
#endif
}


#endif
