
#ifdef __cplusplus
extern "C" {
#endif

extern unsigned int fileopen(char *name);
extern void fileclose(unsigned int handle);
extern int fileread(void *buffer, int size, unsigned int handle);
extern void fileseek(unsigned int handle, int pos, signed char mode);
extern int filetell(unsigned int handle);

void initMinifmod(char *filename);
void playMinifmod();
void closeMinifmod();
void timeMinifmod();

#ifdef __cplusplus
}
#endif
