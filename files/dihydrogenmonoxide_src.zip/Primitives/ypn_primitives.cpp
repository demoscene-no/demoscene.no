#include "ypn_primitives.h"

//
//bitcodes
//
int CLIP_LEFT = 1;	//0001
int CLIP_RIGHT = 2;	//0010
int CLIP_DOWN = 4;	//0100
int CLIP_UP = 8;	//1000

extern FPoint2D view_port={100,100,640-100,480-100};	//clip against this viewport

void hline(unsigned int *buffer, int x1, int x2, int y, int col)
{
	int x,dx,t;

	if (x1>x2) { t=x1; x1=x2; x2=t; }
	for (x=x1; x<=x2; x++) buffer[x+y*WIDTH]=col;
}

/*void triangle(unsigned int *buffer, int x1, int y1, int x2, int y2, int x3, int y3, int col)
{
	int x,y,t;
	float dxR,dxL;
	float xsL,xsR;

	//check and eventually swap variables to get the desired values.
	if (y1>y2)
	{
		t=y1;
		y1=y2;
		y2=t;
		t=x1;
		x1=x2;
		x2=t;
	}
	if (y2>y3)
	{
		t=y2;
		y2=y3;
		y3=t;
		t=x2;
		x2=x3;
		x3=t;
	}
	if (y1>y2)
	{
		t=y1;
		y1=y2;
		y2=t;
		t=x1;
		x1=x2;
		x2=t;
	}


	if (y1==y2)
	{
		xsL=(float)(x2-x1)/(y2-y1);	//slope to go left
		for (y=y1; y<y3; y++)
		{
//			hline(buffer, x1+(int)dxL, x1, y, 0xffffff);//col);
			dxL+=xsL;
		}
	}

	xsL=-(float)(x1-x2)/(y2-y1);	//slope to go left
	xsR=(float)(x3-x1)/(y3-y1);	//slope to go right

	//draw upper triangle
	for (y=y1; y<y2; y++)
	{
		hline(buffer, x1+(int)dxL, x1+(int)dxR, y, col);
		dxL+=xsL;
		dxR+=xsR;
	}

	xsL=(float)(x3-x2)/(y3-y2);	//slope to right now

	if (y1!=y2)
	for (y=y2; y<y3; y++)
	{
		hline(buffer, x1+(int)dxL, x1+(int)dxR, y, col);
		dxL+=xsL;
		dxR+=xsR;
	}
}
*/

void triangle(unsigned int *buffer, int x1, int y1, int x2, int y2, int x3, int y3, int col)
{
	int x,y,t;
	float dxR,dxL;
	float sxL,sxR;

	//check and eventually swap variables to get the desired values.
	if (y1>y2)
	{
		t=y1;
		y1=y2;
		y2=t;
		t=x1;
		x1=x2;
		x2=t;
	}
	if (y2>y3)
	{
		t=y2;
		y2=y3;
		y3=t;
		t=x2;
		x2=x3;
		x3=t;
	}
	if (y1>y2)
	{
		t=y1;
		y1=y2;
		y2=t;
		t=x1;
		x1=x2;
		x2=t;
	}

	//this is a very bad hack to fix the error. ill get back to this later.
	if (y1==y2) y1--;
	//

	sxL=-(float)(x1-x2)/(y2-y1);
	sxR=(float)(x3-x1)/(y3-y1);

	dxL=dxR=0;

	//draw upper triangle
	for (y=y1; y<y2; y++)
	{
		hline(buffer, x1+(int)dxL, x1+(int)dxR, y, col);
		dxL+=sxL;
		dxR+=sxR;
	}

	sxL=(float)(x3-x2)/(y3-y2);

	for (y=y2; y<y3; y++)
	{
		hline(buffer, x1+(int)dxL, x1+(int)dxR, y, col);
		dxL+=sxL;
		dxR+=sxR;
	}
}


//determine which sector endpoint is in.
int getbitcode(int x, int y)
{
	int bitcode=0;
	if (x<view_port.x0) bitcode=bitcode|CLIP_LEFT;
	if (x>view_port.x1) bitcode=bitcode|CLIP_RIGHT;
	if (y<view_port.y0) bitcode=bitcode|CLIP_UP;
	if (y>view_port.y1) bitcode=bitcode|CLIP_DOWN;
	return bitcode;
}

int inside(int x, int y)
{
	if ((x<view_port.x0) || (x>view_port.x1)) return 0;
	if ((y<view_port.y0) || (y>view_port.y1)) return 0;
	return 1;
}

int line_clip(int *x0, int *y0, int *x1, int *y1)
{
	int out1,out2;

	while(1)
	{
		out1=getbitcode(*x0,*y0);
		out2=getbitcode(*x1,*y1);

		//need clipping?
		if (out1 & out2)
		{
			//both endpoints are outside window,
			//dont draw
			return 0;
		}

		if ((out1 | out2) == 0)
		{
			//both endpoints are inside window,
			//draw without clipping
			return 1;
		}

		//find first endpoint that is outside window
		if (inside(*x0,*y0))
		{
			g_i2swap(x0,x1);
			g_i2swap(y0,y1);
			g_i2swap(&out1,&out2);
		}

		if (out1 & CLIP_UP)
		{
			*x0=(*x0) + (view_port.y0 - *y0) * (*x1 - *x0) / (*y1 - *y0);
			*y0=view_port.y0;
		}
		else
		if (out1 & CLIP_DOWN)
		{
			*x0=(*x0) + (view_port.y1 - *y0) * (*x1 - *x0) / (*y1 - *y0);
			*y0=view_port.y1;
		}
		else
		if (out1 & CLIP_LEFT)
		{
			*y0=(*y0) + (*y1 - *y0) * (view_port.x0 - *x0) / (*x1 - *x0);
			*x0=view_port.x0;
		}
		else
		if (out1 & CLIP_RIGHT)
		{
			*y0=(*y0) + (*y1 - *y0) * (view_port.x1 - *x0) / (*x1 - *x0);
			*x0=view_port.x1;
		}
	}
	return 1;
}

//determine which sector endpoint is in.
int getbitcodef(float x, float y)
{
	int bitcode=0;
	if (x<view_port.x0) bitcode=bitcode|CLIP_LEFT;
	if (x>view_port.x1) bitcode=bitcode|CLIP_RIGHT;
	if (y<view_port.y0) bitcode=bitcode|CLIP_UP;
	if (y>view_port.y1) bitcode=bitcode|CLIP_DOWN;
	return bitcode;
}

int insidef(float x, float y)
{
	if ((x<view_port.x0) || (x>view_port.x1)) return 0;
	if ((y<view_port.y0) || (y>view_port.y1)) return 0;
	return 1;
}

void swapf(float *a, float *b)
{
	float temp;
	temp=*a;
	*a=*b;
	*b=temp;
}

int line_clipf(float *fx0, float *fy0, float *fx1, float *fy1)
{
	int out1,out2;

	while(1)
	{
		out1=getbitcodef(*fx0,*fy0);
		out2=getbitcodef(*fx1,*fy1);

		//need clipping?
		if (out1 & out2)
		{
			//both endpoints on the same side of window,
			//dont draw
			return 0;
		}

		if ((out1 | out2) == 0)
		{
			//both endpoints are inside window,
			//draw without clipping
			return 1;
		}

		//find first endpoint that is outside window
		if (insidef(*fx0,*fy0))
		{
			swapf(fx0,fx1);
			swapf(fy0,fy1);
			g_i2swap(&out1,&out2);
		}

		if (out1 & CLIP_UP)
		{
			*fx0=(*fx0) + (view_port.y0 - *fy0) * (*fx1 - *fx0) / (*fy1 - *fy0);
			*fy0=view_port.y0;
		}
		else
		if (out1 & CLIP_DOWN)
		{
			*fx0=(*fx0) + (view_port.y1 - *fy0) * (*fx1 - *fx0) / (*fy1 - *fy0);
			*fy0=view_port.y1;
		}
		else
		if (out1 & CLIP_LEFT)
		{
			*fy0=(*fy0) + (*fy1 - *fy0) * (view_port.x0 - *fx0) / (*fx1 - *fx0);
			*fx0=view_port.x0;
		}
		else
		if (out1 & CLIP_RIGHT)
		{
			*fy0=(*fy0) + (*fy1 - *fy0) * (view_port.x1 - *fx0) / (*fx1 - *fx0);
			*fx0=view_port.x1;
		}
	}
	return 1;
}

//line routine from scratch by activator. i suppose its not unlike bresenhams.
void line(unsigned int *buffer, int x1, int y1, int x2, int y2, int col)
{
	int px,py;
	int sx,sy;
	int lx,ly;	//lengths
	float step_x,step_y;
	float fy,fx;
	int dir_x; //direction: left or right
	int dir_y; //direction: up or down
	int width=WIDTH;

	if (x1>=WIDTH-1) x1=WIDTH-1;
	if (x1<=0) x1=0;
	if (x2>=WIDTH-1) x2=WIDTH-1;
	if (x2<=0) x2=0;
	if (y1>=HEIGHT-1) y1=HEIGHT-1;
	if (y1<=0) y1=0;
	if (y2>=HEIGHT-1) y2=HEIGHT-1;
	if (y2<=0) y2=0;

	lx=abs(x2-x1);
	ly=abs(y2-y1);

	step_y=ly/(float)lx;
	step_x=lx/(float)ly;

	if (x2>=x1) dir_x=1; else { dir_x=-1; step_x=-step_x; }
	if (y2>=y1) dir_y=1; else { dir_y=-1; step_y=-step_y; }

	if (step_y>=-1 && step_y<1)	//horisontal(x) for loops
	{
		fy=0;
		sx=0;
		for (px=0; px<lx; px++)
		{
			buffer[x1+sx + (y1+(int)(fy))*width]=col;
			sx+=dir_x;
			fy+=step_y;
		}
	}

	if (step_x>=-1 && step_x<1)	//vertical(y) for loops
	{
		fx=0;
		sy=0;
		for (py=0; py<ly; py++)
		{
			buffer[x1+(int)(fx) + (y1+sy)*width]=col;
			sy+=dir_y;
			fx+=step_x;
		}
	}
}

int line_width=WIDTH;
//int line_width=320;
void g_line(int *dst, int x0, int y0, int x1, int y1, int col)
{
   int udx, udy, dx, dy, error, loop, xadd, yadd;
   dx=x1-x0; //      Work out x delta
   dy=y1-y0; //      Work out y delta
             
   udx=abs(dx);  //      udx is the unsigned x delta
   udy=abs(dy);  //      udy is the unsigned y delta

   if(dx<0)  //      Work out direction to step in the x direction.
      xadd=-1;
   else xadd=1;

   if(dy<0)  //      Work out direction to step in the y direction.
      yadd=-1;
   else yadd=1;

   error=0;
   loop=0;

   if(udx>udy) {
      do { //      Delta X > Delta Y
         error += udy;
         if(error>=udx) { //      Time to move up / down?
            error-=udx;
            y0+=yadd;
         }
         loop++;
         // if(gfx_visible(x0,y0))
		 if (visible(x0,y0,line_width,HEIGHT))
         dst[x0+y0*line_width]=col;
         x0+=xadd; // Move horizontally.
      } while(loop<udx);  // Repeat for x length of line.
   } else {
      do {  // Delta Y > Delta X
         error+=udx;
         if(error>=udy) {  // Time to move left / right?
            error-=udy;
            x0+=xadd; // Move across.
         }
         loop++;
         // if(gfx_visible(x0,y0))
		 if (visible(x0,y0,line_width,HEIGHT))
         dst[x0+y0*line_width]=col;
         y0+=yadd;  // Move up / down a row.
      } while(loop<udy);  // Repeat for y length of line.
   }
} 

void g_line(int *dst, int width, int height, int x0, int y0, int x1, int y1, int col)
{
   int udx, udy, dx, dy, error, loop, xadd, yadd;
   dx=x1-x0; //      Work out x delta
   dy=y1-y0; //      Work out y delta
             
   udx=abs(dx);  //      udx is the unsigned x delta
   udy=abs(dy);  //      udy is the unsigned y delta

   if(dx<0)  //      Work out direction to step in the x direction.
      xadd=-1;
   else xadd=1;

   if(dy<0)  //      Work out direction to step in the y direction.
      yadd=-1;
   else yadd=1;

   error=0;
   loop=0;

   if(udx>udy) {
      do { //      Delta X > Delta Y
         error += udy;
         if(error>=udx) { //      Time to move up / down?
            error-=udx;
            y0+=yadd;
         }
         loop++;
         // if(gfx_visible(x0,y0))
		 if (visible(x0,y0,width,height))
         dst[x0+y0*width]=col;
         x0+=xadd; // Move horizontally.
      } while(loop<udx);  // Repeat for x length of line.
   } else {
      do {  // Delta Y > Delta X
         error+=udx;
         if(error>=udy) {  // Time to move left / right?
            error-=udy;
            x0+=xadd; // Move across.
         }
         loop++;
         // if(gfx_visible(x0,y0))
		 if (visible(x0,y0,width,height))
         dst[x0+y0*width]=col;
         y0+=yadd;  // Move up / down a row.
      } while(loop<udy);  // Repeat for y length of line.
   }
} 

void motionblur(unsigned int *tobuffer, unsigned int *frombuffer, int amount)
{
	int i,j;
	for (j=0; j<amount; j++)
	for (i=0; i<SIZE; i++) tobuffer[i]=((frombuffer[i]&0xfefefe)+(tobuffer[i]&0xfefefe))>>1;
	for (i=0; i<SIZE; i++) frombuffer[i]=tobuffer[i];
}
