#ifndef _primitives
#define _primitives

#include "../commonheaders/ypn_common.h"

#ifdef __cplusplus
	extern "C" {
#endif

//
//bitcodes
//
extern CLIP_LEFT;	//0001
extern CLIP_RIGHT;	//0010
extern CLIP_DOWN;	//0100
extern CLIP_UP;		//1000

#ifdef __cplusplus
	}
#endif


typedef struct
{
	int x0, y0;
	int x1, y1;
} Point2D;

typedef struct
{
	int x, y, z; //z to hold z (3d) coordinate for perspective coorected texturemapper. 
	int u, v;
	int bitcode;
} Coord2D;

typedef struct
{
	float x, y;
} Coord2Df;

typedef struct
{
	float x0, y0;
	float x1, y1;
} FPoint2D;

extern FPoint2D view_port;	//clip against this viewport

void hline(unsigned int *buffer, int x1, int x2, int y, int col);
void triangle(unsigned int *buffer, int x1, int y1, int x2, int y2, int x3, int y3, int col);

void line(unsigned int *buffer, int x1, int y1, int x2, int y2, int col);
void g_line(int *dst, int x0, int y0, int x1, int y1, int col);
void g_line(int *dst, int width, int height, int x0, int y0, int x1, int y1, int col);

int line_clip(int *x0, int *y0, int *x1, int *y1);
int line_clipf(float *fx0, float *fy0, float *fx1, float *fy1);

void motionblur(unsigned int *tobuffer, unsigned int *frombuffer, int amount);
//void g_tri_flat(int *dst, int width, int x1, int y1, int x2, int y2, int x3, int y3, int col);
//void g_tri_flat(Layer layer, int tobuffer, int x1, int y1, int x2, int y2, int x3, int y3, int col);

#endif
