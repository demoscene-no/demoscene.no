// kb
// gridexp header
#ifndef __GRIDEXP__
#define __GRIDEXP__
#include "../commonheaders/ypn_common.h"
#include "../3d/ypn_vector3d.h"

#define G_WIDTH 640
#define G_HEIGHT 180//360
#define SQR(a) ((a)*(a))
#define RGB32(r,g,b) ((r<<16)|(g<<8)|b)

//screenbuffer structure
typedef struct
{
	int *buffer;
	unsigned char *cbuffer;
	int width, height;
	int size, sizec;
} scrbuffer;

typedef struct
{
   float x,y,z,u,v;
   int iu,iv;
} FVector;

// grid structure
typedef struct
{
	FVector *buffer;
	int width, height;
	int size;

	float fov;
	int offset;
	int radius;
	bool shade;
} gridbuffer;

extern int *g_zbuffer;

#ifdef __cplusplus
   extern "C" {
#endif 

extern int init_zbuffer(int xres, int yres);
extern void free_zbuffer();

extern void s_hline_tmap_gouraud_z(unsigned int *tobuffer, unsigned int *texture, int x1, int x2, int z1, int z2, int y, int u1, int u2, int v1, int v2, g_irgb colstart, g_irgb colend);
extern void s_tri_tmap_gouraud_z(unsigned int *tobuffer, unsigned int *texture, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int u1, int v1, int u2, int v2, int u3, int v3, g_irgb c1, g_irgb c2, g_irgb c3);

extern void vector_normalize(FVector v);
extern void vector_rotate(FVector *v, FVector *rv, float xan, float yan, float zan);
extern void vector_rotate2(Vector3D *v, Vector3D *rv, float xan, float yan, float zan);

extern void s_tri_tmap(scrbuffer tobuffer, int x1, int y1, int u1, int v1, int x2, int y2, int u2, int v2, int x3, int y3, int u3, int v3, scrbuffer texture);
//extern void s_tri_tmap_gouraud_z(scrbuffer tobuffer, scrbuffer texture, int x1, int y1, int z1, int x2, int y2, int z2, int x3, int y3, int z3, int u1, int v1, int u2, int v2, int u3, int v3, g_irgb c1, g_irgb c2, g_irgb c3);
extern void s_tri_tmap2(unsigned int *tobuffer, int x1, int y1, int u1, int v1, int x2, int y2, int u2, int v2, int x3, int y3, int u3, int v3, unsigned int *texture);

extern gridbuffer makegrid(int width, int height);
extern void gridcopy(gridbuffer togrid, gridbuffer fromgrid);
extern void gridwrap(gridbuffer grid);
extern void gridexpander(unsigned int *tobuffer, gridbuffer grid, unsigned int *texture);
//extern void gridexpander_line(scrbuffer tobuffer, gridbuffer grid, int col);
extern void gridflat(gridbuffer grid, float px, float py);
void gridrotate(gridbuffer grid, float factor, float rot);

extern void gridzoom(gridbuffer grid, float sx, float sy);
extern void gridwave(gridbuffer grid, float scale, float anim, float power);
//extern void gridsinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float power);
extern void gridsinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float xpower, float ypower);
//extern void gridcosinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float power);
extern void gridcosinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float xpower, float ypower);

extern void gridlens(gridbuffer grid, float scale);
extern void gridwtf(gridbuffer grid, float deg);
extern void gridweird(gridbuffer grid, float deg);
extern void gridmorph(gridbuffer grid, gridbuffer fromgrid, gridbuffer togrid, float alpha);

#ifdef __cplusplus
   }
#endif

#endif
