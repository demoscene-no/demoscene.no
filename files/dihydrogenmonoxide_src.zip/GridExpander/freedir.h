// kb
// freedir header
#ifndef __FREEDIR__
#define __FREEDIR__

#define M_PI 3.14159265359
#define DEG2RAD(f) (f*((M_PI*2)/360))
#define SQR(a) ((a)*(a))
#define SGN(a) ((a>0) ? 1:-1)
//gridexpander and uvplanes+tunnels
//#define FOV 60.0
#define FOV 120.0

#include "gridexp.h"
#include "../3d/ypn_vector3d.h"

#ifdef __cplusplus
   extern "C" {
#endif 

extern float PLANE_OFFSET;
extern void freedirectional_plane(gridbuffer grid, Vector3D campos, Vector3D camtar);
extern void freedirectional_tunnel(gridbuffer grid, Vector3D campos, Vector3D camtar);

#ifdef __cplusplus
   }
#endif

#endif
