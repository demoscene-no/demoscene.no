// Yaphan's freedirectional tunnels and planes.
// activator / yaphan
#include <math.h>
#include "freedir.h"
#include "../timerclass/ypn_timer.h"

float PLANE_OFFSET=650;
float CONE_RADIUS=256;//512;

float FOV_PLANE=60;//30;
float FOV_TUNNEL=20;//30;//40;

void freedirectional_plane(gridbuffer grid, Vector3D campos, Vector3D camtar)
{
	int x,y;
	float fov;
	int offset;
	int width=grid.width;
	int height=grid.height;
	int wh=width/2;
	int hh=height/2;
	static int u,v,z;
	static double t;
	Vector3D intersection, direction, rotvector;

	fov = grid.fov;
	offset = grid.offset;

//	PLANE_OFFSET=350+sin(ftime)*200;

	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		rotvector.x=(x-wh)/fov;
		rotvector.y=(y-hh)/fov;
		rotvector.z=1;

		vector_rotate2(&direction, &rotvector, DEG2RAD(camtar.x), DEG2RAD(camtar.y), DEG2RAD(camtar.z));
		direction.Normalize();

		//sjekk for interseksjoner
		t=(SGN(direction.y)*offset-campos.y)/direction.y;
		intersection.x=campos.x+direction.x*t;
		intersection.y=campos.y+direction.y*t;
		intersection.z=campos.z+direction.z*t;
		u=((intersection.x)*0.3);
		v=((intersection.z)*0.3);

		//kalkuler dybda
		t=50000.0/t;
		z=(t>63?63:t);

		grid.buffer[x+y*width].u=u;
		grid.buffer[x+y*width].v=v;
		grid.buffer[x+y*width].z=z;	//brukes til � m�rklegge de dypeste omr�dene
	}
}

void freedirectional_tunnel(gridbuffer grid, Vector3D campos, Vector3D camtar)
{
	int x,y,addr;
	int width=grid.width;
	int height=grid.height;
	int wh=width/2;
	int hh=height/2;
	static int u,v,z;
	static double a,b,c,delta,t1,t2,t;
	int radius;
	float fov;

	Vector3D intersection, direction, rotvector;

	radius=grid.radius;
	fov=grid.fov;

	for(y=0; y<height; y++)
	{
		addr=y*width;
		for(x=0; x<width; x++)
		{
			rotvector.x=(x-wh)/fov;
			rotvector.y=(y-hh)/fov;
			rotvector.z=1;

			vector_rotate2(&direction, &rotvector, DEG2RAD(camtar.x), DEG2RAD(camtar.y), DEG2RAD(camtar.z));
			direction.Normalize();

			//tunnel formel
			a=SQR(direction.x)+SQR(direction.y);
			b=2*(campos.x*direction.x+campos.y*direction.y);
			c=SQR(campos.x)+SQR(campos.y)-SQR(radius);
			//delta=(b*b)-4*a*c;
			delta=sqrt(SQR(b)-4*a*c);
			t1=(-b+delta)/(2*a+EPSILON);
			t2=(-b-delta)/(2*a+EPSILON);
			t=t1>0?t1:t2;

			//sjekk for interseksjoner
			intersection.x=campos.x+direction.x*t;
			intersection.y=campos.y+direction.y*t;
			intersection.z=campos.z+direction.z*t;
			u=(fabs(intersection.z)*0.2);
			v=(fabs(atan2(intersection.y, intersection.x)*256/M_PI));

			//kalkuler dybda
			t=20000.0/t;
			z=(t>63?63:t);

			grid.buffer[x+addr].u=u;
			grid.buffer[x+addr].v=v;
			grid.buffer[x+addr].z=z;	//brukes til � m�rklegge de dypeste omr�dene
		}
	}
}
