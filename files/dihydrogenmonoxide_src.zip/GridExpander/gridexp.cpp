// kb
// Yaphan's grid expander.
// standard 64x36 in 512x288 fakemode (8x8 texels)
// activator / yaphan
#include <math.h>
#include "gridexp.h"
#include "../trianglefillers/ypn_flatfillers.h"
/*
void g_i2swap(int *a, int *b) {
   int tmp=(int)*a;
   *a=(int)*b;
   *b=tmp;
}*/

int yaddr[360];

int init_zbuffer(int xres, int yres)
{
	int i;
	g_zbuffer=(int *)malloc(xres*yres*sizeof(int));
	for (i=0; i<360; i++) yaddr[i]=i*640;

	return 0;
}

void free_zbuffer()
{
	free(g_zbuffer);
}

void vector_normalize(FVector v) {
   float len=(float)sqrt(SQR(v.x)+SQR(v.y)+SQR(v.z));
	if (len!=0) { v.x/=len; v.y/=len; v.z/=len; }
	else v.x=v.y=v.z=0;
}

void vector_rotate(FVector *v, FVector *rv, float xan, float yan, float zan) {
	float M[3][3];
	float cx=cos(xan), cy=cos(yan), cz=cos(zan);
	float sx=sin(xan), sy=sin(yan), sz=sin(zan);
	M[0][0]=cy*cz; M[0][1]=cy*sz; M[0][2]=-sy;
	M[1][0]=(sx*sy*cz)-(cx*sz); M[1][1]=(sx*sy*sz)+(cx*cz); M[1][2]=sx*cy;
	M[2][0]=(cx*sy*cz)+(sx*sz); M[2][1]=(cx*sy*sz)-(sx*cz); M[2][2]=cx*cy;
	v->x=(rv->x*M[0][0])+(rv->y*M[0][1])+(rv->z*M[0][2]);
	v->y=(rv->x*M[1][0])+(rv->y*M[1][1])+(rv->z*M[1][2]);
	v->z=(rv->x*M[2][0])+(rv->y*M[2][1])+(rv->z*M[2][2]);
}

void vector_rotate2(Vector3D *v, Vector3D *rv, float xan, float yan, float zan)
{
	float M[3][3];
	float cx=cos(xan), cy=cos(yan), cz=cos(zan);
	float sx=sin(xan), sy=sin(yan), sz=sin(zan);
	M[0][0]=cy*cz; M[0][1]=cy*sz; M[0][2]=-sy;
	M[1][0]=(sx*sy*cz)-(cx*sz); M[1][1]=(sx*sy*sz)+(cx*cz); M[1][2]=sx*cy;
	M[2][0]=(cx*sy*cz)+(sx*sz); M[2][1]=(cx*sy*sz)-(sx*cz); M[2][2]=cx*cy;
	v->x=(rv->x*M[0][0])+(rv->y*M[0][1])+(rv->z*M[0][2]);
	v->y=(rv->x*M[1][0])+(rv->y*M[1][1])+(rv->z*M[1][2]);
	v->z=(rv->x*M[2][0])+(rv->y*M[2][1])+(rv->z*M[2][2]);
}

// original by guru.
// modification by activator on 29th of july 2003
// and also wrapping fixed.
void s_tri_tmap(scrbuffer tobuffer, int x1, int y1, int u1, int v1,
                          int x2, int y2, int u2, int v2,
                          int x3, int y3, int u3, int v3, scrbuffer texture) {
   int mapsize=texture.width;
   int wrapx=mapsize-1;
   int wrapy=texture.height-1;
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int _u1, _u2, _u3;
   int dudy1, dudy2, dudy3;
   int _v1, _v2, _v3;
   int dvdy1, dvdy2, dvdy3;
   int y2y1, y3y1, y3y2;
   int dudx, dvdx, u, v;
   int sx, ex;
   int x, y;

   if(y1>y2) {
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   if(y1>y3) {
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&u1, &u3);
      g_i2swap(&v1, &v3);
   }

   if(y2>y3) {
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&u2, &u3);
      g_i2swap(&v2, &v3);
   }

   y2y1=y2-y1; // middle
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dudy1=((u2-u1) << 16) / y2y1;
      dvdy1=((v2-v1) << 16) / y2y1;
   } else {
      dxdy1=dudy1=dvdy1=0;
   }

   y3y1=y3-y1; // long
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dudy2=((u3-u1) << 16) / y3y1;
      dvdy2=((v3-v1) << 16) / y3y1;
   } else {
      dxdy2=dudy2=dvdy2=0;
   }

   y3y2=y3-y2; // bottom
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dudy3=((u3-u2) << 16) / y3y2;
      dvdy3=((v3-v2) << 16) / y3y2;
   } else {
      dxdy3=dudy3=dvdy3=0;
   }

   // setup initial vars
   _x1=x1<<16; _u1=u1<<16; _v1=v1<<16; // long
   _x2=x1<<16; _u2=u1<<16; _v2=v1<<16; // middle
   _x3=x2<<16; _u3=u2<<16; _v3=v2<<16; // bottom

   // int dudx, dvdx, u, v; sx / ex
   for(y=y1; y<y2; y++) {
      if(_x2<_x1) {
         sx=_x2>>16;
         ex=_x1>>16;
         if(ex-sx!=0) {
            dudx=(_u1-_u2) / (ex-sx);
            dvdx=(_v1-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      } else {
         sx=_x1>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u1) / (ex-sx);
            dvdx=(_v2-_v1) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u1;
         v=_v1;
      }
      for(x=sx; x<ex; x++) {
         tobuffer.buffer[x+y*G_WIDTH]=texture.buffer[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x1+=dxdy1;
      _u1+=dudy1;
      _v1+=dvdy1;

      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;
   }

   for(; y<y3; y++) {
      if(_x3<_x2) {
         sx=_x3>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u3) / (ex-sx);
            dvdx=(_v2-_v3) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u3;
         v=_v3;
      } else {
         sx=_x2>>16;
         ex=_x3>>16;
         if(ex-sx!=0) {
            dudx=(_u3-_u2) / (ex-sx);
            dvdx=(_v3-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      }
      for(x=sx; x<ex; x++) {
         tobuffer.buffer[x+y*G_WIDTH]=texture.buffer[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;

      _x3+=dxdy3;
      _u3+=dudy3;
      _v3+=dvdy3;
   }
}

void s_tri_tmap2(unsigned int *tobuffer, int x1, int y1, int u1, int v1,
                          int x2, int y2, int u2, int v2,
                          int x3, int y3, int u3, int v3, unsigned int *texture) {
   int mapsize=256;
   int wrapx=mapsize-1;
   int wrapy=256-1;
   int _x1, _x2, _x3;
   int dxdy1, dxdy2, dxdy3;
   int _u1, _u2, _u3;
   int dudy1, dudy2, dudy3;
   int _v1, _v2, _v3;
   int dvdy1, dvdy2, dvdy3;
   int y2y1, y3y1, y3y2;
   int dudx, dvdx, u, v;
   int sx, ex;
   int x, y;

   if(y1>y2) {
      g_i2swap(&x1, &x2);
      g_i2swap(&y1, &y2);
      g_i2swap(&u1, &u2);
      g_i2swap(&v1, &v2);
   }

   if(y1>y3) {
      g_i2swap(&x1, &x3);
      g_i2swap(&y1, &y3);
      g_i2swap(&u1, &u3);
      g_i2swap(&v1, &v3);
   }

   if(y2>y3) {
      g_i2swap(&x2, &x3);
      g_i2swap(&y2, &y3);
      g_i2swap(&u2, &u3);
      g_i2swap(&v2, &v3);
   }

   y2y1=y2-y1; // middle
   if(y2y1!=0) {
      dxdy1=((x2-x1) << 16) / y2y1;
      dudy1=((u2-u1) << 16) / y2y1;
      dvdy1=((v2-v1) << 16) / y2y1;
   } else {
      dxdy1=dudy1=dvdy1=0;
   }

   y3y1=y3-y1; // long
   if(y3y1!=0) {
      dxdy2=((x3-x1) << 16) / y3y1;
      dudy2=((u3-u1) << 16) / y3y1;
      dvdy2=((v3-v1) << 16) / y3y1;
   } else {
      dxdy2=dudy2=dvdy2=0;
   }

   y3y2=y3-y2; // bottom
   if(y3y2!=0) {
      dxdy3=((x3-x2) << 16) / y3y2;
      dudy3=((u3-u2) << 16) / y3y2;
      dvdy3=((v3-v2) << 16) / y3y2;
   } else {
      dxdy3=dudy3=dvdy3=0;
   }

   // setup initial vars
   _x1=x1<<16; _u1=u1<<16; _v1=v1<<16; // long
   _x2=x1<<16; _u2=u1<<16; _v2=v1<<16; // middle
   _x3=x2<<16; _u3=u2<<16; _v3=v2<<16; // bottom

   // int dudx, dvdx, u, v; sx / ex
   for(y=y1; y<y2; y++) {
      if(_x2<_x1) {
         sx=_x2>>16;
         ex=_x1>>16;
         if(ex-sx!=0) {
            dudx=(_u1-_u2) / (ex-sx);
            dvdx=(_v1-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      } else {
         sx=_x1>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u1) / (ex-sx);
            dvdx=(_v2-_v1) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u1;
         v=_v1;
      }
      for(x=sx; x<ex; x++) {
         tobuffer[x+y*G_WIDTH]=texture[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x1+=dxdy1;
      _u1+=dudy1;
      _v1+=dvdy1;

      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;
   }

   for(; y<y3; y++) {
      if(_x3<_x2) {
         sx=_x3>>16;
         ex=_x2>>16;
         if(ex-sx!=0) {
            dudx=(_u2-_u3) / (ex-sx);
            dvdx=(_v2-_v3) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u3;
         v=_v3;
      } else {
         sx=_x2>>16;
         ex=_x3>>16;
         if(ex-sx!=0) {
            dudx=(_u3-_u2) / (ex-sx);
            dvdx=(_v3-_v2) / (ex-sx);
         } else {
            dudx=0;
            dvdx=0;
         }
         u=_u2;
         v=_v2;
      }
      for(x=sx; x<ex; x++) {
         tobuffer[x+y*G_WIDTH]=texture[((u>>16)&wrapx) + (((v>>16)&wrapy)*mapsize)];
//         tobuffer.buffer[x+y*g_xres]=texture.buffer[((u>>16)&wrapx) + (((v>>16))*mapsize)];
         u+=dudx;
         v+=dvdx;
      }
      _x2+=dxdy2;
      _u2+=dudy2;
      _v2+=dvdy2;

      _x3+=dxdy3;
      _u3+=dudy3;
      _v3+=dvdy3;
   }
}

gridbuffer makegrid(int width, int height)
{
	gridbuffer buffer;
	buffer.width=(width/8)+1;
	buffer.height=(height/8)+1;
	buffer.size=buffer.width*buffer.height;
	buffer.buffer=(FVector*)malloc(buffer.size*sizeof(FVector));
	return buffer;
}

void gridcopy(gridbuffer togrid, gridbuffer fromgrid)
{
	int i;
	int size=fromgrid.size;
	for(i=0; i<size; i++)
	{
		togrid.buffer[i].u=fromgrid.buffer[i].u;
		togrid.buffer[i].v=fromgrid.buffer[i].v;
		togrid.buffer[i].z=fromgrid.buffer[i].z;
	}
}

void gridwrap(gridbuffer grid)
{
	int i,size=grid.size;
	int sx=319;//grid.width;
	int sy=199;//grid.height;
	for(i=0; i<size; i++)
	{
		if (grid.buffer[i].u>(sx-1)) grid.buffer[i].u=sx-1;
		if (grid.buffer[i].u<0) grid.buffer[i].u=0;

		if (grid.buffer[i].v>(sy-1)) grid.buffer[i].v=sy-1;
		if (grid.buffer[i].v<0) grid.buffer[i].v=0;
	}
}

void gridexpander(unsigned int *tobuffer, gridbuffer grid, unsigned int *texture)
{
	int addr,addr2,gaddr,gaddr2;
	int x,y,tx,ty;
	int u1,v1,u2,v2,u3,v3,u4,v4;

	//shade values
//	float z1,z2,z3,z4;
	int z1,z2,z3,z4;
//	int zi1,zi2,zi3,zi4;
	g_irgb c1,c2,c3,c4;

	int widtht=(grid.width-1)*8;
//	int widtht=320;

	int gwidth=grid.width;
	int gheight=grid.height;

	int tex_width=256;//320;//256;

	if (grid.shade==false)
	{
		for(y=0; y<gheight-1; y++)
		{
			addr=y*widtht;
			addr2=(y+1)*widtht;

			//ty=(y<<3);
			ty=(y*8);//<<3);
			for(x=0; x<gwidth-1; x++)
			{
				tx=(x*8);//<<3);
				u1=grid.buffer[x+y*gwidth].u;
				v1=grid.buffer[x+y*gwidth].v;
				u2=grid.buffer[x+(y+1)*gwidth].u;
				v2=grid.buffer[x+(y+1)*gwidth].v;
				u3=grid.buffer[x+1+(y+1)*gwidth].u;
				v3=grid.buffer[x+1+(y+1)*gwidth].v;
				u4=grid.buffer[x+1+y*gwidth].u;
				v4=grid.buffer[x+1+y*gwidth].v;
	
				g_tri_tmap((int*)tobuffer, widtht, tx,ty, u1,v1, tx,ty+8, u2,v2, tx+8,ty+8, u3,v3, (int*)texture, tex_width);
				g_tri_tmap((int*)tobuffer, widtht, tx,ty, u1,v1, tx+8,ty, u4,v4, tx+8,ty+8, u3,v3, (int*)texture, tex_width);
			}
		}
	}
	else
	{
		for(y=0; y<gheight-1; y++)
		{
			int ty=(y*8);//<<3);
			gaddr=y*gwidth;
			gaddr2=(y+1)*gwidth;
			for(x=0; x<gwidth-1; x++)
			{
				tx=(x*8);//<<3);
				u1=grid.buffer[x+gaddr].u;
				v1=grid.buffer[x+gaddr].v;
				u2=grid.buffer[x+gaddr2].u;
				v2=grid.buffer[x+gaddr2].v;
				u3=grid.buffer[x+1+gaddr2].u;
				v3=grid.buffer[x+1+gaddr2].v;
				u4=grid.buffer[x+1+gaddr].u;
				v4=grid.buffer[x+1+gaddr].v;
	
				//depth
				z1=(int)(grid.buffer[x+gaddr].z*16);
				z2=(int)(grid.buffer[x+gaddr2].z*16);
				z3=(int)(grid.buffer[x+1+gaddr2].z*16);
				z4=(int)(grid.buffer[x+1+gaddr].z*16);
				z1=(z1>255?255:z1);
				z2=(z2>255?255:z2);
				z3=(z3>255?255:z3);
				z4=(z4>255?255:z4);
/*				z1=grid.buffer[x+gaddr].z;
				z2=grid.buffer[x+gaddr2].z;
				z3=grid.buffer[x+1+gaddr2].z;
				z4=grid.buffer[x+1+gaddr].z;
/*
				zi1=(int)(z1*8);
				zi2=(int)(z2*8);
				zi3=(int)(z3*8);
				zi4=(int)(z4*8);

				zi1=(zi1>255?255:zi1);
				zi2=(zi2>255?255:zi2);
				zi3=(zi3>255?255:zi3);
				zi4=(zi4>255?255:zi4);
*/
				//darkening colors with the use of z-coordinates from grid
				c1.r=c1.g=c1.b=255-z1;
				c2.r=c2.g=c2.b=255-z2;
				c3.r=c3.g=c3.b=255-z3;
				c4.r=c4.g=c4.b=255-z4;
/*				c1.r=c1.g=c1.b=255-(z1<<2);
				c2.r=c2.g=c2.b=255-(z2<<2);
				c3.r=c3.g=c3.b=255-(z3<<2);
				c4.r=c4.g=c4.b=255-(z4<<2);
				*/
				g_tri_gouraud((int*)tobuffer, widtht, tx,ty, c1, tx,ty+8, c2, tx+8,ty+8, c3);
				g_tri_gouraud((int*)tobuffer, widtht, tx,ty, c1, tx+8,ty, c4, tx+8,ty+8, c3);
//				g_tri_tmap_gouraud_z((int*)tobuffer, widtht, tx,ty, 0, tx,ty+8, 0, tx+8,ty+8, 0, u1,v1, u2,v2, u3,v3, c1, c2, c3, tex_width, (int*)texture);
//				g_tri_tmap_gouraud_z((int*)tobuffer, widtht, tx,ty, 0, tx+8,ty, 0, tx+8,ty+8, 0, u1,v1, u4,v4, u3,v3, c1, c4, c3, tex_width, (int*)texture);
			}
		}
	}
}
/*
void gridexpander_line(scrbuffer tobuffer, gridbuffer grid, int col)
{
	int x,y,tx,ty;
	int width=grid.width;
	int height=grid.height;
	for(x=0; x<width-1; x++)
	for(y=0; y<height-1; y++)
	{
		tx=(x<<3);
		ty=(y<<3);
		g_line(tobuffer.buffer, tx, ty, tx, ty+8, col);
		g_line(tobuffer.buffer, tx, ty+8, tx+8, ty+8, col);
		g_line(tobuffer.buffer, tx+8, ty+8, tx, ty, col);
		g_line(tobuffer.buffer, tx, ty, tx+8, ty, col);
		g_line(tobuffer.buffer, tx+8, ty, tx+8, ty+8, col);
	}
}*/

void gridflat(gridbuffer grid, float px, float py)
{
	int x,y,width,height;
	float wh,hh,sx,sy,dx,dy;
	width=grid.width;
	height=grid.height;
	int widthp=width*8;
	int heightp=height*8;
//	sx=256.0/width;
//	sy=256.0/height;
	sx=(float)widthp/width;
	sy=(float)heightp/height;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		grid.buffer[x+y*width].u=(x*sx)+px;
		grid.buffer[x+y*width].v=(y*sy)+py;
		grid.buffer[x+y*width].z=63;
	}
}

void gridrotate(gridbuffer grid, float factor, float rot)
{
	int x,y,width,height;
	float fx,fy,fxb,fyb,f;
	float zx,zy,tx,ty;
	width=grid.width;
	height=grid.height;

	//33
	//19
	//33/19=1.736842
	//f=1.736842;

	zy=sin(-rot)*factor;
	zx=cos(-rot)*factor;

//	fx=(width/2)-(height/2*(zx+zy));
//	fy=(height/2)-(width/2*(zx-zy));
	fx=16.5-(9.5*(zx+zy));
	fy=9.5-(16.5*(zx-zy));

	for(y=0; y<height; y++)
	{
		tx=fx;
		ty=fy;
		for(x=0; x<width; x++)
		{
			grid.buffer[x+y*width].u=tx;
			grid.buffer[x+y*width].v=ty;
			tx+=zx;
			ty-=zy;
		}
		fx+=zy;
		fy+=zx;
	}
}

void gridzoom(gridbuffer grid, float sx, float sy)
{
	int x,y,width,height;
	float wh,hh,dx,dy;
	width=grid.width;
	height=grid.height;
//	sx=256.0/width;
//	sy=256.0/height;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		grid.buffer[x+y*width].u+=(x*sx);
		grid.buffer[x+y*width].v+=(y*sy);
	}
}

void gridwave(gridbuffer grid, float scale, float anim, float power)
{
	int x,y;
	float dx,dy,dist,mul;
	int width=grid.width;
	int height=grid.height;
	float wh=(float)width/2;
	float hh=(float)height/2;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		dx=x-wh;
		dy=y-hh;
		dist=sqrt(SQR(dx)+SQR(dy));
		mul=(1+(float)cos(dist*scale-anim))*power;
		grid.buffer[x+y*width].u+=dx*mul;
		grid.buffer[x+y*width].v+=dy*mul;
	}
}

//void gridsinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float power)
void gridsinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float xpower, float ypower)
{
	int x,y;
	int width=grid.width;
	int height=grid.height;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		grid.buffer[x+y*width].u+=(float)sin(x*xstep+xoffset)*xpower;
		grid.buffer[x+y*width].v+=(float)sin(y*ystep+yoffset)*ypower;
	}
}

//void gridcosinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float power)
void gridcosinus(gridbuffer grid, float xstep, float ystep, float xoffset, float yoffset, float xpower, float ypower)
{
	int x,y;
	int width=grid.width;
	int height=grid.height;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		grid.buffer[x+y*width].u+=(float)cos(x*xstep+xoffset)*xpower;
		grid.buffer[x+y*width].v+=(float)cos(y*ystep+yoffset)*ypower;
	}
}

void gridlens(gridbuffer grid, float scale)
{
	float dx,dy,dist,mul;
	int x,y;
	int width=grid.width;
	int height=grid.height;
	float wh=(float)width/2;
	float hh=(float)height/2;
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		dx=x-wh;
		dy=y-hh;
		dist=sqrt(SQR(dx)+SQR(dy));
//		mul=-scale*(scale-(dist/hh));
//		mul=-scale;
		mul=-scale*(dist/hh);
		grid.buffer[x+y*width].u+=mul*dx;
		grid.buffer[x+y*width].v+=mul*dy;
	}
}

float px[3];
float py[3];
void gridwtf(gridbuffer grid, float deg)
{
	int x,y,i;
	float dx,dy,dist,d,d2;
	float flx,fly;
	int width=grid.width;
	int height=grid.height;
	int pwidth=(grid.width-1)*8;
	int pheight=(grid.height-1)*8;

    px[0]=(25+sin(deg*0.5)*55)/(pwidth)*46;
    py[0]=(50+cos(deg*0.5)*20)/(pheight)*32;
    px[1]=(75+sin(deg*0.2)*50)/(pwidth)*76;
    py[1]=(50+cos(deg*0.2)*10)/(pheight)*32;
	px[2]=(17+sin(deg*0.9)*50)/(pwidth)*76;
	py[2]=(75+cos(deg*0.9)*10)/(pheight)*32;

/*
    px[0]=(50+sin(deg*1.5)*30)/(G_WIDTH)*64;
    py[0]=(100+cos(deg*1.5)*60)/(G_HEIGHT)*64;
    px[1]=(150+sin(deg*1.2)*80)/(G_WIDTH)*64;
    py[1]=(100+cos(deg*1.2)*30)/(G_HEIGHT)*64;
	px[2]=(250+sin(deg*1.9)*50)/(G_WIDTH)*64;
	py[2]=(150+cos(deg*1.9)*40)/(G_HEIGHT)*64;
*/
	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
//		grid.buffer[x+y*width].z=8;//128;
		for(i=0; i<3; i++)
		{
			dx=px[i]-x;
			dy=py[i]-y;
			d=SQR(dx)+SQR(dy);
			dist=sqrt(d);
//			d2=sin(dist/16/64*M_PI*4.0)*dist/32.0*M_PI/2.0*cos(deg*0.4+6)+dist/64.0*sin(deg*0.3+4)+deg;
//			d2=sin(0.000244140625*dist*M_PI)*dist*M_PI2*0.03125*cos(deg*0.4+6)+dist*sin(deg*0.3+4)*0.015625+deg;
//			d2=sin(0.000244140625*dist*M_PI)*dist*M_PI2*0.3125*cos(deg*0.4+6)+dist*sin(deg*0.3+4)*0.015625+deg;
			d2=deg;
			d=4.0/d;
			grid.buffer[x+y*width].u+=(dx*cos(d2)-dy*sin(d2))*d*512;
			grid.buffer[x+y*width].v+=(dx*sin(d2)+dy*cos(d2))*d*512;
//			grid.buffer[x+y*width].z-=dist*2;//64deg*6;//ist*2;
//			grid.buffer[x+y*width].z+=dist*8222;
		}
	}
}

void gridweird(gridbuffer grid, float deg)
{
	int x,y,i;
	float dx,dy,dist,d,d2;
	float flx,fly;
	int width=grid.width;
	int height=grid.height;

	for(x=0; x<width; x++)
	for(y=0; y<height; y++)
	{
		for(i=0; i<3; i++)
		{
			dx=px[i]-x;
			dy=py[i]-y;
			d=SQR(dx)+(dy);
			dist=sqrt(d);
//			d2=sin(0.000244140625*dist*M_PI)*dist*M_PI2*0.3125*cos(deg*0.4+6)+dist*sin(deg*0.3+4)*0.015625+deg;
			d2=deg;
			d=4.0/d;
			grid.buffer[x+y*width].u+=(dx*cos(d2)-dy*sin(d2))*d*512;
			grid.buffer[x+y*width].v+=(dx*sin(d2)+dy*cos(d2))*d*512;
			//grid.buffer[x+y*width].z=dist*2;
		}
	}
}

void gridmorph(gridbuffer grid, gridbuffer fromgrid, gridbuffer togrid, float alpha)
{
	int i;
	int size=togrid.size;
	for(i=0; i<size; i++)
	{
		grid.buffer[i].u=((1.0f-alpha)*fromgrid.buffer[i].u)+(alpha*togrid.buffer[i].u);
		grid.buffer[i].v=((1.0f-alpha)*fromgrid.buffer[i].v)+(alpha*togrid.buffer[i].v);
		grid.buffer[i].z=((1.0f-alpha)*fromgrid.buffer[i].z)+(alpha*togrid.buffer[i].z);
	}
}
