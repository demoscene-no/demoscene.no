#ifndef _particle3d
#define _particle3d

#include "../3d/ypn_vector3d.h"

class Particle3D
{
public:
	Particle3D();
	Particle3D(float x, float y, float z);
	~Particle3D();

	Vector3D pos;
	Vector3D acc;
	Vector3D vel;
	float energy;
	bool dead;
};

#endif