#include "../commonheaders/ypn_common.h"
#include "ypn_particle.h"
#include "ypn_particle3d.h"

Particle::Particle()
{
	particles_real=0;
	particles_physics=0;
	particles_transform=0;
	num_particles=0;
}

Particle::~Particle()
{

}

void Particle::AddParticle(float x, float y, float z)
{
	num_particles++;
	particles_real=(Particle3D **) realloc(particles_real, num_particles*sizeof(Particle3D *));
	particles_real[num_particles-1]=new Particle3D();
	particles_real[num_particles-1]->pos.x=x;
	particles_real[num_particles-1]->pos.y=y;
	particles_real[num_particles-1]->pos.z=z;
	particles_physics=(Particle3D **) realloc(particles_physics, num_particles*sizeof(Particle3D *));
	particles_physics[num_particles-1]=new Particle3D();
	particles_transform=(Particle3D **) realloc(particles_transform, num_particles*sizeof(Particle3D *));
	particles_transform[num_particles-1]=new Particle3D();
}

void Particle::AddParticle(Vector3D *v)
{
	num_particles++;
	particles_real=(Particle3D **) realloc(particles_real, num_particles*sizeof(Particle3D *));
	particles_real[num_particles-1]=new Particle3D();
	particles_real[num_particles-1]->pos.x=v->x;
	particles_real[num_particles-1]->pos.y=v->y;
	particles_real[num_particles-1]->pos.z=v->z;
	particles_physics=(Particle3D **) realloc(particles_physics, num_particles*sizeof(Particle3D *));
	particles_physics[num_particles-1]=new Particle3D();
	particles_transform=(Particle3D **) realloc(particles_transform, num_particles*sizeof(Particle3D *));
	particles_transform[num_particles-1]=new Particle3D();
}

void Particle::AddParticle(Particle3D *v)
{
	num_particles++;
	particles_real=(Particle3D **) realloc(particles_real, num_particles*sizeof(Particle3D *));
	particles_real[num_particles-1]=new Particle3D();
	particles_real[num_particles-1]->pos.x=v->pos.x;
	particles_real[num_particles-1]->pos.y=v->pos.y;
	particles_real[num_particles-1]->pos.z=v->pos.z;
	particles_physics=(Particle3D **) realloc(particles_physics, num_particles*sizeof(Particle3D *));
	particles_physics[num_particles-1]=new Particle3D();
	particles_transform=(Particle3D **) realloc(particles_transform, num_particles*sizeof(Particle3D *));
	particles_transform[num_particles-1]=new Particle3D();
}