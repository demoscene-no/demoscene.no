#include "ypn_particle3d.h"

Particle3D::Particle3D()
{
	dead=false;
}

Particle3D::Particle3D(float x, float y, float z)
{
	pos.x=x;
	pos.y=y;
	pos.z=z;
}

Particle3D::~Particle3D()
{

}
