#include "../2d/ypn_vector2d.h"
#include "../3d/ypn_vector3d.h"
#include "ypn_particle3d.h"

class Particle
{
public:
	Particle();
	~Particle();

	void AddParticle(float x, float y, float z);
	void AddParticle(Vector3D *v);
	void AddParticle(Particle3D *v);

	int num_particles;
	Particle3D **particles_real;
	Particle3D **particles_physics;
	Particle3D **particles_transform;
};
