// 3d starfield by activator.
//

#define num_stars	2040
//#define num_stars	2040*10

typedef struct
{
	float x,y,z;
} fvector;

fvector stars[num_stars];
float star_zv[num_stars];
int scr_stars_x[num_stars];
int scr_stars_y[num_stars];
int scr_oldstars_x[num_stars];
int scr_oldstars_y[num_stars];

//camera
fvector angle;
fvector angleacc;
fvector anglevel;

float sintab[1024];
float costab[1024];
float sintable[450];

void random_stars()
{
	for (int i=0; i<num_stars; i++)
	{
		stars[i].x=500-rand()%1000;
		stars[i].y=500-rand()%1000;
		stars[i].z=100+rand()%900;
		star_zv[i]=(rand()%45+5)/10.0;
	}
}

void init_stars()
{
	int i;
	random_stars();
	for(i=0; i<1024; i++)
	{
		sintab[i]=(float)sin(i*M_PI/512);
		costab[i]=(float)cos(i*M_PI/512);
	}
	for(i=0; i<450; i++) sintable[i]=(float)(sin(2*M_PI*i/360));
}

void do_stars(unsigned int *buffer, int zangle)
{
	int i,b;
	int x,y;
	int xd,yd,length;
	float tempx,tempy,tempz;
	float tx,ty,tz;
	float xsin,xcos;
	float ysin,ycos;
	float zsin,zcos;
	float damping=0.8;
	static int xangle=1;
	static int yangle=1;
//	static int zangle=1;
/*	xangle=90;
	yangle=70;
	zangle=110;*/

//	zangle+=2;
//	if (zangle>359) zangle-=360;

//	xangle=90;
/*	xangle+=2;
	if (xangle>359) xangle-=360;
	yangle+=2;
	if (yangle>359) yangle-=360;*/

	for (i=0; i<num_stars; i++)
	{
/*		angleacc.x=angleacc.x+50-rand()%100;
		angleacc.y=angleacc.y+50-rand()%100;
		angleacc.z=angleacc.z+50-rand()%100;
		anglevel.x=anglevel.x+angleacc.x;
		anglevel.y=anglevel.y+angleacc.y;
		anglevel.z=anglevel.z+angleacc.z;
		//damping the motion
		angleacc.x=angleacc.x*damping;
		angleacc.y=angleacc.y*damping;
		angleacc.z=angleacc.z*damping;
		anglevel.x=anglevel.x*damping;
		anglevel.y=anglevel.y*damping;
		anglevel.z=anglevel.z*damping;
		//moving the camera
		angle.x=(angle.x+anglevel.x)*damping;
		angle.y=(angle.y+anglevel.y)*damping;
		angle.z=(angle.z+anglevel.z)*damping;
*/
		stars[i].z-=star_zv[i];
//		stars[i].z-=5;
//		scr_stars_x[i]=stars[i].x/stars[i].z*100+(WIDTH/2);
//		scr_stars_y[i]=stars[i].y/stars[i].z*100+(HEIGHT/2);

		tempx=stars[i].x;
		tempy=stars[i].y;
		tempz=stars[i].z;//-zangle;//stars[i].z;
		if (tempz<0) tempz=0;
		xsin=sintable[xangle];
		xcos=sintable[xangle+90];
		ysin=sintable[yangle];
		ycos=sintable[yangle+90];
		zsin=sintable[zangle];
		zcos=sintable[zangle+90];

		ty=(tempy*xcos)-(tempz*xsin);
		tz=(tempy*xsin)+(tempz*xcos);
		tempy=ty;
		tempz=tz;
		tx=(tempx*ycos)-(tempz*ysin);
		tz=(tempx*ysin)+(tempz*ycos);
		tempx=tx;
		tempz=tz;
		tx=(tempx*zcos)-(tempy*zsin);
		ty=(tempx*zsin)+(tempy*zcos);
		tempx=tx;
		tempy=ty;

//          Rotate (temp_x, temp_y, temp_z) by angleX degrees in the X-axis		
  //        Rotate (temp_x, temp_y, temp_z) by angleY degrees in the Y-axis		
    //      Rotate (temp_x, temp_y, temp_z) by angleZ degrees in the Z-axis			

		//projecting the stars to the screen
		x=tempx/tempz*45+(WIDTH/2);
		y=tempy/tempz*45+(HEIGHT/2);

//		x=stars[i].x/stars[i].z*100+(WIDTH/2);
//		y=stars[i].y/stars[i].z*100+(HEIGHT/2);
		xd=x-scr_stars_x[i];
		yd=y-scr_stars_y[i];
		length=sqrt(xd*xd+yd*yd);

		if (scr_stars_x[i]>=WIDTH || scr_stars_x[i]<0 ||
			scr_stars_y[i]>=HEIGHT || scr_stars_y[i]<0 || stars[i].z<1)
		{
			stars[i].x=500-rand()%1000;
			stars[i].y=500-rand()%1000;
			stars[i].z=100+rand()%900;
			star_zv[i]=(rand()%45+5)/2;
		}
//		b=255-(stars[i].z*(255./1000.));
//		b=((255/5)*star_zv[i])*(1000/stars[i].z);
//		b=(5000*star_zv[i])/stars[i].z;
		b=(10000*star_zv[i])/stars[i].z;
		if (length>1) b=(b/length);

//		b=255;
		if (visible(scr_stars_x[i],scr_stars_y[i]))
			buffer[scr_stars_x[i]+(scr_stars_y[i]*WIDTH)]=RGB32(b,b,b);
//		plot_wu(buffer,scr_stars_x[i],scr_stars_y[i],RGB32(b,b,b));

//		if (visible(x,y))		
//		if (visible(scr_stars_x[i],scr_stars_y[i]))		
//		line(buffer,x,y,scr_stars_x[i],scr_stars_y[i],RGB32(b,b,b));

		scr_oldstars_x[i]=scr_stars_x[i];
		scr_oldstars_y[i]=scr_stars_y[i];
		scr_stars_x[i]=x;
		scr_stars_y[i]=y;
	}
}