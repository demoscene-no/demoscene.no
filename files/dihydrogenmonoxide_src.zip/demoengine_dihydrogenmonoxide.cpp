//------------------------------------------------------------------------------
//  Dihydrogenmonoxide / yaphan vs excess ......... coder : activator / yaphan
//------------------------------------------------------------------------------
#include "3d/ypn_object.h"
#include "Unassorted/ypn_synchronisation.h"
#include "GridExpander\freedir.h"
#include <math.h>
#include "TriangleFillers\ypn_flatfillers.h"

#include "VoxelEngine\ypn_voxel.h"

int aviflag=0;

unsigned char up_down_count;
unsigned char up_down;
char left_right_count;

int flag_fog=-1;
int flag_bilinear=1;
int flag_texture=-1;
//#define LOADING_SCREEN


#define VOXEL_FOREST 0
#define VOXEL_DESERT 1
int voxel_season=0;

//voxel defs
#define VOXEL_LANDSCAPE
//#define VOXEL_LANDSCAPE_MOVE
//#define SNOW
//#define SCROLLTEXT
//#define BACKGROUND_IMAGE
//#define MOTIONBLUR_AND_ZOOM

#define FPS_IN_TITLE
//#define SHOW_MAP


//#define INTROSCREEN
#define _3DENGINE_

char *window_name="Demoengine [Demo] / activator";
char *song_name="saintfixed.ogg";


float synch_1[32]=
{
	16.599, 16.989, 17.501, 18.007, 18.519, 19.020, 19.539, 20.043, 20.530, 21.055, 21.589, 22.093, 22.600, 23.144, 23.630, 24.145, 24.658, 25.166, 25.681, 26.214, 26.698, 27.227, 27.733, 28.263, 28.793, 29.257, 29.792, 30.292, 30.823, 31.313, 31.835, 32.345
};

float synch_2[38]=
{
//	82.210, 83.334, 84.151, 85.425, 86.188, 87.441, 88.240, 90.302, 91.619, 92.064, 92.361, 93.622, 94.066, 94.463, 95.860, 96.304, 96.552, 98.506, 99.779, 100.519, 102.070, 102.619, 103.885, 104.388, 104.625, 104.997, 106.706, 107.996, 108.481, 108.755, 110.042, 110.530, 110.789, 112.064, 112.569, 112.829, 114.287, 114.425
	82.186, 83.370, 84.129, 85.417, 86.210, 87.471, 87.897, 88.226, 90.303, 91.540, 92.064, 92.361, 93.623, 94.389, 95.659, 96.076, 96.476, 98.496, 99.803, 100.298, 100.538, 101.843, 102.608, 103.843, 104.284, 104.667, 106.685, 107.956, 108.478, 108.742, 110.042, 110.812, 112.086, 112.466, 112.815, 113.886, 114.043, 114.277
};

float synch_3[32]=
{
	82.561, 83.604, 84.645, 85.644, 86.662, 87.705, 88.700, 89.736, 90.773, 91.820, 92.834, 93.818, 94.876, 95.833, 96.899, 97.915, 98.963, 99.977, 101.002, 102.021, 103.046, 104.094, 105.101, 106.130, 107.181, 108.202, 109.210, 110.214, 111.264, 112.311, 113.334, 114.551
};
//----------------------------------------------------------------------------------------------------------------------------
// Main
//----------------------------------------------------------------------------------------------------------------------------
Layer primarylayer;
Layer screenlayer;

Object obj_checkerboard;
Object obj_bounce;
Object obj_teapot;
Object obj_torus;
Object obj_spring;

Object obj_excess;
Object obj_yaphan;
Object obj_robothand;
Object obj_robothandgrid;
Object obj_geosphere;
Object obj_spike;

Object obj_cubes[3];

unsigned int *frombuf;
unsigned int *tobuf;

//
//start of twister-defs
//
Zbuffer zB[4];
int zB_num;

void rotation(Vector3D *vt, Vector3D *vf, float deg)
{
	vt->x=vf->x*cos(deg)+vf->z*sin(deg);
	vt->y=vf->y;
	vt->z=vf->z*cos(deg)-vf->x*sin(deg);
}

void textureline(unsigned int *tb, unsigned int *tex, int px1, int px2, int py, int ty)
{
	int x, y;
	int len, pxt;

	len=abs(px2-px1);
	if (px1>px2)
	{
		pxt=px2;
		px2=px1;
		px1=pxt;
	}
	
	float tx;
	tx=255/(float)len;

	float fx=0;
//	int padd=py*WIDTH;
	int padd=py*320;
	int tex_y=+(ty&0xff)*256;
	for (x=0; x<len; x++, fx+=tx)
		if (visible(x+px1, py, 320,200))
			tb[x+px1+padd]=tex[(int)(fx)+tex_y];
}
//
//end of twister
//

#ifdef _BASS_LIB_
	#include "Sound\ypn_bass.h"
	Bass music;

	void CALLBACK LoopSync(HSYNC handle, DWORD channel, DWORD data, DWORD user)
	{
		music.flag_end=0;
	}
#endif

HWND wnd;
void WriteTitleBar(char *string)
{
	SetWindowText(wnd, string);
}


DWORD spool_tick, spool_tick2;
int spool;

int x,y,i;

#include "3d/3ds/ypn_3ds.h"

Scene3DS scene;
gridbuffer grid;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
//	if (!wnd_open(window_name,640,480,WINDOWED)) return 1;
	if (!wnd_open(window_name,640,480,FULLSCREEN)) return 1; 

/*
#ifdef LOADING_SCREEN
	loading.Init(640,480,0);
	loading.AddBuffer(640,480,0);
	loading.AddImage("loading_empty.png");
	loading.CopyBuffer(SCREENBUFFER, 1);
	ptc_update(loading.mainbuffer.pixel);
#endif*/

#ifdef _BASS_LIB_
//	music.Load(song_name);
	music.LoadStr(song_name);
#endif

//	init_zbuffer(WIDTH, 200);
	init_g_zbuffer(WIDTH,HEIGHT);

	screenlayer.Init(640, 480, 0);

	int pwidth=320;
	int pheight=200;

	grid=makegrid(pwidth, pheight);
//	grid=makegrid(256, 256);
/*
	Layer tunnel_scene;
	tunnel_scene.Init(pwidth, pheight, 0);
	tunnel_scene.AddBuffer(320,200,0);//0
	tunnel_scene.AddImage("stonetexture.png");//1
	tunnel_scene.AddImage("stonetexturebump.png");//2
//	tunnel_scene.AddGradientRadial(256,256,0xff00ff);//3
	tunnel_scene.AddGradientRadial(256,256,0xffffff);//3
	tunnel_scene.AddBuffer(256,256,0);//4
*/
/*
	Layer checkerboard_scene;
	checkerboard_scene.Init(pwidth, pheight, 0);
//	checkerboard_scene.AddImage("particle2.png");//0
//	checkerboard_scene.AddImage("particle32.png");//0
	checkerboard_scene.AddImage("reddot.png");//0
	checkerboard_scene.SetMaskMode(0, MASK_TRANSPARENCY_ADD);
//	checkerboard_scene.AddCheckerboard(256,256, 8); //1
//	checkerboard_scene.AddImage("tex/texgen_mod3b.png");//1
	checkerboard_scene.AddImage("tex/checkgrbl3.png");//1
	checkerboard_scene.AddImage("tex/object.png");//2
//	checkerboard_scene.AddImage("tex/texgen_mod.png");
//	checkerboard_scene.AddImage("data/envmap/grace.png");//8
//	checkerboard_scene.ParticleGenerateRandom(1500, Vector3D(0,0,-64), Vector3D(48, 45, 25));

//	checkerboard_scene.AddImage("y.png");
//	checkerboard_scene.ParticleGenerateFromImage(3);

//	checkerboard_scene.ParticleGenerateRandom(20000, Vector3D(0,0,0), Vector3D(100, 100, 100));
	checkerboard_scene.ParticleGenerateRandom(4000, Vector3D(0,0,0), Vector3D(100, 60, 100));
//	checkerboard_scene.ParticleGenerateRandom(100, Vector3D(0,0,0), Vector3D(100, 60, 100));
	checkerboard_scene.ParticleSetGravity(0, Vector3D(0,0,0), Vector3D(0,-0.1,0), 0.5);//0.7);
//	checkerboard_scene.ParticleAddSet(checkerboard_scene.particleset[0]->num_particles);
*/






	//c:\\DEMOENGINE\\!!demosource_release\\debug\\

	Layer intro_scene;
	intro_scene.Init(pwidth, pheight, 0);
	intro_scene.AddBuffer(pwidth, pheight, 0);	//AlphaBuffer (0)
	intro_scene.AddImage("data/sprites/linebar.png");//1
	intro_scene.AddImage("data/sprites/linebar2.png");
	intro_scene.AddImage("data/sprites/linebar3.png");
	intro_scene.AddImage("data/sprites/light.png");	//4
	intro_scene.SetMaskMode(4, MASK_TRANSPARENCY_ADD);
	intro_scene.AddImage("data/textlogo/logo.png");	//5
	intro_scene.AddImage("data/textlogo/text2.png");	//6
	intro_scene.AddImage("data/textlogo/text3.png");	//7
	intro_scene.AddImage("data/textlogo/text4.png");	//8
	intro_scene.AddImage("data/textlogo/noend.png");	//9
	intro_scene.AddImage("data/am/cubemask.png");	//10
	intro_scene.AddBuffer(pwidth, pheight, 0);	//11
	intro_scene.AddImage("data/am/exypn.png"); //12
	intro_scene.AddBuffer(pwidth, pheight, 0);	//13
	intro_scene.SetMaskMode(13, MASK_ALPHACHANNEL);
	intro_scene.AddImage("data/textures/darkorange.png");//14
	intro_scene.AddImage("data/sprites/hexagon2.png");//15

/*	intro_scene.AddImage("data/lensflares/flare1.png");		//14
	intro_scene.AddImage("data/lensflares/flare2.png");
	intro_scene.AddImage("data/lensflares/flare3.png");
	intro_scene.AddImage("data/lensflares/flare4.png");
	intro_scene.AddImage("data/lensflares/flare5.png");		//18
	intro_scene.SetMaskMode(14, MASK_TRANSPARENCY_ADD);
	intro_scene.SetMaskMode(15, MASK_TRANSPARENCY_ADD);
	intro_scene.SetMaskMode(16, MASK_TRANSPARENCY_ADD);
	intro_scene.SetMaskMode(17, MASK_TRANSPARENCY_ADD);
	intro_scene.SetMaskMode(18, MASK_TRANSPARENCY_ADD);
*/
	Layer voxelscene;
	voxelscene.Init(pwidth, pheight, 0);

//	voxelscene.AddImage("data/voxelscene/texmapdes2.png");
//	voxelscene.AddImage("data/voxelscene/sand2.png");
//	voxelscene.AddImage("data/voxelscene/sandh2.png");

//	voxelscene.AddImage("data/voxelscene/rocks.png");
//	voxelscene.AddImage("data/voxelscene/rocksh.png");

//	voxelscene.AddImage("data/voxelscene/texmapdes.png");
//	voxelscene.AddImage("data/voxelscene/texmapdes2.png");
//	voxelscene.AddImage("data/voxelscene/desert3.png");

//	voxelscene.AddImage("data/voxelscene/desert2.png");
//	voxelscene.AddImage("data/voxelscene/deserth2.png");
//	voxelscene.AddImage("data/voxelscene/sandh2.png");

//	voxelscene.AddImage("data/voxelscene/tex1.png");
//	voxelscene.AddImage("data/voxelscene/dune.png");
//	voxelscene.AddImage("data/voxelscene/duneh.png");

//	voxelscene.AddImage("data/voxelscene/dunedark.png");
//	voxelscene.AddImage("data/voxelscene/land.png");
//	voxelscene.AddImage("data/voxelscene/dunedarkh.png");

//	voxelscene.AddImage("data/voxelscene/tex1.png");		//0
//	voxelscene.AddImage("data/voxelscene/heimapsum.png");	//1

//	voxelscene.AddImage("data/voxelscene/hmap.png");	//1
//	voxelscene.AddImage("data/voxelscene/height.png");	//1
//	voxelscene.AddImage("data/voxelscene/tex29.png");	//1



//	voxelscene.AddImage("data/voxelscene/desert3b.png");
//	voxelscene.AddImage("data/voxelscene/voxtex.png");
	voxelscene.AddImage("data/voxelscene/dune.png");//0
//	voxelscene.AddImage("data/voxelscene/sandh2.png");
	voxelscene.AddImage("data/voxelscene/duneh.png");//1
//	voxelscene.AddImage("data/voxelscene/voxtex3.png");
//	voxelscene.AddImage("data/voxelscene/voxheight.png");

	voxelscene.AddImage("data/lensflares/flare1.png");		//2
	voxelscene.AddImage("data/lensflares/flare2.png");
	voxelscene.AddImage("data/lensflares/flare3.png");
	voxelscene.AddImage("data/lensflares/flare4.png");
	voxelscene.AddImage("data/lensflares/flare5.png");		//6
	voxelscene.SetMaskMode(2, MASK_TRANSPARENCY_ADD);
	voxelscene.SetMaskMode(3, MASK_TRANSPARENCY_ADD);
	voxelscene.SetMaskMode(4, MASK_TRANSPARENCY_ADD);
	voxelscene.SetMaskMode(5, MASK_TRANSPARENCY_ADD);
	voxelscene.SetMaskMode(6, MASK_TRANSPARENCY_ADD);

	voxelscene.AddBuffer(pwidth,pheight,0);//7
	voxelscene.AddBuffer(256,256,0);//8
	voxelscene.AddImage("data/voxelscene/orkenback.png"); //9
//	voxelscene.AddImage("data/am/cubemask.png");	//10

	voxelscene.AddImage("data/sprites/light.png"); //10
	voxelscene.SetMaskMode(10, MASK_TRANSPARENCY_ADD);

	voxelscene.AddBuffer(pwidth,pheight,0);//11
	voxelscene.AddBuffer(pwidth,pheight,0);//12

	Layer cubetwister;
	cubetwister.Init(pwidth, pheight, 0);
	cubetwister.AddImage("data/am/randombg2.png");//0
//	cubetwister.AddImage("data/textures/crabs.png");//1
	cubetwister.AddImage("data/soft/gr.png");//1
	cubetwister.AddBuffer(320,200,0);//2
	cubetwister.AddBuffer(320,200,0);//3
	cubetwister.AddImage("data/textures/noise.png");//4
//	cubetwister.AddImage("data/soft/nl.png");//5
//	cubetwister.AddImage("data/soft/nl2.png");//5
//	cubetwister.AddImage("data/soft/gr.png");//5
//	cubetwister.AddImage("data/soft/gr3.png");//5
	cubetwister.AddImage("data/soft/gr4.png");//5
	cubetwister.AddBuffer(320,200,0);//6
	cubetwister.SetMaskMode(6, MASK_NONZERO);
	cubetwister.AddBuffer(320,200,0);//7
	cubetwister.SetMaskMode(7, MASK_NONZERO);

	Layer tableeffect;
	tableeffect.Init(pwidth, pheight, 0);
	tableeffect.AddBuffer(320,200,0);
	tableeffect.AddBuffer(320,200,0);
	tableeffect.AddBuffer(320,200,0);
	tableeffect.AddBuffer(320,200,0); //3
	tableeffect.AddImage("data/sprites/light.png"); //4
//	tableeffect.AddImage("data/sprites/light2.png"); //4
	tableeffect.SetMaskMode(4, MASK_TRANSPARENCY_ADD); 
	tableeffect.AddBuffer(320,200,0); //5
	tableeffect.AddImage("data/am/beam1.png");//6

	Layer planecrazy;
	planecrazy.Init(pwidth, pheight, 0);
	planecrazy.AddBuffer(320,200,0);//0
	planecrazy.AddBuffer(320,200,0);//1
	planecrazy.AddImage("data/textures/marble3.png");//2
	planecrazy.AddBuffer(320,200,0);//3
	planecrazy.AddBuffer(320,200,0);//4
	planecrazy.AddPalette(2, 0, 256, 0x000000, 0xffffff);
	planecrazy.AddImage("data/textures/watertex.png");//5


	Layer layer_fonts;
	layer_fonts.Init(pwidth, pheight, 0);
	layer_fonts.AddImage("data/fonts/agency_fb_23/0.png"); //0
	layer_fonts.AddImage("data/fonts/agency_fb_23/61.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/62.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/63.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/64.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/65.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/66.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/67.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/68.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/69.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/6a.png");//10
	layer_fonts.AddImage("data/fonts/agency_fb_23/6b.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/6c.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/6d.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/6e.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/6f.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/70.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/71.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/72.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/73.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/74.png");//20
	layer_fonts.AddImage("data/fonts/agency_fb_23/75.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/76.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/77.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/78.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/79.png");
	layer_fonts.AddImage("data/fonts/agency_fb_23/7a.png");//26
	layer_fonts.InitLeading();
	layer_fonts.AddString("",30, 40); //0
	layer_fonts.AddString("greetings goes to",30, 40); //1
	layer_fonts.AddString("cncd",160, 100); //2
	layer_fonts.AddString("ephidrena",160, 100); //3
	layer_fonts.AddString("fairlight",160, 100); //4
	layer_fonts.AddString("gin",160, 100); //5
	layer_fonts.AddString("haujobb",160, 100); //6
	layer_fonts.AddString("inf",160, 100); //7
	layer_fonts.AddString("keyboarders",160, 100); //8
	layer_fonts.AddString("komplex",160, 100); //9
	layer_fonts.AddString("kvasigen",160, 100); //10
	layer_fonts.AddString("moojuice",160, 100); //11
	layer_fonts.AddString("nocturnal",160, 100); //12
	layer_fonts.AddString("odd",160, 100); //13
	layer_fonts.AddString("outracks",160, 100); //14
	layer_fonts.AddString("portal process",160, 100); //15
	layer_fonts.AddString("progress",160, 100); //16
	layer_fonts.AddString("and all the rest",160, 100); //17
	layer_fonts.AddString("",160, 100); //18
	layer_fonts.AddString("",160, 100); //19
/*	layer_fonts.AddString("floating",160, 100); //20
	layer_fonts.AddString("through",160, 100); //21
	layer_fonts.AddString("garden of",160, 100); //22
	layer_fonts.AddString("robotics",160, 100); //23
*/

	Layer waterscene;
	waterscene.Init(pwidth, pheight, 0);
	waterscene.AddBuffer(320,200,0);//0 - waterbuffer
	waterscene.AddBuffer(320,200,0);//1 - waterbuffer
	waterscene.AddImage("data/images/envbackh2.png"); //2 - background image
	waterscene.AddImage("data/textures/front.png");//3 - environment texture
	waterscene.AddImage("data/sprites/light.png");//4
	waterscene.SetMaskMode(4, MASK_TRANSPARENCY_ADD);
	waterscene.AddImage("data/sprites/light2.png");//5
	waterscene.SetMaskMode(5, MASK_TRANSPARENCY_ADD);
	waterscene.AddBuffer(320,200,0);//6
	waterscene.AddBuffer(320,200,0);//7
	waterscene.AddImage("data/text/creds1.png");//8
	waterscene.AddImage("data/text/creds2.png");//9
	waterscene.AddImage("data/text/creds3.png");//10
	waterscene.AddImage("data/text/creds4.png");//11
/*	waterscene.SetMaskMode(8, MASK_ALPHACHANNEL);
	waterscene.SetMaskMode(9, MASK_ALPHACHANNEL);
	waterscene.SetMaskMode(10, MASK_ALPHACHANNEL);
	waterscene.SetMaskMode(11, MASK_ALPHACHANNEL);*/
	waterscene.AddBuffer(320,200,0);//12

/*	waterscene.AddBuffer(320,200,0);//4 - transitionbuffer
	waterscene.AddImage("cloud.png"); //5
	waterscene.AddImage("stop.png"); //6
	waterscene.AddBuffer(320,200,0);//7
	waterscene.AddImage("dykker.png"); //8
	waterscene.setMaskBuffer(8, MASK_ALPHACHANNEL);
*/

	Layer lightfxlayer;
	lightfxlayer.Init(pwidth, pheight, 0);
	lightfxlayer.AddBuffer(320,200,0);//
	lightfxlayer.AddBuffer(320,200,0);//
	lightfxlayer.AddBuffer(320,200,0);//
	lightfxlayer.AddBuffer(320,200,0);//
	lightfxlayer.AddBuffer(320,200,0);//
	lightfxlayer.AddImage("data/sprites/light.png");	//5
	lightfxlayer.SetMaskMode(5, MASK_TRANSPARENCY_ADD);
//	lightfxlayer.AddImage("data/textures/watertex.png");//6
//	lightfxlayer.AddImage("data/textures/darkorange.png");
//	lightfxlayer.AddImage("data/soft/gr.png");//
//	lightfxlayer.AddImage("data/soft/nl.png");//
	lightfxlayer.AddImage("data/soft/gr3.png");//6
	lightfxlayer.AddImage("data/images/envbackh2.png"); //7
	lightfxlayer.AddImage("data/textures/tower.png"); //8
	lightfxlayer.AddImage("data/am/roboeyeoverload.png"); //9

/*	Layer lensflares;
	lensflares.Init(pwidth, pheight, 0);
	lensflares.AddImage("data/lensflares/flare1.png");
	lensflares.AddImage("data/lensflares/flare2.png");
	lensflares.AddImage("data/lensflares/flare3.png");
	lensflares.AddImage("data/lensflares/flare4.png");
	lensflares.AddImage("data/lensflares/flare5.png");
*/

//	Layer avilayer;
//	avilayer.Init(pwidth, pheight,0);
//	avilayer.makeAVIbuffer("data/avi/walking3.avi");

//	primarylayer.InitFonts(" !\"#$\%.�()*+'-./0123456789:;<=>?$ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",0x5f7f80, MASK_DEFAULT);
	primarylayer.Init(pwidth, pheight, 0);
	primarylayer.AddBuffer(320,200,0); //0
	primarylayer.AddBuffer(320,200,0); //1
	primarylayer.AddImage("data/textures/front.png"); //2
	primarylayer.AddImage("data/am/randombluecrap.png");	//3
//	primarylayer.AddImage("data/am/speedpainting2.png"); //2
	primarylayer.AddImage("data/am/surferrobo.png");	//4
	primarylayer.AddImage("data/am/surferrobo2.png");	//5
	primarylayer.AddImage("data/am/surferrobo3.png");	//6
	primarylayer.AddImage("data/am/surferrobo4.png");	//7
	primarylayer.AddImage("data/textures/noise.png");	//8
/*
	primarylayer.AddImage("data/masks/chars02.png");	//9
	primarylayer.AddImage("data/masks/chars03.png");	//10
	primarylayer.AddImage("data/masks/chars04.png");	//11
	primarylayer.AddImage("data/masks/chars05.png");	//12
	primarylayer.AddImage("data/masks/chars06.png");	//13

	primarylayer.AddImage("data/text/fonts.png");	//14
*/
	#define num_pois 45
	Coord2Df poi[num_pois];
	Quad2D p[num_pois];
/*
	Coord2Df *poi=(Coord2Df*)malloc(sizeof(Coord2Df)*80*25);
	int num_p=500;
	Quad2D p[500];*/
/*	for (int i=0; i<80*24; i++)
	{
		p[i].p[0].x=rand()%320;
		p[i].p[0].y=rand()%200;
		p[i].p[1].x=rand()%320;
		p[i].p[1].y=rand()%200;
		p[i].p[2].x=rand()%320;
		p[i].p[2].y=rand()%200;
		p[i].p[3].x=rand()%320;
		p[i].p[3].y=rand()%200;
	}*/

#ifdef _3DENGINE_
/*
	int width_=640;
//	int height_=180;
	int height_=360;
//	int height_=480;
*/
	int width_=320;
	int height_=200;

/*
	obj_checkerboard.SetClipArea(1, 1, width_-1, height_-1);
	obj_checkerboard.flag_uv_texture=true;
	obj_checkerboard.flag_vertex_and_face_normals=true;
	obj_checkerboard.ParseASE("checkerboard.ASE"); //glitter
//	obj_checkerboard.ParseASE("grid2.ASE"); //glitter
	obj_checkerboard.SetZSCALE(60);
	obj_checkerboard.znear=-50;
	obj_checkerboard.perspective_correct=true;

	obj_bounce.SetClipArea(1, 1, width_-1, height_-1);
	obj_bounce.flag_uv_texture=true;
	obj_bounce.flag_vertex_and_face_normals=true;
//	obj_bounce.ParseASE("bounce.ASE");
	obj_bounce.ParseASE("bounce2.ASE");
//	obj_bounce.ParseASE("spring2.ASE");
	obj_bounce.SetZSCALE(60);
	obj_bounce.znear=-50;
	obj_bounce.perspective_correct=true;



	obj_teapot.flag_uv_texture=true;
	obj_teapot.flag_vertex_and_face_normals=true;
	obj_teapot.SetClipArea(1, 1, width_-1, height_-1);
	obj_teapot.ParseASE("teap.ASE");
//	obj_teapot.ParseASE("duck.ASE");
//	obj_teapot.ParseASE("conetest.ASE");
	obj_teapot.SetZSCALE(60);
	obj_teapot.znear=-50;
	obj_teapot.perspective_correct=true;
*/
	obj_torus.SetClipArea(1, 1, width_-1, height_-1);
	obj_torus.flag_uv_texture=true;
	obj_torus.flag_vertex_and_face_normals=true;

	obj_torus.parsemode=1; //old
	obj_torus.ParseASE("data/3dobjects/torus.ASE"); //glitter
	obj_torus.SetZSCALE(60);
	obj_torus.znear=-50;
	obj_torus.perspective_correct=false;
	obj_torus.culling=-1;




	obj_cubes[0].SetClipArea(1, 1, width_-1, height_-1);
//	obj_cubes[0].flag_uv_texture=true;
//	obj_cubes[0].flag_vertex_and_face_normals=true;
//	obj_cubes[0].ParseASE("data/3dobjects/cubes3.ASE");
//	obj_cubes[0].ParseASE("data/3dobjects/cubes-.ASE");
//	obj_cubes[0].ParseASE("data/3dobjects/cubehole.ASE");
//	obj_cubes[0].ParseASE("data/3dobjects/2cubes.ASE");

	obj_cubes[0].flag_uv_texture=false;
	obj_cubes[0].flag_vertex_and_face_normals=false;
	obj_cubes[0].ParseASE("data/3dobjects/cubesmess2.ASE");
	obj_cubes[0].parsemode=0;
	obj_cubes[0].SetZSCALE(60);
	obj_cubes[0].znear=-50;
	obj_cubes[0].perspective_correct=true;

	obj_cubes[1].SetClipArea(1, 1, width_-1, height_-1);
	obj_cubes[1].flag_uv_texture=false;
	obj_cubes[1].flag_vertex_and_face_normals=false;
	obj_cubes[1].ParseASE("data/3dobjects/cubehole.ASE");
	obj_cubes[1].parsemode=0;
	obj_cubes[1].SetZSCALE(60);
	obj_cubes[1].znear=-50;
	obj_cubes[1].perspective_correct=true;

	obj_cubes[2].SetClipArea(1, 1, width_-1, height_-1);
	obj_cubes[2].flag_uv_texture=false;
	obj_cubes[2].flag_vertex_and_face_normals=false;
	obj_cubes[2].ParseASE("data/3dobjects/cubes-.ASE");
	obj_cubes[2].parsemode=0;
	obj_cubes[2].SetZSCALE(60);
	obj_cubes[2].znear=-50;
	obj_cubes[2].perspective_correct=true;

	
	obj_excess.SetClipArea(1, 1, width_-1, height_-1);
//	obj_excess.transmode=1;
	obj_excess.flag_uv_texture=false;
	obj_excess.flag_vertex_and_face_normals=false;
	obj_excess.ParseASE("data/3dobjects/excess.ASE");
//	obj_excess.ParseASE("data/3dobjects/yaphan.ASE");
//	obj_excess.ParseASE("data/3dobjects/yaphan2.ASE");
	obj_excess.parsemode=0;
	obj_excess.SetZSCALE(60);
	obj_excess.znear=-50;
	obj_excess.perspective_correct=true;

	obj_yaphan.SetClipArea(1, 1, width_-1, height_-1);
	obj_yaphan.flag_uv_texture=false;
	obj_yaphan.flag_vertex_and_face_normals=false;
	obj_yaphan.ParseASE("data/3dobjects/yaphan2.ASE");
	obj_yaphan.parsemode=0;
	obj_yaphan.SetZSCALE(60);
	obj_yaphan.znear=-50;
	obj_yaphan.perspective_correct=true;

	obj_robothand.SetClipArea(1, 1, width_-1, height_-1);
	obj_robothand.parsemode=1;
	obj_robothand.ParseASE("data/3dobjects/robothand4.ASE");
	obj_robothand.SetZSCALE(60);
	obj_robothand.znear=-50;
	obj_robothand.perspective_correct=true;

	obj_robothandgrid.SetClipArea(1, 1, width_-1, height_-1);
	obj_robothandgrid.parsemode=1;
	obj_robothandgrid.ParseASE("data/3dobjects/robothandgrid.ASE");
	obj_robothandgrid.SetZSCALE(60);
	obj_robothandgrid.znear=-50;
	obj_robothandgrid.perspective_correct=true;

	obj_geosphere.SetClipArea(1, 1, width_-1, height_-1);
	obj_geosphere.parsemode=1;
	obj_geosphere.ParseASE("data/3dobjects/geosphere.ASE");
	obj_geosphere.SetZSCALE(60);
	obj_geosphere.znear=-50;
	obj_geosphere.perspective_correct=true;


	obj_spring.SetClipArea(1, 1, width_-1, height_-1);
	obj_spring.flag_uv_texture=true;
//	obj_spring.flag_uv_texture=false;
	obj_spring.flag_vertex_and_face_normals=true;
//	obj_spring.flag_vertex_and_face_normals=false;
	obj_spring.ParseASE("data/3dobjects/cylinder4.ase");
	obj_spring.parsemode=0;
	obj_spring.SetZSCALE(60);
	obj_spring.znear=-50;
	obj_spring.perspective_correct=false;


	obj_spike.SetClipArea(1, 1, width_-1, height_-1);
	obj_spike.flag_uv_texture=true;
	obj_spike.flag_vertex_and_face_normals=true;
//	obj_spike.transmode=1;
//	obj_spike.ParseASE("data/3dobjects/rarcube.ASE");
//	obj_spike.ParseASE("data/3dobjects/spikesq2.ASE");
//	obj_spike.ParseASE("data/3dobjects/toruses.ASE");
	obj_spike.ParseASE("data/3dobjects/sphere_spike_faces4.ASE");
	obj_spike.parsemode=0;
	obj_spike.SetZSCALE(60);//+30);
	obj_spike.znear=-50;
	obj_spike.perspective_correct=true;//false;

/*
	obj_cone.SetClipArea(1, 1, width_-1, height_-1);
	obj_cone.flag_uv_texture=true;
	obj_cone.flag_vertex_and_face_normals=true;
	obj_cone.ParseASE("cone.ASE");
	obj_cone.SetZSCALE(60);
	obj_cone.znear=-50;
	obj_cone.perspective_correct=true;

	obj_cone.Translationmatrix.LoadIdentity();
	obj_cone.Translationmatrix.CreateTranslationMatrix(Vector3D(0,60,-120));
	for (i=0; i<obj_cone.num_vertices; i++) obj_cone.vertices_world[i]=obj_cone.Translationmatrix.ApplyMatrix(obj_cone.vertices_real[i]);

	checkerboard_scene.ParticleLoadFromObject(obj_cone);*/




/*
	scene.LogFile("duck.txt", true);
//	scene.Parse3DS("duck.3ds");
	scene.Parse3DS("statues.3ds");
//	scene.Parse3DS("box.3ds");
//	scene.Parse3DS("teapot.3ds");
*/
	
	
	
/*
	scene.AddObject();
	scene.objects[0]->SetClipArea(1, 1, width_-1, height_-1);
	scene.objects[0]->flag_uv_texture=true;
	scene.objects[0]->flag_vertex_and_face_normals=true;
	scene.LoadASE("bounce2.ASE");
//	obj_bounce.ParseASE("bounce2.ASE");
	scene.objects[0]->SetZSCALE(60);
	scene.objects[0]->znear=-50;
	scene.objects[0]->perspective_correct=true;
*/


	//
	//octopus (real hackish octopus, no need for normals on this one)
	//
	Object obj_octopus;
	obj_octopus.SetClipArea(1, 1, width_-1, height_-1);
	obj_octopus.flag_uv_texture=true;
	obj_octopus.flag_vertex_and_face_normals=true;
	obj_octopus.parsemode=1; //old
	obj_octopus.ParseASE("data/3dobjects/octopus_5.ASE");
	obj_octopus.SetZSCALE(60);
	obj_octopus.znear=-50;
	obj_octopus.perspective_correct=false;

	Layer transitionlayer;
	transitionlayer.Init(pwidth, pheight, 0);
	transitionlayer.AddBuffer(320,200,0);

	Layer octopusscene;
	octopusscene.Init(pwidth, pheight, 0);
	octopusscene.AddBuffer(320,200,0);//0
//	octopusscene.AddImage("sen4.png");//1
//	octopusscene.AddImage("asteroid_texture.png");//2
//	octopusscene.AddImage("ctex3.png");//3
//	octopusscene.AddImage("ctex2.png");//4
//	octopusscene.AddImage("disp_map.png");//5
//	octopusscene.AddImage("psy.png");//6
	octopusscene.AddImage("data/textures/crabs.png");//7 = 1
//	octopusscene.AddImage("data/envmap/grace.png");//8
//	octopusscene.AddImage("envback.png");//9
	octopusscene.AddImage("data/textures/widepic3.png");//10 = 2
//	octopusscene.AddImage("mask.png");//11
//	octopusscene.AddImage("mask2.png");//12
//	octopusscene.AddImage("mask3.png");//13
//	octopusscene.AddImage("mask4.png");//14
	octopusscene.AddImage("data/textures/noise.png");//15 = 3
	octopusscene.AddBuffer(320,200,0);//16 = 4
//	octopusscene.AddImage("trans1.png");//17
//	octopusscene.AddImage("blackmen.png");//18
//	octopusscene.AddBuffer(320,200,0);//19
//	octopusscene.AddImage("ladder.png");//20
	/*
	octopusscene.AddImage("data/images/octogray.png");//5
	octopusscene.AddImage("data/sprites/particle32.png"); //6
//	octopusscene.AddImage("data/sprites/light.png"); //6
	octopusscene.SetMaskMode(6, MASK_TRANSPARENCY_ADD); 
*/
/*	while(1){
		ptc_update(screenlayer.mainbuffer.pixel);
	};*/

//	scene.Parse3DS("duck.3ds");
//	scene.Debunk("demoengine.txt");

#endif

	Vector3D floor(0,-20,-120);
	Vector3D pos(0,50,-120);
	Vector3D vel(0,0,0);
	Vector3D acc(0,-0.1,0);

	//
	//VOXEL DEFINES
	//
	float rpx,rpy,rtx,rty,itx,ity;
	Vector3D snowflakes[64];
	for (i=0; i<64; i++)
	{
		snowflakes[i].x=rand()%(320);
		snowflakes[i].y=-32+rand()%(200+32);
		snowflakes[i].z=rand()%32;
	}
	int flare_x,flare_x2,flare_y,flare_y2,flare_alpha=0;

	Camera3D cam,ray;
//	ray.pos.x=77;
//	ray.pos.y=127;
	ray.pos.x=17;
	ray.pos.y=11;
	ray.tar.x=77;
	ray.tar.y=127;
/*
	ray.pos.x=135;
	ray.pos.y=185;
	ray.tar.x=135;
	ray.tar.y=175;
*/
	rpx=ray.pos.x;
	rpy=ray.pos.y;
	rtx=ray.tar.x;
	rty=ray.tar.y;
	//
	//
	//

#ifdef _BASS_LIB_
	//mainloop=music.flag_end;
	music.Play();
#endif

	spool=0;
	DWORD spool_seconds=0;
	int step_seconds=4;

//	BASS_ChannelSetPosition(music.str,(QWORD)MAKELONG(0,spool_seconds));

	timer_reset();

	while (1)
	{
//		timer_update();

		g_clearz(WIDTH*HEIGHT);

//
//SPOLING!!!
//
//	#ifdef _BASS_LIB_
//		mainloop=music.flag_end;

#ifdef _BASS_LIB_
		DWORD time;
		unsigned long ha=music.str?music.str:music.mod;


		time=BASS_ChannelGetPosition(ha);
		if (spool==1)
		{
//			time=BASS_ChannelGetPosition(ha)+
			time=BASS_ChannelSeconds2Bytes(ha, ftime+spool_tick);
//			if (spool_tick==1)
//				BASS_ChannelSetPosition(music.str?music.str:music.mod,time+((spool_tick*step_seconds)<<16));
			BASS_ChannelSetPosition(ha,time);
//
//			if (spool_tick==-1)
//				BASS_ChannelSetPosition(music.str?music.str:music.mod,time+((spool_tick*step_seconds)<<16));
//				BASS_ChannelSetPosition(music.str?music.str:music.mod,time+((spool_tick*step_seconds)<<16));
//			spool_tick*
//			time=
			spool=0;
		}
		ftime=BASS_ChannelBytes2Seconds(ha,time);
//		ftime=(float)(((signed __int64)time)*0.00000565); //what the fu? bytes2sec and sec2bytes is here aight!!!!
	#else
		timer_update();
//		ftime=ftime+spool_tick2*step_seconds;
	#endif
//
//
//

		int cell_border=8;
	//
	//CHECKERBOARD SCENE
	//


//		Vector3D world_rot(0,ftime*0.25,0);
//		Vector3D world_rot(ftime*0.25,0,0);
//		Vector3D world_rot(0,0,ftime*0.25);



/*
		scene.objects[0]->SetZSCALE(120);
		scene.objects[0]->Rotate(world_rot);
		*/
/*
		float energy=0.86;
		static int flag=0;
		if (flag==0) if (itime % 2==0) flag=1;
		if (flag==1) if (itime % 2==1)
		{
			if (pos.y<floor.y) vel.y=-vel.y*energy;
			pos.y=pos.y+vel.y;
			vel.y=vel.y+acc.y;
			flag=0;
		}*/
/*		pos.Set(0,0,-60);

		//
		//
		//
		scene.objects[0]->Translate(pos);
		scene.objects[0]->znear=-20;
		scene.objects[0]->SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
		scene.objects[0]->rendermode=3; //tex
		scene.objects[0]->envmap=false; //envmap
		scene.objects[0]->Show(checkerboard_scene, SCREENBUFFER, 2, 0, 0);
*/

/*
*CAMERAOBJECT {
	*NODE_NAME "Camera01"
	*CAMERA_TYPE Target
	*NODE_TM {
		*NODE_NAME "Camera01"
		*INHERIT_POS 0 0 0
		*INHERIT_ROT 0 0 0
		*INHERIT_SCL 1 1 1
		*TM_ROW0 0.7147	0.6994	0.0000
		*TM_ROW1 -0.1432	0.1463	0.9788
		*TM_ROW2 0.6846	-0.6996	0.2047
		*TM_ROW3 104.2337	-114.5594	45.7313
		*TM_POS 104.2337	-114.5594	45.7313
		*TM_ROTAXIS -0.8397	-0.3425	-0.4215
		*TM_ROTANGLE 1.5379
	}
	*NODE_TM {
		*NODE_NAME "Camera01.Target"
		*INHERIT_POS 0 0 0
		*INHERIT_ROT 0 0 0
		*INHERIT_SCL 0 0 0
		*TM_ROW0 -0.0000	-1.0000	-0.0000
		*TM_ROW1 -0.0000	-0.0000	1.0000
		*TM_ROW2 -1.0000	0.0000	-0.0000
		*TM_ROW3 -0.0000	-8.0460	14.5594
		*TM_POS -0.0000	-8.0460	14.5594
		*TM_ROTAXIS 0.5774	-0.5774	-0.5774
		*TM_ROTANGLE 4.1888
	}
	*CAMERA_SETTINGS {
		*TIMEVALUE 0
		*CAMERA_NEAR 0.0000
		*CAMERA_FAR 1000.0000
		*CAMERA_FOV 0.7854
		*CAMERA_TDIST 152.2546
	}
*/


//		obj_teapot.Rotate(Vector3D(world_rot));
//		obj_teapot.Translate(Vector3D(0,0,-420));

//		obj_teapot.mLoadIdentity();
//		obj_teapot.mTranslate(Vector3D(0,0,-60+sin(ftime)*60));
//		obj_teapot.mRotate(Vector3D(0,ftime,0));
//		obj_teapot.mTranslate(Vector3D(0,0,-420));
/*
		obj_teapot.mCameraLookAt(
			Vector3D(104.2337, -114.5594, 45.7313),
			Vector3D(-0.0000, -8.0460, 14.5594),
//			Vector3D(0, 1, 0));
			Vector3D(0, 0, 1));
//			Vector3D(0, -1, 0));
//			Vector3D(0, 0, -1));

		obj_teapot.mTranslate(Vector3D(0,0,420));


		obj_teapot.SetZSCALE(45); //FOV=45

		obj_teapot.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
		obj_teapot.color_dot_fixed=0xffffff;
		obj_teapot.znear=-20;
		obj_teapot.rendermode=2; //tex
		obj_teapot.envmap=false; //envmap
		obj_teapot.culling=-1;
		obj_teapot.Show(checkerboard_scene, SCREENBUFFER, 2, 0, 0);
*/
/*
		obj_checkerboard.SetZSCALE(120);
///		obj_checkerboard.Rotate(Vector3D(0,ftime,0));
//		obj_checkerboard.Rotate(Vector3D(-0.3+sin(ftime)*M_PI2*0.15,0,0));
//		obj_checkerboard.Rotate(Vector3D(-0.3+sin(ftime)*M_PI2*0.15,0,0));
//		obj_checkerboard.Rotate(Vector3D(-0.3,0,0));
		obj_checkerboard.Rotate(Vector3D(world_rot));

//		obj_checkerboard.Translate(Vector3D(0,0,-70-ftime*20));
//		obj_checkerboard.Translate(Vector3D(0,-20,-120));
		obj_checkerboard.Translate(Vector3D(0,-40,-120));

		obj_checkerboard.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
		obj_checkerboard.color_dot_fixed=0xffffff;
		obj_checkerboard.znear=-20;
//		obj_checkerboard.rendermode=1;
//		obj_checkerboard.rendermode=2;
		obj_checkerboard.rendermode=3; //tex
		obj_checkerboard.envmap=false; //envmap
//		obj_checkerboard.envmap=true; //envmap
		obj_checkerboard.Show(checkerboard_scene, SCREENBUFFER, 1, 0, 0);


//	if (fmod(ftime,14)>=7)
	{
		obj_bounce.SetZSCALE(120);
		obj_bounce.Rotate(world_rot);
//		obj_bounce.Rotate(Vector3D(ftime,ftime,ftime));
//		obj_bounce.Translate(Vector3D(0,0,-120));
//		obj_bounce.Translate(Vector3D(0,20+sin(ftime)*30,-120));
		//
		//
		//
		float energy=0.86;

		static int flag=0;
		if (flag==0) if (itime % 2==0) flag=1;
		if (flag==1) if (itime % 2==1)
		{
			if (pos.y<floor.y) vel.y=-vel.y*energy;
			pos.y=pos.y+vel.y;
			vel.y=vel.y+acc.y;
			flag=0;
		}

		//
		//
		//
		obj_bounce.Translate(pos);
		obj_bounce.znear=-20;

		obj_bounce.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
//		obj_bounce.rendermode=1;
//		obj_bounce.rendermode=2;
		obj_bounce.rendermode=3; //tex
		obj_bounce.envmap=false; //envmap
//		obj_bounce.envmap=true; //envmap
		obj_bounce.Show(checkerboard_scene, SCREENBUFFER, 2, 0, 0);

		checkerboard_scene.ParticleSetGravity(0, Vector3D(0,0,0), Vector3D(0,-0.4,0), 0.7);//0.7);
//		checkerboard_scene.ParticleGenerateRandom(1500, Vector3D(0,0,-64), Vector3D(48, 45, 25));

		for (i=0; i<checkerboard_scene.particleset[0]->num_particles; i++)
		{
			Vector3D pos(0,0,0);
			Vector3D volume(100,100,100);
			float fx=pos.x-(volume.x*0.5)+rand()%(int)(volume.x);
			float fy=pos.y-(volume.y*0.5)+rand()%(int)(volume.y);
			float fz=pos.z-(volume.z*0.5)+rand()%(int)(volume.z);

			checkerboard_scene.particleset[0]->particles_real[i]->pos.x=fx;
			checkerboard_scene.particleset[0]->particles_real[i]->pos.y=fy;
			checkerboard_scene.particleset[0]->particles_real[i]->pos.z=fz;
		}
		flag=1;
	}
	else*/
/*	{
		static int flag=1;
		if (flag)
		{
			for (i=0; i<checkerboard_scene.particleset[0]->num_particles; i++)
				checkerboard_scene.particleset[0]->particles_physics[i]=checkerboard_scene.particleset[0]->particles_real[i];
			flag=0;
		}

	
		checkerboard_scene.ParticlePhysicsGravityFall(0);

		CMatrix matrix,matrix_rot;
		matrix_rot.LoadIdentity();
//		matrix_rot.CreateRotationMatrix(Vector3D(0,ftime,0));
		matrix_rot.CreateTranslationMatrix(Vector3D(0,0,-120));

		matrix.LoadIdentity();
		matrix.CreateRotationMatrix(world_rot);
//		matrix.CreateTranslationMatrix(Vector3D(0,0,-120));
		matrix.MultiplyMatrix(matrix_rot);

		for (i=0; i<checkerboard_scene.particleset[0]->num_particles; i++)
			checkerboard_scene.particleset[0]->particles_transform[i]->pos=matrix.ApplyMatrix(checkerboard_scene.particleset[0]->particles_physics[i]->pos);

//		for (i=0; i<checkerboard_scene.particleset[0]->num_particles; i++) checkerboard_scene.particleset[0]->particles_transform[i]=checkerboard_scene.particleset[0]->particles_physics[i];

		checkerboard_scene.ParticleShow3D(SCREENBUFFER, 0, 0, 120, 160, 100);
	}*/


//-----------------------------------------------------------------------------------------------
//ROTATE CUBES
//-----------------------------------------------------------------------------------------------

//	if (ftime<82.1)
	if (ftime<32.5)
	{
//		intro_scene.ClearBuffer(SCREENBUFFER, 0);
/*		intro_scene.ClearBuffer(SCREENBUFFER,
			RGB32(
			0,
			52+(int)(cos(ftime*0.4)*42),
			54+(int)(sin(ftime*0.3)*40)));*/
//		intro_scene.ClearBuffer(SCREENBUFFER, 0x294429);
		intro_scene.ClearBuffer(SCREENBUFFER, 0x292944);

		obj_cubes[0].mLoadIdentity();
//		obj_cubes[0].mTranslate(Vector3D(0,0,-60+sin(i*0.01)*60));

		static int flat_flag=0,flat_color=0;

		flat_flag=R3D_FLAT_SHADE;
		flat_color=0xffffff;
//		flat_color=0xff7f7f;

		static int flag_tick=1, flag_tick2=0;
/*		for (i=0; i<16; i++)
		{
			if (ftime>=synch_1[i*2] && ftime<(synch_1[i*2+1]))
			{
				flat_flag=R3D_FLAT_SHADE;
//				flat_color=0xff5f5f;
				flat_color=0xffffff;
			}
//			if (ftime>=synch_1[i] && ftime<(synch_1[i]+0.25))
			if (ftime>=synch_1[i*2+1] && ftime<(synch_1[i*2+2]))
			{
//				flat_flag=R3D_FLAT_FIXED;
//				flat_color=0x294429;
				flat_flag=R3D_FLAT_SHADE;
//				flat_color=0xff7f7f;
				flat_color=0xff5f5f;
			}
		}*/
		for (i=0; i<32; i++)
			if (ftime>=synch_1[i] && ftime<(synch_1[i]+0.25))
			{
//				flat_flag=R3D_FLAT_FIXED;
//				flat_color=0x294429;
				flat_flag=R3D_FLAT_SHADE;
//				flat_color=0xff7f7f;
				flat_color=0xff5f5f;
			}


		float ffx=sin(0.2+ftime*0.02)*cos(-ftime*0.03)*M_PI;
		float ffy=sin(0.4+ftime*0.01)*cos(ftime*0.02)*M_PI;
		float ffz=sin(0.3-ftime*0.03)*cos(-ftime*0.01)*M_PI;
		obj_cubes[0].mRotate(Vector3D(ffx,0,0)); //x
		obj_cubes[0].mRotate(Vector3D(0,ffy,0)); //y
		obj_cubes[0].mRotate(Vector3D(0,0,ffz)); //z
		obj_cubes[0].mRotate(Vector3D(ftime*0.2,0,0)); //x
		obj_cubes[0].mRotate(Vector3D(0,ftime*0.2,0)); //y
		obj_cubes[0].mRotate(Vector3D(0,0,ftime*0.2)); //z
//		obj_cubes[0].mRotate(Vector3D(ftime,ftime,ftime));

		obj_cubes[0].SetZSCALE(90); //FOV=45
//		obj_cubes[0].mTranslate(Vector3D(0,0,-200+sin(ftime*10)*50));
//		obj_cubes[0].mTranslate(Vector3D(0,0,-200));
		obj_cubes[0].mTranslate(Vector3D(0,0,-400));


//		obj_cubes[0].culling=-1;
		obj_cubes[0].rendermode=RENDERMODE_FLAT;
		obj_cubes[0].envmap=false;
		obj_cubes[0].znear=-10;
//		obj_cubes[0].znear=-20;

//		obj_cubes[0].SetColor(R3D_FLAT_SHADE, 0);
		obj_cubes[0].SetColor(R3D_FLAT_FIXED, 0);//xffffff);
		obj_cubes[0].Show(intro_scene, SCREENBUFFER, 0, 4);

		g_clearz(WIDTH*HEIGHT);
		obj_cubes[0].mTranslate(Vector3D(0,0,-cell_border));
		obj_cubes[0].SetColor(flat_flag, flat_color);
		obj_cubes[0].Show(intro_scene, SCREENBUFFER, 0, 4);



	
/*
		//fade inn out logo
		if (ftime>=32.8 && ftime<38.5) intro_scene.BlendAdd(SCREENBUFFER, 5, (ftime-32.8)*127.5);
		if (ftime>=38.5 && ftime<40.5) intro_scene.BlendAdd(SCREENBUFFER, 5, 255-(ftime-38.5)*127.5);

		//fade inn out
		if (ftime>=41 && ftime<46.6) intro_scene.BlendAdd(SCREENBUFFER, 6, (ftime-41)*127.5);
		if (ftime>=46.6 && ftime<49.282) intro_scene.BlendAdd(SCREENBUFFER, 6, 255-(ftime-46.6)*127.5);

		//fade inn out
		if (ftime>=49.28 && ftime<56.37) intro_scene.BlendAdd(SCREENBUFFER, 7, (ftime-49.28)*127.5);
		if (ftime>=56.37 && ftime<57.9) intro_scene.BlendAdd(SCREENBUFFER, 7, 255-(ftime-56.37)*127.5);

		//fade inn out
		if (ftime>=57.9 && ftime<63.631) intro_scene.BlendAdd(SCREENBUFFER, 8, (ftime-57.9)*127.5);
		if (ftime>=63.63 && ftime<67.631) intro_scene.BlendAdd(SCREENBUFFER, 8, 255-(ftime-63.63)*127.5);
*/

	
//
//NOISE
//
/*			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
//			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
			intro_scene.CopyBufferLayer(0, primarylayer, 1);
			*/
			float sf=0.5*sin((ftime-32.5)*0.04)*0.5;
			int co=(int)((127+sin(ftime*cos(-ftime*1.5)*2.5)*127)*sf);
			intro_scene.Noise(0, RGB32(co,co,co));
			intro_scene.BlendSub(SCREENBUFFER, 0, 255);
//			intro_scene.BlendAdd(SCREENBUFFER, 0, 255);
//
//

//		intro_scene.ClearBuffer(11,0);

		if (/* (ftime<8.86) ||*/ ((ftime>=16.815) && (ftime<24.692)) )
		{
/*			//excess logo
			obj_excess.SetZSCALE(120);
//			obj_excess.Rotate(Vector3D(-M_PI2,-M_PI-ftime,0));
			obj_excess.Rotate(Vector3D(-M_PI2,-0.2-M_PI2-ftime*(M_PI/8.86),0));
//			obj_excess.Translate(Vector3D(0+rand()%20,0+rand()%20,-250));
			obj_excess.Translate(Vector3D(-5+rand()%10,-5+rand()%10,-250));
			obj_excess.rendermode=1+rand()%2;
			obj_excess.envmap=false;
			obj_excess.znear=-20;
			obj_excess.SetColor(R3D_FLAT_SHADE, 0xffffff);
//			obj_excess.Show(intro_scene, 11, 0, 4);
			obj_excess.Show(intro_scene, SCREENBUFFER, 0, 4);*/

			//yaphan logo
			obj_yaphan.SetZSCALE(90);
//			obj_yaphan.Rotate(Vector3D(-M_PI2,-M_PI-ftime,0));
			obj_yaphan.mLoadIdentity();
			obj_yaphan.mRotate(Vector3D(-M_PI2, 4.7-(ftime-16.815)*(M_PI/8.86),0));
			obj_yaphan.mTranslate(Vector3D(-M_PI2+rand()%4,-0.2-M_PI2-ftime*(M_PI/8.86)+rand()%4,-250));
//			obj_yaphan.rendermode=2;
			obj_yaphan.rendermode=rand()%2;
			obj_yaphan.envmap=false;
			obj_yaphan.znear=-20;
			obj_yaphan.SetColor(R3D_FLAT_SHADE, 0xffffff);
			obj_yaphan.Show(intro_scene, SCREENBUFFER, 0, 4);
		}

//		intro_scene.SetMaskMode(11, MASK_NONZERO);
//		intro_scene.CopyBuffer(SCREENBUFFER, 11);

		if ( /*(ftime>=8.86 && ftime<16.815) || */(ftime>=24.692) )
		{
/*			//yaphan logo
			obj_yaphan.SetZSCALE(120);
//			obj_yaphan.Rotate(Vector3D(-M_PI2,-M_PI-ftime,0));
			obj_yaphan.Rotate(Vector3D(-M_PI2,+1-ftime*(M_PI/8.86),0));
			obj_yaphan.Translate(Vector3D(-5+rand()%10,-5+rand()%10,-380));
//			obj_yaphan.rendermode=2;
			obj_yaphan.rendermode=1+rand()%2;
			obj_yaphan.envmap=false;
			obj_yaphan.znear=-20;
			obj_yaphan.SetColor(R3D_FLAT_SHADE, 0xffffff);
			obj_yaphan.Show(intro_scene, SCREENBUFFER, 0, 4);
			*/
			//excess logo
			obj_excess.SetZSCALE(90);
			obj_excess.mLoadIdentity();
//			obj_excess.Rotate(Vector3D(-M_PI2,-M_PI-ftime,0));
			obj_excess.mRotate(Vector3D(-M_PI2,-3.8 -M_PI2-ftime*(M_PI/8.86),0));
//			obj_excess.Translate(Vector3D(0+rand()%20,0+rand()%20,-250));
			obj_excess.mTranslate(Vector3D(-2+rand()%4,-5+rand()%4,-250));
//			obj_excess.Translate(Vector3D(-M_PI2,-0.2-M_PI2-ftime*(M_PI/8.86),-250));
			obj_excess.rendermode=rand()%2;
			obj_excess.envmap=false;
			obj_excess.znear=-20;
			obj_excess.SetColor(R3D_FLAT_SHADE, 0xffffff);
//			obj_excess.Show(intro_scene, 11, 0, 4);
			obj_excess.Show(intro_scene, SCREENBUFFER, 0, 4);
		}

	
		
//		intro_scene.RadialBlurSubpixel(SCREENBUFFER, 160, 100, -0.005);
		intro_scene.RadialBlur(SCREENBUFFER, 0.05);
//		intro_scene.MotionBlur(SCREENBUFFER, 0, 5);



//		if (ftime>30.2)
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;


//		primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 127+sin(ftime*0.5)*sin(ftime)*127);

//		1.139, 4.674, 8.860, 15.373, 16.815, 23.481, 24.692
		if (ftime>=0 && ftime<4.6)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 10);
//			intro_scene.FilterHexagon(SCREENBUFFER, 11, 15);

/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, ftime*55.5);
		}
		if (ftime>=4.6 && ftime<8.86)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 10);
//			intro_scene.FilterHexagon(SCREENBUFFER, 11, 15);
/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-4.6)*(255/(8.86-4.6)));
		}
		if (ftime>=8.86 && ftime<15.373)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 4);
//			intro_scene.FilterHexagon(SCREENBUFFER, 11, 15);
/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-8.86)*(255/(15.373-8.86)));
		}
		if (ftime>=15.373 && ftime<16.815)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 3);
//			intro_scene.FilterHexagon(SCREENBUFFER, 11, 15);
/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-15.373)*(255/(16.815-15.373)));
		}
		if (ftime>=16.815 && ftime<23.481)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 2);
/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-16.815)*(255/(23.481-16.815)));
		}
		if (ftime>=23.481 && ftime<24.692)
		{
			intro_scene.CopyBuffer(11, SCREENBUFFER);
			intro_scene.Mosaic(SCREENBUFFER, 11, 2);
/*			intro_scene.Mosaic(0, 11, 10);
			intro_scene.BlendAdd(SCREENBUFFER, 0);*/
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-23.481)*(255/(24.692-23.481)));
		}

		if (ftime>=24.692)// && ftime<30.2)
		{
			primarylayer.CopyBuffer(0, SCREENBUFFER);
			primarylayer.Mosaic(SCREENBUFFER, 0, 2);

			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-24.692)*(255/(30.2-24.692)));
			primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
		}

		if (ftime>=73) primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-73)*32);

//		primarylayer.BlendMask(SCREENBUFFER, 2);
//		primarylayer.MotionBlur(SCREENBUFFER, 0, 2);
	}







//-----------------------------------------------------------------------------------------------
//DESERT LAND
//-----------------------------------------------------------------------------------------------
	if (ftime>=32.5 && ftime<82.1)
	{
	//
	//voxels!!!!!!!!!
	//
	flag_bilinear=-1;
	flag_texture=-1;


//	flag_fog=1;
	flag_bilinear=1;

		int bg_color;
//		if (voxel_season==VOXEL_FOREST) bg_color=0x202070;
//		if (voxel_season==VOXEL_DESERT)
//		bg_color=0x847593;//0x706030;
//		bg_color=0xF34F03;
		bg_color=0x2B3557;
//		bg_color=0x5050a0;
//		bg_color=0xa02070;
//		bg_color=RGB32(0x20, 0x40, (int)(64+sin(ftime)*32));

		voxelscene.mainbuffer.Clear(bg_color); //background fog color
//		voxelscene.CopyBuffer(SCREENBUFFER, 9); //background image
		voxelscene.ClearBuffer(7,0);

//-bakgrunnslys-------------------------------------------------------------------------------
	if (ftime>=56.5)
	{
		static int one=1;
		if (one)
		{
			for (int i=0; i<num_pois; i++)
			{
				p[i].p[0].x=rand()%320;
				p[i].p[0].y=rand()%200;
				p[i].p[1].x=rand()%320;
				p[i].p[1].y=rand()%200;
				p[i].p[2].x=rand()%320;
				p[i].p[2].y=rand()%200;
				p[i].p[3].x=rand()%320;
				p[i].p[3].y=rand()%200;
			}
			one=0;
		}
		for (i=0; i<num_pois-1; i++)
		{
			bezier(poi[i], p[i], 0.5+sin(ftime+i)*0.5);
			voxelscene.PutBuffer(SCREENBUFFER, 10, poi[i].x, poi[i].y, 255);
			voxelscene.PutBuffer(7, 10, poi[i].x, poi[i].y, 255);
//			g_line((int*)voxelscene.mainbuffer.pixel, poi[i].x, poi[i].y, poi[i+1].x, poi[i+1].y, 320, 127+(ftime)*127);
		}

//Gj�r om lys til mosaic
		voxelscene.Mosaic(11, 7, 4);//8
		voxelscene.mainbuffer+=voxelscene.buffer[11];

		if (ftime>=75) voxelscene.CopyBuffer(11, SCREENBUFFER);
	}
//--------------------------------------------------------------------------------
		



		int fog_color=bg_color;

//		voxelscene.PutBuffer(SCREENBUFFER, 9, 0, 0);

		unsigned int *sc=voxelscene.mainbuffer.pixel;
		unsigned int *texturemap=voxelscene.buffer[0]->pixel;
//		unsigned int *texturemap=voxelscene.buffer[7]->pixel;
		unsigned int *heightmap=voxelscene.buffer[1]->pixel;
		unsigned char texwidth=(unsigned char)voxelscene.getWidthBuffer(0)-1;
		unsigned char texheight=(unsigned char)voxelscene.getHeightBuffer(0)-1;

		//hmm
		unsigned int *voxtex=voxelscene.buffer[0]->pixel;

		//
		//snow
		//
#ifdef SNOW
//		if ((rand()%4)==1)
		int ra=rand()%(256*256);
		voxelscene.buffer[14]->pixel[ra]=0xffffff;//rand()%127;
		voxelscene.BlendAdd(12,14,255);
#endif
		//
		//
		//

//		ray.pos.x=rpx;
//		ray.pos.y=rpy;

		if (ftime<40.5)
		{
			ray.pos.x=265.85 + (ftime-32.5) * 10;
			ray.pos.y=0;
		}
		else
		if (ftime>=40.5 && ftime<56.5)
		{
			ray.pos.x=0;
			ray.pos.y=27.60 + (ftime-40.5)*5;
		}
		if (ftime>=56.5)
		{
			ray.pos.x=127+ftime-56;
			ray.pos.y=127-(ftime-56);
		}

		int x,y,z,hp,pp,cp;
		float ang,zf;
		float ang_max;
//		ang_max=DEG2RAD(60);
		ang_max=DEG2RAD(40);

		int px,py,i;
		ang=0;
		int col=0,col_old=0;
		float height,height_old;



#ifdef PERFORM_DEMO
		int view_length=(ftime-41.5 +7)*4;
		if (view_length>=160) view_length=160;
#else
//		int view_length=80;
//		int view_length=120;
		int view_length=160;
#endif
//		int zscale=128;
		int zscale=128+32;
//		int zscale=192;

		flare_y2=0;
		int ys, ys2;

		for (x=0; x<320; x++)
		{
//			ang+=0.02f;
//			ang=x*0.005;//ftime*0.1;
//			ang=M_PI2/320*x;//ftime*0.1;
			ang=DEG2RAD(60)/320*x;

			height=0;
//			height=199;
			int ytop;
			ytop=0;

//			float c_ang=cos(ang);
//			float s_ang=sin(ang);
			float c_ang=cos(ang+left_right_count*M_PI2/32);
			float s_ang=sin(ang+left_right_count*M_PI2/32);

			for (zf=0; zf<view_length; zf+=1)
			{
				int yp;

//				itx = ray.pos.x + (c_ang*(view_length-zf));
//				ity = ray.pos.y + (s_ang*(view_length-zf));
				itx = ray.pos.x + (c_ang*zf);
				ity = ray.pos.y + (s_ang*zf);
				
				//find the point in the map
				height_old=height;
				col_old=col;

//				if (heim[((int)(itx)&0xff)+(((int)(ity)&0xff)<<8)]<=height_old)
				{
					int rtxw=((int)itx)&texwidth;
					int rtyw=((int)ity)&texheight;

					//
					//bilinear filtering
					//

					int r,g,b;

					//optimalize:
					int rtyw256=(rtyw<<8);
					int rtyw1256=((rtyw+1)<<8);
					//

					if (flag_bilinear==1)
					{
						float uf,vf,uf2,vf2;
						int w0,w1,w2,w3;
						uf=getfraction(itx);
						vf=getfraction(ity);
						uf2=1-uf;
						vf2=1-vf;

						w0=heightmap[rtxw+rtyw256]&texwidth;
						w1=heightmap[1+rtxw+rtyw256]&texwidth;
						w2=heightmap[rtxw+rtyw1256]&texwidth;
						w3=heightmap[1+rtxw+rtyw1256]&texwidth;

						//optimalize:
						float uf2vf2=uf2*vf2;
						float uf1uf2=(1-uf2)*vf2;
						float uf21vf2=uf2*(1-vf2);
						float uf121vf2=(1-uf2)*(1-vf2);
						//
						height=((float)(w0*uf2vf2)+(float)(w1*uf1uf2)+(float)(w2*uf21vf2)+(float)(w3*uf121vf2));
//						height=((float)(w0*uf2*vf2)+(float)(w1*(1-uf2)*vf2)+(float)(w2*uf2*(1-vf2))+(float)(w3*(1-uf2)*(1-vf2)));

						g_irgb w[4];
						w[0].r=((texturemap[rtxw+rtyw256]&0xff0000)>>16);
						w[0].g=((texturemap[rtxw+rtyw256]&0x00ff00)>>8);
						w[0].b=((texturemap[rtxw+rtyw256]&0x0000ff));
						w[1].r=((texturemap[1+rtxw+rtyw256]&0xff0000)>>16);
						w[1].g=((texturemap[1+rtxw+rtyw256]&0x00ff00)>>8);
						w[1].b=((texturemap[1+rtxw+rtyw256]&0x0000ff));
						w[2].r=((texturemap[rtxw+rtyw1256]&0xff0000)>>16);
						w[2].g=((texturemap[rtxw+rtyw1256]&0x00ff00)>>8);
						w[2].b=((texturemap[rtxw+rtyw1256]&0x0000ff));
						w[3].r=((texturemap[1+rtxw+rtyw1256]&0xff0000)>>16);
						w[3].g=((texturemap[1+rtxw+rtyw1256]&0x00ff00)>>8);
						w[3].b=((texturemap[1+rtxw+rtyw1256]&0x0000ff));
						r=(int)((float)(w[0].r*uf2vf2)+(float)(w[1].r*uf1uf2)+(float)(w[2].r*uf21vf2)+(w[3].r*(float)(uf121vf2)));
						g=(int)((float)(w[0].g*uf2vf2)+(float)(w[1].g*uf1uf2)+(float)(w[2].g*uf21vf2)+(w[3].g*(float)(uf121vf2)));
						b=(int)((float)(w[0].b*uf2vf2)+(float)(w[1].b*uf1uf2)+(float)(w[2].b*uf21vf2)+(w[3].b*(float)(uf121vf2)));
					}
					else
					{
						//
						//no filtering
						//
						height=heightmap[rtxw+rtyw256]&0xff;
						r=(texturemap[rtxw+rtyw256]&0xff0000)>>16;
						g=(texturemap[rtxw+rtyw256]&0x00ff00)>>8;
						b=(texturemap[rtxw+rtyw256]&0x0000ff);
					}

					//
					//add fog color
					//
					if (flag_fog==1)
					{
						int fr=((fog_color&0xff0000)>>16);
						int fg=((fog_color&0x00ff00)>>8);
						int fb=((fog_color&0x0000ff));
						float bf0, bf1;
						float fog_start=view_length-92; //fra 0 - view_length

//						bf0=(view_length-zf)/view_length;
//						bf0=zf/view_length;

						if (zf>=fog_start) bf0=(zf-fog_start)/(view_length-fog_start);
						else bf0=0;

						bf1=(1-bf0);
						
						float lr=fr*bf0 + r*bf1;
						float lg=fg*bf0 + g*bf1;
						float lb=fb*bf0 + b*bf1;
						r=(int)lr;
						g=(int)lg;
						b=(int)lb;
					}
					//
					col=RGB32(r,g,b);



					//
					//get colors
					//
					if (flag_bilinear==1)
					{
						float uf3=getfraction(ray.pos.x);
						float vf3=getfraction(ray.pos.y);
						float uf4=1-uf3;
						float vf4=1-vf3;
						int y0=heightmap[(int)(ray.pos.x)+(((int)ray.pos.y)<<8)]&texheight;
						int y1=heightmap[(int)(1+ray.pos.x)+(((int)ray.pos.y)<<8)]&texheight;
						int y2=heightmap[(int)(ray.pos.x)+(((int)(ray.pos.y+1))<<8)]&texheight;
						int y3=heightmap[(int)(1+ray.pos.x)+(((int)(ray.pos.y+1))<<8)]&texheight;

						yp=((float)(y0*uf4*vf4)+(y1*(float)(1-uf4)*vf4)+(y2*(float)uf4*(1-vf4))+(y3*(float)(1-uf4)*(1-vf4)));
					}
					else
						yp=heightmap[(int)(ray.pos.x)+(((int)ray.pos.y)<<8)]&texheight;

					//
					//implementere fixed point nsr tiden er inne:
					//

//					Ys = ( Yv - Ye ) * Yk / Z + Yc
//					int ys=(height - yp) * (64+32)/(288-ray.tar.y);
//					int ys2=(height_old - yp) * (64+32)/(288-ray.tar.y);
//					ys=(height - yp) * (view_length)/(view_length-zf+92);
//					ys2=(height_old - yp) * (view_length)/(view_length-zf+92);
//					ys=(height - yp) * (view_length)/(256-view_length-zf+128);
//					ys2=(height_old - yp) * (view_length)/(256-view_length-zf+128);

//					float vlenzf=(view_length)/(zf+92);
					float vlenzf=(zscale)/(zf+92);
					ys=(height - yp) * vlenzf;
					ys2=(height_old - yp) * vlenzf;
//					ys*=0.5;
//					ys2*=0.5;

					if (ys>=199) ys=199;
					if (ys<2) ys=2;
					if (ys2>=199) ys2=199;
					if (ys2<2) ys2=2;

					int ya,yaold;
//					ya=1-rand()%3;
//					ya=2-rand()%5;

					if (ys>ytop)
					{
						ytop=ys;

						if (flag_texture==-1)
						{
							if (flag_bilinear==-1)
							{
//								if (ys2>=100) ys2=100;
//								if (ys>=100) ys=100;
//								g_line((int*)sc, x, ys, x, ys2, col);
								g_line((int*)sc, x, 199-ys, x, 199-ys2-cell_border, 0);	//black border
								g_line((int*)sc, x, 199-ys, x, 199-ys2, col);

//								g_line((int*)sc, x+rand()%3-1, 200-1-ys+rand()%3-1, x+rand()%3-1, 200-1-ys2+rand()%3-1, col);
//								g_line((int*)sc, x, 198-ys+ya, x, 198-ys2+yaold, col);
							}
							else
							{
//								line_gouraud(sc, x, ys, ys2, col, col_old);
								g_line((int*)sc, x, 199-ys, x, 199-ys2-cell_border, 0);	//black border
								line_gouraud(sc, x, 199-ys, 199-ys2, col, col_old);

//								line_gouraud(sc, x+rand()%3-1, 200-1-ys, 200-1-ys2, col, col_old);
//								line_gouraud(sc, x+rand()%3-1, 200-2-ys+rand()%3-1, 200-2 - ys2+rand()%3-1, col, col_old);

//								line_gouraud(sc, x, 200-2-ys+ya, 200-2 - ys2+yaold, col, col_old);
							}
						}
						else
						{
//							textureliney(sc, voxtex, x, 199-ys, 200, x, 0, 255);
//							textureliney(sc, voxtex, x, 199-ys, 199-ys2, x, height, height_old);
//							textureliney(sc, voxtex, x, 199-ys, 199-ys2, x, ys/(255-height)*256, ys/(255-height_old)*256);

							int y0=height;
							int y1=height_old;
							int ydiff=height-height_old;

							textureliney(sc, voxtex, x, 199-ys, 199-ys2, x, y0, y1-ydiff);
//							textureliney(sc, voxtex, x, 199-ys, 199-ys2, x, y1, y0);
						}
						yaold=ya;
//						g_line((int*)sc, ray.pos.x, ray.pos.y, itx, ity, 0xffffff);

						//
						//hent h�yden til spannet. brukes til lensflare rutinen
						//
						if (x==flare_x)
						{
							if (flare_y2<ytop) flare_y2=ytop;
//							g_line((int*)sc, x, 199-ys, x, 199, 320, 0xffffff);
						}
//						if (x==flare_x2) if (flare_y2<ytop) flare_y2=ytop;
					}
				}
			}
		}
/*		//
		//Lens flare
		//
		flare_x=fmod((ftime-32.5)*7.5,320);
		flare_x2=fmod((ftime-32.5)*7.5+10,320);

		flare_y=10 + 20;

		if (flare_y<(199-flare_y2)) flare_alpha+=32; else flare_alpha-=32;
		if (flare_alpha<0) flare_alpha=0;
		if (flare_alpha>=255) flare_alpha=255;

//		flare_x=0;
//		flare_y=0;
//		flare_alpha=255;

		voxelscene.MoveLensFlares(SCREENBUFFER, 2, 6,
			-160 + flare_x, -100 + flare_y, flare_alpha);
		//
		//Lens flare(END)
		//
*/


		//
		//add some noise (things get more interesting)
		//
//		voxelscene.Noise(7, 0xffffff);
//		voxelscene.BlendAdd(SCREENBUFFER,7,32);//92);
		//
		//
		//

//		primarylayer.MotionBlur(SCREENBUFFER, 0, 1);

		//am's design-layer
//		voxelscene.BlendMask(SCREENBUFFER, 10);



		//fallende sn�..
/*		if (ftime>=64)
		{
			for (i=0; i<32; i++)
			{
				snowflakes[i].x=160+cos(ftime*0.02 + i*0.4)*160;
				snowflakes[i].y+=rand()%2;//=100+sin(1+ftime*2.0 + i*0.24)*10;
				snowflakes[i].y=fmod(snowflakes[i].y, 200);
				snowflakes[i].z=-16+sin(ftime*1.8 + i*0.7)*6;
				int alpha;
//				alpha=127+sin(i*0.4+ftime*2)*127;
				alpha=192+sin(i*0.4+ftime*2)*64;
//				alpha=255;
//				alpha=((snowflakes[i].z+28+24)*5.3125);
				voxelscene.PutBuffer(SCREENBUFFER, 10, snowflakes[i].x, snowflakes[i].y, snowflakes[i].z, alpha);
			}
		}
*/


//
//NOISE
//
			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
//			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
			voxelscene.CopyBufferLayer(7, primarylayer, 1);
			voxelscene.BlendSub(SCREENBUFFER, 7, 255);
//			intro_scene.BlendAdd(SCREENBUFFER, 7, 255);
//
//



		//fadeout voxelland
		if (ftime>=75)
		{
			voxelscene.CrossFade(SCREENBUFFER, SCREENBUFFER, 11, (ftime-75)*92);
		}

		primarylayer.mainbuffer.pixel=voxelscene.mainbuffer.pixel;

		//ASDF
/*		primarylayer.ClearBuffer(0, 0);
		primarylayer.BlendMask(0, 1);
		primarylayer.RadialBlurSubpixel(0, 10+cos(ftime)*10, 200 - 10+sin(ftime*2)*sin(-ftime*1.4+1)*10, -0.007+sin(ftime)*cos(1+ftime*1.4)*0.006);
		primarylayer.BlendAdd(SCREENBUFFER, 0);
		primarylayer.BlendMask(SCREENBUFFER, 1, 255);
*/

		if (ftime<40)
		{
			//fadeinn
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-32.5)*64);
		}

		if (ftime>=40 && ftime<40.5)
		{
			primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-40)*512);
		}

		if (ftime>=40.5 && ftime<48.5)
		{
			if (ftime<42.5)
				primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-40.5)*127.5);
		}

		//fadein robot mask
		if (ftime>=49.2 && ftime<56.5) primarylayer.BlendMask(SCREENBUFFER, 4, (ftime-49.2)*127.5);

		if (ftime>=55.5 && ftime<56.5)
		{
				primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-55.5)*255);
		}

		if (ftime>=56.5 && ftime<57.5)
				primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-56.5)*255);




		//robotmask
		if (ftime>=56.5 && ftime<70)
		{
/*			static int pic[7];
			int it=(int)(ftime-56.5)%6;
			if (it==0) pic[0]=4;
			if (it==1) pic[1]=5;
			if (it==2) pic[2]=6;
			if (it==3) pic[3]=7;
			if (it==4) pic[4]=6;
			if (it==5) pic[5]=5;
			if (it==6) pic[6]=4;

			it=0;
*/
//			primarylayer.CrossFadeA(1, pic[it], pic[it+1], fmod(ftime-56.5, 1)*255);
//			primarylayer.CrossFadeA(1, 4, 5, (int)(fmod((ftime-56.5)*255, 255)));
//			primarylayer.CopyBuffer(1,4);
			primarylayer.BlendMask(SCREENBUFFER, 4, 255);
		}




		//fadeout mask
		if (ftime>=70 && ftime<72) primarylayer.BlendMask(SCREENBUFFER, 4, 255-(ftime-70)*127.5);


		if (ftime>=79 && ftime<82.1)
		{
			primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-78)*100);
		}

		//remove bugs
		g_line((int *)primarylayer.mainbuffer.pixel,0,198,319,198, 0);
		g_line((int *)primarylayer.mainbuffer.pixel,0,199,319,199, 0);
}


//-----------------------------------------------------------------------------------------------
//ROTATE CUBE (ORANGE STYLE)
//-----------------------------------------------------------------------------------------------
	if (ftime>=82.1 && ftime<114.8)
	{


		static float rotf=0,traf=0;
//		traf=0;

//		if (ftime>=90.2)
		{
			if (traf==100)
				gridflat(grid, ftime*100, 0);
			else
				gridflat(grid, 00, ftime*100);

			if (ftime>=90.26)
				gridflat(grid, ftime*100, sin(ftime-90.26)*20);

//			gridflat(grid, 0, 0);
//			gridwtf(grid, (ftime-71)*2);
			gridwave(grid, 0.5, ftime*4, 1);
			gridsinus(grid, 0.15, 0.2, ftime*4, ftime*3, 15,0);
//			gridcosinus(grid, 0.25, 0.2, ftime*4, ftime*3, 0, 25);
//			gridwrap(grid);

			grid.shade=false;
//			grid.shade=true;

			gridexpander(intro_scene.mainbuffer.pixel, grid, intro_scene.buffer[14]->pixel);
//			gridexpander(intro_scene.buffer[11]->pixel, grid, intro_scene.buffer[14]->pixel);
/*
			if (ftime>=90.2 && ftime<91.2) intro_scene.CrossFade(SCREENBUFFER, SCREENBUFFER, 11, (ftime-90.2)*255);
			else
			if (ftime>=113.8 && ftime<114.8) intro_scene.CrossFade(SCREENBUFFER, SCREENBUFFER, 11, 255-(ftime-113.8)*255);
			else
				intro_scene.CopyBuffer(SCREENBUFFER, 11);
				*/
		}
		if (ftime>=98.1)
		{
			intro_scene.ClearBuffer(0, 0);
//			intro_scene.ClearBuffer(SCREENBUFFER, 0xF34F03);
			intro_scene.ScrollHorisontal(0, 3, 164-70, ftime*50);
//			intro_scene.ScrollHorisontal(0, 2, 164-70, sin(ftime)*30+ftime*30);
			intro_scene.ScrollHorisontal(0, 2, 172-70+2, ftime*30);
			intro_scene.ScrollHorisontal(0, 1, 177-70+5, ftime*15);
			if (ftime<105) intro_scene.BlendAdd(SCREENBUFFER, 0, (ftime-98.1)*51);
			if (ftime>=105 && ftime<106) intro_scene.BlendAdd(SCREENBUFFER, 0, sin((ftime-105)*M_PI2)*255);
			if (ftime>=106 && ftime<113) intro_scene.BlendAdd(SCREENBUFFER, 0, 255);
			if (ftime>=113) intro_scene.BlendAdd(SCREENBUFFER, 0, 255-(ftime-113)*255);
		}

		//am's design-layer
		intro_scene.BlendMask(SCREENBUFFER, 10);



		static int cubeobj=1;

		obj_cubes[cubeobj].mLoadIdentity();
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-60+sin(i*0.01)*60));


	//synch
		static float synchi=0;
/*		
//		if (ftime>=87.2)
		{
			if (ftime<synch_3[25])
			{
				for (i=0; i<31; i++)
				{
					if (ftime>=synch_3[i] && ftime<synch_3[i+1])
					{
						synchi=(ftime-synch_3[i])*40;
					}
				}
			}
		}
*/
//smash!!
		int cuberand,cubefl;
		float fxs=0;
		for (i=0; i<38; i++)
		{
			if (ftime>=synch_2[i] && ftime<(synch_2[i]+0.1))
			{
				rotf=i*0.2;
//				traf=60;
//				traf=80;
				traf=100;

//				if ((i%3)<2) cubeobj=1;
//				else cubeobj=2;

/*				if ((i%9)==0) cubeobj=1;
				if ((i%9)==1) cubeobj=1;
				if ((i%9)==2) cubeobj=1;
				if ((i%9)==3) cubeobj=2;
				if ((i%9)==4) cubeobj=1;
				if ((i%9)==5) cubeobj=1;
				if ((i%9)==6) cubeobj=2;
				if ((i%9)==7) cubeobj=1;
				if ((i%9)==8) cubeobj=2;*/

				if ((i%9)==0) cubeobj=1;
				if ((i%9)==1) cubeobj=1;//if (i<2) cubeobj=2; else cubeobj=1;
//				if ((i%9)==2) cubeobj=1;
				if ((i%9)==2) cubeobj=2;
				if ((i%9)==3) cubeobj=1;
				if ((i%9)==4) cubeobj=1;
				if ((i%9)==5) cubeobj=2;
				if ((i%9)==6) cubeobj=1;
				if ((i%9)==7) cubeobj=2;// else cubeobj=1;
				if ((i%9)==8) cubeobj=2;


				if ((i%9)==0) { cuberand=25; cubefl=2; }
				else cuberand=0;

				if ((i%9)==1) { cuberand=25; cubefl=1; }
				else cuberand=0;
			}
		}
//		traf--;
		traf-=2;
		if (traf<0) traf=0;

		float ffx=sin(0.1+ftime*0.3)*cos(-ftime*0.8)*M_PI;
		float ffy=sin(0.3+ftime*0.5)*cos(ftime*0.5)*M_PI;
		float ffz=sin(0.2-ftime*0.6)*cos(-ftime*0.3)*M_PI;
//		float ffx=sin(0.2+ftime*0.4)*cos(-ftime*1.0)*M_PI; //kjappere
//		float ffy=sin(0.4+ftime*0.7)*cos(ftime*0.6)*M_PI;
//		float ffz=sin(0.3-ftime*0.8)*cos(-ftime*0.4)*M_PI;
//		float ffx=sin(0.2+ftime*0.2)*cos(-ftime*0.3)*M_PI;
//		float ffy=sin(0.4+ftime*0.1)*cos(ftime*0.2)*M_PI;
//		float ffz=sin(0.3-ftime*0.3)*cos(-ftime*0.1)*M_PI;


		if (ftime>=87.4)
			obj_cubes[cubeobj].mRotate(Vector3D(ftime-87.4,0,1));
		if (ftime>=94.37)
			obj_cubes[cubeobj].mRotate(Vector3D(1,ftime-94.37,0));
		if (ftime>=98.49)
			obj_cubes[cubeobj].mRotate(Vector3D(0,1,ftime-98.49));

		obj_cubes[cubeobj].mRotate(Vector3D(ffx+rotf,0,0)); //x
		obj_cubes[cubeobj].mRotate(Vector3D(0,ffy,0)); //y
		obj_cubes[cubeobj].mRotate(Vector3D(0,0,ffz)); //z
		obj_cubes[cubeobj].mRotate(Vector3D(ftime,0,0)); //x
		obj_cubes[cubeobj].mRotate(Vector3D(0,ftime,0)); //y
		obj_cubes[cubeobj].mRotate(Vector3D(0,0,ftime)); //z

//		obj_cubes[cubeobj].SetZSCALE(140); //FOV=45
//		obj_cubes[cubeobj].SetZSCALE(160); //FOV=45
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-180+traf));
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-200+traf));
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-220+traf));
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-240+traf));

//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-260+traf));
		
		static float ta=0;
		if (ftime>=112.8)
		{
			ta=(ftime-112.8)*30;
			synchi=synchi*(1-(ftime-112.8)*0.01);
			if (synchi<0) synchi=0;
		}
//		obj_cubes[cubeobj].SetZSCALE(120+synchi); //FOV=45
		obj_cubes[cubeobj].SetZSCALE(140-30+synchi); //FOV=45


		static float fx=0, fy=0;

//		84.67, 90.270, 94.422, 99.663, 103.060, 108.060
		if ((ftime>=89.7))
//		if ( (ftime>=90.67) )//&& (ftime<93.27))
		{
			fx=sin((ftime-89.7)*1)*50;
//			fx=sin(ftime-90.67)*50;

			if ( (ftime>=94.6) )
			{
				fy=sin(ftime-94.6)*15;
			}
		}
		if ( (ftime>=95.6) && (ftime<105.6))
		{
			fy=sin(ftime-95.67)*15;
		}
		
//		fx+=(int)(primarylayer.fft[rand()%320]*32000*0.07);

		obj_cubes[cubeobj].mTranslate(Vector3D(fx,fy,0));


		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-240+traf+ta));


		//move to inside of cube
//		if (ftime>=synch_2[14] && ftime<(synch_2[16])) obj_cubes[cubeobj].mTranslate(Vector3D(0,0,+160));



		//smash dunk til sidene
/*		if (cuberand>0 && cuberand<36)
		{
			if (cubefl==2) obj_cubes[cubeobj].mTranslate(Vector3D(rand()%cuberand,0,0));
			if (cubefl==1) obj_cubes[cubeobj].mTranslate(Vector3D(0,rand()%cuberand,0));
		}*/
			

		//move cube downwards
		if (ftime>=114) obj_cubes[cubeobj].mTranslate(Vector3D(0,-(ftime-114)*175,0));


		obj_cubes[cubeobj].SetColor(R3D_FLAT_FIXED, 0);
		obj_cubes[cubeobj].Show(intro_scene, SCREENBUFFER, 0, 4);

/*		if (ftime<10) obj_cubes[cubeobj].SetZSCALE(160); //FOV=45
		if (ftime>=20)
		{
			obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-200));
			obj_cubes[cubeobj].SetZSCALE(120);
		}
		if (ftime>=10 && ftime<20)
		{
			obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-((ftime-10)*20)));
			obj_cubes[cubeobj].SetZSCALE(160-(ftime-10)*4); //FOV=45
		}*/
		g_clearz(WIDTH*HEIGHT);
		obj_cubes[cubeobj].SetColor(R3D_FLAT_SHADE, 0xffffff);

		obj_cubes[cubeobj].znear=-20;

		if (ftime<116.215) 
			obj_cubes[cubeobj].rendermode=1;//2;
		else
			obj_cubes[cubeobj].rendermode=4;

		obj_cubes[cubeobj].envmap=false; //envmap

		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-cell_border));
//		obj_cubes[cubeobj].mTranslate(Vector3D(0,0,-20));

		obj_cubes[cubeobj].Show(intro_scene, SCREENBUFFER, 0, 4);

		//fade inn
//		if (ftime>=120) intro_scene.BlendAdd(SCREENBUFFER, 9, (ftime-120)*127.5);


		//make some noise
		intro_scene.ClearBuffer(11, 0);
		intro_scene.Noise(11, RGB32(98,98,98));
/*
//yaphan vs. excess

		if (ftime>=89 && ftime<100)
		{
			intro_scene.ScrollHorisontal(13, 12, 10+rand()%10, rand()%10);
			intro_scene.BlendMask(SCREENBUFFER, 13, 127+sin(M_PI2+(ftime-89)*2)*127);
		}*/

		//make some noise
		intro_scene.BlendAdd(SCREENBUFFER, 11, 127+sin(-M_PI2 + (ftime-82.1)*cos(ftime*1.5)*3)*127);


		primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;

		if (ftime>=82.1 && ftime<84.1) primarylayer.CrossFade(SCREENBUFFER, WHITEBUFFER, SCREENBUFFER, (ftime-82.1)*127);
		if (ftime>=113.8 && ftime<114.8) primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-113.8)*255);
	}

//----------------------------------------------------------------------------------
//fft synch
//----------------------------------------------------------------------------------

#ifdef _BASS_LIB_
		BASS_ChannelGetData(ha, primarylayer.fft, BASS_DATA_FFT1024);
#endif

//----------------------------------------------------------------------------------
//cubetwister
//----------------------------------------------------------------------------------

//	if (ftime>=114.8)
	if (ftime>=114.8 && ftime<147.5)
	{
/*		grid.offset=100;
		grid.radius=300;
		grid.fov=28;
		grid.shade=false;
//		freedirectional_tunnel(grid, Vector3D(10,10,ftime*250), Vector3D(0,0,10));
		gridflat(grid,0,0);
		gridwtf(grid, ftime*0.1);*/

/*
//		tableeffect.ClearBuffer(1,0);
//		tableeffect.ClearBuffer(2,0);
		tableeffect.ClearBuffer(1,0xF34F03);
		tableeffect.ClearBuffer(2,0xF34F03);

		float i2, f3=ftime*3;
		for (i=0; i<32; i++)
		{
			i2=i*0.2;
			tableeffect.PutBuffer(1, 4,
				140+cos(ftime+i2)*50,// + sin(ftime+i*0.3)*50,
				90+sin(ftime+i*0.3)*40,// + cos(ftime*0.8+i*0.2)*70,
				sin(f3 + i2)*50, 127+sin(ftime*2+i)*127);
			tableeffect.PutBuffer(2, 4,
				140+cos(ftime*0.7+i2)*i*0.7,// + sin(ftime*0.6+i*0.2)*50,
				90+sin(ftime*0.4+i*0.22)*i*0.8,//+ cos(ftime*0.8+i*0.1)*70,
				sin(f3 + i2)*50, 127+sin(ftime+i*0.06)*127);
		}
		tableeffect.RadialBlur(1, 0.25+sin(ftime)*0.2);
		tableeffect.RadialBlur(2, 0.5+sin(ftime*0.8+1)*0.48);
		*tableeffect.buffer[1]^=tableeffect.buffer[2];
		tableeffect.FilterEdgeDetection(SCREENBUFFER, 1);
		tableeffect.MotionBlur(SCREENBUFFER, 3, 2);

//		tableeffect.Noise(5, RGB32(0,48,72));
		tableeffect.Noise(5, RGB32(64,64,64));
		tableeffect.BlendAdd(SCREENBUFFER, 5);

		tableeffect.BlendMask(SCREENBUFFER, 6);
		//border
		g_line((int *)tableeffect.mainbuffer.pixel,0,0,0,200-1, 0); //venstre
		g_line((int *)tableeffect.mainbuffer.pixel,1,0,1,200-1, 0); //venstre
		g_line((int *)tableeffect.mainbuffer.pixel,0,0,320,0,0);	//oppe
		g_line((int *)tableeffect.mainbuffer.pixel,320-1,0,320-1,200-1,0);//h�yre
		g_line((int *)tableeffect.mainbuffer.pixel,320-2,0,320-2,200-1,0);//h�yre
		g_line((int *)tableeffect.mainbuffer.pixel,0,200-2,320,200-2,0);//nede
		g_line((int *)tableeffect.mainbuffer.pixel,0,200-1,320,200-1,0);//nede

		primarylayer.mainbuffer.pixel=tableeffect.mainbuffer.pixel;
*/


	//
	//twister!!!!!!!!!
	//
		//114.8
//		int posvx=30+((ftime-114.8)*30)+sin((ftime-114.8)*4)*10;
		int posvx=30+(ftime-114.8)*75;
		if (posvx>=210) posvx=210;

		if (ftime>=145)
		{
			posvx=210-(ftime-145)*120;
		}

		if (ftime>=127.1)
		{
			posvx=210+(ftime-127.1)*75;
		}


		static float fstep=0;
//		118.958, 121.015, 123.042, 125.084

		if (ftime>=116.92) fstep=M_PI;
		if (ftime>=118.9) fstep=0;

		//fade to a gridexpander effekt
//		if (ftime>=118)
		if (ftime>=114.8 && ftime<127.1)
		{
			grid.shade=false;
			gridflat(grid, 0, 0);
			gridwtf(grid, (ftime-71)*2+fstep);

//			gridwave(grid, 0.5, ftime*4, 1);
//			gridsinus(grid, 0.15, 0.2, ftime*4, ftime*3, 15,0);
//			gridcosinus(grid, 0.25, 0.2, ftime*4, ftime*3, 0, 25);
//			gridwrap(grid);
//			gridexpander(7, grid, cubetwister.buffer[5]->pixel);
			gridexpander(cubetwister.mainbuffer.pixel, grid, cubetwister.buffer[5]->pixel);
		}

		float yro;
//		if (ftime>=132.5)// && ftime<137.15)
		if (ftime>=131.25)// && ftime<137.15)
		{
//			yro=sin(ftime-132.5-1)*180;
			yro=sin(ftime-132.5)*40;
		}
		else
			yro=0;

//		if (ftime>=127.1)// && ftime<135.1)
		if (ftime>=122.52)// && ftime<135.1)
		{
			grid.shade=false;//true;
//			grid.fov=50;
			grid.fov=50+sin(ftime-122.52)*40;

			grid.radius=200;
			freedirectional_tunnel(grid,
//					Vector3D(0, sin(ftime*1)*150, ftime*2000),
//					Vector3D(cos(ftime*0.3)*25, yro, cos(ftime)*45));
					Vector3D(0, sin(ftime*1)*150, ftime*3000),
					Vector3D(cos(ftime*0.3)*15, yro, cos(ftime)*45));

			gridexpander(cubetwister.buffer[7]->pixel, grid, cubetwister.buffer[5]->pixel);
//			gridexpander(cubetwister.mainbuffer.pixel, grid, cubetwister.buffer[5]->pixel);
//			cubetwister.CopyBuffer(SCREENBUFFER, 7);
			cubetwister.CrossFade(SCREENBUFFER, SCREENBUFFER, 7, (ftime-122.52)*255);
		}

//		gridexpander(planecrazy.buffer[3]->pixel, grid, planecrazy.buffer[2]->pixel);

//		if (ftime>=127.1)// && ftime<135.1)
		if (ftime>=122.52)// && ftime<135.1)
		{
			grid.shade=true;
			gridexpander(cubetwister.buffer[2]->pixel, grid, cubetwister.buffer[5]->pixel);
			cubetwister.mainbuffer+=cubetwister.buffer[2];
//			cubetwister.mainbuffer-=cubetwister.buffer[2];
		}

		//invertshit
		 if (ftime>=139.493 && ftime<140.493) cubetwister.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-139.493)*255));

		int anic=255;
		if (ftime>=123.0 && ftime<124.0)
		{
			anic=(ftime-123)*255;
		}

		if (ftime>=127.13 && ftime<128.13)
		{
			anic=(ftime-127.13)*255;
		}

		int gr=4;
		if (ftime>=118.9 && ftime<130.8)
			cubetwister.InvertRectangleAnim(SCREENBUFFER, 50+rand()%gr,80+rand()%gr,130+rand()%gr,140+rand()%gr,0xffffff, ftime-118.9, SCREENBUFFER,  anic);

		if (ftime>=130.8 && ftime<131.8)
			cubetwister.InvertRectangleAnim(SCREENBUFFER, 50+rand()%gr,80+rand()%gr,130+rand()%gr,140+rand()%gr,0xffffff, 1-(ftime-130.8), SCREENBUFFER,  anic);
/*
		if (ftime>=145.6)
		{
			for (i=0; i<40; i++)
			{
				int sdx=cos(ftime+i*0.1)*120;
				int sdy=sin(ftime+i*0.1)*70;
				cubetwister.InvertRectangleAnim(SCREENBUFFER, 40+sdx, 40+sdy, 280-sdx, 160-sdy,0xffffff, (ftime-145.6), SCREENBUFFER,  anic);
			}
		}*/
//, 139.420, 143.602


/*
		//CHARS NOISE
		if (ftime>=135.39)
		{
//			cubetwister.CopyBufferLayer(2, primarylayer, 9+fmod(ftime*15, 4));
			cubetwister.CopyBufferLayer(2, primarylayer, 14);
			cubetwister.BlendSub(SCREENBUFFER, 2, 255);
		}*/

/*
		if (ftime<119)
			cubetwister.CrossFade(SCREENBUFFER, SCREENBUFFER, 0, 255-(ftime-118)*255);
*/
/*		if (ftime>=120 && ftime<123)
			cubetwister.CrossFade(SCREENBUFFER, SCREENBUFFER, 0, (ftime-120)*255);

		if (ftime>=123)// && ftime<124)
			cubetwister.CrossFade(SCREENBUFFER, SCREENBUFFER, 0, 255-(ftime-123)*255);
			*/
//		}
/*		else
		{
			cubetwister.CopyBufferLayer(0,primarylayer,3);
			cubetwister.CopyBuffer(SCREENBUFFER, 0); //background image
		}*/


//------------------------------------------------------------------------------------------------------
//spectrum speech thing (equalizer)
//------------------------------------------------------------------------------------------------------
//		primarylayer.ClearBuffer(SCREENBUFFER, 0xffffff);
//		primarylayer.ClearBuffer(SCREENBUFFER, 0);
//		octopusscene.CopyBufferArea(SCREENBUFFER, 10, (int)(ftime*20)%1024, 0);
//		primarylayer.CopyBufferLayer(SCREENBUFFER, octopusscene, SCREENBUFFER);
//		primarylayer.CopyBufferLayer(2, octopusscene, SCREENBUFFER);
//		primarylayer.CopyBuffer(2, SCREENBUFFER);
		
/*		primarylayer.SetFFTSynch(true);
		if ((ftime>=62.8 && ftime<66) ||
			(ftime>=67 && ftime<69) ||
			(ftime>=70 && ftime<71.5) ||
			(ftime>=73.5 && ftime<82)
			)
			primarylayer.NoiseSpanHorisontal(SCREENBUFFER, 2, 16+sin(ftime)*15);

//		if (ftime>=79.8)
//		if (ftime>=84.8)
		if ((ftime>=94.8 && ftime<99.924) ||
			(ftime>=104.032 && ftime<108.065) ||
			(ftime>=112)
			)

			primarylayer.NoiseSpanHorisontal(SCREENBUFFER, 2, 16+sin(ftime)*15);
//			primarylayer.NoiseSpanVertical(SCREENBUFFER, 2, 16+sin(ftime)*15);
		primarylayer.SetFFTSynch(false);
*/



		//synch equalizern (dunking)
		//114.870, 116.95, 118.997, 123.068,
		int ydunk;

//		if (ftime>=114.87 && ftime<116.95) ydunk=40-(ftime-114.87)*70;
		if (ftime>=116.95 && ftime<118.997) ydunk=40-(ftime-116.95)*60;
		if (ftime>=118.95 && ftime<121.0) ydunk=40-(ftime-118.95)*60;
		if (ftime>=127.17 && ftime<129.17) ydunk=40-(ftime-127.17)*60;

		if (ftime>=123) ydunk=40-(ftime-123)*60;

		if (ydunk<0) ydunk=0;

		cubetwister.ClearBuffer(7,0);
		for (x=0; x<320; x++)
		{
			y=(int)(primarylayer.fft[(int)(x*0.5)]*32000*0.07)%200;

//			g_line((int*)cubetwister.mainbuffer.pixel, x, 40-y, x, 40, 0);
//			g_line((int*)cubetwister.mainbuffer.pixel, 319-x, 40+y, 319-x, 40, 0);
//			g_line((int*)cubetwister.mainbuffer.pixel, x, 40-y+ydunk, x, 40+ydunk, 0);
//			g_line((int*)cubetwister.mainbuffer.pixel, 319-x, 40+y+ydunk, 319-x, 40+ydunk, 0);
			g_line((int*)cubetwister.buffer[7]->pixel, x, 40-y+ydunk, x, 40+ydunk, 0xffffff);
			g_line((int*)cubetwister.buffer[7]->pixel, 319-x, 40+y+ydunk, 319-x, 40+ydunk, 0xffffff);
		}
		g_line((int*)cubetwister.buffer[7]->pixel, 320, 200, 0, 40+ydunk, 320, 40+ydunk, 0xffffff);
//		if (ftime>=127.1 && ftime<128.1) cubetwister.CrossFade(7, BLACKBUFFER, 7, (ftime-127.1)*255);
		if (ftime>=124.1) cubetwister.BlendSub(SCREENBUFFER, 7, 255-(ftime-124.1)*63.75);
		else
			cubetwister.BlendSub(SCREENBUFFER, 7, 255);
//			cubetwister.CopyBuffer(SCREENBUFFER, 7);

//		primarylayer.MotionBlur(SCREENBUFFER, 0, 1);
//		primarylayer.MotionBlur(SCREENBUFFER, 0, 2);
//------------------------------------------------------------------------------------------------------
//spectrum speech thing(END)
//------------------------------------------------------------------------------------------------------


		//scroller
//		cubetwister.PutStringWithScroller(0, ftime-100.2);

		cubetwister.ClearBuffer(2, 0x000000);
		cubetwister.ClearBuffer(3, 0x000000);
			

		unsigned int *bf, *bf2, *bf3;
//		bf=cubetwister.mainbuffer.pixel;
		bf=cubetwister.buffer[6]->pixel;
		bf2=cubetwister.buffer[2]->pixel;	//textured
		bf3=cubetwister.buffer[3]->pixel;	//shaded

		cubetwister.ClearBuffer(6,0);

		Coord2D p[8],vp[2];
		int col[4];
		int z[4];
//		int start_y=-170;
//		int length_y=340;
		int start_y=-99;
		int length_y=198;

	Vector3D v[8],vt[8];
	Vector3D size;

/*	size.x=25;
//	size.y=30;
	size.z=25;*/

	size.x=35;
	size.z=35;

	Vector3D rot,mv;

//	size.x=20+sin(ftime)*15;
//	size.z=20+cos(1+ftime)*10;


		Vector3D vb[4];


		//den som har st�rst z tegnes f�rst (dybde-sortering)
		for (int y=0; y<length_y; y++)
		{
			vb[0].Set(-size.x,0,size.z);
			vb[1].Set(size.x,0,size.z);
			vb[2].Set(-size.x,0,-size.z);
			vb[3].Set(size.x,0,-size.z);

//			size.x=20+sin(ftime+y*0.01)*15;
			size.z=20+cos(1+ftime-y*0.02)*10;

//			size.z=20+cos(1+ftime-y*0.06)*5;

			//back
			v[0].Set(-size.x,0,size.z);
			v[1].Set(size.x,0,size.z);

			//right
			v[2].Set(size.x,0,size.z);
			v[3].Set(size.x,0,-size.z);

			//front
			v[4].Set(-size.x,0,-size.z);
			v[5].Set(size.x,0,-size.z);

			//left
			v[6].Set(-size.x,0,size.z);
			v[7].Set(-size.x,0,-size.z);

			rot.y=ftime+ sin(ftime+y*0.01) * 3;
//			rot.y=sin(ftime+y*0.01)*2+ftime;

			int q;

//			for (q=0; q<8; q++)
//				v[q].y=v[q].y * (0.5+sin(q*0.08+ftime)*0.5)*(q*0.1);

			for (q=0; q<8; q++)
			{
				v[q].x=v[q].x + (0.5+cos(1+q*0.02+ftime*2)*0.5)*32;
				v[q].z=v[q].z + (0.5+sin(q*0.02+ftime*3)*0.5)*34;
			}

			rotation(&vt[0], &v[0], rot.y);
			rotation(&vt[1], &v[1], rot.y);
			rotation(&vt[2], &v[2], rot.y);
			rotation(&vt[3], &v[3], rot.y);
			rotation(&vt[4], &v[4], rot.y);
			rotation(&vt[5], &v[5], rot.y);
			rotation(&vt[6], &v[6], rot.y);
			rotation(&vt[7], &v[7], rot.y);

			z[0]=vt[0].z+vt[1].z;
			z[1]=vt[2].z+vt[3].z;
			z[2]=vt[4].z+vt[5].z;
			z[3]=vt[6].z+vt[7].z;

			for (int i=0; i<4; i++)
			{
				zB[i].index = i;
				zB[i].depth = z[i];
			}
			//sorter verdiene tilslutt.
			//
			qsort(zB, 4, sizeof(Zbuffer), compare);


			for (i=0; i<4; i++)
			{
				int d=zB[i].index;
				int i1=(d*2);
				int i2=(d*2+1);
				p[0]=project3d(vt[i1], 128, posvx, 100);
				p[1]=project3d(vt[i2], 128, posvx, 100);
//				p[0]=project3d_new(vt[i1], 128, posvx, 100);
//				p[1]=project3d_new(vt[i2], 128, posvx, 100);
//				p[0]=project3d_mid(vt[i1], 92, posvx, 100);
//				p[1]=project3d_mid(vt[i2], 92, posvx, 100);

//				vp[0]=project3d(vb[0], 128);
//				vp[1]=project3d(vb[1], 128);


				//rotasjonsvinkelen b�r jo egentlig angi en slags "normal vektor".
				//denne kan vi bruke som farge for s legge ps "shading".
				Vector3D vector_a, vector_b, vector_c, normal_vector, light;

				vector_a=vt[i1];
				vector_b=vt[i2];
				vector_c=vt[i1];
				vector_c.y=-1;//make a tri

				vector_c.Substract(vector_a);
				vector_b.Substract(vector_a);

				normal_vector=cross_product(vector_c,vector_b);
				normal_vector.Normalize();


//				light.Set(0,0,-1);
				light.Set(0,0,1);
				light.Normalize();


				float intensity=dot_product(light,normal_vector);
//				if (intensity<0) intensity=0;
//				int c=255*intensity;

				if (intensity>=-1 && intensity<0) intensity=1-intensity;

//				int color=0xF34F03;
				int color=0x344F33;
//				int c=(int)(255*intensity)&0xff;
				int c=RGB32(((int)(getRed(color)*intensity)&0xff),
					((int)(getGreen(color)*intensity)&0xff),
					((int)(getBlue(color)*intensity)&0xff));

//				int c=(int)(15.9375*intensity*16)&0xff;
//				int c=(int)(7.96875*intensity*32)&0xff;
//				int c=(0.5+sin(intensity)*0.5)*255;

//				if (c<0) c=0;
//				if (c>255) c=255;

//				g_line((int*)bf, p[0].x, start_y + p[0].y + y, p[1].x, start_y + p[1].y + y, col[d]);
//				g_line((int*)bf, p[0].x, start_y + p[0].y + y, p[1].x, start_y + p[1].y + y, RGB32(c,c,c));
//				g_line((int*)bf, p[0].x, start_y + p[0].y + y, p[1].x, start_y + p[1].y + y, 0);

				//textured
//				textureline(bf2, cubetwister.buffer[7]->pixel, p[0].x, p[1].x, start_y+p[0].y+y, p[0].y+y+sin(-ftime+y*0.05)*60);
				textureline(bf2, cubetwister.buffer[1]->pixel, p[0].x, p[1].x, start_y+p[0].y+y, p[0].y+y+ftime*10);

				//shaded
//				g_line((int*)bf3, p[0].x, start_y + p[0].y + y, p[1].x, start_y + p[1].y + y, 0);
				g_line((int*)bf3, 320, 200, p[0].x, start_y + p[0].y + y, p[1].x, start_y + p[1].y + y, c);
			}
		}


//		cubetwister.RadialBlur(2, 0.075+sin(ftime)*0.05);
//		cubetwister.MotionBlur(0, 8, 2);
//		cubetwister.MotionBlur(1, 8, 3);
//		cubetwister.MotionBlur(2, 8, 3);

		//add shading
//		cubetwister.CopyBuffer(SCREENBUFFER, 0);
//		cubetwister.mainbuffer-=cubetwister.buffer[1];
//		cubetwister.mainbuffer+=cubetwister.buffer[1];

//her
//		cubetwister.mainbuffer&=cubetwister.buffer[0];
//		cubetwister.mainbuffer|=cubetwister.buffer[0];
//		cubetwister.mainbuffer+=cubetwister.buffer[0];
//		cubetwister.mainbuffer-=cubetwister.buffer[1];
//		cubetwister.mainbuffer+=cubetwister.buffer[1];

		//kewl
//		*cubetwister.buffer[2]-=cubetwister.buffer[3];
		*cubetwister.buffer[2]+=cubetwister.buffer[3];
//		cubetwister.RadialBlur(1, 0.1);
//		cubetwister.MotionBlur(1, 3, 1);

//		cubetwister.mainbuffer+=cubetwister.buffer[2];

		*cubetwister.buffer[6]+=cubetwister.buffer[2];

//		if (ftime>=127.1) cubetwister.CrossFade(6, 6, BLACKBUFFER, (ftime-127.1)*255);
		cubetwister.CopyBuffer(SCREENBUFFER, 6);

//		cubetwister.mainbuffer+=cubetwister.buffer[2+2];

/*
//NOISE
//			cubetwister.CopyBufferArea(2, 4, 0, rand()%600);
//			cubetwister.BlendAdd(SCREENBUFFER, 2, 255);
			cubetwister.CopyBufferArea(2, 4, 0, rand()%600);
			cubetwister.BlendSub(SCREENBUFFER, 2, 255);
//
*/


		primarylayer.mainbuffer.pixel=cubetwister.mainbuffer.pixel;

		
//180.539, 181.814, 182.543, 183.805, 184.600, 185.857, 186.276, 186.670, 188.661, 189.972, 190.763, 192.033, 192.820, 194.100, 194.455, 194.851

//		if (ftime>=131.298)
		if (ftime>=127.674)
		{
			//NOISE
			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
//			primarylayer.BlendAdd(SCREENBUFFER, 1, 255);
			primarylayer.BlendAdd(SCREENBUFFER, 1, (ftime-127.674)*63.75);

//			primarylayer.BlendSub(SCREENBUFFER, 1, 255);
//			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
//			primarylayer.BlendSub(SCREENBUFFER, 1, 255);
		}

		if (ftime>=146.5 && ftime<147.5)
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-146.6)*255);

	//
	//twister!!!!!!!!!(END)
	//
	}

/*
//
//CHARS NOISE (9-13)
//

			cubetwister.CopyBufferLayer(2, primarylayer, 9+fmod(ftime*15, 4));
			cubetwister.BlendSub(SCREENBUFFER, 2, 255);
//
//
*/



//------------------------------------------------------------------------------------
//FD PLANE SCENE
//------------------------------------------------------------------------------------
//		g_clearz(width_*height_);
//		if (ftime>=112)//53.5)
//ftime>=112 && ftime<159.9)//53.5)

		if (ftime>=147.5 && ftime<164)
		{
			float ft=ftime-147.5;

			grid.offset=650;
			grid.fov=30;//10; //60;
			grid.shade=false;

			static float rx=0;
			if (fmod(ft, 3)>=1.5)
			{
//				rx+=sin(fmod(ft*0.2,0.75))*2;
				rx=0;
			}
			else
			{
//				rx-=sin(fmod(ft*0.2,0.75));
				rx=0;
			}

			if (
//				(ftime>=116 && ftime<120) ||
				(ftime>=116 && ftime<124) ||
//				(ftime>=124 && ftime<128) ||
				(ftime>=128 && ftime<132)// ||
//				(ftime>=132 && ftime<136) ||
//				(ftime>=140)
				)
				freedirectional_plane(grid,
//					Vector3D(0,sin(ft*4)*450,ft*1500),
//					Vector3D(0,50+cos(ft*1.1)*50, cos(ft*0.5)*45));
					Vector3D(0, sin(ft*4)*250, ft*3000),
					Vector3D(0, cos(ft*1.1)*25, cos(ft)*25));
			else
				freedirectional_plane(grid,
					Vector3D(0, sin(ft*2)*150, ft*3000),
					Vector3D(cos(ft*1.1)*25, 0, cos(ft)*25));

			grid.shade=false;
			gridexpander(planecrazy.mainbuffer.pixel, grid, planecrazy.buffer[2]->pixel);
			grid.shade=true;
			gridexpander(planecrazy.buffer[3]->pixel, grid, planecrazy.buffer[2]->pixel);

//			float fti=fmod(ftime-112, 15);
//			if (fti>=5 && fti<10)
//				planecrazy.mainbuffer-=planecrazy.buffer[3];
//			else
//			if (fti>=10 && fti<15)
				planecrazy.mainbuffer-=planecrazy.buffer[3];	//m�rkt innover
//				planecrazy.mainbuffer+=planecrazy.buffer[3];	//lyst innover


//			if (ftime>=120 && ftime<121) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 255-(ftime-120)*255);
//			if (ftime>=128 && ftime<129) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 255-(ftime-128)*255);
//			if (ftime>=128 && ftime<129) planecrazy.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-(ftime-128)*255);

			//
			//dunk etter musikken
			//
//151.764, 159.964
			if (ftime>=147.5 && ftime<148.5) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-147.5)*255));
			if (ftime>=149.7 && ftime<151.7) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 127.5-((ftime-149.7)*63.5));
			if (ftime>=151.7 && ftime<153.7) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 127.5-((ftime-151.7)*63.5));
			if (ftime>=155.8 && ftime<157.8) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-155.8)*127.5));
			if (ftime>=157.9 && ftime<158.9) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-157.9)*255));
			if (ftime>=159.9 && ftime<161.9) planecrazy.Invert(SCREENBUFFER, SCREENBUFFER, 127.5-((ftime-159.9)*63.5));

//			149.735, 151.731, 155.890, 157.940, 159.937





			obj_spike.mLoadIdentity();

			Vector3D rot, tra;
			rot.x=ftime*0.6;
			rot.y=-ftime*0.3;
			rot.z=sin(ftime*0.1)*M_2PI;

			obj_spike.mRotate(rot);

			obj_spike.mLoadIdentityN();
			obj_spike.mRotateN(rot);
			
			tra.x=cos(ftime*cos(ftime*0.05)*0.2)*140*(0.5+sin(M_PI+ftime*0.5));
			tra.y=sin(ftime*cos(-ftime*0.04)*0.5)*50;
//			tra.z=(-(ftime-147.5)*40 - 150) -(100+sin(ftime*0.2)*cos(1+ftime*0.7)*100);
			tra.z=(-(ftime-147.5)*70 - 150) -(100+sin(ftime*0.2)*cos(1+ftime*0.7)*100);

//			if (tra.z<-550) tra.z=-550;

			obj_spike.mTranslate(tra);

			obj_spike.culling=-1;
			obj_spike.rendermode=RENDERMODE_TEXTURE;//3;
			obj_spike.envmap=true;
//			obj_spike.octopus=false;
			obj_spike.SetColor(R3D_FLAT_SHADE, 0xffffff);
//			obj_spike.SetColor(R3D_FLAT_FIXED, 0xff7f7f);
			obj_spike.Show(primarylayer, SCREENBUFFER, 2, 0);



			primarylayer.mainbuffer.pixel=planecrazy.mainbuffer.pixel;


//			Vector3D rot, tra;

//			rot.x=ftime*0.4;
//			rot.y=ftime*0.3;
//			rot.z=ftime*0.2;
			rot.x=ftime*0.6;
			rot.y=ftime*0.5;
			rot.z=ftime*0.4;

//			tra.x=70;
			tra.x=80;
			if (ftime>=148.5 && ftime<150.5) tra.y=-(ftime-150.5)*80;
			else
				tra.y=0;

			if (ftime>=171.5 && ftime<180.4) tra.y=-(ftime-171.5)*80;

			tra.z=-250;
/*
			if (ftime>=148.5)// && ftime<144)
			{
				obj_torus.SetZSCALE(120);
				obj_torus.Rotate(rot);
				obj_torus.Translate(tra);

				obj_torus.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
				obj_torus.color_dot_fixed=0xffffff;
				obj_torus.znear=-20;
//				obj_torus.rendermode=1;
//				obj_torus.rendermode=2;
				obj_torus.rendermode=3; //tex

//				obj_torus.envmap=false; //envmap
				obj_torus.envmap=true; //envmap

				obj_torus.Show(primarylayer, SCREENBUFFER, 2, 0);//her
//				obj_torus.Show(primarylayer, SCREENBUFFER, 42, 0);//her
			}*/
			if (ftime>=147.5 && ftime<148.8) primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-((ftime-147.5)*255));
/*
font writer
			if (ftime>=149.5 && ftime<180.4)
			{
				layer_fonts.ClearBuffer(SCREENBUFFER, 0);
				layer_fonts.PutStringWithCursor(SCREENBUFFER, 0, 19, (ftime-149.5)*20, 0, 0.25);

//				float fti=fmod(ftime-112, 15);
//				if (fti>=10 && fti<15)

				//white first then go black
				if (ftime>=154)
					layer_fonts.Invert(SCREENBUFFER, SCREENBUFFER,255);

				primarylayer.CopyBufferLayer(0, layer_fonts, SCREENBUFFER);
				primarylayer.BlendMask(SCREENBUFFER, 0, 255);
			}*/


			
			if (ftime>=148.179 && ftime<(148.179+0.5))
			{
				int co=255-((ftime-148.179)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 192);
			}
			if (ftime>=149.213 && ftime<(149.213+0.5))
			{
				int co=255-((ftime-149.213)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}

			if (ftime>=150.255 && ftime<(150.255+0.5))
			{
				int co=255-((ftime-150.255)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}

			if (ftime>=151.308 && ftime<(151.308+0.5))
			{
				int co=255-((ftime-151.308)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=152.303 && ftime<(152.303+0.5))
			{
				int co=255-((ftime-152.303)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=153.345 && ftime<(153.345+0.5))
			{
				int co=255-((ftime-153.345)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=154.344 && ftime<(154.344+0.5))
			{
				int co=255-((ftime-154.344)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=155.387 && ftime<(155.387+0.5))
			{
				int co=255-((ftime-155.387)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=156.418 && ftime<(156.418+0.5))
			{
				int co=255-((ftime-156.418)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=157.455 && ftime<(157.455+0.5))
			{
				int co=255-((ftime-157.455)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=158.441 && ftime<(158.441+0.5))
			{
				int co=255-((ftime-158.441)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=159.457 && ftime<(159.457+0.5))
			{
				int co=255-((ftime-159.457)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=160.519 && ftime<(160.519+0.5))
			{
				int co=255-((ftime-160.519)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=161.527 && ftime<(161.527+0.5))
			{
				int co=255-((ftime-161.527)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=162.531 && ftime<(162.531+0.5))
			{
				int co=255-((ftime-162.531)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}
			if (ftime>=163.559 && ftime<(163.559+0.5))
			{
				int co=255-((ftime-163.559)*512);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}


			/*
			if (ftime<149.5)
			{
				int co=255-((ftime-147.5)*127.5);
				primarylayer.Noise(0, RGB32(co,co,co));
				primarylayer.BlendAdd(SCREENBUFFER, 0, 255);
			}*/
		}



//-----------------------------------------------------------------------------------------------
//bezier scene
//-----------------------------------------------------------------------------------------------

		if (0)//ftime>=164 && ftime<196.8)
		{
//			intro_scene.ClearBuffer(SCREENBUFFER, 0);
			intro_scene.ClearBuffer(SCREENBUFFER, 0x123256);
/*
			obj_geosphere.mLoadIdentity();
			obj_geosphere.Rotate(Vector3D(ftime*0.2,ftime*0.2,ftime*0.2));
			obj_geosphere.Translate(Vector3D(0,0,0));
			obj_geosphere.SetZSCALE(150); //FOV=45
			obj_geosphere.rendermode=4;
			obj_geosphere.envmap=false;
			obj_geosphere.znear=-10;
			obj_geosphere.SetColor(R3D_FLAT_SHADE, 0xffffff);
			obj_geosphere.culling=-1;
			obj_geosphere.Show(intro_scene, SCREENBUFFER, 0, 4);
*/
			//-----------------------------------------------------------------------------------------------
			//ROBOTHAND
			//-----------------------------------------------------------------------------------------------
			obj_robothand.mLoadIdentity();
			obj_robothand.Rotate(Vector3D(-M_PI+0.4,-0.2-M_PI2-ftime*(M_PI/8.86),0));
			obj_robothand.Translate(Vector3D(0,0,-150));
			obj_robothand.SetZSCALE(45); //FOV=45
			obj_robothand.rendermode=2;
			obj_robothand.envmap=false;
			obj_robothand.znear=-20;
			obj_robothand.SetColor(R3D_FLAT_SHADE, 0xffffff);
			obj_robothand.Show(intro_scene, SCREENBUFFER, 0, 4);

//			intro_scene.RadialBlur(SCREENBUFFER, 0.1+sin(ftime)*0.1);
			intro_scene.RadialBlur(SCREENBUFFER, 0.1);
			intro_scene.MotionBlur(SCREENBUFFER, 11, 2);//3);

			obj_robothandgrid.mLoadIdentity();
			obj_robothandgrid.Rotate(Vector3D(-M_PI+0.4,-0.2-M_PI2-ftime*(M_PI/8.86),0));
			obj_robothandgrid.Translate(Vector3D(0,0,-150));
			obj_robothandgrid.SetZSCALE(45); //FOV=45
			obj_robothandgrid.rendermode=4;
			obj_robothandgrid.envmap=false;
			obj_robothandgrid.znear=-20;
			obj_robothandgrid.SetColor(R3D_FLAT_SHADE, 0xffffff);
			obj_robothandgrid.Show(intro_scene, SCREENBUFFER, 0, 4);





//			Quad2D p[80*25];
			static int one=1;
			if (one)
			{
				for (int i=0; i<num_pois; i++)
				{
					p[i].p[0].x=rand()%320;
					p[i].p[0].y=rand()%200;
					p[i].p[1].x=rand()%320;
					p[i].p[1].y=rand()%200;
					p[i].p[2].x=rand()%320;
					p[i].p[2].y=rand()%200;
					p[i].p[3].x=rand()%320;
					p[i].p[3].y=rand()%200;
				}
				one=0;
			}
			for (i=0; i<num_pois-1; i++)
			{
				float zerone=(ftime-164)*0.25 + (i*0.0005208);
				if (zerone>=1) zerone=1;
				bezier(poi[i], p[i], zerone);

				intro_scene.PutBuffer(SCREENBUFFER, 4, poi[i].x, poi[i].y, 255);
			}
//			ans_show.MotionBlur(SCREENBUFFER, 256, 2);
//			ans_show.RadialBlurSubpixel(SCREENBUFFER, 320, 220, -0.004);//+sin(ftime)*0.01);
//			ans_show.FilterEdgeDetection(SCREENBUFFER, 256);
//			ans_show.DrawBox(SCREENBUFFER, rand()%200, rand()%200, rand()%200, rand()%200, 0xff0033);
//			ans_show.BlurH(SCREENBUFFER, SCREENBUFFER, rand()%100);

			primarylayer.CopyBufferLayer(SCREENBUFFER, intro_scene, SCREENBUFFER);
			
		}





//----------------------------------------------------------
//LYSEFFEKT UT AV OBJEKT (synes den er veldig t�ff � se p�)
//----------------------------------------------------------

		if (ftime>=164 && ftime<180.4)
		{
//			lightfxlayer.ClearBuffer(SCREENBUFFER, 0);
//			lightfxlayer.ClearBuffer(0, 0x2f3f4f);
//			lightfxlayer.ClearBuffer(0, 0);
//			lightfxlayer.ClearBuffer(1, 0);
			for (int i=0; i<32; i++)
			{
//				lightfxlayer.PutBuffer(0, 10,
//					140+cos(ftime*0.7+i*0.1)*i*0.7 + sin(ftime*0.6+i*0.2)*50,
//					90+sin(ftime*0.4+i*0.22)*i*0.8 + cos(ftime*0.8+i*0.1)*70,
//					sin(ftime*3 + i*0.2)*50, 127+sin(ftime+i*0.06)*127);
				lightfxlayer.PutBuffer(0, 5,
					140+cos(ftime*0.8+i*0.2)*50 + sin(ftime+i*0.3)*50,
					90+sin(ftime*0.6+i*0.3)*40 + cos(ftime*0.8+i*0.2)*70,
					sin(ftime*3 + i*0.2)*50, 127+sin(ftime*2+i)*127);

/*				lightfxlayer.PutBuffer(1, 5,
					140+cos(ftime*0.7+i*0.1)*i*0.7 + sin(ftime*0.6+i*0.2)*50,
					90+sin(ftime*0.4+i*0.22)*i*0.8 + cos(ftime*0.8+i*0.1)*70,
					sin(ftime*3 + i*0.2)*50, 127+sin(ftime+i*0.06)*127);*/
			}
			lightfxlayer.RadialBlur(0, 0.25+sin(ftime)*0.2);
//			lightfxlayer.MotionBlur(0,3, 2);
//			lightfxlayer.MotionBlur(1, 3, 3);
//			*lightfxlayer.buffer[0]-=lightfxlayer.buffer[1];
//			*lightfxlayer.buffer[0]+=lightfxlayer.buffer[1];

			//3,4,5,6, 9,10

//			lightfxlayer.ClearBuffer(4, 0);
			Vector3D rot, tra;
			rot.x=ftime*0.6;
			rot.y=-ftime*0.3;
			rot.z=sin(ftime*0.1)*M_2PI;

			obj_spike.mLoadIdentity();
			obj_spike.mRotate(rot);
			tra.x=0;
			tra.y=(ftime-164)*3;
//			tra.z=-150-(ftime-164)*100;
			tra.z=-150-(ftime-164)*100+sin(ftime)*100;
//			if (tra.z<-550) tra.z=-550;

			obj_spike.mTranslate(tra);
			obj_spike.rendermode=RENDERMODE_TEXTURE;//3;
//			obj_spike.octopus=false;
			obj_spike.SetColor(R3D_FLAT_SHADE, 0xffffff);
//			obj_spike.SetColor(R3D_FLAT_FIXED, 0xff7f7f);
//			obj_spike.Show(lightfxlayer, 4, 6, 0);


/*	      if(ftime>=0 && ftime<12.56)
		  {*/
			gridflat(grid, 0, 0);
//			gridflat(grid3, 0, 0);

			gridwave(grid, 1, ftime*10, 1);
//			gridsinus(grid3, 0.2f, 0.3f, -ftime*4, -ftime*2, 20);
//			gridlens(grid3, 8+sin(ftime*0.75)*8);

//			gridmorph(grid1, grid2, grid3, 0.5+sin(M_PI2+ftime*0.5)*0.5);
/*		}
		if(ftime>=12.56 && ftime<25.12)
		{
			gridflat(grid2, 0, 0);
			gridflat(grid3, 0, 0);

			gridsinus(grid2, 0.2f, 0.3f, -ftime*4, -ftime*2, 20);
			gridwave(grid2, 0.5f, ftime*10, 2);
			gridsinus(grid3, 0.2f, 0.3f, -ftime*4, -ftime*2, 20);
			gridlens(grid3, 8+sin(ftime*0.75)*8);

			gridmorph(grid1, grid2, grid3, 0.5+sin(M_PI2+ftime*0.5)*0.5);
		}*/
			grid.shade=false;
			gridexpander(lightfxlayer.buffer[4]->pixel, grid, lightfxlayer.buffer[8]->pixel);
//			grid.shade=true;
//			gridexpander(planecrazy.buffer[3]->pixel, grid, planecrazy.buffer[2]->pixel);


			obj_spike.mLoadIdentityN();
			obj_spike.mRotateN(rot);

//			obj_spike.envmap=false;
			obj_spike.envmap=true;
//			obj_spike.Show(lightfxlayer, 4, 8, 0);
			obj_spike.Show(lightfxlayer, 4, 6, 0);

			lightfxlayer.MotionBlur(4, 0, 2);
			
			

			if (ftime>=176.48)
				lightfxlayer.CrossFade(4,4,9, (ftime-176.48)*63.5);
//				lightfxlayer.CrossFade(4,4,9, (ftime-184)*63.5);

			lightfxlayer.RadialBlur(4, 0.01);
			lightfxlayer.CopyBuffer(SCREENBUFFER,4);

			if (ftime>=180.5 && ftime<181) lightfxlayer.CrossFade(SCREENBUFFER, WHITEBUFFER, SCREENBUFFER, (ftime-180.5)*512);
			

			//qwe
			primarylayer.CopyBufferArea(1, 8, 0, rand()%600);

			if (ftime>=172.37)
				primarylayer.BlendSub(SCREENBUFFER, 1, 255-(ftime-172.37)*63.7);
			else
				primarylayer.BlendSub(SCREENBUFFER, 1, 255);

			primarylayer.mainbuffer=lightfxlayer.mainbuffer;

			if (ftime>=164 && ftime<165) primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-((ftime-164)*255));
		}
//----------------------------------------------------------
//LYSEFFEKT UT AV OBJEKT (slutt)
//----------------------------------------------------------

//-----------------------------------------------------------------------------------------------
//ROTATE CUBES WITH LIGHTBACKGROUND
//-----------------------------------------------------------------------------------------------

	if (ftime>=180.4 && ftime<196.8)
	{
		g_clearz(WIDTH*HEIGHT);
//		intro_scene.ClearBuffer(SCREENBUFFER, 0);
		intro_scene.ClearBuffer(SCREENBUFFER, 0x294429);

		obj_cubes[0].mLoadIdentity();

		static int flat_flag=0,flat_color=0;

		flat_flag=R3D_FLAT_SHADE;
		flat_color=0xffffff;

		float ffx=sin(0.2+ftime*0.02)*cos(-ftime*0.03)*M_PI;
		float ffy=sin(0.4+ftime*0.01)*cos(ftime*0.02)*M_PI;
		float ffz=sin(0.3-ftime*0.03)*cos(-ftime*0.01)*M_PI;


		obj_cubes[0].mRotate(Vector3D(ffx,0,0)); //x
		obj_cubes[0].mRotate(Vector3D(0,ffy,0)); //y
		obj_cubes[0].mRotate(Vector3D(0,0,ffz)); //z

		float sxr,syr,szr;
		if (ftime<181.758)
		{
			sxr=syr=szr=0;
		}

		if (ftime>=181.758 && ftime<182.559) sxr=M_PI2;
		if (ftime>=182.559 && ftime<183.826) sxr=M_PI2*3;
//		if (ftime>=183.826 && ftime<184.635) sxr=M_PI2*3;
//		if (ftime>=184.635 && ftime<185.912) sxr=M_PI2*4;
		if (ftime>=185.912 && ftime<186.358) sxr=M_PI2*5;
		if (ftime>=185.912 && ftime<186.358) sxr=M_PI2;
		if (ftime>=186.358 && ftime<186.706) sxr=M_PI2*2;
/*		if (ftime>=186.706) {
			sxr=M_PI2*8;
		}*/
			
			
		obj_cubes[0].mRotate(Vector3D(ftime*0.2+sxr,0,0)); //x
		obj_cubes[0].mRotate(Vector3D(0,ftime*0.2+sxr,0)); //y
		obj_cubes[0].mRotate(Vector3D(0,0,ftime*0.2+sxr)); //z

		obj_cubes[0].SetZSCALE(120); //FOV=45
		obj_cubes[0].mTranslate(Vector3D(0,0,-400));

		obj_cubes[0].rendermode=2;
		obj_cubes[0].envmap=false;
		obj_cubes[0].znear=-10;

		obj_cubes[0].SetColor(R3D_FLAT_FIXED, 0);
		obj_cubes[0].Show(intro_scene, SCREENBUFFER, 0, 4);

		obj_cubes[0].SetColor(flat_flag, flat_color);
		obj_cubes[0].mTranslate(Vector3D(0,0,-cell_border));
//lights backgrounds

		primarylayer.CopyBuffer(SCREENBUFFER, 3);


		//dunk
		if (ftime<181.4)
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-180.4)*255);

		if (ftime>=181.798 && ftime<181.798+0.5)
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-181.798)*512);

		if (ftime>=182.554 && ftime<(182.554+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-182.554)*512);

		if (ftime>=183.831 && ftime<(183.831+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-183.831)*512);
		if (ftime>=184.615 && ftime<(184.615+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-184.615)*512);
		if (ftime>=185.841 && ftime<(185.841+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-185.841)*512);
		if (ftime>=186.277 && ftime<(186.277+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-186.277)*512);
		if (ftime>=186.651 && ftime<(186.651+0.5))
			primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, (ftime-186.651)*512);

		obj_cubes[0].Show(primarylayer, SCREENBUFFER, 0, 4);

		primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;

		//noize
		primarylayer.CopyBufferArea(1, 8, 0, rand()%600);
		primarylayer.BlendSub(SCREENBUFFER, 1, 255);
	}




//-----------------------------------------------------------------------------------------------
//avi scene / waterwall scene
//-----------------------------------------------------------------------------------------------
	if (ftime>=196.8 && ftime<213)
	{

//			, 201.001, 203.065, 205.114, 207.141, 209.161
//			if(ftime>=198.9)
			{
				grid.shade=false;//true;
				grid.fov=50;//+(ftime-196.8)*10;
				grid.offset=100;//+sin(ftime*2)*80;
//				freedirectional_plane(grid, Vector3D(0,0,ftime*500), Vector3D(0,0,90));
				freedirectional_plane(grid, Vector3D(0,0,ftime*500), Vector3D(0,0,0));

				grid.shade=false;
				gridexpander(planecrazy.buffer[0]->pixel, grid, planecrazy.buffer[5]->pixel);
				grid.shade=true;
				gridexpander(planecrazy.buffer[3]->pixel, grid, planecrazy.buffer[2]->pixel);
//				*planecrazy.buffer[0]|=planecrazy.buffer[3];	//m�rkt innover
				*planecrazy.buffer[0]-=planecrazy.buffer[3];	//m�rkt innover
//				*planecrazy.buffer[0]+=planecrazy.buffer[3];	//lyst innover
				waterscene.buffer[6]->pixel=planecrazy.buffer[0]->pixel;
//				waterscene.CrossFade(6,6,7, (ftime-198.9)*255);
			}


/*			
			int xr=rand()%320;
			for (y=0; y<200; y++) waterscene.buffer[1]->pixel[xr + y * 320]=rand()%255;
*/
			int yr=rand()%200;
			for (x=0; x<320; x++) waterscene.buffer[1]->pixel[x + yr * 320]=rand()%255;

			waterscene.RadialBlurSubpixel(1, 160, 100, -0.005);
			waterscene.Water2D(SCREENBUFFER, 0, 1, 6, 2);
			primarylayer=waterscene;
				g_line((int *)primarylayer.mainbuffer.pixel,0,0,319,0, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,0,199,319,199, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,0,0,0,199, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,319,0,319,199, 0);

		if (ftime<197.8) primarylayer.CrossFade(SCREENBUFFER, WHITEBUFFER, SCREENBUFFER, (ftime-196.8)*255);
	}

//-----------------------------------------------------------------------------------------------
//octopus scene
//-----------------------------------------------------------------------------------------------

	if (ftime>=213 && ftime<262.4)
	{
//		g_clearz(width_*height_);

		Vector3D rot, tra;

		float standstill=1; 
		float rxi;

		rxi=0;
//		if (ftime>=221.51) rxi=M_PI/2;
//		if (ftime>=225.62) rxi=M_PI;

/*		if (ftime>=181.5 && ftime<182.5)
		{
			rot.x=181.5*0.6;
			rot.y=181.5*0.7;
			rot.z=181.5*0.4;
		}
		else*/
		{
			rot.x=(ftime-1)*0.6+rxi;
			rot.y=(ftime-1)*0.7+rxi;
			rot.z=(ftime-1)*0.4+rxi;
		}

		tra.x=0;//+cos(1.5*ftime)*30;
/*
//		if (ftime>=51.88 && ftime<52.88)
*/


		//BOUNCE DOWN
//181.803, 182.521, 183.778, 184.562, 185.803, 186.302, 186.615, 188.774, 189.980, 190.736
		//215.4, 217.452
		if (ftime>=215.3 && ftime<216.3)
		{
			tra.y= - (1-(ftime-215.3))*35;//50;
		}
		else
		if (ftime>=217.2 && ftime<218.2)
		{
//			tra.y= - (1-(ftime-217.2))*35;//50;
			tra.z=-100 - (1-(ftime-(217.2)))*80;
		}
		else
/*		if (ftime>=219.4 && ftime<220.4)
		{
			tra.y= - (1-(ftime-219.4))*35;//50;
		}
		else*/
		{
			tra.y=0;
			tra.z=-180+80;
		}

		//bounce a bit backward to forward
//		if (ftime>=(180.4) && ftime<(181.4))
//			tra.z=-100 - (1-(ftime-(180.4)))*80;
//		else
/*		if (ftime>=(40+60.3) && ftime<(41+60.3))
			tra.z=-100 + (1-(ftime-(40+60.3)))*60;
		else
		if (ftime>=(64+60.3) && ftime<(65+60.3))
			tra.z=-100 - (1-(ftime-(64+60.3)))*100;
		else
		if (ftime>=(66+60.3) && ftime<(67+60.3))
			tra.z=-100 - (1-(ftime-(66+60.3)))*150;
		else*/
//			tra.z=-180+80;
//		tra.z=-130+sin(ftime)*50;

		obj_octopus.SetZSCALE(120-30);
		obj_octopus.mLoadIdentity();
		obj_octopus.mRotate(rot);
		obj_octopus.mTranslate(tra);

		obj_octopus.culling=-1;
		obj_octopus.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
		obj_octopus.color_dot_fixed=0xffffff;
		obj_octopus.znear=-20;
//		obj_octopus.rendermode=1;
//		obj_octopus.rendermode=2;
		obj_octopus.rendermode=RENDERMODE_TEXTURE; //tex

		obj_octopus.parsemode=0;
//		if (ftime<48) obj_octopus.rendermode=1+ (int)(fmod(ftime, 3));

		obj_octopus.envmap=false; //envmap
//		obj_octopus.envmap=true; //envmap
//		octopusscene.ClearBuffer(SCREENBUFFER, 0);
//		octopusscene.CopyBuffer(SCREENBUFFER, 10);
//		if (ftime<48)
//			octopusscene.CopyBufferArea(SCREENBUFFER, 20, 0, 205-((int)(ftime*20)%206));
//		else
			octopusscene.CopyBufferArea(SCREENBUFFER, 2, (int)(ftime*20)%1024, 0);

		if (ftime>=215.2 && ftime<216.2) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-(215.2))*255));

		//smash
//		if (ftime>=48 && ftime<49) octopusscene.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-48)*255));

//		if (ftime>=(48+60.3) && ftime<(49+60.3)) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-48)*255));

//		if (ftime>=(180.4))
//		if (ftime>=181.746)
//			obj_octopus.octopus=true;
//		else
//			obj_octopus.octopus=false;

//		if (ftime>=32)
//			obj_octopus.Show(octopusscene, SCREENBUFFER, 1, 0, 0);
//			obj_octopus.Show(octopusscene, SCREENBUFFER, 6, 0, 0);//squidish
			obj_octopus.Show(octopusscene, SCREENBUFFER, 1, 0);//goldish
//			obj_octopus.Show(octopusscene, SCREENBUFFER, 8, 0, 0);//



			if (ftime>=222 && ftime<242)
			{
				layer_fonts.ClearBuffer(SCREENBUFFER, 0);
				layer_fonts.PutStringWithCursor(SCREENBUFFER, 0, 19, (ftime-222)*10, 0, 0.25);

				//white first then go black
//				layer_fonts.Invert(SCREENBUFFER, SCREENBUFFER,255);

				octopusscene.CopyBufferLayer(0, layer_fonts, SCREENBUFFER);
				octopusscene.BlendMask(SCREENBUFFER, 0, 255);
			}



	//particle obj
/*		obj_octopus.rendermode=4;
		obj_octopus.Show(octopusscene, SCREENBUFFER, 0, 6);//goldish
		*/

//		octopusscene.RadialBlurSubpixel(SCREENBUFFER, 160, 100, -0.02);
//		octopusscene.MotionBlur(SCREENBUFFER,0,2);
/*
//show gray image of octopuss
		if (ftime>=181.5 && ftime<182.5)
		{
			octopusscene.CopyBuffer(SCREENBUFFER, 5);
		}*/

		int inc;
		inc=(int)(ftime*10);
		inc=inc%4;
		inc=0;

//		if (ftime>=8) //31
//		if ( (ftime>=(39.75+60.3) && ftime<(41.25+60.3)) ||
//			 (ftime>=(44+60.3) && ftime<(46+60.3)) ||
//			 (ftime>=(48+60.3) && ftime<(71.5+60.3)) ||
//			 (ftime>=(73.5+60.3)) )
		{
			octopusscene.CopyBufferArea(4, 3, 0, rand()%600);
//			octopusscene.BlendSub(SCREENBUFFER, 11+inc, 255);
			octopusscene.BlendAdd(SCREENBUFFER, 4, 255);
			octopusscene.CopyBufferArea(4, 3, 0, rand()%600);
			octopusscene.BlendSub(SCREENBUFFER, 4, 255);
		}

		
		
/*		if (ftime>=221.455 && ftime<229.689)
		{
			//timer-settings for avi.
			tickCount=GetTickCount();
			milliseconds=(tickCount-lasttickCount);
			next+=milliseconds;		// Increase next Based On Timer (Milliseconds)
			lasttickCount=GetTickCount();
			aviframe=next/mpf;				// Calculate The Current Frame
			if (aviframe>=lastframe)		// Have We Gone Past The Last Frame?
			{
				aviframe=0;				// Reset The Frame Back To Zero (Start Of Video)
				next=0;					// Reset The Animation Timer (next)
			}
			avilayer.GrabAVIFrame(SCREENBUFFER, aviframe);
			octopusscene=avilayer;
		}*/
	

		
		if (ftime>=219.4 && ftime<220.4) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-(219.4))*255));
	
		if (ftime>=213 && ftime<214) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-((ftime-(213))*255));

/*		if (ftime>=(32+60.3) && ftime<(33+60.3)) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-(32+60.3))*255));
		if (ftime>=(36+60.3) && ftime<(37+60.3)) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-(36+60.3))*255));
		if (ftime>=(40+60.3) && ftime<(41+60.3)) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-((ftime-(40+60.3))*255));
		if (ftime>=(51.88+60.3) && ftime<(52.88+60.3)) octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, 255-((ftime-(51.88+60.3))*255));

		if (ftime>=(44+60.3) && ftime<(45+60.3))
			octopusscene.Invert(SCREENBUFFER, SCREENBUFFER, 255-((ftime-(44+60.3))*255));

		if (ftime>=(71.5+60.3) && ftime<(73.5+60.3))
		{
//			BASS_ChannelSlideAttributes(music.str?music.str:music.mod,1000,-1,-101,1000);
//			Sleep(300);
			// ...and fade-out to avoid a "click"
//			BASS_ChannelSlideAttributes(str?str:mod,-1,-2,-101,200);
//			while (BASS_ChannelIsSliding(str?str:mod)) Sleep(1);

			octopusscene.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-((ftime-(71.5+60.3))*127.5));
		}
//		if (ftime>=73.5 && ftime<75.5)
//			BASS_ChannelSlideAttributes(music.str?music.str:music.mod, 44000, 100, 0, 1000);
*/

/*
//transition fx
		if (ftime<(23.5+60.3))
		{
			octopusscene.CopyBufferLayer(19, transitionlayer, SCREENBUFFER);
			octopusscene.TransitionThreshold(SCREENBUFFER, 19, 17, 255-(ftime-(21.5+60.3))*127.5);
		}
		//transition
		if (ftime>=(77.5+60.3)) transitionlayer.CopyBufferLayer(SCREENBUFFER, octopusscene, SCREENBUFFER);
*/

		primarylayer.mainbuffer.pixel=octopusscene.mainbuffer.pixel;

//
//text floating over screen
//

/*
		textfloat.ClearBuffer(SCREENBUFFER, 0);
		if (ftime>=5 && ftime<7) textfloat.PutBuffer(SCREENBUFFER, 1, 10+(ftime-5)*6,54);
		if (ftime>=7 && ftime<9) textfloat.PutBuffer(SCREENBUFFER, 2, 68+(ftime-7)*6,54);
		if (ftime>=9 && ftime<11) textfloat.PutBuffer(SCREENBUFFER, 3, 107+(ftime-9)*6,54);

		primarylayer.CopyBufferLayer(0, textfloat, SCREENBUFFER);

		if (ftime>=5 && ftime<6) primarylayer.BlendMask(SCREENBUFFER, 0, (ftime-5)*255);
		if (ftime>=6 && ftime<7) primarylayer.BlendMask(SCREENBUFFER, 0, 255-(ftime-6)*255);
		if (ftime>=7 && ftime<8) primarylayer.BlendMask(SCREENBUFFER, 0, (ftime-7)*255);
		if (ftime>=8 && ftime<9) primarylayer.BlendMask(SCREENBUFFER, 0, 255-(ftime-8)*255);
		if (ftime>=9 && ftime<10) primarylayer.BlendMask(SCREENBUFFER, 0, (ftime-9)*255);
		if (ftime>=10 && ftime<11) primarylayer.BlendMask(SCREENBUFFER, 0, 255-(ftime-10)*255);
*/
			if (ftime>=261.4 && ftime<262.4) primarylayer.CrossFade(SCREENBUFFER, SCREENBUFFER, BLACKBUFFER, (ftime-261.4)*255);

		if (ftime>=260)
		{
			waterscene.ClearBuffer(0,0);
			waterscene.ClearBuffer(1,0);
		}
	}

//-----------------------------------------------------------------------------------------------
//water scene
//-----------------------------------------------------------------------------------------------

		if (ftime>=262.4)
//		if (ftime>=164)
		{
/*			int rx=rand()%320;
			int ry=rand()%200;
//			waterscene.buffer[1]->pixel[rx + ry * 320]=rand()%255;
//			waterscene.buffer[1]->pixel[rx+1 + ry * 320]=rand()%255;
//			waterscene.buffer[1]->pixel[160 + (int)(cos(ftime*0.5)*70) + (100 + (int)(sin(ftime*0.5)*70)) *320]=255;//RGB32(255,255,255);
//			waterscene.buffer[1]->pixel[rx + (ry+1) * 320]=255;
//			waterscene.buffer[1]->pixel[rx+1 + (ry+1) * 320]=255;
			int xr=rand()%320;
			int yr=rand()%200;
//			g_line((int*)waterscene.buffer[1]->pixel,0, yr,320,yr,320,0x7f7f7f);
//			xr=160+(int)(sin(ftime*2)*159);
			yr=100+(int)(sin(ftime*3)*99);
//			for (x=0; x<320; x++) waterscene.buffer[1]->pixel[x + yr * 320]=rand()%255;
			for (y=0; y<200; y++) waterscene.buffer[1]->pixel[xr + y * 320]=rand()%255;
//			g_line((int*)waterscene.buffer[1]->pixel,0, yr,320,yr,320,0x7f7f7f);
//			waterscene.MotionBlur(1,0,2);
*/
/*
		gridflat(grid, 0, 0);
//		gridwtf(grid, (ftime-71)*2);
//		gridwave(grid, 0.5, ftime*4, 1);
//		gridsinus(grid, 0.15, 0.2, ftime*4, ftime*3, 15,0);
//		gridcosinus(grid, 0.25, 0.2, ftime*4, ftime*3, 0, 25);
//		gridwrap(grid);
//		gridwave(grid, 0.5, ftime*4, 1);
		freedirectional_tunnel2(grid, Vector3D(0,0,ftime*40), Vector3D(2,2,4));
		gridexpander2(waterscene.buffer[2]->pixel, grid, waterscene.buffer[3]->pixel);
*/
/*
//			waterscene.Blur(1,1);
//			waterscene.RadialBlur(1, 0.02);
//			waterscene.RadialBlurSubpixel(1, 160, 100, 0.01);
//			waterscene.RadialBlurSubpixel(1, 160+cos(ftime)*100, 100+sin(ftime)*70, -0.005);
			waterscene.RadialBlurSubpixel(1, 160, 100, -0.005);
//			waterscene.BlurH(1,1,2+sin(ftime*3)*2);
			waterscene.Water2D(SCREENBUFFER, 0, 1, 2);
//			waterscene.CopyBuffer(SCREENBUFFER, 1);
//			waterscene.CopyBuffer(SCREENBUFFER, 0);

			primarylayer.mainbuffer.pixel=waterscene.mainbuffer.pixel;
*/

/*
//
//looks like a waterwall moving towards the screen always.
//
			int xr=rand()%320;
			for (y=0; y<200; y++) waterscene.buffer[1]->pixel[xr + y * 320]=rand()%255;
			waterscene.RadialBlurSubpixel(1, 160, 100, -0.005);
			waterscene.Water2D(SCREENBUFFER, 0, 1, 2);
//			primarylayer.mainbuffer.pixel=waterscene.mainbuffer.pixel;

//
//looks like a waterwall moving towards the screen always. (END)
//
*/
/*
			int rx=rand()%320;
			int ry=rand()%200;
			waterscene.buffer[1]->pixel[rx + ry * 320]=255;
			waterscene.buffer[1]->pixel[rx+1 + ry * 320]=255;
//			waterscene.buffer[1]->pixel[rx + (ry+1) * 320]=255;
			waterscene.buffer[1]->pixel[rx+1 + (ry+1) * 320]=255;
			waterscene.Water2D(SCREENBUFFER, 0, 1, 2);
*/


//			waterscene.ClearBuffer(0,0);
//			waterscene.ClearBuffer(1,0);

//		if (ftime>=270.3 && ftime<272.9)
		if (ftime>=270.3 && ftime<274.9)
		{
			int rx=rand()%320;
			int ry=rand()%200;
/*
			waterscene.buffer[1]->pixel[rx + ry * 320]=255;
			waterscene.buffer[1]->pixel[rx+1 + ry * 320]=255;
			waterscene.buffer[1]->pixel[rx + (ry+1) * 320]=255;
			waterscene.buffer[1]->pixel[rx+1 + (ry+1) * 320]=255;*/
			waterscene.PutBuffer(1, 4, rx, ry,255);
		}

//			waterscene.PutBuffer(1, 4, 159+(int)(cos(ftime*0.5)*70), 100 + (int)(sin(ftime*0.5)*70), 127+(int)(sin(ftime+cos(ftime*0.3)*3)*127));
//			waterscene.PutBuffer(1, 4, 159+(int)(cos(ftime*0.5)*70), 100 + (int)(sin(ftime*0.5)*70), 255);

//			if (ftime>=270.3)
//				waterscene.PutBuffer(1, 5, 159+(int)(cos(ftime*0.5)*70), 100 + (int)(sin(ftime*0.25)*30), 127+(int)(cos(ftime+cos(ftime*0.4)*2)*127));

//		for (i=0; i<4; i++)
//		{
			int dix=159 + (int)(cos(ftime*0.5)*70);
			int diy=100 + (int)(sin(ftime*0.5)*70);

			waterscene.buffer[1]->pixel[dix + diy*320]=255;
			waterscene.buffer[1]->pixel[dix+1 + diy*320]=255;
			waterscene.buffer[1]->pixel[dix + (diy+1)*320]=255;
			waterscene.buffer[1]->pixel[dix+1 + (diy+1)*320]=255;
//		}

//			waterscene.buffer[1]->pixel[159 + (int)(cos(ftime*0.5)*70) + (100 + (int)(sin(ftime*0.5)*70)) *320]=255;//RGB32(255,255,255);


/*
			int xr=rand()%320;
			int yr=rand()%200;
//			g_line((int*)waterscene.buffer[1]->pixel,0, yr,320,yr,320,0x7f7f7f);
//			xr=160+(int)(sin(ftime*2)*159);
			yr=100+(int)(sin(ftime*3)*99);
			*/
//			for (x=0; x<320; x++) waterscene.buffer[1]->pixel[x + yr * 320]=rand()%255;
//			for (y=0; y<200; y++) waterscene.buffer[1]->pixel[xr + y * 320]=rand()%255;
//			g_line((int*)waterscene.buffer[1]->pixel,0, yr,320,yr,320,0x7f7f7f);
//			waterscene.MotionBlur(1,0,2);

//			waterscene.CopyBuffer(7,2);
//			waterscene.PutBuffer(7, 8, 319-155 -30+sin(ftime*0.25)*35, 199-138 -30+cos(ftime*0.35)*20, 255);

			//
			waterscene.CopyBuffer(12,2);

			if (ftime>=275.551 && ftime<280.773)
				waterscene.BlendMask(12, 8, (ftime-275.551)*63.75);
			else
			if (ftime>=280.773)
				 waterscene.BlendMask(12, 8, 255-(ftime-280.773)*63.75);


			if ( (ftime>=(275.551+0.75)) && (ftime<(280.773+0.75)) )
				waterscene.BlendMask(12, 9, (ftime-(275.551+0.75))*63.75);
			else
			if (ftime>=(280.773+0.75)) waterscene.BlendMask(12, 9, 255-(ftime-(280.773+(0.75*1)))*63.75);


			if ( (ftime>=(275.551+(0.75*2))) && (ftime<(280.773+(0.75*2))) )
				waterscene.BlendMask(12, 10, (ftime-(275.551+(0.75*2)))*63.75);
			else
			if (ftime>=(280.773+(0.75*2))) waterscene.BlendMask(12, 10, 255-(ftime-(280.773+(0.75*2)))*63.75);


			if ( (ftime>=(275.551+(0.75*3))) && (ftime<(280.773+(0.75*3))) )
				waterscene.BlendMask(12, 11, (ftime-(275.551+(0.75*3)))*63.75);
			else
			if (ftime>=(280.773+(0.75*3))) waterscene.BlendMask(12, 11, 255-(ftime-(280.773+(0.75*3)))*63.75);
/*
			if (ftime<280.773)
			if (ftime<(280.773+0.75)) waterscene.BlendMask(12, 9, 255-(ftime-(280.773+(0.75*1)))*63.75);
			if (ftime<(280.773+(0.75*2))) waterscene.BlendMask(12, 10, 255-(ftime-(280.773+(0.75*2)))*63.75);
			if (ftime<(280.773+(0.75*3))) waterscene.BlendMask(12, 11, 255-(ftime-(280.773+(0.75*3)))*63.75);
*/
				waterscene.Water2D(SCREENBUFFER, 0, 1, 12, 4);


			Vector3D rot, tra;

			rot.x=cos(ftime*0.8+1)*0.1;
			rot.y=-ftime*1.3;
			rot.z=sin(ftime)*0.11;

			tra.x=6 + 25+sin(ftime*0.2)*2;
			tra.y=0;//+sin(ftime)*20;
			tra.z=-75 + sin(ftime)*8;	

			obj_spring.znear=-15;
			obj_spring.SetZSCALE(120-30);
			obj_spring.mLoadIdentity();
			obj_spring.mRotate(rot);
			obj_spring.mTranslate(tra);

			obj_spring.mLoadIdentityN();
			obj_spring.mRotateN(rot);

//			obj_spring.SetColor(R3D_FLAT_SHADE, RGB32(192+(int)(cos(ftime)*32), 195, 127+(int)(sin(ftime)*32)));
			obj_spring.rendermode=RENDERMODE_TEXTURE; //tex
			obj_spring.envmap=true; //envmap

//			waterscene.CopyBuffer(SCREENBUFFER,2);

//			obj_spring.octopus=false;
			obj_spring.Show(waterscene, SCREENBUFFER, 3, 0);

//			waterscene.Stretch(1, SCREENBUFFER, 0, 0, 10+sin(ftime)*8);
//			waterscene.Bounce(SCREENBUFFER, 1);
//			waterscene.CopyBuffer(SCREENBUFFER,1);
/*
			if (ftime<79.5)
			{
				waterscene.CopyBuffer(SCREENBUFFER, 6);
				waterscene.CopyBufferLayer(4, transitionlayer, SCREENBUFFER);
				waterscene.TransitionThreshold(SCREENBUFFER, 4, 5, 255-(ftime-77.5)*127.5);
			}
			else
				if (ftime>=79.5 && ftime<80.0)
					waterscene.CopyBuffer(SCREENBUFFER, 6);
*/

			
			

//		primarylayer.mainbuffer.pixel=intro_scene.mainbuffer.pixel;
			
			
			
			
			if (ftime>=262.4 && ftime<264.4)
				waterscene.CrossFade(SCREENBUFFER, SCREENBUFFER, WHITEBUFFER, 255-(ftime-262.4)*127.5);


			g_line((int *)waterscene.mainbuffer.pixel, 0, 0, 320, 0, 0);
			g_line((int *)waterscene.mainbuffer.pixel, 0, 0, 0, 200, 0);
			g_line((int *)waterscene.mainbuffer.pixel, 0, 200, 320, 200, 0);
			g_line((int *)waterscene.mainbuffer.pixel, 320, 0, 320, 200, 0);

			primarylayer.mainbuffer.pixel=waterscene.mainbuffer.pixel;

				g_line((int *)primarylayer.mainbuffer.pixel,0,0,319,0, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,0,199,319,199, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,0,0,0,199, 0);
				g_line((int *)primarylayer.mainbuffer.pixel,319,0,319,199, 0);

			if (ftime>=281)// && ftime<=285)
				primarylayer.CrossFade(SCREENBUFFER, BLACKBUFFER, SCREENBUFFER, 255-((ftime-281)*61));
		}
//
//
//



//	primarylayer.geff_blur_fast_vert(SCREENBUFFER, SCREENBUFFER, 320, 200, 124+sin(ftime*10)*124);
//	primarylayer.geff_blur_fast_horiz(SCREENBUFFER, SCREENBUFFER, 320, 200, 124+sin(ftime*10)*124);














/*		tunnel_scene.BumpMap(4, 1, 2, 3, cos(ftime)*110, sin(ftime)*90);

//		tunnel_scene.GridExpander(
		grid.offset=100;
		grid.radius=300;
		grid.fov=28;
		grid.shade=false;
//		freedirectional_plane(grid, Vector3D(10,10,ftime*250), Vector3D(0,0,10));
		freedirectional_tunnel(grid, Vector3D(10,10,ftime*250), Vector3D(0,0,10));
		gridexpander(tunnel_scene.mainbuffer.pixel, grid, tunnel_scene.buffer[4]->pixel);
//		grid.shade=true;
//		gridexpander(tunnel_scene.buffer[0]->pixel, grid, tunnel_scene.buffer[4]->pixel);
//		tunnel_scene.mainbuffer-=tunnel_scene.buffer[0];
//		tunnel_scene.PutBuffer(SCREENBUFFER, 4, 0, 0);

		primarylayer.mainbuffer.pixel=tunnel_scene.mainbuffer.pixel;
*/
//
//
//
#ifdef FPS_IN_TITLE
		//
		//fps
		//
		fps_end=clock();
		float fps=(float)(fps_frames*CLOCKS_PER_SEC) / (fps_end-fps_start);
	
		char str[10], stri[4];

		memset(str, 0, 10);
		memset(stri, 0, 4);
		itoa((int)fps, stri, 10);
//		strncpy(stri, , stri, 10);
		strncpy(str, "fps: ",5);
		strcat(str, stri);
//		memset(str, 0, 64);
//		strncpy(str, " (    ) ",8);
//		strcat(str, " (  )");
		WriteTitleBar(str);
#endif
//
//fake interlaced mode
//
		unsigned int *frombuf;
		unsigned int *tobuf;
		frombuf=screenlayer.mainbuffer.pixel;
		tobuf=primarylayer.mainbuffer.pixel;
		int yaddr,yaddr2;

		float fx,fy;
		int d;
		int xaddr;
//		yaddr=40*640;
		yaddr2=0;

		//big blocks (x2)
		fy=0;
		for (y=0; y<400; y++, fy+=0.5)
		{
			yaddr=y*640;
			fx=0;
			yaddr2=(int)((y>>1)*320);
//			yaddr2=(int)((y*0.5)*320);
			for (x=0; x<640; x++, fx+=0.5) frombuf[25600+x+yaddr]=tobuf[(int)fx+yaddr2];
		}

		//removed interlacing filter because I want it to be my own.

		wnd_update(screenlayer.mainbuffer.pixel);
//		ptc_update(primarylayer.mainbuffer.pixel);
	}

//	FreeMem();
	timer_end("output.ytx");
//	synchronisation_logger("synchronisation.ytx");
//    ptc_close();
	ExitProcess(0);
}

void FreeMem()
{
//	free_zbuffer();
//	object.Free();
/*	object2.Free();
	object3.Free();
	object4.Free();
	object5.Free();*/
//	layer_credits.Free();
//	primarylayer.Free();
//	noiselayer.Free();
//FILE *f=fopen("bajs.txt", "w"); fclose(f);
	//noe feil med fri'ing av minne
//	layer.Free();
//	layer.FreeTunnel();

#ifdef _BASS_LIB_
	music.Free();
#endif
}
