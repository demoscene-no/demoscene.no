#include "ypn_vertex.h"

Vertex::Vertex()
{

}

Vertex::~Vertex()
{

}
