#include "ypn_face.h"

Face::Face()
{

}

Face::~Face()
{

}

void Face::Set(unsigned short _a, unsigned short _b, unsigned short _c)
{
	a=_a;
	b=_b;
	c=_c;
}

//SetEdge
void Face::SetSides(char _ab, char _bc, char _ca)
{
	ab=_ab;
	bc=_bc;
	ca=_ca;
}
