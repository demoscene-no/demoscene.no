#include "ypn_scene.h"

//the viewport is in our sense used within the screen-coordinates.
void Scene::SetViewport(int x, int y, int width, int height)
{
	viewport.x.min=x;
	viewport.y.min=y;
	viewport.x.max=width;
	viewport.y.max=height;
}

void Scene::SetFrustum(float left, float right, float bottom, float top, float near, float far)
{
	/*
	frustum.x.min=(int)left;
//	frustum.x.min=(int)left;
	frustum.z.min=(int)near;
	frustum.z.max=(int)far;*/
}

//fovy = field of view (y angle)
void Scene::SetPerspective(float fovy, float aspect, float near, float far)
{

}
