#include "ypn_zbuffer.h"

Zbuffer::Zbuffer()
{
	index=0;
	depth=0;
}

Zbuffer::~Zbuffer()
{

}
