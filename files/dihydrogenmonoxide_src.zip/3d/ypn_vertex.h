class Vertex
{
public:
	Vertex();
	~Vertex();
};

