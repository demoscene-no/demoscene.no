#ifndef _vector3d
#define _vector3d

class Vector3D
{
public:
	Vector3D();
	Vector3D(float _x, float _y, float _z);
	Vector3D(float _x, float _y, float _z, float _w);
	~Vector3D();

	inline Vector3D operator-(const Vector3D v) const { return Vector3D(x-v.x, y-v.y, z-v.z); }

	//cross product
	inline Vector3D operator^(const Vector3D v) const { return Vector3D(y*v.z-z*v.y,z*v.x-x*v.z,x*v.y-y*v.x); }

	void Set(float _x, float _y, float _z);
	void Set(float _x, float _y, float _z, float _w);
	void Add(Vector3D a);
	void Substract(Vector3D a);
	void Multiply(Vector3D a);
	void Multiply(float scalar);

	void RotateX(float theta);
	void RotateY(float theta);
	void RotateZ(float theta);

	float DistanceSqr();
	float Length();
	void Normalize();
	void LinearInterpolate(Vector3D a, float u);
	void CosineInterpolate(Vector3D a, Vector3D b, float x);
	Vector3D CosineInterpolateR(Vector3D a, Vector3D b, float x);
	void CubicInterpolate(Vector3D v0, Vector3D v1, Vector3D v2, Vector3D v3, float x);
	void Negate();

	//3d-components
	float x;
	float y;
	float z;

	//texture
	float u;
	float v;
	float w;

/*	//color
	float r;
	float g;
	float b;*/

//	float sqr_length;
};

float dot_product(Vector3D a, Vector3D b);
Vector3D cross_product(Vector3D a, Vector3D b);

typedef struct
{
	Vector3D vec;
	int index;
} Normal;


class Point
{
public:
	Point();
	Point(float _x, float _y, float _z);
	~Point();

	float x;
	float y;
	float z;
};

#endif