#include "../CommonHeaders/ypn_common.h"

struct Viewport
{
	MinMax x,y;
};
/*
struct Frustum
{
	MinMax x,y,z;
};
*/
typedef struct
{
	MinMax x,y,z;
} Frustum;

class Scene
{
public:

	Scene();
	~Scene();

	//Viewport
	void SetViewport(int x, int y, int width, int height);
	Viewport viewport;

	//Window
	void SetFrustum(float left, float right, float bottom, float top, float near, float far);
	Frustum frustum;

	void SetPerspective(float fovy, float aspect, float near, float far);
};

/*
clipping - best done in screenspace before perspective divide.

//
what we want to do is to clip against a homogeneous set of clipping rules:

-w < x < w
-w < y < w
0 < z < w
*/
