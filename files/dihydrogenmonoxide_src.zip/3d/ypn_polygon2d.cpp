#include "ypn_polygon.h"

Polygon::Polygon()
{
	points=0;
	num_points=0;
}

Polygon::~Polygon()
{
//	free(points);
}

void Polygon::Reset()
{
	points=0;
	num_points=0;
}

void Polygon::AddPoint(int x, int y)
{
	num_points++;
	points=(Coord2D *)realloc(points, num_points*sizeof(Coord2D));
	points[num_points-1].x=x;
	points[num_points-1].y=y;
}

int Polygon::GetNumPoints()
{
	return num_points;
}

void Polygon::DrawLine(uint *pixel, int col)
{
	/*
//	if (ab==1)
	if (visible(points[0].x,points[0].y) && visible(points[1].x,points[1].y))
		g_line((int*)pixel,points[0].x, points[0].y, points[1].x, points[1].y, col);

//	if (bc==1)
	if (visible(points[1].x,points[1].y) && visible(points[2].x,points[2].y))
		g_line((int*)pixel,points[1].x, points[1].y, points[2].x, points[2].y, col);

//	if (ca==1)
	if (visible(points[2].x,points[2].y) && visible(points[0].x,points[0].y))
		g_line((int*)pixel,points[2].x, points[2].y, points[0].x, points[0].y, col);
*/

	//a polygon has N edges.
	//
	//an edge has a flag: on(1) or off(0)
	//
	//the same as a face has A,B,C edges - ab,bc,ca flags.
	//
/*	for (int i=0; i<num_edges; i++)
	{
		if (edge[i].flag==1)
		{
			if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
				g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);
		}

	}*/

	for (int i=0; i<num_points; i++)
	{
		if (i<(num_points-1))
		{
//			if (i==0 && ab==1)
				if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
					g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);//0x0000ff);
//			if (i==1 && bc==1)
				if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
					g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);//0x00ff00);
		}
		//last edge connected
		else
		{
			if (visible(points[num_points-1].x,points[num_points-1].y) && visible(points[0].x,points[0].y))
				g_line((int*)pixel,points[num_points-1].x, points[num_points-1].y, points[0].x, points[0].y, col);//0xff0000);
		}
	}
}

void Polygon::DrawTriFill(uint *pixel, int col)
{
	//quick and easy polygon tesselation
	for (int i=0; i<num_points-2; i++)
	{
//		if (visible(points[0].x,points[0].y) && visible(points[i+1].x,points[i+1].y) && visible(points[i+2].x,points[i+2].y))
		g_tri_flat((int*)pixel,
			points[0].x, points[0].y,
			points[i+1].x, points[i+1].y,
			points[i+2].x, points[i+2].y, col);
	}
}
