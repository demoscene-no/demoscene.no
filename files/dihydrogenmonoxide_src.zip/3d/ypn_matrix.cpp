#include "ypn_vector3d.h"
#include "ypn_matrix.h"

CMatrix::CMatrix()
{

}

CMatrix::~CMatrix()
{

}

CMatrix CMatrix::operator*(const CMatrix m) const
{
//	float tempMatrix[16];
	CMatrix temp;

	temp.Matrix[0]=Matrix[0]*m.Matrix[0] + Matrix[1]*m.Matrix[4] + Matrix[2]*m.Matrix[8] + Matrix[3]*m.Matrix[12];
	temp.Matrix[1]=Matrix[0]*m.Matrix[1] + Matrix[1]*m.Matrix[5] + Matrix[2]*m.Matrix[9] + Matrix[3]*m.Matrix[13];
	temp.Matrix[2]=Matrix[0]*m.Matrix[2] + Matrix[1]*m.Matrix[6] + Matrix[2]*m.Matrix[10] + Matrix[3]*m.Matrix[14];
	temp.Matrix[3]=Matrix[0]*m.Matrix[3] + Matrix[1]*m.Matrix[7] + Matrix[2]*m.Matrix[11] + Matrix[3]*m.Matrix[15];

	temp.Matrix[4]=Matrix[4]*m.Matrix[0] + Matrix[5]*m.Matrix[4] + Matrix[6]*m.Matrix[8] + Matrix[7]*m.Matrix[12];
	temp.Matrix[5]=Matrix[4]*m.Matrix[1] + Matrix[5]*m.Matrix[5] + Matrix[6]*m.Matrix[9] + Matrix[7]*m.Matrix[13];
	temp.Matrix[6]=Matrix[4]*m.Matrix[2] + Matrix[5]*m.Matrix[6] + Matrix[6]*m.Matrix[10] + Matrix[7]*m.Matrix[14];
	temp.Matrix[7]=Matrix[4]*m.Matrix[3] + Matrix[5]*m.Matrix[7] + Matrix[6]*m.Matrix[11] + Matrix[7]*m.Matrix[15];

	temp.Matrix[8]=Matrix[8]*m.Matrix[0] + Matrix[9]*m.Matrix[4] + Matrix[10]*m.Matrix[8] + Matrix[11]*m.Matrix[12];
	temp.Matrix[9]=Matrix[8]*m.Matrix[1] + Matrix[9]*m.Matrix[5] + Matrix[10]*m.Matrix[9] + Matrix[11]*m.Matrix[13];
	temp.Matrix[10]=Matrix[8]*m.Matrix[2] + Matrix[9]*m.Matrix[6] + Matrix[10]*m.Matrix[10] + Matrix[11]*m.Matrix[14];
	temp.Matrix[11]=Matrix[8]*m.Matrix[3] + Matrix[9]*m.Matrix[7] + Matrix[10]*m.Matrix[11] + Matrix[11]*m.Matrix[15];

	temp.Matrix[12]=Matrix[12]*m.Matrix[0] + Matrix[13]*m.Matrix[4] + Matrix[14]*m.Matrix[8] + Matrix[15]*m.Matrix[12];
	temp.Matrix[13]=Matrix[12]*m.Matrix[1] + Matrix[13]*m.Matrix[5] + Matrix[14]*m.Matrix[9] + Matrix[15]*m.Matrix[13];
	temp.Matrix[14]=Matrix[12]*m.Matrix[2] + Matrix[13]*m.Matrix[6] + Matrix[14]*m.Matrix[10] + Matrix[15]*m.Matrix[14];
	temp.Matrix[15]=Matrix[12]*m.Matrix[3] + Matrix[13]*m.Matrix[7] + Matrix[14]*m.Matrix[11] + Matrix[15]*m.Matrix[15];

//	memcpy(&Matrix, tempMatrix, sizeof(float)*16);
//	Matrix=temp;

	return temp;
}

void CMatrix::operator=(const CMatrix m)
{
	for (int i=0; i<16; i++) Matrix[i]=m.Matrix[i];
}

void CMatrix::PreTranspose(Vector3D *v)
{
	Matrix[12]=Matrix[0]*v->x + Matrix[4]*v->y + Matrix[8]*v->z;
	Matrix[13]=Matrix[1]*v->x + Matrix[5]*v->y + Matrix[9]*v->z;
	Matrix[14]=Matrix[2]*v->x + Matrix[6]*v->y + Matrix[10]*v->z;
}

void CMatrix::LoadIdentity()
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=0;	Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=0;	Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=1;	Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;
}

void CMatrix::CreateTranslationMatrix(Vector3D translation)
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=0;	Matrix[12]=translation.x;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=0;	Matrix[13]=translation.y;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=1;	Matrix[14]=translation.z;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;
}

void CMatrix::CreateScalingMatrix(Vector3D scaling)
{
	Matrix[0]=scaling.x;	Matrix[4]=0;			Matrix[8]=0;			Matrix[12]=0;
	Matrix[1]=0;			Matrix[5]=scaling.y;	Matrix[9]=0;			Matrix[13]=0;
	Matrix[2]=0;			Matrix[6]=0;			Matrix[10]=scaling.z;	Matrix[14]=0;
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=0;			Matrix[15]=1;
}

void CMatrix::CreateRotationMatrix(Vector3D rotation)
{
	CMatrix TempMatrix;
	CreateXRotationMatrix(rotation.x);
	TempMatrix.CreateYRotationMatrix(rotation.y);
	MultiplyMatrix(TempMatrix);
	TempMatrix.CreateZRotationMatrix(rotation.z);
	MultiplyMatrix(TempMatrix);
}

void CMatrix::CreateXRotationMatrix(float xrotation)
{
/*	Matrix[0]=1;	Matrix[4]=0;				Matrix[8]=0;				Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=cos(xrotation);	Matrix[9]=sin(xrotation);	Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=-sin(xrotation);	Matrix[10]=cos(xrotation);	Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;				Matrix[11]=0;				Matrix[15]=1;
*/
	//counter-clockwise in a right handed coordinate system
	Matrix[0]=1;	Matrix[4]=0;				Matrix[8]=0;				Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=cos(xrotation);	Matrix[9]=-sin(xrotation);	Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=sin(xrotation);	Matrix[10]=cos(xrotation);	Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;				Matrix[11]=0;				Matrix[15]=1;
}

void CMatrix::CreateYRotationMatrix(float yrotation)
{
/*	Matrix[0]=cos(yrotation);	Matrix[4]=0;	Matrix[8]=-sin(yrotation);	Matrix[12]=0;
	Matrix[1]=0;				Matrix[5]=1;	Matrix[9]=0;				Matrix[13]=0;
	Matrix[2]=sin(yrotation);	Matrix[6]=0;	Matrix[10]=cos(yrotation);	Matrix[14]=0;
	Matrix[3]=0;				Matrix[7]=0;	Matrix[11]=0;				Matrix[15]=1;
*/
	//counter-clockwise in a right handed coordinate system
	Matrix[0]=cos(yrotation);	Matrix[4]=0;	Matrix[8]=sin(yrotation);	Matrix[12]=0;
	Matrix[1]=0;				Matrix[5]=1;	Matrix[9]=0;				Matrix[13]=0;
	Matrix[2]=-sin(yrotation);	Matrix[6]=0;	Matrix[10]=cos(yrotation);	Matrix[14]=0;
	Matrix[3]=0;				Matrix[7]=0;	Matrix[11]=0;				Matrix[15]=1;
}

void CMatrix::CreateZRotationMatrix(float zrotation)
{
/*	Matrix[0]=cos(zrotation);	Matrix[4]=sin(zrotation);	Matrix[8]=0;	Matrix[12]=0;
	Matrix[1]=-sin(zrotation);	Matrix[5]=cos(zrotation);	Matrix[9]=0;	Matrix[13]=0;
	Matrix[2]=0;				Matrix[6]=0;				Matrix[10]=1;	Matrix[14]=0;
	Matrix[3]=0;				Matrix[7]=0;				Matrix[11]=0;	Matrix[15]=1;
*/
	//counter-clockwise in a right handed coordinate system
	Matrix[0]=cos(zrotation);	Matrix[4]=-sin(zrotation);	Matrix[8]=0;	Matrix[12]=0;
	Matrix[1]=sin(zrotation);	Matrix[5]=cos(zrotation);	Matrix[9]=0;	Matrix[13]=0;
	Matrix[2]=0;				Matrix[6]=0;				Matrix[10]=1;	Matrix[14]=0;
	Matrix[3]=0;				Matrix[7]=0;				Matrix[11]=0;	Matrix[15]=1;
}

void CMatrix::MultiplyMatrix(CMatrix fromMatrix)
{
	float tempMatrix[16];
	tempMatrix[0]=Matrix[0]*fromMatrix.Matrix[0] + Matrix[1]*fromMatrix.Matrix[4] + Matrix[2]*fromMatrix.Matrix[8] + Matrix[3]*fromMatrix.Matrix[12];
	tempMatrix[1]=Matrix[0]*fromMatrix.Matrix[1] + Matrix[1]*fromMatrix.Matrix[5] + Matrix[2]*fromMatrix.Matrix[9] + Matrix[3]*fromMatrix.Matrix[13];
	tempMatrix[2]=Matrix[0]*fromMatrix.Matrix[2] + Matrix[1]*fromMatrix.Matrix[6] + Matrix[2]*fromMatrix.Matrix[10] + Matrix[3]*fromMatrix.Matrix[14];
	tempMatrix[3]=Matrix[0]*fromMatrix.Matrix[3] + Matrix[1]*fromMatrix.Matrix[7] + Matrix[2]*fromMatrix.Matrix[11] + Matrix[3]*fromMatrix.Matrix[15];

	tempMatrix[4]=Matrix[4]*fromMatrix.Matrix[0] + Matrix[5]*fromMatrix.Matrix[4] + Matrix[6]*fromMatrix.Matrix[8] + Matrix[7]*fromMatrix.Matrix[12];
	tempMatrix[5]=Matrix[4]*fromMatrix.Matrix[1] + Matrix[5]*fromMatrix.Matrix[5] + Matrix[6]*fromMatrix.Matrix[9] + Matrix[7]*fromMatrix.Matrix[13];
	tempMatrix[6]=Matrix[4]*fromMatrix.Matrix[2] + Matrix[5]*fromMatrix.Matrix[6] + Matrix[6]*fromMatrix.Matrix[10] + Matrix[7]*fromMatrix.Matrix[14];
	tempMatrix[7]=Matrix[4]*fromMatrix.Matrix[3] + Matrix[5]*fromMatrix.Matrix[7] + Matrix[6]*fromMatrix.Matrix[11] + Matrix[7]*fromMatrix.Matrix[15];

	tempMatrix[8]=Matrix[8]*fromMatrix.Matrix[0] + Matrix[9]*fromMatrix.Matrix[4] + Matrix[10]*fromMatrix.Matrix[8] + Matrix[11]*fromMatrix.Matrix[12];
	tempMatrix[9]=Matrix[8]*fromMatrix.Matrix[1] + Matrix[9]*fromMatrix.Matrix[5] + Matrix[10]*fromMatrix.Matrix[9] + Matrix[11]*fromMatrix.Matrix[13];
	tempMatrix[10]=Matrix[8]*fromMatrix.Matrix[2] + Matrix[9]*fromMatrix.Matrix[6] + Matrix[10]*fromMatrix.Matrix[10] + Matrix[11]*fromMatrix.Matrix[14];
	tempMatrix[11]=Matrix[8]*fromMatrix.Matrix[3] + Matrix[9]*fromMatrix.Matrix[7] + Matrix[10]*fromMatrix.Matrix[11] + Matrix[11]*fromMatrix.Matrix[15];

	tempMatrix[12]=Matrix[12]*fromMatrix.Matrix[0] + Matrix[13]*fromMatrix.Matrix[4] + Matrix[14]*fromMatrix.Matrix[8] + Matrix[15]*fromMatrix.Matrix[12];
	tempMatrix[13]=Matrix[12]*fromMatrix.Matrix[1] + Matrix[13]*fromMatrix.Matrix[5] + Matrix[14]*fromMatrix.Matrix[9] + Matrix[15]*fromMatrix.Matrix[13];
	tempMatrix[14]=Matrix[12]*fromMatrix.Matrix[2] + Matrix[13]*fromMatrix.Matrix[6] + Matrix[14]*fromMatrix.Matrix[10] + Matrix[15]*fromMatrix.Matrix[14];
	tempMatrix[15]=Matrix[12]*fromMatrix.Matrix[3] + Matrix[13]*fromMatrix.Matrix[7] + Matrix[14]*fromMatrix.Matrix[11] + Matrix[15]*fromMatrix.Matrix[15];

	memcpy(&Matrix, tempMatrix, sizeof(float)*16);
}

Vector3D CMatrix::ApplyMatrix(Vector3D in)
{
	return Vector3D(in.x*Matrix[0] + in.y*Matrix[4] + in.z*Matrix[8] + Matrix[12],
					in.x*Matrix[1] + in.y*Matrix[5] + in.z*Matrix[9] + Matrix[13],
					in.x*Matrix[2] + in.y*Matrix[6] + in.z*Matrix[10] + Matrix[14]);
}

Particle3D *CMatrix::ApplyMatrixP3D(Particle3D *in)
{
	Particle3D *p;
	p->pos.x=in->pos.x*Matrix[0] + in->pos.y*Matrix[4] + in->pos.z*Matrix[8] + Matrix[12];
	p->pos.y=in->pos.x*Matrix[1] + in->pos.y*Matrix[5] + in->pos.z*Matrix[9] + Matrix[13];
	p->pos.z=in->pos.x*Matrix[2] + in->pos.y*Matrix[6] + in->pos.z*Matrix[10] + Matrix[14];
	return p;
}



Normal CMatrix::ApplyMatrix(Normal in)
{
	Normal normal;
	normal.vec.x=in.vec.x*Matrix[0] + in.vec.y*Matrix[4] + in.vec.z*Matrix[8] + Matrix[12];
	normal.vec.y=in.vec.x*Matrix[1] + in.vec.y*Matrix[5] + in.vec.z*Matrix[9] + Matrix[13];
	normal.vec.z=in.vec.x*Matrix[2] + in.vec.y*Matrix[6] + in.vec.z*Matrix[10] + Matrix[14];
	normal.index=in.index;
	return normal;
}

Vector4D CMatrix::ApplyMatrixW(Vector3D in)
{
	return Vector4D(in.x*Matrix[0] + in.y*Matrix[4] + in.z*Matrix[8] + Matrix[12],
					in.x*Matrix[1] + in.y*Matrix[5] + in.z*Matrix[9] + Matrix[13],
					in.x*Matrix[2] + in.y*Matrix[6] + in.z*Matrix[10] + Matrix[14],
					in.x*Matrix[3] + in.y*Matrix[7] + in.z*Matrix[11] + Matrix[15]);
}

//perspective division
Vector3D CMatrix::ApplyMatrix_W(Vector3D in)
{
	Vector4D out=ApplyMatrixW(in);
	
	//return the normalized vector
	return Vector3D(out.x/out.w,out.y/out.w,out.z/out.w);
}

//void CMatrix::Update3DSCameraMatrix(Vector3D pos, Vector3D tar, Vector3D up, float roll)
void CMatrix::Update3DSCameraMatrix(Vector3D pos, Vector3D tar, Vector3D up, float grader)
{
	CMatrix r; // roll
	Vector3D x, y, z;
	Vector3D negpos;

	float fov=0.7854;
//	float fov=45;

	//kamera posisjonen
	negpos=pos;
	negpos.Negate();

	z=pos - tar;
	z.Normalize();

	x=up^z;
	up=z^x;

	x.Normalize();
	y.Normalize();

	Matrix[0]=x.x;	Matrix[4]=x.y;	Matrix[8]=x.z;	Matrix[12]=0;
	Matrix[1]=up.x;	Matrix[5]=up.y;	Matrix[9]=up.z;	Matrix[13]=0;
	Matrix[2]=z.x;	Matrix[6]=z.y;	Matrix[10]=z.z;	Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;

	r.LoadIdentity();
//	r.CreateRotationMatrix(Vector3D(0,0, radianer*M_2PI));
	r.CreateRotationMatrix(Vector3D(0,0, grader/180.0f*M_PI));
	MultiplyMatrix(r);

	int xres=640;
	int yres=480;
	PreTranspose(&negpos);
	float tanfov=tan((fov / 2.0f) / 180.0f*M_PI);
	float aspectratio=(float)yres/xres;
	float perx=xres / 2.0f / tanfov;
	float pery=yres / 2.0f /(aspectratio) / tanfov;

//	mN=m;	//matrix for face normal calculations
}

//------------------------------------------------------------------------------------------------------------
//CAMERA MATRISE
//------------------------------------------------------------------------------------------------------------
//
//	cameramatrix: C = Camera * CameraTransformation * CameraRotation(X,Y,Z)
//
//	C = M * (W-P)
//
//	CameraSpaceCoordinates = CameraMatrix * (WorldSpaceCoordinates - CameraPosition)
//
//------------------------------------------------------------------------------------------------------------

void CMatrix::CreateCameraMatrix(Vector3D eye, Vector3D center, Vector3D up)
{
	Vector3D Forward, Right, Up;

//	Forward=eye;
//	Forward.Substract(center);
/*	Forward.x=center.x-eye.x;
	Forward.y=center.y-eye.y;
	Forward.z=center.z-eye.z;*/

	//Direction the camera is pointing (Forward)
	//Rotate about this axis to perform a camera roll.
	Forward=center;
	Forward.Substract(eye);
	Forward.Normalize();

//	up.Normalize();
//	Vector3D s=cross_product(Forward,up);
//	Vector3D u=cross_product(s,Forward);

	//Vector defining its camera's X-axis
	Right=cross_product(up, Forward);
	Right.Normalize();

	//Vector defining its camera's Y-axis
	Up=cross_product(Forward, Right);
	Up.Normalize();

	Matrix[0]=Right.x;		Matrix[4]=Right.y;		Matrix[8]=Right.z;		Matrix[12]=0;
	Matrix[1]=Up.x;			Matrix[5]=Up.y;			Matrix[9]=Up.z;			Matrix[13]=0;
	Matrix[2]=Forward.x;	Matrix[6]=Forward.y;	Matrix[10]=Forward.z;	Matrix[14]=0;
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=0;			Matrix[15]=1;

}

void CMatrix::LookAt(Vector3D eye, Vector3D lookat, Vector3D up)
{
	//C=V*P*M
	//V IS THE Viewport XFORM,
	//P IS THE Projection XFORM,
	//AND M IS THE Modelview XFORM.

	Vector3D x,y,z;

	z=eye;
	z.Substract(lookat);
	z.Normalize();

	x=cross_product(up,z);
//	x=cross_product(z,up);
	x.Normalize();

	y=cross_product(z,x);
//	y=cross_product(x,z);
	y.Normalize();
	
	Matrix[0]=x.x;	Matrix[4]=x.y;	Matrix[8]=x.z;	Matrix[12]=-dot_product(x,eye);
	Matrix[1]=y.x;	Matrix[5]=y.y;	Matrix[9]=y.z;	Matrix[13]=-dot_product(y,eye);
	Matrix[2]=z.x;	Matrix[6]=z.y;	Matrix[10]=z.z;	Matrix[14]=-dot_product(z,eye);
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;

/*
//feil
	Matrix[0]=x.x;	Matrix[4]=y.y;	Matrix[8]=z.z;	Matrix[12]=-dot_product(x,eye);
	Matrix[1]=x.x;	Matrix[5]=y.y;	Matrix[9]=z.z;	Matrix[13]=-dot_product(y,eye);
	Matrix[2]=x.x;	Matrix[6]=y.y;	Matrix[10]=z.z;	Matrix[14]=-dot_product(z,eye);
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;*/
}

void CMatrix::CreateOrthographicProjectionMatrix()
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=0;	Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=0;	Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=0;	Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;	Matrix[15]=1;
}

void CMatrix::CreateProjectionMatrix(float znear, float zfar, float aspect, float fovx, float fovy)
{
	Matrix[0]=1/tan(fovx/2)/aspect;	Matrix[4]=0;				Matrix[8]=0;							Matrix[12]=0;
	Matrix[1]=0;					Matrix[5]=1/tan(fovy/2);	Matrix[9]=0;							Matrix[13]=0;
	Matrix[2]=0;					Matrix[6]=0;				Matrix[10]=(znear+zfar)/(znear-zfar);	Matrix[14]=(2*znear*zfar)/(znear-zfar);
	Matrix[3]=0;					Matrix[7]=0;				Matrix[11]=-1;							Matrix[15]=0;
}

//-----------------------------------------------
//ved � bruke homogene koordinater kan vi skrive:
//-----------------------------------------------
//        | x |        | 1  0  0   0 |
//| x'|   | y |        | 0  1  0   0 |
//| y'| = | z |    P'= | 0  0  1   0 | * P
//| d |   |z/d|        | 0  0 1/d  0 |
//-----------------------------------------------

//
//Homogeneous matrix witch performs Perspective Projection.
//
void CMatrix::CreatePerspectiveProjectionMatrix(float dist)
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=0;		Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=0;		Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=1;		Matrix[14]=0;
//	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=-1/dist;	Matrix[15]=0;	//right-handed
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=1/dist;	Matrix[15]=0;	//left-handed

}

void CMatrix::CreateOpenglFrustumMatrix(float l, float r, float b, float t, float n, float f)
{
	Matrix[0]=(2*n)/(r-l);	Matrix[4]=0;			Matrix[8]=(r+l)/(r-l);		Matrix[12]=0;
	Matrix[1]=0;			Matrix[5]=(2*n)/(t-b);	Matrix[9]=(t+b)/(t-b);		Matrix[13]=0;
	Matrix[2]=0;			Matrix[6]=0;			Matrix[10]=-(f+n)/(f-n);	Matrix[14]=-(2*f*n)/(f-n);
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=-1;				Matrix[15]=0;
/*
	//inverse
	Matrix[0]=(r-l)/(2*n);	Matrix[4]=0;			Matrix[8]=0;				Matrix[12]=(r+l)/(2*n);
	Matrix[1]=0;			Matrix[5]=(t-b)/(2*n);	Matrix[9]=0;				Matrix[13]=(t+b)/(2*n);
	Matrix[2]=0;			Matrix[6]=0;			Matrix[10]=0;				Matrix[14]=-1;
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=-(f-n)/(2*n*f);	Matrix[15]=(f+n)/(2*f*n);*/
}

void CMatrix::CreateOpenglFrustumMatrix2(float l, float r, float b, float t, float n, float f)
{
	Matrix[0]=(2*n)/(r-l);	Matrix[4]=0;			Matrix[8]=0;				Matrix[12]=0;
	Matrix[1]=0;			Matrix[5]=(2*n)/(t-b);	Matrix[9]=0;				Matrix[13]=0;
	Matrix[2]=(r+l)/(r-l);	Matrix[6]=(t+b)/(t-b);	Matrix[10]=-(f+n)/(f-n);	Matrix[14]=-1;
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=(-2*f*n)/(f-n);	Matrix[15]=0;
}

void CMatrix::CreateTestMatrix(float fov, float zn, float zf)
{
	Matrix[0]=cos(fov/2);	Matrix[4]=0;			Matrix[8]=0;						Matrix[12]=0;
	Matrix[1]=0;			Matrix[5]=cos(fov/2);	Matrix[9]=0;						Matrix[13]=0;
	Matrix[2]=0;			Matrix[6]=0;			Matrix[10]=sin(fov/2)/(1-zn/zf);	Matrix[14]=sin(fov/2);
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=-sin(fov/2)/(1-zn/zf)*zn;Matrix[15]=0;
}

void CMatrix::CreatePerspectiveProjectionMatrix2(float l, float r, float b, float t, float n)
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=(r+l)/(2*n);	Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=(t+b)/(2*n);	Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=1;			Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=0;			Matrix[15]=1;
}

//vrend engine
void CMatrix::PerspectiveMatrix(Vector3D eye)
{
	eye.Normalize();
	Matrix[0]=1.0;			Matrix[4]=0;			Matrix[8]=0;		Matrix[12]=0;
	Matrix[1]=0;			Matrix[5]=1.0;			Matrix[9]=0;		Matrix[13]=0;
	Matrix[2]=-eye.x/eye.z;	Matrix[6]=-eye.y/eye.z;	Matrix[10]=1.0;		Matrix[14]=-1/(eye.Length()*eye.z);
	Matrix[3]=0;			Matrix[7]=0;			Matrix[11]=0;		Matrix[15]=1;
}

void CMatrix::ViewPlaneWindow(int width, int height)
{
	float w_h=width/2;
	float h_h=height/2;

	Matrix[0]=w_h;	Matrix[4]=0;	Matrix[8]=0;		Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=-w_h;	Matrix[9]=0;		Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=w_h;		Matrix[14]=0;
	Matrix[3]=w_h;	Matrix[7]=h_h;	Matrix[11]=0;		Matrix[15]=1;
}


void CMatrix::CPPM(int d)
{
	Matrix[0]=1;	Matrix[4]=0;	Matrix[8]=0;		Matrix[12]=0;
	Matrix[1]=0;	Matrix[5]=1;	Matrix[9]=0;		Matrix[13]=0;
	Matrix[2]=0;	Matrix[6]=0;	Matrix[10]=1;		Matrix[14]=0;
	Matrix[3]=0;	Matrix[7]=0;	Matrix[11]=(float)1/d;		Matrix[15]=0;
}






void matrix_clear(Matrix m)
{
	m[0][0]=0;	m[0][1]=0;	m[0][2]=0;	m[0][3]=0;
	m[1][0]=0;	m[1][1]=0;	m[1][2]=0;	m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=0;	m[2][3]=0;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=0;	m[3][3]=0;
}

void matrix_identity(Matrix m)
{
	m[0][0]=1;	m[0][1]=0;	m[0][2]=0;	m[0][3]=0;
	m[1][0]=0;	m[1][1]=1;	m[1][2]=0;	m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=1;	m[2][3]=0;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=0;	m[3][3]=1;
}

void matrix_copy(Matrix m, Matrix m2)
{
	int x,y;
	for (y=0; y<4; y++)
	for (x=0; x<4; x++) m[x][y]=m2[x][y];
}

void matrix_times_matrix(Matrix m, Matrix m2)
{
	int x,y;
	Matrix t;
	for (x=0; x<4; x++)
	for (y=0; y<4; y++)
	{
		t[x][y]=m[y][0]*m2[0][x]+
				m[y][1]*m2[1][x]+
				m[y][2]*m2[2][x]+
				m[y][3]*m2[3][x];
	}
	matrix_copy(m,t);
}

void vector_times_matrix(Vector3D *v, Matrix m)
{
	Vector3D t;
	t.x=v->x;
	t.y=v->y;
	t.z=v->z;
	v->x=(m[0][0]*t.x)+(m[0][1]*t.y)+(m[0][2]*t.z)+(m[0][3]);//*t.w);
	v->y=(m[1][0]*t.x)+(m[1][1]*t.y)+(m[1][2]*t.z)+(m[1][3]);//*t.w);
	v->z=(m[2][0]*t.x)+(m[2][1]*t.y)+(m[2][2]*t.z)+(m[2][3]);//*t.w);

//	v->w=(m[3][0]*t.x)+(m[3][1]*t.y)+(m[3][2]*t.z)+(m[3][3]);//*t.w);
//	t.w=v->w;
//	v->x=(m[0][0]*t.x)+(m[0][1]*t.y)+(m[0][2]*t.z)+(m[0][3]*t.w);
//	v->y=(m[1][0]*t.x)+(m[1][1]*t.y)+(m[1][2]*t.z)+(m[1][3]*t.w);
//	v->z=(m[2][0]*t.x)+(m[2][1]*t.y)+(m[2][2]*t.z)+(m[2][3]*t.w);
//	v->w=(m[3][0]*t.x)+(m[3][1]*t.y)+(m[3][2]*t.z)+(m[3][3]*t.w);
}

//translation
void matrix_translate(Matrix m, Vector3D v)
{
	Matrix t;
	t[0][0]=1;		t[0][1]=0;		t[0][2]=0;		t[0][3]=0;
	t[1][0]=0;		t[1][1]=1;		t[1][2]=0;		t[1][3]=0;
	t[2][0]=0;		t[2][1]=0;		t[2][2]=1;		t[2][3]=0;
	t[3][0]=v.x;	t[3][1]=v.y;	t[3][2]=v.z;	t[3][3]=1;
	matrix_times_matrix(m,t);
}

//rotation around x-axis
void matrix_rotate_x(Matrix m, float rx)
{
	Matrix r;
	float sx=sin(rx);
	float cx=cos(rx);
	r[0][0]=1;		r[0][1]=0;		r[0][2]=0;		r[0][3]=0;
	r[1][0]=0;		r[1][1]=cx;		r[1][2]=sx;		r[1][3]=0;
	r[2][0]=0;		r[2][1]=-sx;	r[2][2]=cx;		r[2][3]=0;
	r[3][0]=0;		r[3][1]=0;		r[3][2]=0;		r[3][3]=1;
	matrix_times_matrix(m,r);
}

//rotation around y-axis
void matrix_rotate_y(Matrix m, float ry)
{
	Matrix r;
	float sy=sin(ry);
	float cy=cos(ry);
	r[0][0]=cy;		r[0][1]=0;		r[0][2]=-sy;	r[0][3]=0;
	r[1][0]=0;		r[1][1]=1;		r[1][2]=0;		r[1][3]=0;
	r[2][0]=sy;		r[2][1]=0;		r[2][2]=cy;		r[2][3]=0;
	r[3][0]=0;		r[3][1]=0;		r[3][2]=0;		r[3][3]=1;
	matrix_times_matrix(m,r);
}

//rotation around z-axis
void matrix_rotate_z(Matrix m, float rz)
{
	Matrix r;
	float sz=sin(rz);
	float cz=cos(rz);
	r[0][0]=cz;		r[0][1]=sz;		r[0][2]=0;		r[0][3]=0;
	r[1][0]=-sz;	r[1][1]=cz;		r[1][2]=0;		r[1][3]=0;
	r[2][0]=0;		r[2][1]=0;		r[2][2]=1;		r[2][3]=0;
	r[3][0]=0;		r[3][1]=0;		r[3][2]=0;		r[3][3]=1;
	matrix_times_matrix(m,r);
}

//rotation around x,y and z axis.
void matrix_rotate(Matrix m, Vector3D r)
{
	Matrix x,y,z,mx,my,mz;
	float sx=sin(r.x);
	float cx=cos(r.x);
	float sy=sin(r.y);
	float cy=cos(r.y);
	float sz=sin(r.z);
	float cz=cos(r.z);

	x[0][0]=1;		x[0][1]=0;		x[0][2]=0;		x[0][3]=0;
	x[1][0]=0;		x[1][1]=cx;		x[1][2]=sx;		x[1][3]=0;
	x[2][0]=0;		x[2][1]=-sx;	x[2][2]=cx;		x[2][3]=0;
	x[3][0]=0;		x[3][1]=0;		x[3][2]=0;		x[3][3]=1;

	y[0][0]=cy;		y[0][1]=0;		y[0][2]=-sy;	y[0][3]=0;
	y[1][0]=0;		y[1][1]=1;		y[1][2]=0;		y[1][3]=0;
	y[2][0]=sy;		y[2][1]=0;		y[2][2]=cy;		y[2][3]=0;
	y[3][0]=0;		y[3][1]=0;		y[3][2]=0;		y[3][3]=1;

	z[0][0]=cz;		z[0][1]=sz;		z[0][2]=0;		z[0][3]=0;
	z[1][0]=-sz;	z[1][1]=cz;		z[1][2]=0;		z[1][3]=0;
	z[2][0]=0;		z[2][1]=0;		z[2][2]=1;		z[2][3]=0;
	z[3][0]=0;		z[3][1]=0;		z[3][2]=0;		z[3][3]=1;

	matrix_times_matrix(x,m);
	matrix_times_matrix(y,x);
	matrix_times_matrix(z,y);
	matrix_copy(m,z);
}

//scaling
void matrix_scale(Matrix m, Vector3D sc)
{
	Matrix s;
	s[0][0]=sc.x;	s[0][1]=0;		s[0][2]=0;		s[0][3]=0;
	s[1][0]=0;		s[1][1]=sc.y;	s[1][2]=0;		s[1][3]=0;
	s[2][0]=0;		s[2][1]=0;		s[2][2]=sc.z;	s[2][3]=0;
	s[3][0]=0;		s[3][1]=0;		s[3][2]=0;		s[3][3]=1;
	matrix_times_matrix(m,s);
}

//clipping coordinate system
void matrix_clip_coord(Matrix m, float d, float s)
{
	m[0][0]=d/s;	m[0][1]=0;		m[0][2]=0;		m[0][3]=0;
	m[1][0]=0;		m[1][1]=d/s;	m[1][2]=0;		m[1][3]=0;
	m[2][0]=0;		m[2][1]=0;		m[2][2]=1;		m[2][3]=0;
	m[3][0]=0;		m[3][1]=0;		m[3][2]=0;		m[3][3]=1;
}


//void matrix_projection(Matrix m, float d, float s, float f)
void matrix_projection(Matrix m, float d)
{
/*	m[0][0]=1;		m[0][1]=0;		m[0][2]=0;				m[0][3]=0;
	m[1][0]=0;		m[1][1]=1;		m[1][2]=0;				m[1][3]=0;
	m[2][0]=0;		m[2][1]=0;		m[2][2]=s/(d*(1-d/f));	m[2][3]=s/d;
	m[3][0]=0;		m[3][1]=0;		m[3][2]=-s/(1-d/f);		m[3][3]=0;
*/
	m[0][0]=1;		m[0][1]=0;		m[0][2]=0;		m[0][3]=0;
	m[1][0]=0;		m[1][1]=1;		m[1][2]=0;		m[1][3]=0;
//	m[2][0]=0;		m[2][1]=0;		m[2][2]=0;		m[2][3]=-1/d;
//	m[3][0]=0;		m[3][1]=0;		m[3][2]=0;		m[3][3]=1;
	m[2][0]=0;		m[2][1]=0;		m[2][2]=0;		m[2][3]=0;
	m[3][0]=0;		m[3][1]=0;		m[3][2]=-1/d;		m[3][3]=1;
}








/**
* A perspective projection matrix as presented by Jim Blinn in 
* book "A Trip Down the Graphics Pipeline: Jim Blinn's Corner" 
* (ISBN 1-55860-387-5) 
*/ 
void matrix_perspective_proj(Matrix m, float fov, float znear, float zfar) 
{ 
	float s=sin(fov/2); 
	float c=cos(fov/2); 
	float q=s/(1-znear/zfar); 
	m[0][0]=c;	m[0][1]=0;	m[0][2]=0;			m[0][3]=0; 
	m[1][0]=0;	m[1][1]=c;	m[1][2]=0;			m[1][3]=0; 
	m[2][0]=0;	m[2][1]=0;	m[2][2]=q;			m[2][3]=s; 
	m[3][0]=0;	m[3][1]=0;	m[3][2]=-q*znear;	m[3][3]=0; 
}

/*
void matrix_perspective_proj(Matrix m, float fov, float aspect, float nearplane, float farplane)
{ 
	float w=aspect*cos(fov/2)/sin(fov/2);
	float h=1.0f*(cos(fov/2)/sin(fov/2);
	float q=farplane/(farplane-nearplane);
	m[0][0]=w;	m[0][1]=0;	m[0][2]=0;			m[0][3]=0; 
	m[1][0]=0;	m[1][1]=h;	m[1][2]=0;			m[1][3]=0; 
	m[2][0]=0;	m[2][1]=0;	m[2][2]=q;			m[2][3]=1.0f; 
	m[3][0]=0;	m[3][1]=0;	m[3][2]=-q*nearplane;	m[3][3]=0; 
}
*/











void matrix_perspective_projection(Matrix m, float d)
{
	m[0][0]=1;	m[0][1]=0;	m[0][2]=0;		m[0][3]=0;
	m[1][0]=0;	m[1][1]=1;	m[1][2]=0;		m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=1;		m[2][3]=0;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=1.0f/d;	m[3][3]=0;
}

//a simple perspective projection matrix
/*void matrix_perspective_projection(Matrix m)
{
	m[0][0]=1;	m[0][1]=0;	m[0][2]=0;		m[0][3]=0;
	m[1][0]=0;	m[1][1]=1;	m[1][2]=0;		m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=0;		m[2][3]=0;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=1/d;	m[3][3]=1;
}*/

//hearn & baker perspective projection matrix
/*void matrix_perspective_projection(Matrix m)
{
	m[0][0]=1;	m[0][1]=0;	m[0][2]=0;		m[0][3]=0;
	m[1][0]=0;	m[1][1]=1;	m[1][2]=0;		m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=-Zvp/d;	m[2][3]=Zvp*(Zprp/d);
	m[3][0]=0;	m[3][1]=0;	m[3][2]=-1/d;	m[3][3]=Zprp/d;
}*/

/*void matrix_perspective_projection(Matrix mat, float fov, float znear, float zfar)
{
	Matrix m,m2;
	float s=sin(fov/2);
	float c=cos(fov/2);
	float q=s/(1-znear/zfar);

	m[0][0]=c;	m[0][1]=0;	m[0][2]=0;	m[0][3]=0;
	m[1][0]=0;	m[1][1]=c;	m[1][2]=0;	m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=q;	m[2][3]=-q*znear;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=s;	m[3][3]=0;

	matrix_copy(m2, mat);
	matrix_times_matrix(mat, m, m2);
}*/

void matrix_frustum(Matrix m, float l, float r, float b, float t, float zn, float zf)
{
	Matrix p;
	p[0][0]=(2*zn)/(r-l);	p[0][1]=0;				p[0][2]=(r+l)/(r-l);		p[0][3]=0;
	p[1][0]=0;				p[1][1]=(2*zn)/(t-b);	p[1][2]=(t+b)/(t-b);		p[1][3]=0;
	p[2][0]=0;				p[2][1]=0;				p[2][2]=-(zf+zn)/(zf-zn);	p[2][3]=-(2*zf*zn)/(zf-zn);
	p[3][0]=0;				p[3][1]=0;				p[3][2]=-1;					p[3][3]=0;
	matrix_times_matrix(m,p);
}

void matrix_perspective(Matrix m, float yfov, float aspect, float ndist, float fdist)
{
	float wt,wb,wr,wl;
	yfov*=0.0174532f;	//convert to radians
	wt=(float)tan(yfov*0.5f)*ndist;
	wb-=wt;
	wr=wt*aspect;
	wl-=wr;
	matrix_frustum(m,wl,wr,wb,wt,ndist,fdist);
}


/*
float* Mult16fv3fvPerspDiv(float *NewV, float* M, float *V)
{
  float tNewV[3];
  float W = M[3]*V[0] + M[7]*V[1] + M[11]*V[2] + M[15];
  tNewV[0] = (M[0]*V[0] + M[4]*V[1] + M[8]*V[2] + M[12]) / W;
  tNewV[1] = (M[1]*V[0] + M[5]*V[1] + M[9]*V[2] + M[13]) / W;
  tNewV[2] = (M[2]*V[0] + M[6]*V[1] + M[10]*V[2] + M[14]) / W;
  Copy3fv(NewV,tNewV);
  return(NewV);
} 
*/

void matrix_perspectivediv(Vector3D *v, Matrix m)
{
	Vector3D t;
	t.x=v->x;
	t.y=v->y;
	t.z=v->z;
	t.w=v->w;

//	t.w=(m[3][0]*t.x + m[3][1]*t.y + m[3][2]*t.z + m[3][3]);
//	t.w=(m[0][3]*t.x + m[1][3]*t.y + m[2][3]*t.z + m[3][3]);

	v->x=(m[0][0]*t.x + m[0][1]*t.y + m[0][2]*t.z + m[0][3]) / t.w;
	v->y=(m[1][0]*t.x + m[1][1]*t.y + m[1][2]*t.z + m[1][3]) / t.w;
	v->z=(m[2][0]*t.x + m[2][1]*t.y + m[2][2]*t.z + m[2][3]) / t.w;
}

void matrix_viewport(Matrix m)
{
//	What glViewport does is convert normalised device coordinates to window coordinates.
//	The normalised coordinates are in the range [-1..1], and the window coordinates can be anything.
//If your window is 640 pixels wide and 480 pixels high, then the conversion would be:
//windowx = (normalisedx + 1) * 320
//windowy = (normalisedy + 1) * 240
//glViewport also defines an offset x,y, so the final formula is:
//windowx = (normalisedx + 1) * (width/2) + x
//windowy = (normalisedy + 1) * (height/2) + y

}

void matrix_lookat(Matrix m, Vector3D eye, Vector3D lookat, Vector3D up)
{
	//C=V*P*M
	//V IS THE Viewport XFORM,
	//P IS THE Projection XFORM,
	//AND M IS THE Modelview XFORM.

	Vector3D x,y,z;
	z=eye;

	z.Substract(lookat);
	z.Normalize();
	x=cross_product(up,z);
//	x=cross_product(z,up);
	x.Normalize();
	y=cross_product(z,x);
//	y=cross_product(x,z);
	y.Normalize();
	
//	m[0][0]=x.x;	m[1][0]=x.y;	m[2][0]=x.z;	m[3][0]=-dot_product(x,eye);
//	m[0][1]=y.x;	m[1][1]=y.y;	m[2][1]=y.z;	m[3][1]=-dot_product(y,eye);
//	m[0][2]=z.x;	m[1][2]=z.y;	m[2][2]=z.z;	m[3][2]=-dot_product(z,eye);
//	m[0][3]=0;		m[1][3]=0;		m[2][3]=0;		m[3][3]=1;
	m[0][0]=x.x;	m[0][1]=x.y;	m[0][2]=x.z;	m[0][3]=-dot_product(x,eye);
	m[1][0]=y.x;	m[1][1]=y.y;	m[1][2]=y.z;	m[1][3]=-dot_product(y,eye);
	m[2][0]=z.x;	m[2][1]=z.y;	m[2][2]=z.z;	m[2][3]=-dot_product(z,eye);
	m[3][0]=0;		m[3][1]=0;		m[3][2]=0;		m[3][3]=1;
//	m[0][0]=x.x;	m[0][1]=y.x;	m[0][2]=z.x;	m[0][3]=-dot_product(x,eye);
//	m[1][0]=x.y;	m[1][1]=y.y;	m[1][2]=z.y;	m[1][3]=-dot_product(y,eye);
//	m[2][0]=x.z;	m[2][1]=y.z;	m[2][2]=z.z;	m[2][3]=-dot_product(z,eye);
//	m[3][0]=0;		m[3][1]=0;		m[3][2]=0;		m[3][3]=1;
}

//- The glFrustum function multiplies the current matrix by a perspective matrix.
//- void glFrustum(double left, double right, double bottom, double top, double zNear, double zFar)
//Sets up a perspective matrix with the supplied clipping planes so that perspective projection can be used.
//zNear and zFar must both be positive, although they represent negative values.
//- the distances to the near- and far-depth clipping planes. Both distances must be positive.
//never set znear to zero.
/*
void matrix_perspective_projection(Matrix m, float fov, float n, float f)
{
	//n=near
	//f=far
	Matrix p;
//	float cx=WIDTH_HALF;
//	float cy=HEIGHT_HALF;
//	float aspect=WIDTH/HEIGHT;
//	p[0][0]=-cx/aspect;	p[0][1]=0;			p[0][2]=0;					p[0][3]=0;
//	p[1][0]=0;			p[1][1]=-cy;		p[1][2]=0;					p[1][3]=0;
//	p[2][0]=cx*(h/n);	p[2][1]=cy*(h/n);	p[2][2]=(h*f)/(n*(f-n));	p[2][3]=(h/n);
//	p[3][0]=0;			p[3][1]=0;			p[3][2]=-(h*f)/(f-n);		p[3][3]=0;
//	p[0][0]=cx/aspect;	p[0][1]=0;			p[0][2]=0;					p[0][3]=0;
//	p[1][0]=0;			p[1][1]=-cy;		p[1][2]=0;					p[1][3]=0;
//	p[2][0]=-cx;		p[2][1]=-cy;		p[2][2]=f/(n-f);			p[2][3]=-1;
//	p[3][0]=0;			p[3][1]=0;			p[3][2]=-n*f/(n-f);			p[3][3]=0;
	float aspect=WIDTH/HEIGHT;
	float h=tan(fov/2);
	float w=h*aspect;
	p[0][0]=w;	p[0][1]=0;	p[0][2]=0;			p[0][3]=0;
	p[1][0]=0;	p[1][1]=h;	p[1][2]=0;			p[1][3]=0;
//	p[2][0]=0;	p[2][1]=0;	p[2][2]=f/(n-f);	p[2][3]=-1;
	p[2][0]=0;	p[2][1]=0;	p[2][2]=f/(f-n);	p[2][3]=-1;
//	p[3][0]=0;	p[3][1]=0;	p[3][2]=n*f/(f-n);	p[3][3]=0;
	p[3][0]=0;	p[3][1]=0;	p[3][2]=-n*f/(f-n);	p[3][3]=1;

	matrix_times_matrix(m,p);
}
*/
/*
void matrix_perspective_projection(Matrix m, float d)
{
	Matrix p;
	p[0][0]=1;	p[0][1]=0;	p[0][2]=0;		p[0][3]=0;
	p[1][0]=0;	p[1][1]=1;	p[1][2]=0;		p[1][3]=0;
	p[2][0]=0;	p[2][1]=0;	p[2][2]=1;		p[2][3]=0;
	p[3][0]=0;	p[3][1]=0;	p[3][2]=1/d;	p[3][3]=0;
	matrix_times_matrix(m,p);
}
*/
/*
void matrix_perspective_projection(Matrix m, float fov, float znear, float zfar)
{
	Matrix p;
	float aspect=WIDTH/HEIGHT;
//	float w=aspect*(cos(fov/2.0f)/sin(fov/2.0f));
//	float h=cos(fov/2.0f)/sin(fov/2.0f);

	float h=cos(fov/2.0f)/sin(fov/2.0f);
	float w=h/aspect;

//	float c=cos(fov/2.0f);
//	float s=sin(fov/2.0f);

	float q=zfar/(zfar-znear);

//	p[0][0]=c;	p[0][1]=0;	p[0][2]=0;	p[0][3]=0;
//	p[1][0]=0;	p[1][1]=c;	p[1][2]=0;	p[1][3]=0;
//	p[2][0]=0;	p[2][1]=0;	p[2][2]=s/(1-znear/zfar);	p[2][3]=1;
//	p[3][0]=0;	p[3][1]=0;	p[3][2]=1;	p[3][3]=0;

	p[0][0]=w;	p[0][1]=0;	p[0][2]=0;	p[0][3]=0;
	p[1][0]=0;	p[1][1]=h;	p[1][2]=0;	p[1][3]=0;
//	p[2][0]=0;	p[2][1]=0;	p[2][2]=q;	p[2][3]=-q*znear;
//	p[3][0]=0;	p[3][1]=0;	p[3][2]=1;	p[3][3]=0;

	p[2][0]=0;	p[2][1]=0;	p[2][2]=q;	p[2][3]=1;
	p[3][0]=0;	p[3][1]=0;	p[3][2]=-q*znear;	p[3][3]=0;
	matrix_times_matrix(m, p);
}*/

/*
void matrix_perspective_projection(Matrix m, float xfov, float yfov, float znear, float zfar)
{
	Matrix p;
	float w=1/(float)(tan(xfov*0.5));
	float h=1/(float)(tan(yfov*0.5));
	float q=zfar/(zfar-znear);

	p[0][0]=w;	p[0][1]=0;	p[0][2]=0;	p[0][3]=0;
	p[1][0]=0;	p[1][1]=h;	p[1][2]=0;	p[1][3]=0;
	p[2][0]=0;	p[2][1]=0;	p[2][2]=q;	p[2][3]=-q*znear;
	p[3][0]=0;	p[3][1]=0;	p[3][2]=1;	p[3][3]=0;
	matrix_times_matrix(m, p);
}*/
/*void matrix_perspective_projection(Matrix mat, float xfov, float yfov, float znear, float zfar)
{
	Matrix m,m2;
	float w=1/(float)(tan(xfov*0.5));
	float h=1/(float)(tan(yfov*0.5));
	float q=zfar/(zfar-znear);

	float d;

	m[0][0]=1;	m[0][1]=0;	m[0][2]=0;	m[0][3]=0;
	m[1][0]=0;	m[1][1]=1;	m[1][2]=0;	m[1][3]=0;
	m[2][0]=0;	m[2][1]=0;	m[2][2]=1;	m[2][3]=0;
	m[3][0]=0;	m[3][1]=0;	m[3][2]=1/d;m[3][3]=0;
//	matrix_times_matrix(mat, m2
}*/
void matrix_orthographic_projection(Matrix m)
{
	Matrix n;
	n[0][0]=1;	n[0][1]=0;	n[0][2]=0;	n[0][3]=0;
	n[1][0]=0;	n[1][1]=1;	n[1][2]=0;	n[1][3]=0;
	n[2][0]=0;	n[2][1]=0;	n[2][2]=0;	n[2][3]=0;
	n[3][0]=0;	n[3][1]=0;	n[3][2]=0;	n[3][3]=1;
	matrix_times_matrix(m,n);
}

void matrix_p_projection(Matrix m)
{
	Matrix n;

	float w=WIDTH;
	float h=HEIGHT;
	float aspect=(float)w/h;

	float fov=30;

	float nearz=0.01;	//near
	float farz=1;

	float t=nearz*tan(fov/2);	//top
	float b=-t;	//bottom
	float l=b*aspect;	//left
	float r=t*aspect;	//right

//	n[0][0]=1;	n[0][1]=0;	n[0][2]=0;	n[0][3]=0;
//	n[1][0]=0;	n[1][1]=1;	n[1][2]=0;	n[1][3]=0;
//	n[2][0]=0;	n[2][1]=0;	n[2][2]=0;	n[2][3]=0;
//	n[3][0]=0;	n[3][1]=0;	n[3][2]=0;	n[3][3]=1;
	n[0][0]=(2*nearz)/(r-l);	n[0][1]=0;					n[0][2]=-(r+l)/(r-l);				n[0][3]=0;
	n[1][0]=0;					n[1][1]=(2*nearz)/(t-b);	n[1][2]=-(b+t)/(b-t);				n[1][3]=0;
	n[2][0]=0;					n[2][1]=0;					n[2][2]=(nearz+farz)/(nearz-farz);	n[2][3]=(2*farz*nearz)/(nearz-farz);
	n[3][0]=0;					n[3][1]=0;					n[3][2]=-1;							n[3][3]=1;
//	n[0][0]=(2*nearz)/(r-l);	n[0][1]=0;					n[0][2]=0;							n[0][3]=-(r+l)/(r-l);
//	n[1][0]=0;					n[1][1]=(2*nearz)/(t-b);	n[1][2]=0;							n[1][2]=-(t+b)/(t-b);
//	n[2][0]=0;					n[2][1]=0;					n[2][2]=(farz+nearz)/(farz-nearz);	n[2][3]=(-2*farz*nearz)/(farz-nearz);
//	n[3][0]=0;					n[3][1]=0;					n[3][2]=1;							n[3][3]=1;
	matrix_times_matrix(m,n);
}