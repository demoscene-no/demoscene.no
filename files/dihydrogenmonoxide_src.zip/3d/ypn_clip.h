//#include "../ypn_common.h"
#include "ypn_vector3d.h"

class Plane2
{
public:

	Plane2();
	Plane2(float _a, float _b, float _c, float _d);
//	Plane2(Vector3D _normal);
	~Plane2();

	void ConstructABCD(Vector3D v1, Vector3D v2, Vector3D v3);
	int ClipLineAgainstPlane(Vector3D *v1, Vector3D *v2);

	float a,b,c,d;
	Vector3D normal;
	float distance;

	float distance_plane_to_point_v1;
	float distance_plane_to_point_v2;
};


class Frustum2
{
public:
	Frustum2();
	~Frustum2();

	void Init(float project_scale, float sx, float sy);

	Plane2 planes[5];
	float angle_horizontal;
	float angle_vertical;
	float sh,sv,ch,cv;
};