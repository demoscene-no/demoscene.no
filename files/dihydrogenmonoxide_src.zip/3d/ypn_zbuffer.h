class Zbuffer
{
public:

	Zbuffer();
	~Zbuffer();

	int index;
	float depth;
};
