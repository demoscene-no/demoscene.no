#include "ypn_vector3d.h"
#include "ypn_poly.h"
#include "../trianglefillers/ypn_flatfillers.h"
//#include "../ypn_guru_inc.h"

#include <limits.h>

Poly::Poly()
{
	Reset();
}

Poly::~Poly()
{
	free(points);
}

void Poly::Reset()
{
	points=0;
	num_points=0;
	vertices=0;
	num_vertices=0;
	edges=0;
	num_edges=0;

	point_counter=0;
	vertex_counter=0;
}

void Poly::AddPoint(int x, int y)
{
	num_points++;
	points=(Coord2D *)realloc(points, num_points*sizeof(Coord2D));
	points[num_points-1].x=x;
	points[num_points-1].y=y;
}

void Poly::AddPoint(int x, int y, int u, int v)
{
	num_points++;
	points=(Coord2D *)realloc(points, num_points*sizeof(Coord2D));
	points[num_points-1].x=x;
	points[num_points-1].y=y;
	points[num_points-1].u=u;
	points[num_points-1].v=v;
}

void Poly::InitPoints(int amount)
{
	points=(Coord2D *)malloc(sizeof(Coord2D)*amount);
	num_points=amount;
}

void Poly::SetPoint(int x, int y, int index)
{
	points[index].x=x;
	points[index].y=y;
}

void Poly::SetUV(int u, int v, int index)
{
	points[index].u=u;
	points[index].v=v;
}

void Poly::SetVertexUV(int u, int v, int index)
{
	vertices[index].u=u;
	vertices[index].v=v;
}

void Poly::AddVertex(Vector3D *v)
{
	num_vertices++;
	vertices=(Vector3D *)realloc(vertices, num_vertices*sizeof(Vector3D));
	vertices[num_vertices-1].x=v->x;
	vertices[num_vertices-1].y=v->y;
	vertices[num_vertices-1].z=v->z;
}

void Poly::SetFaceNormal(Vector3D *v)
{
	face_normal.x=v->x;
	face_normal.y=v->y;
	face_normal.z=v->z;
}

void Poly::SetVertexNormal(Normal *v, int index)
{
	vertex_normals[index].vec.x=v->vec.x;
	vertex_normals[index].vec.y=v->vec.y;
	vertex_normals[index].vec.z=v->vec.z;
	vertex_normals[index].index=v->index;
}
////
////
////
//void Poly::InitVertices()
void Poly::InitVertices(int amount)
{
//	vertices=new Vector3D[3];
//	num_vertices=3;
	vertices=new Vector3D[amount];
	num_vertices=amount;
}

void Poly::SetVertex(Vector3D *v, int index)
{
	vertices[index].x=v->x;
	vertices[index].y=v->y;
	vertices[index].z=v->z;
}

Vector3D Poly::GetVertex(int index)
{
//	return (vertices[index]);
	return (vertices[index]);
}
////
////
////

void Poly::AddEdge(int vertex_num1, int vertex_num2)
{
	num_edges++;
	edges=(Edge *) realloc(edges, num_edges*sizeof(Edge));

	//what makes an edge? a start point and a end point :)
	edges[num_edges-1].Set(vertex_num1, vertex_num2);
}

int Poly::GetNumPoints()
{
	return num_points;
}

void Poly::DrawLine(uint *pixel, int col)
{
	/*
//	if (ab==1)
	if (visible(points[0].x,points[0].y) && visible(points[1].x,points[1].y))
		g_line((int*)pixel,points[0].x, points[0].y, points[1].x, points[1].y, col);

//	if (bc==1)
	if (visible(points[1].x,points[1].y) && visible(points[2].x,points[2].y))
		g_line((int*)pixel,points[1].x, points[1].y, points[2].x, points[2].y, col);

//	if (ca==1)
	if (visible(points[2].x,points[2].y) && visible(points[0].x,points[0].y))
		g_line((int*)pixel,points[2].x, points[2].y, points[0].x, points[0].y, col);
*/

	//a polygon has N edges.
	//
	//an edge has a flag: on(1) or off(0)
	//
	//the same as a face has A,B,C edges - ab,bc,ca flags.
	//
/*	for (int i=0; i<num_edges; i++)
	{
		if (edge[i].flag==1)
		{
			if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
				g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);
		}

	}*/

	for (int i=0; i<num_points; i++)
	{
		if (i<(num_points-1))
		{
//			if (i==0 && ab==1)
				if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
					g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);//0x0000ff);
//			if (i==1 && bc==1)
				if (visible(points[i].x,points[i].y) && visible(points[i+1].x,points[i+1].y))
					g_line((int*)pixel,points[i].x, points[i].y, points[i+1].x, points[i+1].y, col);//0x00ff00);
		}
		//last edge connected
		else
		{
			if (visible(points[num_points-1].x,points[num_points-1].y) && visible(points[0].x,points[0].y))
				g_line((int*)pixel,points[num_points-1].x, points[num_points-1].y, points[0].x, points[0].y, col);//0xff0000);
		}
	}
}

void Poly::DrawTriFill(Layer layer, int tobuffer, int col)
{
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);
	int width=layer.getWidthBuffer(tobuffer);
	int height=layer.getHeightBuffer(tobuffer);

	//quick and easy polygon tesselation
	for (int i=0; i<num_points-2; i++)
	{
/*		g_tri_flat((int*)pixel, width, height,
			WIDTH-1-points[0].x, points[0].y,
			WIDTH-1-points[i+1].x, points[i+1].y,
			WIDTH-1-points[i+2].x, points[i+2].y, col);*/
/*			points[0].x, points[0].y,
			points[i+1].x, points[i+1].y,
			points[i+2].x, points[i+2].y, col);*/

		g_tri_flat_z((int*)pixel, width, height,
/*			WIDTH-1-points[0].x, points[0].y, points[0].z,
			WIDTH-1-points[i+1].x, points[i+1].y, points[i+1].z,
			WIDTH-1-points[i+2].x, points[i+2].y, points[i+2].z, col);*/
			points[0].x, points[0].y, points[0].z,
			points[i+1].x, points[i+1].y, points[i+1].z,
			points[i+2].x, points[i+2].y, points[i+2].z, col);
		
		
/*
		g_tri_flat_z((int*)pixel, width,
			points[0].x, points[0].y, points[0].z,
			points[i+1].x, points[i+1].y, points[i+1].z,
			points[i+2].x, points[i+2].y, points[i+2].z, col);
*/
	}
}

void Poly::DrawGouraud(Layer layer, int tobuffer, int col1, int col2, int col3)
{
	g_irgb c1,c2,c3;
	c1.r=getRed(col1);
	c1.g=getGreen(col1);
	c1.b=getBlue(col1);
	c2.r=getRed(col2);
	c2.g=getGreen(col2);
	c2.b=getBlue(col2);
	c3.r=getRed(col3);
	c3.g=getGreen(col3);
	c3.b=getBlue(col3);
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);
	int width=layer.getWidthBuffer(tobuffer);
	int height=layer.getHeightBuffer(tobuffer);

	//quick and easy polygon tesselation
	for (int i=0; i<num_points-2; i++)
	{
/*		g_tri_gouraud((int*)pixel, width, 
			WIDTH-1-points[0].x, points[0].y, c1,
			WIDTH-1-points[i+1].x, points[i+1].y, c2, 
			WIDTH-1-points[i+2].x, points[i+2].y, c3);*/

		g_tri_gouraud_z((int*)pixel, width,
			WIDTH-1-points[0].x, points[0].y, points[0].z, c1,
			WIDTH-1-points[i+1].x, points[i+1].y, points[i+1].z, c2, 
			WIDTH-1-points[i+2].x, points[i+2].y, points[i+2].z, c3);
	}
}
void Poly::DrawSprite(Layer layer, int tobuffer, int frombuffer, int alpha)
{
	int sw=layer.buffer[frombuffer]->width/2;
	int sh=layer.buffer[frombuffer]->height/2;
	for (int i=0; i<num_points-2; i++)
	{
		layer.PutBuffer(tobuffer, frombuffer, points[0].x-sw, points[0].y-sh, alpha);
		layer.PutBuffer(tobuffer, frombuffer, points[i+1].x-sw, points[i+1].y-sh, alpha);
		layer.PutBuffer(tobuffer, frombuffer, points[i+2].x-sw, points[i+2].y-sh, alpha);
//		layer.PutBuffer(tobuffer, frombuffer, points[0].x-sw, points[0].y-sh);
//		layer.PutBuffer(tobuffer, frombuffer, points[i+1].x-sw, points[i+1].y-sh);
//		layer.PutBuffer(tobuffer, frombuffer, points[i+2].x-sw, points[i+2].y-sh);
	}
}

void Poly::DrawDot(Layer layer, int tobuffer, int col)
{
	int width=layer.width;
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);

	//quick and easy polygon tesselation
	for (int i=0; i<num_points-2; i++)
	{
		pixel[points[0].x+(points[0].y)*width]=col;
		pixel[points[i+1].x+(points[i+1].y)*width]=col;
		pixel[points[i+2].x+(points[i+2].y)*width]=col;
	}
}

//void Poly::DrawTexture(uint *pixel, unsigned int *texture)
void Poly::DrawTexture(Layer layer, int tobuffer, int texbuffer)
{
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);
	unsigned int *texture=layer.getPixelBuffer(texbuffer);
	int width=layer.getWidthBuffer(tobuffer);
	int mapwidth=layer.getWidthBuffer(texbuffer);

	if (perspective_correct==false)
	{
		//quick and easy polygon tesselation
		for (int i=0; i<num_points-2; i++)
		{
			g_tri_tmap((int*)pixel,	width, points[0].x, points[0].y, points[0].u, points[0].v,
								points[i+1].x, points[i+1].y, points[i+1].u, points[i+1].v,
								points[i+2].x, points[i+2].y, points[i+2].u, points[i+2].v,
								(int*)texture, mapwidth);
/*
			g_tri_tmap_z((int*)pixel, width,
				points[0].x, points[0].y,
				points[0].z,
//				vertices[0].z,
				points[0].u, points[0].v,
				points[i+1].x, points[i+1].y,
				points[i+1].z,
//				vertices[i+1].z,
				points[i+1].u, points[i+1].v,
				points[i+2].x, points[i+2].y,
				points[i+2].z,
//				vertices[i+2].z,
				points[i+2].u, points[i+2].v,
				(int*)texture, mapwidth);*/
		}
	}
	else
	{
		//quick and easy polygon tesselation
		for (int i=0; i<num_points-2; i++)
		{
			drawtpolyperspsubtri(pixel,
				points[0].x,points[0].y, points[0].z,
				points[i+1].x,points[i+1].y, points[i+1].z,
				points[i+2].x,points[i+2].y, points[i+2].z,
				points[0].u, points[0].v,
				points[i+1].u, points[i+1].v,
				points[i+2].u, points[i+2].v, texture);
		}
	}
}
