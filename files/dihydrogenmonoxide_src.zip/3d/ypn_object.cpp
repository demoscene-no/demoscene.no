#include "ypn_object.h"
#include <math.h>
//#define SWAPZY

typedef struct
{
	Vector3D pos;
	Vector3D tar;
	Vector3D up;
	float roll;
} Camera;

Object::Object()
{
	zBuffer=0;
	zBuffer_num=0;

	vertices_real=0;
	vertices_world=0;

	//new faces
	num_faces_new=0;

	material_index=0;
	flag_material=0;

	//set all flags to zero before we parse a objekt
	flag_mapping_coordinates=0;
}

Object::~Object()
{

}

void Object::SetColor(int flag, int col)
{
	color_flag=flag;
	if (color_flag==R3D_FLAT_FIXED) color_flat_fixed=col;
	if (color_flag==R3D_FLAT_SHADE) color_flat_shading=col;
}

void Object::Free()
{
	free(vertices_real);
	free(vertices_world);
	free(zBuffer);
}

void Object::CreateCube()
{
/*	num_vertices=8;
	num_faces=12;

	//init memory
	vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	faces_real=(Face *)malloc(sizeof(Face)*num_faces);

	int s=40;
	//vertices
	vertices_real[0].Set(-s,-s,-s);
	vertices_real[1].Set(s,-s,-s);
	vertices_real[2].Set(s,s,-s);
	vertices_real[3].Set(-s,s,-s);
	vertices_real[4].Set(-s,-s,s);
	vertices_real[5].Set(s,-s,s);
	vertices_real[6].Set(s,s,s);
	vertices_real[7].Set(-s,s,s);

	//faces
	faces_real[0].Set(1,0,3);
	faces_real[1].Set(3,2,1);
	faces_real[2].Set(4,5,6);
	faces_real[3].Set(6,7,4);
	faces_real[4].Set(0,4,7);
	faces_real[5].Set(7,3,0);
	faces_real[6].Set(5,1,2);
	faces_real[7].Set(2,6,5);
	faces_real[8].Set(5,4,0);
	faces_real[9].Set(0,1,5);
	faces_real[10].Set(7,6,2);
	faces_real[11].Set(2,3,7);

	faces_real[0].SetSides(1,1,0);
	faces_real[1].SetSides(1,1,0);
	faces_real[2].SetSides(1,1,0);
	faces_real[3].SetSides(1,1,0);
	faces_real[4].SetSides(1,1,0);
	faces_real[5].SetSides(1,1,0);
	faces_real[6].SetSides(1,1,0);
	faces_real[7].SetSides(1,1,0);
	faces_real[8].SetSides(1,1,0);
	faces_real[9].SetSides(1,1,0);
	faces_real[10].SetSides(1,1,0);
	faces_real[11].SetSides(1,1,0);*/
}

void Object::ParseASE(char *filename)
{
	int i,index;
	unsigned short tempi;
	char *temp=(char *)malloc(128);
	char line[128];

	FILE *fp;
//	FILE *fpo;
//	fpo=fopen("out.ase","w");

	if ((fp=fopen(filename,"rb"))==NULL)
		MessageBox(NULL, "The ASE file could not be opened!", "ERROR", MB_OK);

parsemode=1;

if (parsemode==0)
{
	float flx,fly,flz;
	unsigned short ia,ib,ic;
	char iab,ibc,ica;

	int num_vertices_scene=0;
	int num_faces_scene=0;
	while(1)
	{
		//
		//Search for objects
		//
		fscanf(fp,"%s",temp);

		if (!strcmp(temp,"*GEOMOBJECT"))
		{
//			fprintf(fpo, "*GEOMOBJECT\n");

			while(1)
			{
				fscanf(fp,"%s",temp);
				if (!strcmp(temp,"*MESH_NUMVERTEX"))
				{
					fscanf(fp,"%i",&num_vertices);
//					fprintf(fpo, "\t*MESH_NUMVERTEX %i\n",num_vertices);
				}
				fscanf(fp,"%s",temp);
				if (!strcmp(temp,"*MESH_NUMFACES"))
				{
					fscanf(fp,"%i",&num_faces);
//					fprintf(fpo, "\t*MESH_NUMFACES %i\n",num_faces);
				}

				//
				//Search for vertices
				//
				fscanf(fp,"%s", temp);
				if (!strcmp(temp,"*MESH_VERTEX_LIST"))
				{
					fscanf(fp,"%s",temp);
//					fprintf(fpo, "\t\t*MESH_VERTEX_LIST\n");

					//get vertices from vertex list
					for (i=0; i<num_vertices; i++)
					{
						num_vertices_scene++;
						vertices_real=(Vector3D *)realloc(vertices_real, num_vertices_scene * sizeof(Vector3D));
						vertices_world=(Vector3D *)realloc(vertices_world, num_vertices_scene * sizeof(Vector3D));

						fscanf(fp,"%s", temp);
						fscanf(fp,"%i", &index);
						fscanf(fp,"%f", &flx);
						fscanf(fp,"%f", &fly);
						fscanf(fp,"%f", &flz);

						vertices_real[num_vertices_scene-1].x=flx;
						vertices_real[num_vertices_scene-1].y=fly;
						vertices_real[num_vertices_scene-1].z=flz;

//						fprintf(fpo, "\t\t\t*MESH_VERTEX\t%i\t%.4f %.4f %.4f\n",index,vertices_real[i].x,vertices_real[i].y,vertices_real[i].z);
						vertices_real[num_vertices_scene-1].w=1;
					}
				}

				//
				//

				fscanf(fp,"%s", temp); // }

				//
				//Search for faces
				//
				fscanf(fp,"%s", temp);
				if (!strcmp(temp,"*MESH_FACE_LIST"))
				{
					fscanf(fp,"%s",temp);
//					fprintf(fpo, "\t\t*MESH_FACE_LIST\n");

					//get faces from face list
					for (i=0; i<num_faces; i++)
					{
						num_faces_scene++;
						faces_real=(Face *)realloc(faces_real, num_faces_scene * sizeof(Face));

						fscanf(fp,"%s\t%i:\t%s\t%i %s\t%i %s\t%i %s\t%i %s\t%i %s\t%i\t%s %i\t%s %i",
							temp,&index,temp,
							&ia, temp,
							&ib, temp,
							&ic, temp,
							&iab, temp,
							&ibc, temp,
							&ica, temp,
							&tempi, temp, &tempi, temp, &tempi);

						faces_real[num_faces_scene-1].a=ia+num_vertices_scene-num_vertices;
						faces_real[num_faces_scene-1].b=ib+num_vertices_scene-num_vertices;
						faces_real[num_faces_scene-1].c=ic+num_vertices_scene-num_vertices;
						faces_real[num_faces_scene-1].ab=iab;
						faces_real[num_faces_scene-1].bc=ibc;
						faces_real[num_faces_scene-1].ca=ica;
//						fprintf(fpo, "\t\t\t*MESH_FACE\t%i:\tA:\t%d\tB:\t%d\tC:\t%d\tAB:\t%d\tBC:\t%d\tCA:\t%d\n",index,faces_real[i].a,faces_real[i].b,faces_real[i].c,faces_real[i].ab,faces_real[i].bc,faces_real[i].ca);
					}
					break;
				}
			}
			while(1)
			{
				fscanf(fp,"%s", temp);
				float f[3];
				//
				//Search for color
				//
				if (!strcmp(temp,"*WIREFRAME_COLOR"))
				{
					fscanf(fp,"%f",&f[0]);
					fscanf(fp,"%f",&f[1]);
					fscanf(fp,"%f",&f[2]);
//					fprintf(fpo, "*WIREFRAME_COLOR %.4f %.4f %.4f\n",f[0],f[1],f[2]);
					int delta=num_vertices_scene-num_vertices;
					for (i=delta; i<num_vertices_scene; i++)
					{
						faces_real[delta+i].color=RGB32((int)(f[0]*255),(int)(f[1]*255),(int)(f[2]*255));
//						fprintf(fpo, "*WIREFRAME_COLOR %i, %.4f %.4f %.4f\n",i,f[0],f[1],f[2]);
//						fprintf(fpo, "*WIREFRAME_COLOR 0x%.6x\n",faces_real[delta+i].color);
					}
					break;
				}
			}
		}
		if (feof(fp)) break;
	}

	num_vertices=num_vertices_scene;
	num_faces=num_faces_scene;
}

if (parsemode==1)
{
		while(strncmp(temp,"*MESH_NUMVERTEX",15)) fscanf(fp,"%s",temp);
		fscanf(fp,"%i",&num_vertices);

		//init memory
		vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
		vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
		//
		distance_buffer=new float[num_vertices];
		rotation_buffer=new Vector3D[num_vertices];
		//
		//

		while(strncmp(temp,"*MESH_NUMFACES",14)) fscanf(fp,"%s",temp);
		fscanf(fp,"%i",&num_faces);

		//init memory
		faces_real=(Face *)malloc(sizeof(Face)*num_faces);
/*
		for (i=0; i<num_faces; i++)
		{
			//init fixed colors
			if (i<1048)
				faces_real[i].color=0xffffff;
			else
				faces_real[i].color=0xff0000;
		}*/
		//
		//
		//

		//search for vertices
		while(strncmp(temp,"*MESH_VERTEX_LIST",17)) fscanf(fp,"%s",temp);
		fgets(line,128,fp);

		//get vertices from vertex list
		for (i=0; i<num_vertices; i++)
		{
			fgets(line,128,fp);
			sscanf(line,"%s %i",temp,&index);
#ifndef SWAPZY
			sscanf(line,"%s %i %f %f %f",temp,&index,&vertices_real[index].x,&vertices_real[index].y,&vertices_real[index].z);
#else
			sscanf(line,"%s %i %f %f %f",temp,&index,&vertices_real[index].x,&vertices_real[index].z,&vertices_real[index].y);
#endif
			vertices_real[i].w=1;


			//for vector slime
			Vector3D v=vertices_real[i];
			distance_buffer[i]=sqrtf(SQR(v.x)+SQR(v.y)+SQR(v.z));
			rotation_buffer[i].x=0;
			rotation_buffer[i].y=0;
			rotation_buffer[i].z=0;
		}

		//search for faces
		while(strncmp(temp,"*MESH_FACE_LIST",15)) fscanf(fp,"%s",temp);
		fgets(line,128,fp);

		//get faces from face list
		for (i=0; i<num_faces; i++)
		{
			fgets(line,128,fp);
			sscanf(line,"%s %i",temp,&index);
			sscanf(line,"%s %i:    A: %i B: %i C: %i AB: %i BC: %i CA: %i",temp,&index,&faces_real[index].a,&faces_real[index].b,&faces_real[index].c,&faces_real[index].ab,&faces_real[index].bc,&faces_real[index].ca);
		}

		//
		//texture info (NEW)
		//
		if (flag_uv_texture)
		{
			while(strncmp(temp,"*MESH_NUMTVERTEX",16)) fscanf(fp,"%s",temp);
			fscanf(fp,"%i",&num_tvertices);

			//init memory
			vertices_texture=(TextureCoord *)malloc(sizeof(TextureCoord)*num_tvertices);

			//search for texture-vertices-info
			while(strncmp(temp,"*MESH_TVERTLIST",15)) fscanf(fp,"%s",temp);
			fgets(line,128,fp);

			for (i=0; i<num_tvertices; i++)
			{
				fgets(line,128,fp);
				sscanf(line,"%s %i %f %f %f",temp,&index,&vertices_texture[i].u,&vertices_texture[i].v,&vertices_texture[i].w);
			}

			while(strncmp(temp,"*MESH_NUMTVFACES",16)) fscanf(fp,"%s",temp);
			fscanf(fp,"%i",&num_tfaces);

			//search for texture-face-info
			while(strncmp(temp,"*MESH_TFACELIST",15)) fscanf(fp,"%s",temp);
			fgets(line,128,fp);

			for (i=0; i<num_tfaces; i++)
			{
				fgets(line,128,fp);
				sscanf(line,"%s %i %i %i %i",temp,&index,&faces_real[i].t1,&faces_real[i].t2,&faces_real[i].t3);
			}
		}

		//
		//search for mesh normals
		//
		if (flag_vertex_and_face_normals)
		{
			while(strncmp(temp,"*MESH_NORMALS",13)) fscanf(fp,"%s",temp);
			fgets(line,128,fp);

			face_normals=(Vector3D *)malloc(sizeof(Vector3D)*num_faces);
			vertex_normals[0]=(Normal *)malloc(sizeof(Normal)*num_faces);
			vertex_normals[1]=(Normal *)malloc(sizeof(Normal)*num_faces);
			vertex_normals[2]=(Normal *)malloc(sizeof(Normal)*num_faces);

			for (i=0; i<num_faces; i++)
			{
				fgets(line,128,fp);
				sscanf(line,"%s %i %f %f %f",temp, &index, &faces_real[i].face_normal.x, &faces_real[i].face_normal.y, &faces_real[i].face_normal.z);
				fgets(line,128,fp);
				sscanf(line,"%s %i %f %f %f",temp, &faces_real[i].vertex_normals[0].index, &faces_real[i].vertex_normals[0].vec.x, &faces_real[i].vertex_normals[0].vec.y, &faces_real[i].vertex_normals[0].vec.z);
				fgets(line,128,fp);
				sscanf(line,"%s %i %f %f %f",temp, &faces_real[i].vertex_normals[1].index, &faces_real[i].vertex_normals[1].vec.x, &faces_real[i].vertex_normals[1].vec.y, &faces_real[i].vertex_normals[1].vec.z);
				fgets(line,128,fp);
				sscanf(line,"%s %i %f %f %f",temp, &faces_real[i].vertex_normals[2].index, &faces_real[i].vertex_normals[2].vec.x, &faces_real[i].vertex_normals[2].vec.y, &faces_real[i].vertex_normals[2].vec.z);
			}
		}
/*		else
		{
			face_normals=(Vector3D *)malloc(sizeof(Vector3D)*num_faces);
			Vector3D vector_a, vector_b, normal_vector;
			for (i=0; i<num_faces; i++)
			{
				vector_a=vertices_real[faces_real[i].a];
				vector_a.Substract(vertices_real[faces_real[i].b]);
				vector_b=vertices_real[faces_real[i].c];
				vector_b.Substract(vertices_real[faces_real[i].b]);
				normal_vector=cross_product(vector_a,vector_b);
				normal_vector.Normalize();
				faces_real[i].face_normal=normal_vector;
			}
		}*/
}
	fclose(fp);

	//------------------------------------------------------------------------------------------------
/*	if (!(fp=fopen("out.txt","w"))) exit(1);
	for (i=0; i<num_tvertices; i++) fprintf(fp,"MESH_TVERT %i \t %.4f \t %.4f \t %.4f\n", i, vertices_texture[i].u, vertices_texture[i].v, vertices_texture[i].w);
	for (i=0; i<num_tfaces; i++) fprintf(fp,"MESH_TFACE %i \t %i \t %i \t %i\n", i, faces_real[i].t1, faces_real[i].t2, faces_real[i].t3);
	for (i=0; i<num_faces; i++)
	{
		fprintf(fp,"MESH_FACENORMAL %i \t %.4f \t %.4f \t %.4f\n", i, faces_real[i].face_normal.x, faces_real[i].face_normal.y, faces_real[i].face_normal.z);
		fprintf(fp,"MESH_VERTEXNORMAL %i \t %.4f \t %.4f \t %.4f\n", faces_real[i].vertex_normals[0].index, faces_real[i].vertex_normals[0].vec.x, faces_real[i].vertex_normals[0].vec.y, faces_real[i].vertex_normals[0].vec.z);
		fprintf(fp,"MESH_VERTEXNORMAL %i \t %.4f \t %.4f \t %.4f\n", faces_real[i].vertex_normals[1].index, faces_real[i].vertex_normals[1].vec.x, faces_real[i].vertex_normals[1].vec.y, faces_real[i].vertex_normals[1].vec.z);
		fprintf(fp,"MESH_VERTEXNORMAL %i \t %.4f \t %.4f \t %.4f\n", faces_real[i].vertex_normals[2].index, faces_real[i].vertex_normals[2].vec.x, faces_real[i].vertex_normals[2].vec.y, faces_real[i].vertex_normals[2].vec.z);
	}*/
//	printf("found..\n");
//	printf("num_vertices=%i\n",num_vertices);
//	printf("num_faces=%i\n",num_faces);
//	for (i=0; i<num_vertices; i++) printf("Vertex %i: (%.4f,%.4f,%.4f)\n", i, vertices_real[i].x,vertices_real[i].y,vertices_real[i].z);
//	for (i=0; i<num_faces; i++) printf("Face %i: (A:%i,B:%i,C:%i) (AB:%i,BC:%i,CA:%i)\n", i, faces_real[i].a,faces_real[i].b,faces_real[i].c,faces_real[i].ab,faces_real[i].bc,faces_real[i].ca);
//	fclose(fp);
	//------------------------------------------------------------------------------------------------

	if (flag_uv_texture)
	{
		//materialize
		for (i=0; i<num_faces; i++)
		{
//			faces_real[i].au=vertices_texture[faces_real[i].t1].u;
//			faces_real[i].av=vertices_texture[faces_real[i].t1].v;
//			faces_real[i].bu=vertices_texture[faces_real[i].t2].u;
//			faces_real[i].bv=vertices_texture[faces_real[i].t2].v;
//			faces_real[i].cu=vertices_texture[faces_real[i].t3].u;
//			faces_real[i].cv=vertices_texture[faces_real[i].t3].v;
			faces_real[i].au=(int)(vertices_texture[faces_real[i].t1].u*255)&0xff;
			faces_real[i].av=(int)(vertices_texture[faces_real[i].t1].v*255)&0xff;
			faces_real[i].bu=(int)(vertices_texture[faces_real[i].t2].u*255)&0xff;
			faces_real[i].bv=(int)(vertices_texture[faces_real[i].t2].v*255)&0xff;
			faces_real[i].cu=(int)(vertices_texture[faces_real[i].t3].u*255)&0xff;
			faces_real[i].cv=(int)(vertices_texture[faces_real[i].t3].v*255)&0xff;
		}
	}

	culling=0;

//	culling=-1;

	///
	///
	///
	polygons_temp=new Poly[num_faces*2];
	for (i=0; i<num_faces*2; i++)
	{
		polygons_temp[i].InitPoints(36+36);
		polygons_temp[i].InitVertices(3);
	}

	///
	///
	///

	///
	///
	///
	polygons_real=new Poly[num_faces*2];
	for (i=0; i<num_faces*2; i++) polygons_real[i].InitVertices(8);

	polygons_clipped=new Poly[num_faces*2];
	for (i=0; i<num_faces*2; i++) polygons_clipped[i].InitPoints(36+36);
	///
	///
	///

	//allocate some static faces for our clipped polygons
	InitNewFaces(num_faces*2);


	vertices_zclipped=(Vector3D *)malloc(sizeof(Vector3D)*9*num_faces);
	points_project=(Coord2D *)malloc(sizeof(Coord2D)*9*num_faces);


	light.Set(0,0,-1);
	light.Normalize();

//	fclose(fpo);
}

void Object::MakeTriangle()
{
	int s=50;	//size
	num_vertices=3;
	num_faces=1;
//	num_vertices=4;
//	num_faces=2;

	//init memory
	vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);

	faces_real=(Face *)malloc(sizeof(Face)*num_faces);

	//get vertices from vertex list
	vertices_real[0].x=-s;		vertices_real[0].y=-s;		vertices_real[0].z=0;	vertices_real[0].w=1;
	vertices_real[1].x=s;		vertices_real[1].y=-s;		vertices_real[1].z=0;	vertices_real[0].w=1;
	vertices_real[2].x=s;		vertices_real[2].y=s;		vertices_real[2].z=0;	vertices_real[0].w=1;
//	vertices_real[3].x=-50;		vertices_real[3].y=50;		vertices_real[3].z=0;	vertices_real[0].w=1;

	faces_real[0].a=0;
	faces_real[0].b=1;
	faces_real[0].c=2;
	faces_real[0].ab=0;
	faces_real[0].bc=1;
	faces_real[0].ca=1;

/*	faces_real[0].a=0;
	faces_real[0].b=1;
	faces_real[0].c=3;
	faces_real[0].ab=0;
	faces_real[0].bc=1;
	faces_real[0].ca=1;

	faces_real[1].a=1;
	faces_real[1].b=2;
	faces_real[1].c=3;
	faces_real[1].ab=1;
	faces_real[1].bc=0;
	faces_real[1].ca=1;*/
}

void Object::MakeTestObject()
{
	int i;
	num_vertices=9;
	num_faces=8;

	//init memory
	vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	faces_real=(Face *)malloc(sizeof(Face)*num_faces);

	//vertices
	vertices_real[0].Set(0,0,0);
	vertices_real[1].Set(-50,-50,0);
	vertices_real[2].Set(-60,0,0);
	vertices_real[3].Set(-50,50,0);
	vertices_real[4].Set(0,60,0);
	vertices_real[5].Set(50,50,0);
	vertices_real[6].Set(60,0,0);
	vertices_real[7].Set(50,-50,0);
	vertices_real[8].Set(0,-60,0);

	for (i=0; i<num_vertices; i++) vertices_world[i]=vertices_real[i];

	//faces
	faces_real[0].Set(0,1,2);
	faces_real[1].Set(0,2,3);
	faces_real[2].Set(0,3,4);
	faces_real[3].Set(0,4,5);
	faces_real[4].Set(0,5,6);
	faces_real[5].Set(0,6,7);
	faces_real[6].Set(0,7,8);
	faces_real[7].Set(0,8,1);

	faces_real[0].SetSides(0,1,0);
	faces_real[1].SetSides(0,1,0);
	faces_real[2].SetSides(0,1,0);
	faces_real[3].SetSides(0,1,0);
	faces_real[4].SetSides(0,1,0);
	faces_real[5].SetSides(0,1,0);
	faces_real[6].SetSides(0,1,0);
	faces_real[7].SetSides(0,1,0);
}

void Object::ParseASC(char *filename)
{
	int i,index;
	char *temp;
	char line[128];
	FILE *fp,*fp2;

	if (!(fp=fopen(filename,"rb"))) exit(1);
	temp=(char *)malloc(128);

	while(strncmp(temp,"Vertices:",9)) fscanf(fp,"%s",temp);
	fscanf(fp,"%i",&num_vertices);

	//init memory
	vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);

	while(strncmp(temp,"Faces:",6)) fscanf(fp,"%s",temp);
	fscanf(fp,"%i",&num_faces);

	//init memory
	faces_real=(Face *)malloc(sizeof(Face)*num_faces);


	//search for vertices
	//tryner p� strings med space (mellomrom) virker det som
	while(strncmp(temp,"list:",5)) fscanf(fp,"%s",temp);
	fgets(line,128,fp);

	//get vertices from vertex list
	for (i=0; i<num_vertices; i++)
	{
		fgets(line,128,fp);
		sscanf(line,"%s %i",temp,&index);
		sscanf(line,"%s %i:  X: %f     Y: %f     Z: %f",temp,&index,&vertices_real[index].x,&vertices_real[index].y,&vertices_real[index].z);
	}

	//search for faces
	while(strncmp(temp,"list:",5)) fscanf(fp,"%s",temp);
	fgets(line,128,fp);

	//get faces from face list
	for (i=0; i<num_faces; i++)
	{
		fgets(line,128,fp);
		sscanf(line,"%s %i",temp,&index);
		sscanf(line,"%s %i:    A:%i B:%i C:%i AB:%i BC:%i CA:%i",temp,&index,&faces_real[index].a,&faces_real[index].b,&faces_real[index].c,&faces_real[index].ab,&faces_real[index].bc,&faces_real[index].ca);
		fgets(line,128,fp);
		fgets(line,128,fp);
	}

	fclose(fp);
/*
	for (i=0; i<num_vertices; i++)
	{
		float size=0.1;
		vertices_real[i].x=vertices_real[i].x*size;
		vertices_real[i].y=vertices_real[i].y*size;
		vertices_real[i].z=vertices_real[i].z*size;
	}*/

/*
	if (!(fp2=fopen("out.txt","w"))) exit(1);
	fprintf(fp2,"vertices=%i\n",num_vertices);
	fprintf(fp2,"faces=%i\n",num_faces);
	for (i=0; i<num_vertices; i++) fprintf(fp2,"Vertex %i: (%.4f,%.4f,%.4f)\n", i, vertices_real[i].x,vertices_real[i].y,vertices_real[i].z);
	for (i=0; i<num_faces; i++) fprintf(fp2,"Face %i: (A:%i,B:%i,C:%i) (AB:%i,BC:%i,CA:%i)\n", i, faces_real[i].a,faces_real[i].b,faces_real[i].c,faces_real[i].ab,faces_real[i].bc,faces_real[i].ca);
	fclose(fp2);*/
}

int norway[19*12]=
{
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,

0xffffff,0xfffffff,0xffffff,0xffffff,0xffffff,0xffffff,0x0000ff,0x0000ff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,
0x0000ff,0x00000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,
0x0000ff,0x00000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,0x0000ff,
0xffffff,0xfffffff,0xffffff,0xffffff,0xffffff,0xffffff,0x0000ff,0x0000ff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,0xffffff,

0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,
0xff0000,0xff00000,0xff0000,0xff0000,0xff0000,0xffffff,0x0000ff,0x0000ff,0xffffff,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000,0xff0000};

void Object::MakeGrid(int x, int y)
{
	int i,sx,sy,mx,my;
	num_vertices=x*y;
	num_faces=(x*2)*(y*2);

	//init memory
	vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);
	vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*num_vertices);

	faces_real=(Face *)malloc(sizeof(Face)*num_faces);

//	for (i=0; i<num_vertices; i++)
/*	for (sy=0; sy<y; sy++)
	for (sx=0; sx<x; sx++)
	{
		mx=(x/2);
		my=(y/2);
		vertices_real[i].x=-mx+sx;
		vertices_real[i].y=-my+sy;
		vertices_real[i].z=1;
		i++;
	}
*/


	mx=(x/2);
	my=(y/2);
	i=0;
	for (sy=0; sy<y; sy++)
	for (sx=0; sx<x; sx++)
	{
		vertices_real[i].x=-mx + sx;
		vertices_real[i].y=-my + sy;
		i++;
	}
	//20x12

	i=0;
	for (sy=0; sy<y-1; sy++)
	for (sx=0; sx<x-1; sx++)
	{
		faces_real[i].a=sx + x*sy;
		faces_real[i].b=sx+1 + x*(sy+1);
		faces_real[i].c=sx + x*(sy+1);
		faces_real[i].SetSides(0,1,1);
		i++;
	}
	for (sy=0; sy<y-1; sy++)
	for (sx=0; sx<x-1; sx++)
	{
		faces_real[i].a=sx + x*sy;
		faces_real[i].b=sx+1 + x*sy;
		faces_real[i].c=sx+1 + x*(sy+1);
		faces_real[i].SetSides(1,1,0);
		i++;
	}

	//tror det er linjerutina som f�r den til � blinke
	for (i=0; i<num_vertices; i++)
	{
		vertices_real[i].x*=10;
		vertices_real[i].y*=10;
	}
/*
	for (i=0; i<num_vertices; i++)
	{
		vertices_world[i].x=vertices_real[i].x;
		vertices_world[i].y=vertices_real[i].y;
		vertices_world[i].z=vertices_real[i].z;
	}
*/
	//sett fargene
	for (i=0; i<num_faces; i++)
//		faces_real[i].color=0xffff00;	//gul
//		faces_real[i].color=0xffaf7f;	//brun
//		faces_real[i].color=0x7f7fff;	//bl�
//		faces_real[i].color=0x7fafff;
		faces_real[i].color=0xffff7f;
//		faces_real[i].color=0x7fff7f;


	
	//norflag
	i=0;
	for (sy=0; sy<y-1; sy++)
	for (sx=0; sx<x-1; sx++)
	{
		faces_real[i].color=norway[sx+sy*(x-1)];
		i++;
	}
	for (sy=0; sy<y-1; sy++)
	for (sx=0; sx<x-1; sx++)
	{
		faces_real[i].color=norway[sx+sy*(x-1)];
		i++;
	}
}

void Object::SetZSCALE(float _zscale)
{
	zscale=_zscale;
}

void Object::FrustumSetup(float sx, float sy)
{
	//set up the planes of the frustum, in worldspace coordinates.

/*	float s,c,angle;
	Vector3D curpos;

	curpos.Set(0,0,0);

	//left
	angle=atan(2.0/zscale*WIDTH/WIDTH);
	s=sin(angle);
	c=cos(angle);
	frustum.planes[0].normal.Set(s,0,c);
	frustum.planes[0].distance=dot_product(curpos,frustum.planes[0].normal)+0.0001;

	//right
	frustum.planes[1].normal.Set(-s,0,c);
	frustum.planes[1].distance=dot_product(curpos,frustum.planes[1].normal)+0.0001;

	//bottom
	angle=atan(2.0/zscale*WIDTH/HEIGHT);
	s=sin(angle);
	c=cos(angle);
	frustum.planes[2].normal.Set(0,s,c);
	frustum.planes[2].distance=dot_product(curpos,frustum.planes[2].normal)+0.0001;

	//top
	frustum.planes[3].normal.Set(0,-s,c);
	frustum.planes[3].distance=dot_product(curpos,frustum.planes[3].normal)+0.0001;
*/

/*	
//	float t=zscale*0.5;
//	float sinx=sin(t);
//	float cosx=cos(t);
	float angx=atan2(sx/2,zscale)-0.0001;
	float angy=atan2(sy/2,zscale)-0.0001;
	float sinx=sin(angx);
	float siny=sin(angy);
	float cosx=cos(angx);
	float cosy=cos(angy);

	//left
	frustum.planes[0].normal.Set(cosx,0,sinx);
	frustum.planes[1].distance=0;

	//right
	frustum.planes[1].normal.Set(-cosx,0,sinx);
	frustum.planes[1].distance=0;

	//top
	frustum.planes[2].normal.Set(0,-cosy,siny);
	frustum.planes[2].distance=0;

	//bottom
	frustum.planes[3].normal.Set(0,cosy,siny);
	frustum.planes[3].distance=0;

	//znear
	frustum.planes[4].normal.Set(0,0,1);
	frustum.planes[4].distance=-10;*/
}

Coord2D project3d(Vector3D v, float zscale)
{
	Coord2D scr;
//	float relative_z=1.0f/(v.z-zscale);
//	scr.x=320+v.x*zscale*relative_z;
//	scr.y=240+v.y*zscale*relative_z;

//	*****************
//	weird perspective
//	*****************
//	scr.x=320+v.x*v.z*relative_z;
//	scr.y=240+v.y*v.z*relative_z;

	scr.x=WIDTH_HALF+(v.x*(zscale/(zscale-v.z)));
	scr.y=HEIGHT_HALF+(v.y*(zscale/(zscale-v.z)));
//	scr.x=320+(v.x*zscale)/(zscale-v.z);
//	scr.y=240+(v.y*zscale)/(zscale-v.z);
//	scr.x=320+(v.x*zscale)/(v.z-zscale);
//	scr.y=240+(v.y*zscale)/(v.z-zscale);
//	scr.x=320+zscale*(x/z);
//	scr.y=240+zscale*(y/z);
	return scr;
}

Coord2D project3d(Vector3D v, float zscale, int xresh, int yresh)
{
	Coord2D scr;
	scr.x=xresh+(v.x*(zscale/(zscale-v.z)));
	scr.y=yresh+(v.y*(zscale/(zscale-v.z)));
	return scr;
}

Coord2D project3d_new(Vector3D v, float zper, int xresh, int yresh)
{
	Coord2D scr;
	float z_delta=(float)fabs((float)WIDTH/((float)tan(zper*(M_PI/180)/2)*2));
	scr.x=xresh+(v.x*z_delta)/(v.z);
	scr.y=yresh+(v.y*z_delta)/(v.z);
	return scr;
}

//determine which sector endpoint is in.
int Object::GetBitCode(int x, int y)
{
	int bitcode=0;
	if (x<screenarea[0].x) bitcode=bitcode|CLIP_LEFT;
	if (x>screenarea[1].x) bitcode=bitcode|CLIP_RIGHT;
	if (y<screenarea[0].y) bitcode=bitcode|CLIP_UP;
	if (y>screenarea[1].y) bitcode=bitcode|CLIP_DOWN;
	return bitcode;
}

int Object::Inside(int x, int y)
{
	if ((x<screenarea[0].x) || (x>screenarea[1].x)) return 0;
	if ((y<screenarea[0].y) || (y>screenarea[1].y)) return 0;
	return 1;
}

int Object::InsideLEFT(int x)
{
	if (x>screenarea[0].x) return 1;
	else return 0;
}

int Object::InsideRIGHT(int x)
{
	if (x<screenarea[1].x) return 1;
	else return 0;
}

int Object::InsideTOP(int y)
{
	if (y>screenarea[0].y) return 1;
	else return 0;
}

int Object::InsideBOTTOM(int y)
{
	if (y<screenarea[1].y) return 1;
	else return 0;
}

int Object::InsideNEAR(float z)
{
	if (z<=znear) return 1;
	else return 0;
}

void Object::InitNewFaces(int amount)
{
	faces_new=new Face[amount];//(Face *)malloc(sizeof(Face)*amount);
}

void Object::SetNewFace(int index, int vertnum1, int vertnum2, int vertnum3)
{
	faces_new[index].a=vertnum1;
	faces_new[index].b=vertnum2;
	faces_new[index].c=vertnum3;
}

void Object::SetNewFaceColor(int index, int color)
{
	faces_new[index].color=color;
}

void Object::addZbuffer()
{
	zBuffer_num++;
	zBuffer=(Zbuffer *) realloc(zBuffer, zBuffer_num*sizeof(Zbuffer));
}

void Object::SetClippedVertex(Vector3D *v, int index)
{
	vertices_zclipped[index].x=v->x;
	vertices_zclipped[index].y=v->y;
	vertices_zclipped[index].z=v->z;

	//make sure the texture coordinates follow.
	vertices_zclipped[index].u=v->u;
	vertices_zclipped[index].v=v->v;
}

void Object::SetProjectedPoints(Vector3D *v, Coord2D midpoint, int index)
{
	float z_delta=(float)fabs((float)WIDTH/((float)tan(zscale*(M_PI/180)/2)*2));
	points_project[index].x=midpoint.x+(v->x*z_delta)/(v->z);
	points_project[index].y=midpoint.y+(v->y*z_delta)/(v->z);
	points_project[index].z=v->z;

	//make sure the texture coordinates follow.
	points_project[index].u=v->u;
	points_project[index].v=v->v;
}

void Object::SetClipArea(int x1, int y1, int x2, int y2)
{
	screenarea[0].x=x1;
	screenarea[0].y=y1;
	screenarea[1].x=x2;
	screenarea[1].y=y2;
}

void Object::DrawClipArea(Layer layer, int tobuffer, int col)
{
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);
	g_line((int*)pixel,screenarea[0].x,screenarea[0].y,screenarea[1].x,screenarea[0].y,col);
	g_line((int*)pixel,screenarea[1].x,screenarea[0].y,screenarea[1].x,screenarea[1].y,col);
	g_line((int*)pixel,screenarea[1].x,screenarea[1].y,screenarea[0].x,screenarea[1].y,col);
	g_line((int*)pixel,screenarea[0].x,screenarea[1].y,screenarea[0].x,screenarea[0].y,col);
}

void Object::SetLight(Vector3D l)
{
	light.x=l.x;
	light.y=l.y;
	light.z=l.z;
	light.Normalize();
}

int compare(const void *_a, const void *_b)
{
	Zbuffer *a=(Zbuffer *)_a;
	Zbuffer *b=(Zbuffer *)_b;
	return (a->depth<b->depth?-1:a->depth==b->depth?0:1);
}

void Object::Show(Layer layer, int tobuffer, int texture, int frombuffer)
{
	int i,j,i3,count,facenum;
	float intensity;
	Vector3D v1,v2,vin;
	Coord2D cin, scr[3], t1, t2, ti;
	Coord2D n[18];	//for showing the normals
	Vector3D v[3];
	Vector3D vector_a,vector_b,normal_vector;
	Coord2D midpoint={layer.getWidthBuffer(tobuffer)/2, layer.getHeightBuffer(tobuffer)/2};
	unsigned int *pixel=layer.getPixelBuffer(tobuffer);
	int width=layer.getWidthBuffer(tobuffer);
	int height=layer.getHeightBuffer(tobuffer);
	int width_half=width/2;
	int height_half=height/2;

if (parsemode==1 && transmode==0)
{
//--------------------------------------------------------------------------------------------------------------------
/*
//Denne brukes bare til Liquid helium demoen
	//well.. roter f�rst og s� transler. denne har s�klart begrensninger.
	Objectmatrix.LoadIdentity();
	Objectmatrix.CreateRotationMatrix(rotate);	//ROTATION
	Processmatrix.LoadIdentity();
	Processmatrix.CreateTranslationMatrix(translate);	//TRANSLATION
	Objectmatrix.MultiplyMatrix(Processmatrix);
	Finalmatrix=Objectmatrix;
*/

//Denne brukes til alt bortsett fra Liquid helium demoen
//	Finalmatrix.LoadIdentity();

//--------------
//	3DS CAMERA
//--------------
	/*
//	Vector3D up(0,0,-1);
	Vector3D up(0,0,1);

//	campos.z=140+cos(ftime)*240;
//	campos.y=340+sin(ftime)*340;

//	Finalmatrix.Update3DSCameraMatrix(campos, camtar, up, 45);// + ftime*50);
//	Finalmatrix.Update3DSCameraMatrix(campos, camtar, up, 4.1888);// + ftime*50);
	Finalmatrix.Update3DSCameraMatrix(campos, camtar, up, cambank);// + ftime*50);
	*/
//--------------

}


//
//
//

if (parsemode==0 || transmode==1)
{
	Finalmatrix=Currentmatrix;
}

//	Normalsmatrix=Finalmatrix;
	Normalsmatrix=CurrentmatrixN;
//	Normalsmatrix.PreTranspose(&Vector3D(1,1,1));
//	Normalsmatrix.PreTranspose(&Vector3D(-1,-1,-1));	//her

//	Translationmatrix.PreTranspose(&Vector3D(-1,-1,-1));
//	Normalsmatrix=Normalsmatrix*Translationmatrix;

//	Normalsmatrix.LoadIdentity();
//	Normalsmatrix.CreateRotationMatrix(rotate);
//	Normalsmatrix.MultiplyMatrix(Translationmatrix);
//	Normalsmatrix.MultiplyMatrix(Finalmatrix);



//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Vector Slime.
//	
/*
if (ftime>=4)
{
	Vector3D u;
	u.x=sin(ftime*0.2)*0.13;
	u.y=sin(-ftime*0.1)*0.13;
	u.z=sin(-ftime*0.12)*0.13;
	for (i=0; i<num_vertices; i++) vertices_world[i]=vertices_real[i];

	for (i=0; i<num_vertices; i++)
	{
		Vector3D *v=&vertices_real[i];
		float *d=&distance_buffer[i];
		Vector3D *r=&rotation_buffer[i];//,rotation_buffer[i].y,rotation_buffer[i].z);
		float amount=ftime_delta*100.0f;

		r->x += ((u.x - r->x) / (*d)) * amount;
		r->y += ((u.y - r->y) / (*d)) * amount;
		r->z += ((u.z - r->z) / (*d)) * amount;

		Vector3D k=vertices_world[i];

		k.RotateX(r->x);
		k.RotateY(r->y);
		k.RotateZ(r->z);

		*v=k;
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

}
*/
	for (i=0; i<num_vertices; i++) vertices_world[i]=Finalmatrix.ApplyMatrix(vertices_real[i]);

	//rotate normals too
	if (flag_vertex_and_face_normals==true)
	{
		for (i=0; i<num_faces; i++)
		{
			face_normals[i]=Normalsmatrix.ApplyMatrix(faces_real[i].face_normal);
			vertex_normals[0][i]=Normalsmatrix.ApplyMatrix(faces_real[i].vertex_normals[0]);
			vertex_normals[1][i]=Normalsmatrix.ApplyMatrix(faces_real[i].vertex_normals[1]);
			vertex_normals[2][i]=Normalsmatrix.ApplyMatrix(faces_real[i].vertex_normals[2]);
		}
	}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Husk � implementere i tesselation rutina:
//	
//	at facene inneholder informasjon om hver edge til et triangel eller polygon.
//	alts�.. hver face har en .a .b og .c definisjon som betyr hvilke vertices som
//	skal settes sammen til en triangel. (jeg burde egentlig lage en egen -dynamisk- edge-table) (senere)
//	
//	Saken er den at tesselation rutina ikke har st�tte for dette, og jeg m� omstrukturere
//	hele face rutinen til dynamisk minne-allokering for � gj�re det enklere � opprette nye
//	edges i sanntid og f� dette til.
//	
//	[a -> b],  [b -> c] og [c -> a] er definisjonen p� en face, vel.. et polygon har flere edges
//	s� dette m� vi ta hennsyn til og da er det vi kommer til tesselation.
//
//	tesselation er hele grunnen til at vi lager nye faces. Polygonet kan 'bare' ha 3 eller 4 edges
//	fordi vi klipper bare mot 'et' plan, og det betyr at vi maksimum kan opprette to faces per polygon.
//	
//	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//****************************************************************************************************************
	//Z-Klipping (3D)
	//****************************************************************************************************************
	//Klipp til 'Z-NEAR' planet
	//************************************
	for (i=0; i<num_faces; i++)
	{
		int vinc;

		//
		//hvert polygon blir tildelt 3 vertices som vi ser her.
		//
		polygons_temp[i].SetVertex(&vertices_world[faces_real[i].a], 0);
		polygons_temp[i].SetVertex(&vertices_world[faces_real[i].b], 1);
		polygons_temp[i].SetVertex(&vertices_world[faces_real[i].c], 2);

		polygons_temp[i].color=faces_real[i].color;

		if (flag_vertex_and_face_normals==true)
		{
			polygons_temp[i].SetFaceNormal(&face_normals[i]);
			polygons_temp[i].SetVertexNormal(&vertex_normals[0][i], 0);
			polygons_temp[i].SetVertexNormal(&vertex_normals[1][i], 1);
			polygons_temp[i].SetVertexNormal(&vertex_normals[2][i], 2);
		}

		polygons_temp[i].vertex_counter=3;

		//col
//		polygons_temp[i].color=faces_real[i].color;

		//tex
		polygons_temp[i].SetVertexUV(faces_real[i].au, faces_real[i].av, 0);
		polygons_temp[i].SetVertexUV(faces_real[i].bu, faces_real[i].bv, 1);
		polygons_temp[i].SetVertexUV(faces_real[i].cu, faces_real[i].cv, 2);
		//

		count=0;	//antallet vertices i polygonet
		vinc=0;

		polygons_real[i].vertex_counter=0;
		//
		// s� lenge 'count' er mindre enn antallet vertices i 'polygons_temp' utf�rer vi denne l�kka.
		//
		while(count < 3)//polygons_temp[i].vertex_counter)
		{
			//g� igjennom verticene i det klippede polygonet
			//og lag edgen(v1 og v2) vi skal klippe mot.

			if (count < 2)//polygons_temp[i].vertex_counter-1)
			{
				v1=polygons_temp[i].vertices[count];
				v2=polygons_temp[i].vertices[count+1];

				//tex
				t1.u=polygons_temp[i].vertices[count].u;
				t1.v=polygons_temp[i].vertices[count].v;
				t2.u=polygons_temp[i].vertices[count+1].u;
				t2.v=polygons_temp[i].vertices[count+1].v;
			}
			else
			{
				v1=polygons_temp[i].vertices[count];
				v2=polygons_temp[i].vertices[0];

				//tex
				t1.u=polygons_temp[i].vertices[count].u;
				t1.v=polygons_temp[i].vertices[count].v;
				t2.u=polygons_temp[i].vertices[0].u;
				t2.v=polygons_temp[i].vertices[0].v;
			}
			count++;

			//
			//husk � implementere z-klippinga i 3d slik at vi klipper 3d komponenter fra vertices,
			//og legg slutt-resultatet i et object, etterfulgt av projiserings- og 2d-klippingsprosessen.
			//

			//
			//Z-klipping virker p� denne m�ten:	(bruk den parametriske linje likninga)
			//For � finne t bruker vi Z-komponenten, for s� � substituere tilbake til de andre..
			//
			//Z(t) = Z0 - (Z1-Z0)*t
			//X(t) = X0 - (X1-X0)*t		(husk at t-verdien er den samme for alle 3 ligningene)
			//Y(t) = Y0 - (Y1-Y0)*t
			//
			//substituer Z(t) til Z-near og finn verdien t..
			//z_near      =  Z0 - (Z1-Z0) * t
			//z_near - Z0 = (Z1 - Z0) * t
			//          t = (z_near - Z0) / (Z1-Z0)
			//
			//for � finne de nye x og y verdiene p� planet, bruker vi den kalkulerte verdien t.
			//X(t) = X0 - (X1-X0) * t
			//Y(t) = Y0 - (Y1-Y0) * t

			//sann hvis v1 er utenfor og v2 er utenfor
			if ((!InsideNEAR(v1.z)) && (!InsideNEAR(v2.z)))
			{
				//ikke gj�r en skit..
			} else

			//sann hvis v1 er innenfor og v2 er innenfor
			if (InsideNEAR(v1.z) && InsideNEAR(v2.z))
			{
				//legg til v2
				polygons_real[i].SetVertex(&v2, polygons_real[i].vertex_counter++);
				polygons_real[i].SetVertexUV(t2.u, t2.v, polygons_real[i].vertex_counter-1);
				vinc++;
			} else
		
			//sann hvis v1 er innenfor og v2 er utenfor (leave region (v2))
			if ((InsideNEAR(v1.z)) && (!InsideNEAR(v2.z)))
			{
				double ip=(znear - v1.z) / (v2.z - v1.z);
				vin.x=v1.x + (v2.x - v1.x) * ip;
				vin.y=v1.y + (v2.y - v1.y) * ip;
				vin.z=znear;

				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;

				//legg til interseksjonspunktet
				polygons_real[i].SetVertex(&vin, polygons_real[i].vertex_counter++);
				polygons_real[i].SetVertexUV(ti.u, ti.v, polygons_real[i].vertex_counter-1);
				vinc++;
			} else

			//Sann hvis v1 er utenfor og v2 er innenfor
			if ((!InsideNEAR(v1.z)) && (InsideNEAR(v2.z)))
			{
				double ip=(znear - v2.z) / (v1.z - v2.z);
				vin.x=v2.x + (v1.x - v2.x) * ip;
				vin.y=v2.y + (v1.y - v2.y) * ip;
				vin.z=znear;

				ti.u=t2.u + (t1.u - t2.u) * ip;
				ti.v=t2.v + (t1.v - t2.v) * ip;

				polygons_real[i].SetVertex(&vin, polygons_real[i].vertex_counter++);
				polygons_real[i].SetVertex(&v2, polygons_real[i].vertex_counter++);
				polygons_real[i].SetVertexUV(ti.u, ti.v, polygons_real[i].vertex_counter-2);
				polygons_real[i].SetVertexUV(t2.u, t2.v, polygons_real[i].vertex_counter-1);
				vinc++;
				vinc++;
			}
		}
		polygons_real[i].num_vertices=polygons_real[i].vertex_counter;


		polygons_real[i].color=polygons_temp[i].color;
	}
	//****************************************************************************************************************
	//Z-Klipping (slutt)
	//****************************************************************************************************************

	int fc;
	fc=0;

	num_faces_new=0;
	for (i=0; i<num_faces; i++)
	{
		for (int n=0; n<polygons_real[i].num_vertices; n++)
		{
			if (n>=2)
			{
				int fc3=fc*3;
				SetClippedVertex(&polygons_real[i].vertices[n-n], fc3);
				SetClippedVertex(&polygons_real[i].vertices[n-1], fc3+1);
				SetClippedVertex(&polygons_real[i].vertices[n], fc3+2);
				SetNewFace(fc, fc3, fc3+1, fc3+2);
				SetNewFaceColor(fc, polygons_real[i].color);
				fc++;
			}
		}
		//todo: make some debugging info to get total amount of new faces..
	}
	num_faces_new=fc;




	//****************************************************************************************************************
	//Z-Sorting
	//****************************************************************************************************************
	zBuffer_num=0;

	//regn ut totalsummen av z-komponentene til face for � finne den st�rste (lengste) verdien.
	//kvadratrot er ikke n�dvendig siden avstanden har like stor skala.
	//
	for (i=0; i<num_faces_new; i++)
	{
		addZbuffer();
		zBuffer[i].index = i;
		zBuffer[i].depth = vertices_zclipped[faces_new[i].a].z+vertices_zclipped[faces_new[i].b].z+vertices_zclipped[faces_new[i].c].z;
	}

	//sorter verdiene tilslutt.
	//
	qsort(zBuffer, num_faces_new, sizeof(Zbuffer), compare);
	//****************************************************************************************************************
	//Z-Sorting (Slutt)
	//****************************************************************************************************************





	for (i=0, i3=0; i<num_faces_new; i++, i3+=3)
	{
		facenum=zBuffer[i].index; //facet som ligger lengst unna kameraet er f�rst.

		//
		//Regner ut 3 projiserte koordinater fra en face(triangel)
		//
		SetProjectedPoints(&vertices_zclipped[faces_new[facenum].a], midpoint, i3);
		SetProjectedPoints(&vertices_zclipped[faces_new[facenum].b], midpoint, i3+1);
		SetProjectedPoints(&vertices_zclipped[faces_new[facenum].c], midpoint, i3+2);
	}

	//****************************************************************************************************************
	//Sutherland-Hodgeman 2D Polygon Clipping
	//****************************************************************************************************************
//#define CLIP2D

	for (i=0, i3=0; i<num_faces_new; i++, i3+=3)
	{
		int ppinc;
//		facenum=zBuffer[i].index; //facet som ligger lengst unna kameraet er f�rst.

		//this is where the final clipped polygon is processed and stored.
		polygons_temp[i].SetPoint(points_project[i3].x, points_project[i3].y, 0);
		polygons_temp[i].SetPoint(points_project[i3+1].x, points_project[i3+1].y, 1);
		polygons_temp[i].SetPoint(points_project[i3+2].x, points_project[i3+2].y, 2);
		polygons_temp[i].point_counter=3;

		polygons_temp[i].points[0].u=points_project[i3].u;
		polygons_temp[i].points[0].v=points_project[i3].v;
		polygons_temp[i].points[1].u=points_project[i3+1].u;
		polygons_temp[i].points[1].v=points_project[i3+1].v;
		polygons_temp[i].points[2].u=points_project[i3+2].u;
		polygons_temp[i].points[2].v=points_project[i3+2].v;

		polygons_temp[i].points[0].z=points_project[i3].z;
		polygons_temp[i].points[1].z=points_project[i3+1].z;
		polygons_temp[i].points[2].z=points_project[i3+2].z;

		polygons_clipped[i].point_counter=0;


		//color
		polygons_clipped[i].color=faces_real[i].color;

#ifdef CLIP2D
		float is;
		//************************************
		//Clip to the 'LEFT' clipping boundary
		//************************************
		count=0;	//counting vertices of polygon.
		ppinc=0;
		while(count < polygons_temp[i].point_counter)
		{
			if (count < polygons_temp[i].point_counter-1)
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[count+1];
				c2.z=polygons_temp[i].points[count+1].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[count+1].u;
				t2.v=polygons_temp[i].points[count+1].v;
			}
			else
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[0];
				c2.z=polygons_temp[i].points[0].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[0].u;
				t2.v=polygons_temp[i].points[0].v;
			}

			count++;

			//True if c1 is outside and c2 is outside
			if ((!InsideLEFT(c1.x)) && (!InsideLEFT(c2.x)))
			{
				//no output
			} else

			//True if c1 is inside and c2 is inside
			if (InsideLEFT(c1.x) && InsideLEFT(c2.x))
			{
				//output c2
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
			} else

			//True if c1 is inside and c2 is outside
			if ((InsideLEFT(c1.x)) && (!InsideLEFT(c2.x)))
			{
//				double ip=(screenarea[0].x - c1.x) / (c2.x - c1.x);

				cin.x=screenarea[0].x;
				cin.y=c1.y + (c2.y - c1.y) * (screenarea[0].x - c1.x) / (c2.x - c1.x);

//				ti.u=0;
//				ti.v=t1.v + (t2.v - t1.v) * (0 - t1.u) / (t2.u - t1.u);

				double ip=(screenarea[0].x - c1.x) / (c2.x - c1.x);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=ci.z;
				ppinc++;
			} else

			//True if c1 is outside and c2 is inside
			if ((!InsideLEFT(c1.x)) && (InsideLEFT(c2.x)))
			{
				cin.y=c2.y + (c1.y - c2.y) * (screenarea[0].x - c2.x) / (c1.x - c2.x);
				cin.x=screenarea[0].x;

//				ti.u=0;
//				ti.v=t1.v + (t2.v - t1.v) * (0 - t1.u) / (t2.u - t1.u);

				double ip=(screenarea[0].x - c2.x) / (c1.x - c2.x);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
//				ci.z=c2.z + (c1.z - c2.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection and c2
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-2);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-2].z=ci.z;
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
				ppinc++;
			}
		}

		polygons_temp[i].point_counter=0;
		for (int j=0; j<ppinc; j++)
		{
			polygons_temp[i].SetPoint(polygons_clipped[i].points[j].x, polygons_clipped[i].points[j].y, j);
			polygons_temp[i].SetUV(polygons_clipped[i].points[j].u, polygons_clipped[i].points[j].v, j);
			polygons_temp[i].points[j].z=polygons_clipped[i].points[j].z;
			polygons_temp[i].point_counter++;
		}

		//************************************
		//Clip to the 'RIGHT' clipping boundary
		//************************************
		polygons_clipped[i].point_counter=0;
		count=0;
		ppinc=0;
		while(count < polygons_temp[i].point_counter)
		{
			if (count < polygons_temp[i].point_counter-1)
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[count+1];
				c2.z=polygons_temp[i].points[count+1].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[count+1].u;
				t2.v=polygons_temp[i].points[count+1].v;
			}
			else
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[0];
				c2.z=polygons_temp[i].points[0].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[0].u;
				t2.v=polygons_temp[i].points[0].v;
			}

			count++;

			//True if c1 is outside and c2 is outside
			if ((!InsideRIGHT(c1.x)) && (!InsideRIGHT(c2.x)))
			{
				//no output
			} else

			//True if c1 is inside and c2 is inside
			if (InsideRIGHT(c1.x) && InsideRIGHT(c2.x))
			{
				//output c2
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
			} else

			//True if c1 is inside and c2 is outside
			if ((InsideRIGHT(c1.x)) && (!InsideRIGHT(c2.x)))
			{
				cin.y=c1.y + (c2.y - c1.y) * (screenarea[1].x - c1.x) / (c2.x - c1.x);
				cin.x=screenarea[1].x;

				double ip=(screenarea[1].x - c1.x) / (c2.x - c1.x);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
//				ci.z=c2.z + (c1.z - c2.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=ci.z;
				ppinc++;
			} else

			//True if c1 is outside and c2 is inside
			if ((!InsideRIGHT(c1.x)) && (InsideRIGHT(c2.x)))
			{
				cin.y=c2.y + (c1.y - c2.y) * (screenarea[1].x - c2.x) / (c1.x - c2.x);
				cin.x=screenarea[1].x;

				double ip=(screenarea[1].x - c2.x) / (c1.x - c2.x);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
//				ci.z=c2.z + (c1.z - c2.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection and c2
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-2);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-2].z=ci.z;
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
				ppinc++;
			}
		}


		polygons_temp[i].point_counter=0;
		for (j=0; j<ppinc; j++)
		{
			polygons_temp[i].SetPoint(polygons_clipped[i].points[j].x, polygons_clipped[i].points[j].y, j);
			polygons_temp[i].SetUV(polygons_clipped[i].points[j].u, polygons_clipped[i].points[j].v, j);
			polygons_temp[i].points[j].z=polygons_clipped[i].points[j].z;
			polygons_temp[i].point_counter++;
		}


		//************************************
		//Clip to the 'TOP' clipping boundary
		//************************************
		polygons_clipped[i].point_counter=0;
		count=0;
		ppinc=0;
		while(count < polygons_temp[i].point_counter)
		{
			if (count < polygons_temp[i].point_counter-1)
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[count+1];
				c2.z=polygons_temp[i].points[count+1].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[count+1].u;
				t2.v=polygons_temp[i].points[count+1].v;
			}
			else
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[0];
				c2.z=polygons_temp[i].points[0].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[0].u;
				t2.v=polygons_temp[i].points[0].v;
			}

			count++;

			//True if c1 is outside and c2 is outside
			if ((!InsideTOP(c1.y)) && (!InsideTOP(c2.y)))
			{
				//no output
			} else

			//True if c1 is inside and c2 is inside
			if ((InsideTOP(c1.y)) && (InsideTOP(c2.y)))
			{
				//output c2
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
			} else

			//True if c1 is inside and c2 is outside
			if ((InsideTOP(c1.y)) && (!InsideTOP(c2.y)))
			{
				cin.x=c1.x + (screenarea[0].y - c1.y) * (c2.x - c1.x) / (c2.y - c1.y);
				cin.y=screenarea[0].y;

				double ip=(screenarea[0].y - c1.y) / (c2.y - c1.y);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=ci.z;
				ppinc++;
			} else

			//True if c1 is outside and c2 is inside
			if ((!InsideTOP(c1.y)) && (InsideTOP(c2.y)))
			{
				cin.x=c2.x + (screenarea[0].y - c2.y) * (c1.x - c2.x) / (c1.y - c2.y);
				cin.y=screenarea[0].y;

				double ip=(screenarea[0].y - c2.y) / (c1.y - c2.y);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection and c2
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-2);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-2].z=ci.z;
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
				ppinc++;
			}
		}

		polygons_temp[i].point_counter=0;
		for (j=0; j<ppinc; j++)
		{
			polygons_temp[i].SetPoint(polygons_clipped[i].points[j].x, polygons_clipped[i].points[j].y, polygons_temp[i].point_counter);
			polygons_temp[i].SetUV(polygons_clipped[i].points[j].u, polygons_clipped[i].points[j].v, j);
			polygons_temp[i].points[j].z=polygons_clipped[i].points[j].z;
			polygons_temp[i].point_counter++;
		}

		//************************************
		//Clip to the 'BOTTOM' clipping boundary
		//************************************
		polygons_clipped[i].point_counter=0;
		count=0;
		ppinc=0;
		while(count < polygons_temp[i].point_counter)
		{
			if (count < polygons_temp[i].point_counter-1)
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[count+1];
				c2.z=polygons_temp[i].points[count+1].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[count+1].u;
				t2.v=polygons_temp[i].points[count+1].v;
			}
			else
			{
				c1=polygons_temp[i].points[count];
				c1.z=polygons_temp[i].points[count].z;
				c2=polygons_temp[i].points[0];
				c2.z=polygons_temp[i].points[0].z;

				//tex
				t1.u=polygons_temp[i].points[count].u;
				t1.v=polygons_temp[i].points[count].v;
				t2.u=polygons_temp[i].points[0].u;
				t2.v=polygons_temp[i].points[0].v;
			}

			count++;

			//True if c1 is outside and c2 is outside
			if ((!InsideBOTTOM(c1.y)) && (!InsideBOTTOM(c2.y)))
			{
				//no output
			} else

			//True if c1 is inside and c2 is inside
			if ((InsideBOTTOM(c1.y)) && (InsideBOTTOM(c2.y)))
			{
				//output c2
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
			} else

			//True if c1 is inside and c2 is outside
			//(going out)
			if ((InsideBOTTOM(c1.y)) && (!InsideBOTTOM(c2.y)))
			{
				cin.x=c1.x + (screenarea[1].y - c1.y) * (c2.x - c1.x) / (c2.y - c1.y);
				cin.y=screenarea[1].y;

//				double t=1; //t=dist1/(dist1-dist2);
//				ti.u=t1.u+(t2.u-t1.u)*t;
//				ti.v=t1.v+(t2.v-t1.v)*t;
				double ip=(screenarea[1].y - c1.y) / (c2.y - c1.y);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=ci.z;
				ppinc++;
			} else

			//True if c1 is outside and c2 is inside
			//(coming in)
			if ((!InsideBOTTOM(c1.y)) && (InsideBOTTOM(c2.y)))
			{
				cin.x=c2.x + (screenarea[1].y - c2.y) * (c1.x - c2.x) / (c1.y - c2.y);
				cin.y=screenarea[1].y;

				double ip=(screenarea[1].y - c2.y) / (c1.y - c2.y);
				ti.u=t1.u + (t2.u - t1.u) * ip;
				ti.v=t1.v + (t2.v - t1.v) * ip;
				ti.z=t1.z + (t2.z - t1.z) * ip;
				ci.z=c1.z + (c2.z - c1.z) * ip;

				//output intersection and c2
				polygons_clipped[i].SetPoint(cin.x,cin.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetPoint(c2.x,c2.y, polygons_clipped[i].point_counter++);
				polygons_clipped[i].SetUV(ti.u, ti.v, polygons_clipped[i].point_counter-2);
				polygons_clipped[i].SetUV(t2.u, t2.v, polygons_clipped[i].point_counter-1);
				polygons_clipped[i].points[polygons_clipped[i].point_counter-2].z=ci.z;
				polygons_clipped[i].points[polygons_clipped[i].point_counter-1].z=c2.z;
				ppinc++;
				ppinc++;
			}
		}

		polygons_temp[i].point_counter=0;
		for (j=0; j<ppinc; j++)
		{
			polygons_temp[i].SetPoint(polygons_clipped[i].points[j].x, polygons_clipped[i].points[j].y, j);
			polygons_temp[i].SetUV(polygons_clipped[i].points[j].u, polygons_clipped[i].points[j].v, j);
			polygons_temp[i].points[j].z=polygons_clipped[i].points[j].z;
			polygons_temp[i].point_counter++;
		}

		polygons_clipped[i].num_points=polygons_clipped[i].point_counter;

#else
//
//		no clip
//
		for (j=0; j<3; j++)
		{
			polygons_clipped[i].SetPoint(polygons_temp[i].points[j].x, polygons_temp[i].points[j].y, j);
			polygons_clipped[i].points[j].u=polygons_temp[i].points[j].u;
			polygons_clipped[i].points[j].v=polygons_temp[i].points[j].v;

			//for texturemapper
			polygons_clipped[i].points[j].z=polygons_temp[i].points[j].z;
		}
		polygons_clipped[i].num_points=3;
//
//
//
#endif
		//
		polygons_clipped[i].ab=faces_real[i].ab;
		polygons_clipped[i].bc=faces_real[i].bc;
		polygons_clipped[i].ca=faces_real[i].ca;

		//add color
//		polygons_clipped[i].color=polygons_temp[i].color;
//		polygons_clipped[i].color=faces_real[i].color;

		if (flag_vertex_and_face_normals==true)
		{
			polygons_clipped[i].face_normal=polygons_temp[i].face_normal;
			polygons_clipped[i].vertex_normals[0]=polygons_temp[i].vertex_normals[0];
			polygons_clipped[i].vertex_normals[1]=polygons_temp[i].vertex_normals[1];
			polygons_clipped[i].vertex_normals[2]=polygons_temp[i].vertex_normals[2];
		}
	}




	//-----------------------------------------------------------------------------------------------------------------
	//Draw Clipped object
	//-----------------------------------------------------------------------------------------------------------------
	//- projected+clipped polygon .

	Vector3D face_normal;

//	int gh=ftime*100;
//	gh%=num_faces_new;
	for (i=0, i3=0; i<num_faces_new; i++, i3+=3)
//	for (i=0, i3=0; i<gh; i++, i3+=3)
	{
		facenum=zBuffer[i].index;
//		facenum=i;

		v[0]=vertices_zclipped[faces_new[facenum].a];
		v[1]=vertices_zclipped[faces_new[facenum].b];
		v[2]=vertices_zclipped[faces_new[facenum].c];

//		int col=faces_real[facenum].color;
//		int col=faces_new[facenum].color;
//		int col=polygons_clipped[i].color;
		int col=0xffffff;

		//
		// Projiserte koordinater
		//
		scr[0].x=points_project[i3].x;
		scr[0].y=points_project[i3].y;
		scr[1].x=points_project[i3+1].x;
		scr[1].y=points_project[i3+1].y;
		scr[2].x=points_project[i3+2].x;
		scr[2].y=points_project[i3+2].y;

//		scr[0]=project3d(v[0],zscale);
//		scr[1]=project3d(v[1],zscale);
//		scr[2]=project3d(v[2],zscale);

		//
		// Prosessen for � bestemme om et face er synlig
		// eller ikke omtales vanligvis som Backface Culling.
		//
		Vector2D d1(scr[2].x-scr[0].x, scr[2].y-scr[0].y);
		Vector2D d2(scr[2].x-scr[1].x, scr[2].y-scr[1].y);
		float backface=cross_product_2d(d1,d2);



		//
		//calculate face normals
		//
		Vector3D FA,FB,FC,N,n0,n1,n2;
		Vector3D no[3];

		//
		//load vertex normal
		//
		bool show_normals;
//		show_normals=true;
		show_normals=false;

		int mul;
		if (flag_vertex_and_face_normals==true)
		{
//			mul=8;
//			mul=16;
//			mul=64;
			mul=128;
//			mul=192;
//			mul=256;

			face_normal=polygons_clipped[facenum].face_normal;
//			face_normal=face_normals[facenum];
//			face_normal.Normalize();

			no[0].Set(
			polygons_clipped[facenum].vertex_normals[1].vec.x,
			polygons_clipped[facenum].vertex_normals[1].vec.y,
			polygons_clipped[facenum].vertex_normals[1].vec.z);
			no[0].Normalize();

	  		n0.Set(v[0].x, v[0].y, v[0].z);
			n0.x+=no[0].x;
			n0.y+=no[0].y;
			n0.z+=no[0].z;

			no[1].Set(
			polygons_clipped[facenum].vertex_normals[2].vec.x,
			polygons_clipped[facenum].vertex_normals[2].vec.y,
			polygons_clipped[facenum].vertex_normals[2].vec.z);
			no[1].Normalize();

  			n1.Set(v[1].x, v[1].y, v[1].z);
			n1.x+=no[1].x;
			n1.y+=no[1].y;
			n1.z+=no[1].z;

			no[2].Set(
			polygons_clipped[facenum].vertex_normals[0].vec.x,
			polygons_clipped[facenum].vertex_normals[0].vec.y,
			polygons_clipped[facenum].vertex_normals[0].vec.z);
			no[2].Normalize();

  			n2.Set(v[2].x, v[2].y, v[2].z);
			n2.x+=no[2].x;
			n2.y+=no[2].y;
			n2.z+=no[2].z;

			if (show_normals==true)
			{
				n[0]=project3d_new(v[0], zscale, width_half, height_half);
				n[1]=project3d_new(n0, zscale, width_half, height_half);
				n[2]=project3d_new(v[1], zscale, width_half, height_half);
				n[3]=project3d_new(n1, zscale, width_half, height_half);
				n[4]=project3d_new(v[2], zscale, width_half, height_half);
				n[5]=project3d_new(n2, zscale, width_half, height_half);
			}
		}




		//
		//
		//

		if(backface>0 || culling==-1)
		{
			//we dont need these when we calculate them before the loop starts

			//
			//calculate face-normal vector
			//
			vector_a=v[0];
			vector_a.Substract(v[1]);
//			vector_b=v[0];
//			vector_b.Substract(v[2]);
			vector_b=v[2];
			vector_b.Substract(v[1]);
			normal_vector=cross_product(vector_a,vector_b);
			normal_vector.Normalize();
			//
			//end of calculating face-normal vector
			//

//			face_normal.Normalize();
//			if (culling==0) normal_vector.z=-1;
//			if(normal_vector.z<0)// || culling==-1)
			{
/*				//
				//Flat Shading: Lambert flat
				//
//				light.Set(10,10,-0.003);
				light.Set(0,0,-1);
//				light.Set(0,0,1);
//				light.Set(1,-2,1);
//				light.Set(1,-1,1);
				light.Set(1,1,sin(mov*0.1)*2);
				light.Normalize();
*/
				//hack
//				if (culling==-1) if (normal_vector.z<0) normal_vector.z=-normal_vector.z;

				//
				//calculate intensity for face_normal
				//
				light.Set(
//					0.5+sin(ftime)*0.5,
//					0.5+sin(2*ftime)*0.5,
//					0.5+sin(3*ftime)*0.5
					0,
					0,//-1,
					-1//sin(ftime)
					);

		if (flag_vertex_and_face_normals==true)
				intensity=dot_product(light,face_normal);
		else
				intensity=dot_product(light,normal_vector);

				if (intensity<=0) intensity=0;
//				if (intensity<=0) intensity=-intensity; //se outside and inside
				if (intensity>=1) intensity=1;

				//
				//do the same for vertex normals
				//
/*				no[0].Negate();
				no[1].Negate();
				no[2].Negate();*/

				float intensity_0=dot_product(light,no[0]);
				if (intensity_0<=0.0) intensity_0=0.0;
				if (intensity_0>=1.0) intensity_0=1.0;
//				if (intensity_0<=0) intensity_0=-intensity_0;

				float intensity_1=dot_product(light,no[1]);
				if (intensity_1<=0.0) intensity_1=0.0;
				if (intensity_1>=1.0) intensity_1=1.0;
//				if (intensity_1<=0) intensity_1=-intensity_1;

				float intensity_2=dot_product(light,no[2]);
				if (intensity_2<=0.0) intensity_2=0.0;
				if (intensity_2>=1.0) intensity_2=1.0;
//				if (intensity_2<=0) intensity_2=-intensity_2;

				intensity_0=1-intensity_0;
				intensity_1=1-intensity_1;
				intensity_2=1-intensity_2;

				//environment mapping
				if (envmap==true && flag_vertex_and_face_normals==true)
				{
//					v[0].Normalize();
//					v[1].Normalize();
//					v[2].Normalize();
/*					polygons_clipped[i].points[0].u=(int)(scr[0].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[0].v=(int)(scr[0].y*height_half+height_half-1)&0xff;
					polygons_clipped[i].points[1].u=(int)(scr[1].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[1].v=(int)(scr[1].y*height_half+height_half-1)&0xff;
					polygons_clipped[i].points[2].u=(int)(scr[2].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[2].v=(int)(scr[2].y*height_half+height_half-1)&0xff;
*/
					float sf=0.5;
//					float sf=1.5;
//					float sf=1.0;
//					float sf=128;
/*					polygons_clipped[i].points[0].u=(int)(sf*v[0].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[0].v=(int)(sf*v[0].y*height_half+height_half-1)&0xff;
					polygons_clipped[i].points[1].u=(int)(sf*v[1].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[1].v=(int)(sf*v[1].y*height_half+height_half-1)&0xff;
					polygons_clipped[i].points[2].u=(int)(sf*v[2].x*width_half+width_half-1)&0xff;
					polygons_clipped[i].points[2].v=(int)(sf*v[2].y*height_half+height_half-1)&0xff;
*/

					//mul=127;
					no[0].x=(int)(no[0].x*mul);
					no[0].y=(int)(no[0].y*mul);
					no[1].x=(int)(no[1].x*mul);
					no[1].y=(int)(no[1].y*mul);
					no[2].x=(int)(no[2].x*mul);
					no[2].y=(int)(no[2].y*mul);

//					polygons_clipped[i].points[0].u=(int)(no[0].x+width_half-1)&0xff;
//					polygons_clipped[i].points[0].v=(int)(no[0].y+height_half-1)&0xff;
//					polygons_clipped[i].points[1].u=(int)(no[1].x+width_half-1)&0xff;
//					polygons_clipped[i].points[1].v=(int)(no[1].y+height_half-1)&0xff;
//					polygons_clipped[i].points[2].u=(int)(no[2].x+width_half-1)&0xff;
//					polygons_clipped[i].points[2].v=(int)(no[2].y+height_half-1)&0xff;
					polygons_clipped[i].points[0].u=(int)(no[0].x+width_half-1);
					polygons_clipped[i].points[0].v=(int)(no[0].y+height_half-1);
					polygons_clipped[i].points[1].u=(int)(no[1].x+width_half-1);
					polygons_clipped[i].points[1].v=(int)(no[1].y+height_half-1);
					polygons_clipped[i].points[2].u=(int)(no[2].x+width_half-1);
					polygons_clipped[i].points[2].v=(int)(no[2].y+height_half-1);

					if (polygons_clipped[i].points[0].u>=255) polygons_clipped[i].points[0].u=255;
					if (polygons_clipped[i].points[0].v>=255) polygons_clipped[i].points[0].v=255;
					if (polygons_clipped[i].points[1].u>=255) polygons_clipped[i].points[1].u=255;
					if (polygons_clipped[i].points[1].v>=255) polygons_clipped[i].points[1].v=255;
					if (polygons_clipped[i].points[2].u>=255) polygons_clipped[i].points[2].u=255;
					if (polygons_clipped[i].points[2].v>=255) polygons_clipped[i].points[2].v=255;
/*
					polygons_clipped[i].points[0].u=(int)(n0.x*sf+width_half-1)&0xff;
					polygons_clipped[i].points[0].v=(int)(n0.y*sf+height_half-1)&0xff;
					polygons_clipped[i].points[1].u=(int)(n1.x*sf+width_half-1)&0xff;
					polygons_clipped[i].points[1].v=(int)(n1.y*sf+height_half-1)&0xff;
					polygons_clipped[i].points[2].u=(int)(n2.x*sf+width_half-1)&0xff;
					polygons_clipped[i].points[2].v=(int)(n2.y*sf+height_half-1)&0xff;
*/
				}
				//
				//Flat Shading: Z-flat (FAKE M�TE � GJ�RE DET P�!! IKKE BRUK DENNE PLZ!)
				//
/*				v[0].Normalize();
				v[1].Normalize();
				v[2].Normalize();
				float intensity=(v[0].z+v[1].z+v[2].z)/3;
				if (intensity<0) intensity=0;
				if (intensity>=1) intensity=1;
*/



				int color;
				int gcol[3]; //gouraud colors

				//
				//3ds and gouraud
				//
				if (color_flag==0) //fixed
					color=color_flat_fixed;
				else
				if (color_flag==1) //shading
				{
//					color=RGB32((int)(intensity*getRed(color_flat_shading)),(int)(intensity*getGreen(color_flat_shading)),(int)(intensity*getBlue(color_flat_shading)));
//					color=RGB32((int)(intensity*getRed(col)),(int)(intensity*getGreen(col)),(int)(intensity*getBlue(col)));
/*
					//Assign material color to color
					int material_ambient_color; int mac;
					int material_diffuse_color;
					int material_specular_color;
					if (flag_material)
					{
						//fjas inn phong illumination modellen her:
						//color = ambient + (cos x) * diffuse + (cos x)^n * specular

						//view angle:
						Vector3D view(0,0,-1);

						int ra,ga,ba;	//ambient
						int rd,gd,bd;	//diffuse
						int rs,gs,bs;	//specular
						float specular_level, specular_exponent;//glossiness;

						material_ambient_color=material[0].PhongParameters[MATERIAL_AMBIENT];
						material_diffuse_color=material[0].PhongParameters[MATERIAL_DIFFUSE];
						material_specular_color=material[0].PhongParameters[MATERIAL_SPECULAR];
						ra=getRed(material_ambient_color);
						ga=getGreen(material_ambient_color);
						ba=getBlue(material_ambient_color);
						rd=getRed(material_diffuse_color);
						gd=getGreen(material_diffuse_color);
						bd=getBlue(material_diffuse_color);

						material[0].specular_level=50+sin(ftime)*49;
						specular_level=(float)material[0].specular_level/100;

						rs=(float)getRed(material_specular_color) * specular_level;
						gs=(float)getGreen(material_specular_color) * specular_level;
						bs=(float)getBlue(material_specular_color) * specular_level;

						material[0].glossiness=(float)50+sin(ftime*2)*46;
						specular_exponent=(float)material[0].glossiness/100;///100*180;

						float r_diffuse[3];
						float g_diffuse[3];
						float b_diffuse[3];
						float r_specular[3];
						float g_specular[3];
						float b_specular[3];

						r_diffuse[0]=intensity_0 * rd;
						g_diffuse[0]=intensity_0 * gd;
						b_diffuse[0]=intensity_0 * bd;
						r_diffuse[1]=intensity_1 * rd;
						g_diffuse[1]=intensity_1 * gd;
						b_diffuse[1]=intensity_1 * bd;
						r_diffuse[2]=intensity_2 * rd;
						g_diffuse[2]=intensity_2 * gd;
						b_diffuse[2]=intensity_2 * bd;

						r_specular[0]=pow(intensity_0, specular_exponent) * rs;
						g_specular[0]=pow(intensity_0, specular_exponent) * gs;
						b_specular[0]=pow(intensity_0, specular_exponent) * bs;
						r_specular[1]=pow(intensity_1, specular_exponent) * rs;
						g_specular[1]=pow(intensity_1, specular_exponent) * gs;
						b_specular[1]=pow(intensity_1, specular_exponent) * bs;
						r_specular[2]=pow(intensity_2, specular_exponent) * rs;
						g_specular[2]=pow(intensity_2, specular_exponent) * gs;
						b_specular[2]=pow(intensity_2, specular_exponent) * bs;

						int rsum0=ra;
						int gsum0=ga;
						int bsum0=ba;
						rsum0+=r_diffuse[0];
						gsum0+=g_diffuse[0];
						bsum0+=b_diffuse[0];
						rsum0+=r_specular[0];
						gsum0+=g_specular[0];
						bsum0+=b_specular[0];

						int rsum1=ra;
						int gsum1=ga;
						int bsum1=ba;
						rsum1+=r_diffuse[1];
						gsum1+=g_diffuse[1];
						bsum1+=b_diffuse[1];
						rsum1+=r_specular[1];
						gsum1+=g_specular[1];
						bsum1+=b_specular[1];

						int rsum2=ra;
						int gsum2=ga;
						int bsum2=ba;
						rsum2+=r_diffuse[2];
						gsum2+=g_diffuse[2];
						bsum2+=b_diffuse[2];
						rsum2+=r_specular[2];
						gsum2+=g_specular[2];
						bsum2+=b_specular[2];

						if (rsum0>255) rsum0=255;
						if (gsum0>255) gsum0=255;
						if (bsum0>255) bsum0=255;
						if (rsum1>255) rsum1=255;
						if (gsum1>255) gsum1=255;
						if (bsum1>255) bsum1=255;
						if (rsum2>255) rsum2=255;
						if (gsum2>255) gsum2=255;
						if (bsum2>255) bsum2=255;

//						if (rsum0<0) rsum0=0;
//						if (gsum0<0) gsum0=0;
//						if (bsum0<0) bsum0=0;
//						if (rsum1<0) rsum1=0;
//						if (gsum1<0) gsum1=0;
//						if (bsum1<0) bsum1=0;
//						if (rsum2<0) rsum2=0;
//						if (gsum2<0) gsum2=0;
//						if (bsum2<0) bsum2=0;

						//gouraud
						gcol[0]=RGB32(rsum0,gsum0,bsum0);
						gcol[1]=RGB32(rsum1,gsum1,bsum1);
						gcol[2]=RGB32(rsum2,gsum2,bsum2);

						//flat
						int rsum_=ra + rd*intensity + powf(intensity, specular_exponent)*rs;
						int gsum_=ga + gd*intensity + powf(intensity, specular_exponent)*gs;
						int bsum_=ba + bd*intensity + powf(intensity, specular_exponent)*bs;
						rsum_=rsum_>=255?255:rsum_;
						gsum_=gsum_>=255?255:gsum_;
						bsum_=bsum_>=255?255:bsum_;
						color=RGB32(rsum_,gsum_,bsum_);
				}
					else
					{
						material_ambient_color=0xffffff;	//default: material ambient color
						
						//gouraud
						gcol[0]=RGB32((int)(intensity_0*getRed(material_ambient_color)),(int)(intensity_0*getGreen(material_ambient_color)),(int)(intensity_0*getBlue(material_ambient_color)));
						gcol[1]=RGB32((int)(intensity_1*getRed(material_ambient_color)),(int)(intensity_1*getGreen(material_ambient_color)),(int)(intensity_1*getBlue(material_ambient_color)));
						gcol[2]=RGB32((int)(intensity_2*getRed(material_ambient_color)),(int)(intensity_2*getGreen(material_ambient_color)),(int)(intensity_2*getBlue(material_ambient_color)));
						color=RGB32((int)(intensity*getRed(material_ambient_color)),(int)(intensity*getGreen(material_ambient_color)),(int)(intensity*getBlue(material_ambient_color)));
					}*/
//for flat
					color=RGB32((int)(intensity*getRed(color_flat_shading)),(int)(intensity*getGreen(color_flat_shading)),(int)(intensity*getBlue(color_flat_shading)));
				}


//for gouraud
				int material_ambient_color=0xffffff;
				gcol[0]=RGB32((int)(intensity_0*getRed(material_ambient_color)),(int)(intensity_0*getGreen(material_ambient_color)),(int)(intensity_0*getBlue(material_ambient_color)));
				gcol[1]=RGB32((int)(intensity_1*getRed(material_ambient_color)),(int)(intensity_1*getGreen(material_ambient_color)),(int)(intensity_1*getBlue(material_ambient_color)));
				gcol[2]=RGB32((int)(intensity_2*getRed(material_ambient_color)),(int)(intensity_2*getGreen(material_ambient_color)),(int)(intensity_2*getBlue(material_ambient_color)));
//

				color_wireframe_fixed=0;
//				color_wireframe_fixed=0xffffff;
//				color_wireframe_shading=RGB32((int)(intensity*255),(int)(intensity*255),(int)(intensity*255));

/*				if (scr[0].x>=0 && scr[0].x<WIDTH &&
					scr[0].y>=0 && scr[0].y<HEIGHT &&
					scr[1].x>=0 && scr[1].x<WIDTH &&
					scr[1].y>=0 && scr[1].y<HEIGHT &&
					scr[2].x>=0 && scr[2].x<WIDTH &&
					scr[2].y>=0 && scr[2].y<HEIGHT)
*/
//				if (line_clip(&scr[0].x, &scr[0].y, &scr[1].x, &scr[1].y))
//				if (line_clip(&scr[1].x, &scr[1].y, &scr[2].x, &scr[2].y))
//				if (line_clip(&scr[2].x, &scr[2].y, &scr[0].x, &scr[0].y))



				//alpha=127;//255-vertices_zclipped[faces_new[facenum].a].z*212;

				color_dot_fixed=col;//polygons_clipped[i].color;
//				color=polygons_clipped[i].color;

				polygons_clipped[i].perspective_correct=perspective_correct;


//				rendermode=material[0].shading_type;
//				rendermode=RENDERMODE_FLAT;
//				rendermode=RENDERMODE_GOURAUD;

				//?polygons_clipped[i].DrawDot(layer, tobuffer, color_dot_fixed):
				(rendermode==RENDERMODE_WIREFRAME)	?polygons_clipped[i].DrawLine(layer.mainbuffer.pixel,color)://_wireframe_shading):
				(rendermode==RENDERMODE_FLAT)		?polygons_clipped[i].DrawTriFill(layer, tobuffer, color):
				(rendermode==RENDERMODE_GOURAUD)	?polygons_clipped[i].DrawGouraud(layer, tobuffer, gcol[0], gcol[1], gcol[2]):
				(rendermode==RENDERMODE_PHONG)		?polygons_clipped[i].DrawGouraud(layer, tobuffer, gcol[0], gcol[1], gcol[2]):
				(rendermode==RENDERMODE_METAL)		?polygons_clipped[i].DrawGouraud(layer, tobuffer, gcol[0], gcol[1], gcol[2]):
				(rendermode==RENDERMODE_TEXTURE)	?polygons_clipped[i].DrawTexture(layer, tobuffer, texture):
				(rendermode==6)?polygons_clipped[i].DrawSprite(layer, tobuffer, frombuffer, vertices_zclipped[faces_new[facenum].a].z+375):0;

//					polygons_clipped[i].DrawLine(layer.mainbuffer.pixel,color_wireframe_fixed):(rendermode==4)?
/*					polygons_clipped[i].DrawTriFill(layer, tobuffer, color):(rendermode==1)?
					polygons_clipped[i].DrawLine(layer.mainbuffer.pixel,color_wireframe_shading):(rendermode==2)?
					polygons_clipped[i].DrawSprite(layer, tobuffer, frombuffer, vertices_zclipped[faces_new[facenum].a].z+375):(rendermode==3)?
					polygons_clipped[i].DrawLine(layer.mainbuffer.pixel,color_wireframe_fixed):(rendermode==4)?
					polygons_clipped[i].DrawTexture(layer, tobuffer, texture):(rendermode==5)?*/


//				if (i<1500)
//				if (i<=512)
//				polygons_clipped[i].DrawDot(layer,tobuffer,0xffffff);
//				polygons_clipped[i].DrawDot(layer,tobuffer,0xff0000);





//				g_tri_flat((int*)pixel,scr[0].x,scr[0].y,scr[1].x,scr[1].y,scr[2].x,scr[2].y,color_flat_fixed);
//				triangle(pixel, scr[0].x,scr[0].y,scr[1].x,scr[1].y,scr[2].x,scr[2].y,color);

/*
				if (faces_real[facenum].ab==1)
				{
//					if (line_clip(&scr[0].x, &scr[0].y, &scr[1].x, &scr[1].y))
//						line(pixel,scr[0].x,scr[0].y,scr[1].x,scr[1].y,color_wireframe_shading);

					if (visible(scr[0].x,scr[0].y) && visible(scr[1].x,scr[1].y))
						g_line((int *)pixel,scr[0].x,scr[0].y,scr[1].x,scr[1].y,color_wireframe_fixed);
//						line(pixel,scr[0].x,scr[0].y,scr[1].x,scr[1].y,color_wireframe_fixed);
//						line(pixel,scr[0].x+1,scr[0].y,scr[1].x+1,scr[1].y,color_wireframe_fixed);
//						line(pixel,scr[0].x+1,scr[0].y+1,scr[1].x+1,scr[1].y+1,color_wireframe_fixed);
//						line(pixel,scr[0].x,scr[0].y+1,scr[1].x,scr[1].y+1,color_wireframe_fixed);
				}
				if (faces_real[facenum].bc==1)
				{
//					if (line_clip(&scr[1].x, &scr[1].y, &scr[2].x, &scr[2].y))
//						line(pixel,scr[1].x,scr[1].y,scr[2].x,scr[2].y,color_wireframe_shading);

					if (visible(scr[1].x,scr[1].y) && visible(scr[2].x,scr[2].y))
						g_line((int *)pixel,scr[1].x,scr[1].y,scr[2].x,scr[2].y,color_wireframe_fixed);
//						line(pixel,scr[1].x,scr[1].y,scr[2].x,scr[2].y,color_wireframe_fixed);
//						line(pixel,scr[1].x+1,scr[1].y,scr[2].x+1,scr[2].y,color_wireframe_fixed);
//						line(pixel,scr[1].x+1,scr[1].y+1,scr[2].x+1,scr[2].y+1,color_wireframe_fixed);
//						line(pixel,scr[1].x,scr[1].y+1,scr[2].x,scr[2].y+1,color_wireframe_fixed);
				}
				if (faces_real[facenum].ca==1)
				{
//					if (line_clip(&scr[2].x, &scr[2].y, &scr[0].x, &scr[0].y))
//						line(pixel,scr[2].x,scr[2].y,scr[0].x,scr[0].y,color_wireframe_shading);

					if (visible(scr[2].x,scr[2].y) && visible(scr[0].x,scr[0].y))
						g_line((int *)pixel,scr[2].x,scr[2].y,scr[0].x,scr[0].y,color_wireframe_fixed);
//						line(pixel,scr[2].x,scr[2].y,scr[0].x,scr[0].y,color_wireframe_fixed);
//						line(pixel,scr[2].x+1,scr[2].y,scr[0].x+1,scr[0].y,color_wireframe_fixed);
//						line(pixel,scr[2].x+1,scr[2].y+1,scr[0].x+1,scr[0].y+1,color_wireframe_fixed);
//						line(pixel,scr[2].x,scr[2].y+1,scr[0].x,scr[0].y+1,color_wireframe_fixed);
				}*/



						//
						//show normals
						//
						int normcol=0xffffff;
//						int normcol=0x3faf3f;
//						int normcol=0;
						if (show_normals==true)
						{
							g_line((int*)pixel,width,height,n[0].x,n[0].y,n[1].x,n[1].y,normcol);
							g_line((int*)pixel,width,height,n[2].x,n[2].y,n[3].x,n[3].y,normcol);
							g_line((int*)pixel,width,height,n[4].x,n[4].y,n[5].x,n[5].y,normcol);
						}
/*
						g_line((int*)pixel,n[6].x,n[6].y,n[6].x,n[6].y,normcol);
						g_line((int*)pixel,n[7].x,n[7].y,n[7].x,n[7].y,normcol);
						g_line((int*)pixel,n[8].x,n[8].y,n[8].x,n[8].y,normcol);
						g_line((int*)pixel,n[9].x,n[9].y,n[9].x,n[9].y,normcol);
						g_line((int*)pixel,n[10].x,n[10].y,n[10].x,n[10].y,normcol);
						g_line((int*)pixel,n[11].x,n[11].y,n[11].x,n[11].y,normcol);
						*/
//						line(pixel,n[0].x,n[0].y, n[1].x,n[1].y,normcol);
//						line(pixel,n[2].x,n[2].y, n[3].x,n[3].y,normcol);
//						line(pixel,n[4].x,n[4].y, n[5].x,n[5].y,normcol);
			}
		}
	}
	//
	//
//	DrawClipscreenarea(layer, tobuffer, 0xffffff);
	//
	//
}

void Object::Morph(Object fromObject, float factor)
{
	for (int i=0; i<num_vertices; i++)
	{
		vertices_real[i].x=factor*vertices_real[i].x+(1-factor)*fromObject.vertices_real[i].x;
		vertices_real[i].y=factor*vertices_real[i].y+(1-factor)*fromObject.vertices_real[i].y;
		vertices_real[i].z=factor*vertices_real[i].z+(1-factor)*fromObject.vertices_real[i].z;
	}
}

void Object::Copy(Object fromObject)
{
	for (int i=0; i<num_vertices; i++)
	{
		vertices_real[i].x=fromObject.vertices_real[i].x;
		vertices_real[i].y=fromObject.vertices_real[i].y;
		vertices_real[i].z=fromObject.vertices_real[i].z;
	}
}

void Object::Rotate(float xrot, float yrot, float zrot)
{
	rotate.x=xrot;
	rotate.y=yrot;
	rotate.z=zrot;
}

void Object::Rotate(Vector3D rot)
{
	rotate.x=rot.x;
	rotate.y=rot.y;
	rotate.z=rot.z;
}

void Object::Translate(Vector3D tra)
{
	translate.x=tra.x;
	translate.y=tra.y;
	translate.z=tra.z;
}

void Object::mLoadIdentity()
{
	Currentmatrix.LoadIdentity();
//	Processmatrix.LoadIdentity();
}

void Object::mTranslate(Vector3D translation)
{
//	Translationmatrix.CreateTranslationMatrix(translation);
	Processmatrix.CreateTranslationMatrix(translation);
//	Currentmatrix=Currentmatrix*Translationmatrix;
	Currentmatrix=Currentmatrix*Processmatrix;
}

void Object::mRotate(Vector3D rotation)
{
//	Rotationmatrix.CreateRotationMatrix(rotation);
	Processmatrix.CreateRotationMatrix(rotation);
//	Currentmatrix=Currentmatrix*Rotationmatrix;
	Currentmatrix=Currentmatrix*Processmatrix;
}

//Normals

void Object::mLoadIdentityN()
{
	CurrentmatrixN.LoadIdentity();
}

void Object::mTranslateN(Vector3D translation)
{
	ProcessmatrixN.CreateTranslationMatrix(translation);
	CurrentmatrixN=CurrentmatrixN*ProcessmatrixN;
}

void Object::mRotateN(Vector3D rotation)
{
	ProcessmatrixN.CreateRotationMatrix(rotation);
	CurrentmatrixN=CurrentmatrixN*ProcessmatrixN;
	rotate=rotation;
}

void Object::mCameraLookAt(Vector3D eye, Vector3D center, Vector3D up)
{
	Cameramatrix.CreateCameraMatrix(eye, center, up);
//	Cameramatrix.LookAt(eye, center, up);

	Currentmatrix=Currentmatrix*Cameramatrix;

//	Vector3D ieye(-eye.x, -eye.y, -eye.z); //invert
//	mTranslate(ieye);
}
