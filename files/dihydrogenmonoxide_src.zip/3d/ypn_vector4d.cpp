#include "ypn_vector4d.h"

Vector4D::Vector4D()
{

}

Vector4D::Vector4D(float _x, float _y, float _z, float _w)
{
	x=_x;
	y=_y;
	z=_z;
	w=_w;
}

Vector4D::~Vector4D()
{

}

float dot_product(Vector4D a, Vector4D b)
{
	return ((a.x*b.x)+(a.y*b.y)+(a.z*b.z)+(a.w*b.w));
}
