#include "ypn_edge.h"

Edge::Edge()
{

}

Edge::~Edge()
{

}

void Edge::Set(int si, int ei)
{
	start_point=si;
	end_point=ei;
}