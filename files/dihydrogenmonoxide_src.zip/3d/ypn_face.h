#ifndef _face
#define _face

#include "../commonheaders/ypn_common.h"
#include "ypn_vector3d.h"

class Face
{
public:

	Face();
	~Face();

	void Set(unsigned short _a, unsigned short _b, unsigned short _c);
	void SetSides(char _ab, char _bc, char _ca);

	unsigned short a,b,c;
	char ab,bc,ca;
	int t1, t2, t3;	//texture ref.
	unsigned short visible;
	unsigned short flag;

	//vertex normals (3ds-reader)
	ulong smooth;

	//texture coords.
	int au, av;
	int bu, bv;
	int cu, cv;

	Vector3D face_normal;
	Normal vertex_normals[3];
	Vector3D vertex_normal;

	int color;
};

#endif