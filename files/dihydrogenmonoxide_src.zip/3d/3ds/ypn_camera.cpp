#include "ypn_camera.h"

Camera::Camera()
{

}

Camera::~Camera()
{

}
