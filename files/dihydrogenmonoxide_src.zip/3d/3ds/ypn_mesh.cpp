#include "ypn_mesh.h"

Mesh::Mesh() : ObjectName()
{
	vertices=0;
	num_vertices=0;
	faces=0;
	num_faces=0;

	material_name=0;
	material_name_size=0;
}

Mesh::~Mesh()
{
}

//void Mesh::AddVertex(Vector3D v)
void Mesh::AddVertex(float x, float y, float z)
{
	num_vertices++;

	vertices=(Vector3D*)realloc(vertices, num_vertices*sizeof(Vector3D));
	vertices[num_vertices-1].x=x;
	vertices[num_vertices-1].y=y;
	vertices[num_vertices-1].z=z;
}

void Mesh::AddUV(int index, float u, float v)
{
	vertices[index].u=u;
	vertices[index].v=v;
}

void Mesh::AddFace(unsigned short a, unsigned short b, unsigned short c, unsigned short visible)
{
	num_faces++;
	faces=(Face *)realloc(faces, num_faces*sizeof(Face));
//	faces=(Face**)realloc(faces, num_faces*sizeof(Face*));
//	faces[num_faces-1].Set(a,b,c);
	faces[num_faces-1].a=a;
	faces[num_faces-1].b=b;
	faces[num_faces-1].c=c;
	faces[num_faces-1].visible=visible;
}

void Mesh::SetMaterialName(const char *name)
{
	material_name_size=strlen(name)+1;
	material_name=(char *)malloc(material_name_size);
	strcpy(material_name, name);
}
