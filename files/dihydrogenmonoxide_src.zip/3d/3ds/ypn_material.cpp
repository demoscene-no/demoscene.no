#include "ypn_material.h"

Material::Material()
{
	phong_index=0;
	glossiness=0;
	specular_level=0;
}

Material::~Material()
{

}
