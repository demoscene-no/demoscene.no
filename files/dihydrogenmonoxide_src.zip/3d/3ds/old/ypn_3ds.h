//
//3D-STUDIO (3DS) Parser by Rudi B. Stranden aka activator/yaphan
//Written to have a decent 3d-engine before The Gathering 2005.democompo.
//19.03.2005
//
#include <stdio.h>
#include "ypn_mesh.h"
#include "ypn_material.h"
#include "ypn_camera.h"
#include "ypn_3dsdefs.h"


class Scene3DS
{
public:
	Scene3DS();
	~Scene3DS();

	void AddMesh();
	void AddMaterial();
	void AddCamera();

	//Parser
	void ReadChunk(Chunk &chunk);
	unsigned int GetString(char *buf);
	bool Parse3DS(char *filename);
	void ParseMainChunk(Chunk &chunk);
	void ParseObjectSubChunk(Chunk &chunk);
	void ParseMaterialSubChunk(Chunk &chunk);
	void ParseCameraSubChunk(Chunk &chunk);
	void ParseKeyframerSubChunk(Chunk &chunk);

	void Debunk(char *filename);

	FILE *fp;

	//3ds info:
	int version_3ds;
	int version_editor;
	char cbuffer[80];	//unknown chunks
	char object_name[80];

	//objects info
	Mesh **meshes;
	int num_meshes;

	Material **materials;
	int num_materials;

	Camera **cameras;
	int num_cameras;

	//logg
	void LogFile(char *filename, bool flag);
	void AddLogText(char *text);
	FILE *fpout;
	char temp[256];
	bool logging;

protected:
		Chunk main_chunk;
};