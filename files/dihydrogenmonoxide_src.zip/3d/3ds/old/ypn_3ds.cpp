#include "ypn_3ds.h"
#include "ypn_material.h"
#include "../ypn_matrix.h"

Scene3DS::Scene3DS()
{
//	object_name=0;
	meshes=0;
	num_meshes=0;
	materials=0;
	num_materials=0;
	cameras=0;
	num_cameras=0;
	logging=false;
}

Scene3DS::~Scene3DS()
{

}

void Scene3DS::AddMesh()
{
	num_meshes++;
	meshes=(Mesh**)realloc(meshes, num_meshes*sizeof(Mesh*));
	meshes[num_meshes-1]=new Mesh;
}

void Scene3DS::AddMaterial()
{
	num_materials++;
	materials=(Material**)realloc(materials, num_materials*sizeof(Material*));
	materials[num_materials-1]=new Material();
}

void Scene3DS::AddCamera()
{
	num_cameras++;
	cameras=(Camera**) realloc(cameras, num_cameras*sizeof(Camera *));
	cameras[num_cameras-1]=new Camera();
}

//-------------------------------------------------------------------------------------------
//3DS-Parser
//-------------------------------------------------------------------------------------------
void Scene3DS::ReadChunk(Chunk &chunk)
{
	//read chunk id
	chunk.items=fread(&chunk.id, 1, 2, fp);	//read 2 bytes from file

	//read chunk length
	chunk.items+=fread(&chunk.length, 1, 4, fp);	//read 4 bytes from file
}

unsigned int Scene3DS::GetString(char *buf)
{
	fread(buf, 1, 1, fp);
	while(*(buf++)!=NULL) fread(buf, sizeof(char), 1, fp);
	return strlen(buf)+1;
}

bool Scene3DS::Parse3DS(char *filename)
{
	fp=fopen(filename, "rb");
	ReadChunk(main_chunk);
	if (main_chunk.id!=CHUNK_MAIN) return false;
	ParseMainChunk(main_chunk);
	if (logging==true) fclose(fpout);
	return true;
}

void Scene3DS::ParseMainChunk(Chunk &chunk)
{
	Chunk main;

	while(chunk.length > chunk.items)
	{
		ReadChunk(main);	//read next chunk, place in "main" chunk
		switch(main.id)
		{
			case CHUNK_VERSION:
			{
				main.items+=fread(&version_3ds, 1, main.length-main.items, fp);

				fprintf(fpout, "3DS Version: 0x%02x\n", version_3ds);
				break;
			}

			case CHUNK_OBJECTINFO:
			{
				Chunk infochunk;
				ReadChunk(infochunk);

				infochunk.items+=fread(&version_editor, 1, infochunk.length-infochunk.items, fp);
				main.items+=infochunk.items;

				fprintf(fpout, "Editor Version: 0x%02x\n", version_editor);
				fprintf(fpout, "----------------------------------------------------------------------\n");
				break;
			}

			case CHUNK_OBJECT:
			{
				Chunk objectchunk;

//				object_name=(char *)malloc(32);
				main.items+=GetString(object_name);	//Get name of object

				AddMesh();

				//set name of the object
				meshes[num_meshes-1]->SetName(object_name);

				fprintf(fpout, "[%s] - Mesh Object\n\n", object_name);

				ReadChunk(objectchunk);

				switch(objectchunk.id)
				{
					case CHUNK_OBJECT_MESH:
					{
						ParseObjectSubChunk(objectchunk);
						break;
					}

					case CHUNK_OBJECT_LIGHT:
					{
//						ParseLightSubChunk(chunk_object);
						break;
					}

					case CHUNK_OBJECT_CAMERA:
					{
						ParseCameraSubChunk(objectchunk);
						break;
					}

					default:
					{
						objectchunk.items+=fread(cbuffer, 1, objectchunk.length-objectchunk.items, fp);
						break;
					}
				}
				main.items += objectchunk.items;
				break;
			}

			case CHUNK_MATERIAL:
			{
				ParseMaterialSubChunk(main);
				break;
			}

			case CHUNK_KEYFRAMER:
			{
				fprintf(fpout, "Keyframer chunk found!\n");
				ParseKeyframerSubChunk(main);
				break;
			}

			default:
			{
				fprintf(fpout,"main: unknown-chunk: length(%u) id(%x)\n",main.length, main.id);
//				printf("main: unknown-chunk: length(%u) id(%x)\n",main.length,main.id);

				main.items += fread(cbuffer, 1, main.length - main.items, fp);
				break;
			}
		}
		chunk.items += main.items;
	}
}
	
//------------------------------------------------------------------------------
//					OBJECT SUB-CHUNK
//------------------------------------------------------------------------------
struct rVector
{
	float x,y,z;
};

struct rMatrix
{
	rVector x;
	rVector y;
	rVector z;
	rVector pos;
};

void Scene3DS::ParseObjectSubChunk(Chunk &chunk)
{
	Chunk chunk_object;

	unsigned short count,i,numref;
	rVector p;
	rMatrix m;

//	CMatrix matrix;
//	matrix.LoadIdentity();

	while(chunk.length > chunk.items)
	{
		ReadChunk(chunk_object);
		switch(chunk_object.id)
		{
			case CHUNK_OBJECT_MESH_VERTICES:
			{
//				float f[3];

				//read number of vertices in object
//				chunk_object.items+=fread(&count, sizeof(unsigned short), 1, fp);
				chunk_object.items+=fread(&count, 1, 2, fp);

				//log
//				sprintf(temp, "Number of Vertices: %i\n", count);
//				AddLogText(temp);
				fprintf(fpout, "Number of Vertices: %i\n", count);

//				meshes[num_meshes-1]->num_vertices=count;
//				meshes[num_meshes-1]->vertices=new Vector3D[count];

				//loop through and get the x, y, z coordinates
				for (i=0; i<count; i++)
				{
//					chunk_object.items+=fread(&f[0], sizeof(float), 1, fp);
//					chunk_object.items+=fread(&f[1], sizeof(float), 1, fp);
//					chunk_object.items+=fread(&f[2], sizeof(float), 1, fp);
					chunk_object.items+=fread(&p.x, 1, sizeof(p.x), fp);
					chunk_object.items+=fread(&p.y, 1, sizeof(p.y), fp);
					chunk_object.items+=fread(&p.z, 1, sizeof(p.z), fp);

					//add a vertex to a mesh
//					meshes[num_meshes-1]->AddVertex(f[0],f[1],f[2]);
					meshes[num_meshes-1]->AddVertex(p.x,p.y,p.z);

					//log
//					sprintf(temp, "Vertex %i: \t%f\t%f\t%f\n", i, f[0],f[1],f[2]);
//					AddLogText(temp);
//					fprintf(fpout, "Vertex %i: \t%f\t%f\t%f\n", i, f[0],f[1],f[2]);
					fprintf(fpout, "Vertex %i: \t%f\t%f\t%f\n", i, p.x,p.y,p.z);
				}
				break;
			}
			
			case CHUNK_OBJECT_MESH_FACES:
			{
//				unsigned short num_faces;
				unsigned short f[4];	
			
				chunk_object.items+=fread(&count, sizeof(unsigned short), 1, fp);

				//log
//				sprintf(temp, "Number of Faces: %i\n", count);
//				AddLogText(temp);
				fprintf(fpout, "Number of Faces: %i\n", count);
//				meshes[num_meshes-1]->faces=new Face[count];
//				meshes[num_meshes-1]->num_faces=count;
//				meshes[num_meshes-1]->faces=(Face*)malloc(sizeof(Face)*num_faces);

				for(i=0; i<count; i++)
				{
/*					chunk_object.items+=fread(&f[0], sizeof(unsigned short), 1, fp);
					chunk_object.items+=fread(&f[1], sizeof(unsigned short), 1, fp);
					chunk_object.items+=fread(&f[2], sizeof(unsigned short), 1, fp);
					chunk_object.items+=fread(&f[3], sizeof(unsigned short), 1, fp);*/
					chunk_object.items+=fread(&f[0], 1, sizeof(f[0]), fp);
					chunk_object.items+=fread(&f[1], 1, sizeof(f[1]), fp);
					chunk_object.items+=fread(&f[2], 1, sizeof(f[2]), fp);
					chunk_object.items+=fread(&f[3], 1, sizeof(f[3]), fp);

					//add a face to a scene
					meshes[num_meshes-1]->AddFace(f[0],f[1],f[2],f[3]);

					//log
//					sprintf(temp, "Face %i: \t%d\t%d\t%d\t%d\n", i, f[0],f[1],f[2],f[3]);
//					AddLogText(temp);
					fprintf(fpout, "Face %i: \t%d\t%d\t%d\t%d\n", i, f[0],f[1],f[2],f[3]);

					// visibility flag
//					chunk_object.items+=fread(&flag, 1, sizeof(flag), fp);
/*
					//log
					sprintf(temp, "Flag: %s\n", flag==1?"on":"off");
					AddLogText(temp);*/
				}
				break;
			}

			case CHUNK_OBJECT_MESH_UV:
			{
				float f[2];
				//number of verts
				chunk_object.items+=fread(&count, 1, 2, fp);

				//log
//				sprintf(temp, "Number of Faces: %i\n", count);
//				AddLogText(temp);
				fprintf(fpout, "Number of Texture Coordinates: %i\n", count);

				for (i=0; i<count; i++)
				{
					chunk_object.items+=fread(&f[0], sizeof(float), 1, fp);
					chunk_object.items+=fread(&f[1], sizeof(float), 1, fp);

					//add uv coords to a scene
//					meshes[num_meshes-1]->AddUV(t);
//					meshes[num_meshes-1]->vertices[count].u=f[0];
//					meshes[num_meshes-1]->vertices[count].v=f[1];
					meshes[num_meshes-1]->AddUV(i, f[0],f[1]);

					//log
//					sprintf(temp, "UV %i: \t%f\t%f\n", i, p.u,p.v);
//					AddLogText(temp);
					fprintf(fpout, "UV %i: \t%f\t%f\n", i, f[0],f[1]);
				}
				break;	
			}

			case CHUNK_OBJECT_MESH_LOCAL:
			{
/*				chunk_object.items+=fread(&matrix.Matrix[0], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[4], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[8], 1, sizeof(float), fp);

				chunk_object.items+=fread(&matrix.Matrix[1], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[5], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[9], 1, sizeof(float), fp);

				chunk_object.items+=fread(&matrix.Matrix[2], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[6], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[10], 1, sizeof(float), fp);

				chunk_object.items+=fread(&matrix.Matrix[12], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[13], 1, sizeof(float), fp);
				chunk_object.items+=fread(&matrix.Matrix[14], 1, sizeof(float), fp);
*/
				chunk_object.items+=fread(&m.x.x, 1, sizeof(m.x.x), fp);
				chunk_object.items+=fread(&m.x.y, 1, sizeof(m.x.y), fp);
				chunk_object.items+=fread(&m.x.z, 1, sizeof(m.x.z), fp);

				chunk_object.items+=fread(&m.y.x, 1, sizeof(m.y.x), fp);
				chunk_object.items+=fread(&m.y.y, 1, sizeof(m.y.y), fp);
				chunk_object.items+=fread(&m.y.z, 1, sizeof(m.y.z), fp);

				chunk_object.items+=fread(&m.z.x, 1, sizeof(m.z.x), fp);
				chunk_object.items+=fread(&m.z.y, 1, sizeof(m.z.y), fp);
				chunk_object.items+=fread(&m.z.z, 1, sizeof(m.z.z), fp);

				chunk_object.items+=fread(&m.pos.x, 1, sizeof(m.pos.x), fp);
				chunk_object.items+=fread(&m.pos.y, 1, sizeof(m.pos.y), fp);
				chunk_object.items+=fread(&m.pos.z, 1, sizeof(m.pos.z), fp);

				//log
//				sprintf(temp, "Object Mesh Local Matrix:\n");
//				AddLogText(temp);
/*				fprintf(fpout, "Object Mesh Local Matrix:\n");

				for (int j=0; j<4; j++)
				{
					for (int i=0; i<4; i++)
					{
//						sprintf(temp, "%.2f\t", matrix.Matrix[i+j*4]);
//						AddLogText(temp);
						fprintf(fpout, "%.2f\t", matrix.Matrix[i+j*4]);
					}
//					sprintf(temp, "\n");
//					AddLogText(temp);
					fprintf(fpout, "\n");
				}*/
				break;	
			}

			case CHUNK_OBJECT_FACES_MATERIAL:	//0x4130
			{
//exit(1);
				chunk_object.items += fread(cbuffer, 1, chunk_object.length-chunk_object.items, fp);

//				fprintf(fpout, "Material: %s\n", cbuffer);

				//Set name of the material for this face  --(object)--
				meshes[num_meshes-1]->SetMaterialName(cbuffer);
/*
				chunk_object.items+=fread(&count, 1, sizeof(count), fp);

				//log
				sprintf(temp, "Number of Materials: %d\n", &count);
				AddLogText(temp);

				//for each entry
				for (i=0; i<count; i++)
				{
					//face assigned to this material (number ref.)
					chunk_object.items+=fread(&numref, sizeof(count), 1, fp);

					//log
					sprintf(temp, "Face Number ref: %d\n", numref);
					AddLogText(temp);
				}*/
				break;
			}

			case CHUNK_OBJECT_FACES_SMOOTH:
			{
				float f[2];
				fprintf(fpout, "Smoothing group list found!\n");

				chunk_object.items+=fread(&count, 1, 2, fp);
				fprintf(fpout, "Number of Vertices (Smoothing group): %i\n", count);

				for (i=0; i<count; i++)
				{
					chunk_object.items+=fread(&count, sizeof(f[0]), 1, fp);
					chunk_object.items+=fread(&count, sizeof(f[1]), 1, fp);
					fprintf(fpout, "Mapping coordinates: %.1f\t%.1f\n", f[0],f[1]);
				}
				break;
			}

			case CHUNK_KEYFRAMER:
			{
				fprintf(fpout, "Keyframer chunk found!\n");
//				exit(1);
				//ParseKeyframerSubChunk(chunk_main);
				break;
			}

			default:
			{
				fprintf(fpout,"mesh: unknown-chunk: length(%u) id(%x)\n",chunk_object.length, chunk_object.id);
				chunk_object.items+=fread(cbuffer, 1, chunk_object.length-chunk_object.items, fp); 
				break;
			}
		}
		chunk.items+=chunk_object.items;
	}
}

//------------------------------------------------------------------------------
//					MATERIAL SUB-CHUNK
//------------------------------------------------------------------------------

void Scene3DS::ParseMaterialSubChunk(Chunk &chunk)
{
	Chunk chunk_material;

	AddMaterial();	//Add a new material to the scene

	while(chunk.length > chunk.items)
	{
		ReadChunk(chunk_material);
		
		switch(chunk_material.id)
		{
			case CHUNK_MATERIAL_MAP:
			{
				// ParseMaterialSubChunk(chunk_material);
				break;	
			}
			
			case CHUNK_MATERIAL_NAME:
			{
				chunk_material.items += fread(cbuffer, 1, chunk_material.length - chunk_material.items, fp);
//				materials[num_materials-1]->SetName(buffer);
				break;
			}
			
			case CHUNK_MATERIAL_FILE:
			{
				chunk_material.items += fread(cbuffer, 1, chunk_material.length - chunk_material.items, fp);
//				materials[num_materials-1]->SetTextureFilename(cbuffer);
//				materials[num_materials-1]->LoadJPG(cbuffer);
				break;
			}
			/*
			case ID_MATERIAL_AMBIENT:
			{
				_Chunk colorChunk;
				ReadChunk(colorChunk);
				colorChunk.items+=fread(&material.ambient,1,colorChunk.length-colorChunk.items,fp);
				chunk_material.items+=colorChunk.items;
				
				break;
			}

			case ID_MATERIAL_DIFFUSE:
			{
				_Chunk colorChunk;
				ReadChunk(colorChunk);
				colorChunk.items+=fread(&material.diffuse,1,colorChunk.length-colorChunk.items,fp);
				chunk_material.items+=colorChunk.items;
				
				break;
			}

			case ID_MATERIAL_SPECULAR:
			{
				_Chunk colorChunk;
				ReadChunk(colorChunk);
				colorChunk.items+=fread(&material.specular,1,colorChunk.length-colorChunk.items,fp);
				chunk_material.items+=colorChunk.items;
				
				break;
			}
			
			case ID_MATERIAL_SHININESS:
			{
				_Chunk shin;
				short int percent;
				ReadChunk(shin);
				
				shin.items+=fread(&percent,1,sizeof(short int),fp);
				shin.items+=fread(cbuffer,1,shin.length-shin.items,fp);
				
				material.shininess = percent;
				
				chunk_material.items+=shin.items;

				break;	
			}*/
					
			default:
			{
				printf("material: unknown-chunk: length(%u) id(%x)\n",chunk_material.length,chunk_material.id);
				chunk_material.items += fread(cbuffer, 1, chunk_material.length-chunk_material.items, fp);
				
				break;
			}
		}
		chunk.items += chunk_material.items;
	}
}

//------------------------------------------------------------------------------
//					CAMERA SUB-CHUNK
//------------------------------------------------------------------------------

void Scene3DS::ParseCameraSubChunk(Chunk &chunk)
{
	float temp;
	Vector3D p;

	AddCamera();

	//Read camera position
	chunk.items+=fread(&p.x, sizeof(p.x), 1, fp);
	chunk.items+=fread(&p.y, sizeof(p.y), 1, fp);
	chunk.items+=fread(&p.z, sizeof(p.z), 1, fp);

	//swap y and z pos:
//	temp = p.y;
//	p.y = p.z;
//	p.z = -temp;

//	cameras[num_cameras-1]->SetPosition(p);

	//Read camera target
	chunk.items+=fread(&p.x, sizeof(p.x), 1, fp);
	chunk.items+=fread(&p.y, sizeof(p.y), 1, fp);
	chunk.items+=fread(&p.z, sizeof(p.z), 1, fp);
//	cameras[num_cameras-1]->SetTarget(p);

	//swap y and z pos:
//	temp = p.y;
//	p.y = p.z;
//	p.z = -temp;

	chunk.items+=fread(&temp, sizeof(temp), 1, fp);	//Bank (degree)  fov?
//	cameras[num_cameras-1]->SetBank(temp);

	chunk.items+=fread(&temp, sizeof(temp), 1, fp);	//Lens

	// from lib3ds (http://lib3ds.sourceforge.net) ;-)
	if(fabs(temp<EPSILON)) temp=45.0f;
	else temp=2400.0f/temp;

//	cameras[num_cameras-1]->SetLens(temp);
}

void Scene3DS::ParseKeyframerSubChunk(Chunk &chunk)
{
	//unsigned long frames;//DWORD
	unsigned int frames;
	unsigned short key;
	int current_track;

	Chunk chunk_keyframer;

	while(chunk.length > chunk.items)
	{
		ReadChunk(chunk_keyframer);
		switch(chunk_keyframer.id)
		{
			// 0xb008
			case CHUNK_KEYFRAMER_FRAMES:
			{
//				printf("CHUNK_KEYFRAMER_FRAMES found!\n");

				//read start frame in keyframer
				chunk_keyframer.items+=fread(&frames, 1, sizeof(frames), fp);

				//add start frame to keyframer
//				keyframer.SetStartFrame(frames);

				//read end frame of keyframer
				chunk_keyframer.items+=fread(&frames, 1, sizeof(frames), fp);

				//add end frame to keyframer
//				keyframer.SetEndFrame(frames);

				break;
			}

			// 0xB003 : Camera Track
			case CHUNK_KEYFRAMER_TRACKCAMERAPOS:
			{
				fprintf(fpout, "CHUNK_KEYFRAMER_TRACKCAMERAPOS found!\n");
/*				current_track++;
				m_keyframer.tracks++;*/
//				m_keyframer.CTrack(current_track);
//				m_keyframer.track[current_track]->track_type=CAMERA;
				break;
			}

			case CHUNK_KEYFRAMER_TRACKCAMERATARGET:
			{
				fprintf(fpout, "CHUNK_KEYFRAMER_TRACKCAMERATARGET found!\n");
/*				current_track++;
				m_keyframer.m_trackCount++;*/
//				m_keyframer.CTrack(current_track);
//				m_keyframer.track[current_track]->track_type=CAMERAT;
				break;
			}

			case CHUNK_KEYFRAMER_TRACKINFO:
			{
				fprintf(fpout, "CHUNK_KEYFRAMER_TRACKINFO found!\n");
				break;
			}
/*
			case CHUNK_KEYFRAMER_TRACKOBJNAME:
			{
				printf("CHUNK_KEYFRAMER_TRACKOBJNAME found!\n");

				chunk_keyframer.items+=fread(cbuffer, 1, chunk_keyframer.length-chunk_keyframer.items, m_fp);
				m_keyframer.SetName(cbuffer);

				chunk_keyframer.items+=fread(&key, 1, sizeof(key), m_fp);
				m_keyframer.SetKey1(key);

				chunk_keyframer.items+=fread(&key, 1, sizeof(key), m_fp);
				m_keyframer.SetKey2(key);

				chunk_keyframer.items+=fread(&key, 1, sizeof(key), m_fp);
				m_keyframer.SetKey3(key);

				break;
			}

			case CHUNK_KEYFRAMER_TRACKPOS:
			{
				printf("CHUNK_KEYFRAMER_TRACKPOS found!\n");
				dword flag;

				break;
			}

			case CHUNK_KEYFRAMER_AMBIENTKEY:
			{
				printf("CHUNK_KEYFRAMER_AMBIENT found!\n");
				break;
			}

			case CHUNK_KEYFRAMER_TRACKOBJNUMBER:
			{
				printf("CHUNK_KEYFRAMER_TRACKOBJNUMBER found!\n");

				chunk_keyframer.items+=fread(&num, 1, sizeof(num), m_fp);
				m_keyframer.track[m_trackCount-1]->SetObjNumber(num);
				break;
			}*/

			default:
			{
				//printf("object: unknown-chunk: length(%u) id(%x)\n",objectChunk.length,objectChunk.id);
				chunk_keyframer.items+=fread(cbuffer, 1, chunk_keyframer.length-chunk_keyframer.items, fp);
				break;
			}
		}
		chunk.items+=chunk_keyframer.items;
	}
}

void Scene3DS::LogFile(char *filename, bool flag)
{
	logging=flag;
	if (flag==true)
	{
		fpout=fopen(filename, "w");
//		fclose(fpout);

//		fpout=fopen(filename, "a");
		fprintf(fpout, "----------------------------------------------------------------------\n");
		fprintf(fpout, "3D Studio FileFormat Parser\t\t\t    activator / yaphan\n");
		fprintf(fpout, "----------------------------------------------------------------------\n");
	}
}

void Scene3DS::AddLogText(char *text)
{
	if (logging==true) fprintf(fpout, "%s", text);
}

void Scene3DS::Debunk(char *filename)
{
	FILE *fp;
	fp=fopen(filename, "w");
	fprintf(fp, "=================\n");
	fprintf(fp, "3DS - File Output\n");
	fprintf(fp, "=================\n");
	fprintf(fp, "3DS Version:      %i\n", version_3ds);
	fprintf(fp, "Editor Version:   %i\n", version_editor);
	fprintf(fp, "Object name:      %s\n", object_name);
	fclose(fp);
}
/*
Debug file for 3D Studio Parser by activator
--------------------------------------------

=============
Scene Summary
=============
There are 17 meshes in the scene
There are no lights in the scene
There are 1 camera in the scene
There are 3 materials in the scene

Mesh 0:
--------
Name: Cylinder01
Number of vertices: 127
Number of faces: 216
Assigned material: 1 - Default

Mesh 1:
--------
Name: Cylinder02
Number of vertices: 127
Number of faces: 216
Assigned material: 1 - Default

*/