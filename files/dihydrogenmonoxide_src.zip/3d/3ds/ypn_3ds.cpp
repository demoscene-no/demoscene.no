#include "ypn_3ds.h"
#include "ypn_material.h"
#include "../ypn_vector3d.h"
#include "../ypn_matrix.h"
#include "../../commonheaders/ypn_common.h"

#include <io.h>
#include <conio.h>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;


//void Scene3DS::Les3DS(string filnavn)
//void Scene3DS::Les3DS(char *filnavn)
bool Scene3DS::Les3DS(const char *filnavn)
{
/*	//�pne fila
	fil.open(filnavn, ios::binary);

	//legg filst�rrelsen i variabelen: filstoerrelse.
	fil.seekg(0, ios::end);
	filstoerrelse=fil.tellg();
	fil.seekg(0, ios::beg);

	//hvis fila ikke kan �pnes returner
	if (fil.is_open()==false) return false;

	//analyser fila og hent det vi trenger fra den.
//	AnalyserBlokker();

	cout << "Slutten paa fila." << endl;
	*/
/*
	//test
	ifstream file("eksempel.txt", ios::binary);
	if (!file.is_open())
	{
		printf("fuck, not open");
		exit(1);
	}
*/
	filut=fopen("ut.txt", "w");
//	filut=stdout;

//	filpeker=fopen(file.filnavn, "rb");
	filpeker=fopen(filnavn, "rb");
	if (filpeker==NULL) return false;

	chunk3ds mainchunk;
	uint posisjon=hentpos();

	LesChunk(mainchunk);
	if ((int)mainchunk.id!=CHUNK_MAIN)
	{
		printf("Dette er ikke en 3ds fil.");
		fprintf(filut, "Dette er ikke en 3ds fil.");
		fclose(filut);
		return false;
	}
	printf("CHUNK_MAIN funnet!\n");
	fprintf(filut, "CHUNK_MAIN funnet!\n");

	LesMainBlokka(posisjon+mainchunk.lengde);

	//
	//genererer normalene ved bruk av smoothing gruppene.
	//
	int i;

	//alloker f�rst minne.
	object.face_normals=(Vector3D *)malloc(sizeof(Vector3D)*object.num_faces);
	object.vertex_normals[0]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
	object.vertex_normals[1]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
	object.vertex_normals[2]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
/*
	Vector3D va, vb;
	Vector3D v0,v1,v2;
	Vector3D face_normal;

	ulong smoothing_groups;
	Vector3D *buffers=(Vector3D *)malloc(sizeof(Vector3D)*object.num_vertices*32);
	for (i=0; i<object.num_faces; i++)
	{
		v0=object.vertices_real[object.faces_real[i].a];
		v1=object.vertices_real[object.faces_real[i].b];
		v2=object.vertices_real[object.faces_real[i].c];

		va=v0;
		va.Substract(v1);
//		vb=v0;
//		vb.Substract(v2);
		vb=v2;
		vb.Substract(v1);
		face_normal=cross_product(va,vb);
		face_normal.Normalize();

		//
		//thakker kusma for hjelp.
		//
		smoothing_groups=object.faces_real[i].smooth;
		object.faces_real[i].vertex_normals[0].vec.Set(0,0,0);
		object.faces_real[i].vertex_normals[1].vec.Set(0,0,0);
		object.faces_real[i].vertex_normals[2].vec.Set(0,0,0);
		for (int j=0; j<24; j++)
		{
			int index=1<<j;
			if (smoothing_groups&index)
			{
				buffers[object.faces_real[i].a*32+j].x+=face_normal.x;
				buffers[object.faces_real[i].a*32+j].y+=face_normal.y;
				buffers[object.faces_real[i].a*32+j].z+=face_normal.z;
				buffers[object.faces_real[i].b*32+j].x+=face_normal.x;
				buffers[object.faces_real[i].b*32+j].y+=face_normal.y;
				buffers[object.faces_real[i].b*32+j].z+=face_normal.z;
				buffers[object.faces_real[i].c*32+j].x+=face_normal.x;
				buffers[object.faces_real[i].c*32+j].y+=face_normal.y;
				buffers[object.faces_real[i].c*32+j].z+=face_normal.z;
			}
		}
	}
	//
	//generere normalene:
	//
	for (i=0; i<object.num_faces; i++)
	{
		smoothing_groups=object.faces_real[i].smooth;
		if (smoothing_groups)
		{
			// for hver kant i trekanten 0 -> 3
			//for (i=0; i<3; i++)

			for (int j=0; j<32; j++)
			{
				int index=1<<j;
				if (smoothing_groups&index)
				{
					object.faces_real[i].vertex_normals[0].vec.x+=buffers[object.faces_real[i].a*32+j].x;
					object.faces_real[i].vertex_normals[0].vec.y+=buffers[object.faces_real[i].a*32+j].y;
					object.faces_real[i].vertex_normals[0].vec.z+=buffers[object.faces_real[i].a*32+j].z;
					object.faces_real[i].vertex_normals[1].vec.x+=buffers[object.faces_real[i].b*32+j].x;
					object.faces_real[i].vertex_normals[1].vec.y+=buffers[object.faces_real[i].b*32+j].y;
					object.faces_real[i].vertex_normals[1].vec.z+=buffers[object.faces_real[i].b*32+j].z;
					object.faces_real[i].vertex_normals[2].vec.x+=buffers[object.faces_real[i].c*32+j].x;
					object.faces_real[i].vertex_normals[2].vec.y+=buffers[object.faces_real[i].c*32+j].y;
					object.faces_real[i].vertex_normals[2].vec.z+=buffers[object.faces_real[i].c*32+j].z;
				}
			}
			object.faces_real[i].vertex_normals[0].vec.Normalize();
			object.faces_real[i].vertex_normals[1].vec.Normalize();
			object.faces_real[i].vertex_normals[2].vec.Normalize();
		}
		else
		{
			v0=object.vertices_real[object.faces_real[i].a];
			v1=object.vertices_real[object.faces_real[i].b];
			v2=object.vertices_real[object.faces_real[i].c];

//			vb=v0;
//			vb.Substract(v2);
			vb=v2;
			vb.Substract(v1);
			face_normal=cross_product(va,vb);
			face_normal.Normalize();

			object.faces_real[i].vertex_normals[0].vec.x=object.faces_real[i].vertex_normals[1].vec.x=object.faces_real[i].vertex_normals[2].vec.x=face_normal.x;
			object.faces_real[i].vertex_normals[0].vec.y=object.faces_real[i].vertex_normals[1].vec.y=object.faces_real[i].vertex_normals[2].vec.y=face_normal.y;
			object.faces_real[i].vertex_normals[0].vec.z=object.faces_real[i].vertex_normals[1].vec.z=object.faces_real[i].vertex_normals[2].vec.z=face_normal.z;
		}
	}*/

	//shitstuff
	object.culling=0;
	object.polygons_temp=new Poly[object.num_faces*2];
	for (i=0; i<object.num_faces*2; i++)
	{
		object.polygons_temp[i].InitPoints(36+36);
		object.polygons_temp[i].InitVertices(3);
	}
	object.polygons_real=new Poly[object.num_faces*2];
	for (i=0; i<object.num_faces*2; i++) object.polygons_real[i].InitVertices(8);
	object.polygons_clipped=new Poly[object.num_faces*2];
	for (i=0; i<object.num_faces*2; i++) object.polygons_clipped[i].InitPoints(36+36);
	//allocate some static faces for our clipped polygons
	object.InitNewFaces(object.num_faces*2);
	object.vertices_zclipped=(Vector3D *)malloc(sizeof(Vector3D)*9*object.num_faces);
	object.points_project=(Coord2D *)malloc(sizeof(Coord2D)*9*object.num_faces);
/*
	object.vertex_normals[0]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
	object.vertex_normals[1]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
	object.vertex_normals[2]=(Normal *)malloc(sizeof(Normal)*object.num_faces);
*/
/*
//	object.light.Set(0,0.54,-0.55); //foran og litt ned
//	object.light.Set(0,0,-1);//rett foran
//	object.light.Set(0,-1,-1);//foran og opp
//	object.light.Set(0,1,1);
//	object.light.Set(-0.75, -0.5, 0.5);
	object.light.Set(-0.75, -0.9, 0.5);
//	object.light.Set(-0.1, -0.5, 0.5);
//	object.light.Set(-0.1, -1, 0);
	object.light.Normalize();
*/

/*
	//finn ut om fila er ei 3ds fil. (0x4d4d)
	LesChunk(mainchunk);
	if (mainchunk.id!=CHUNK_MAIN) return false;
	printf("CHUNK_MAIN funnet!\n");
	fprintf(filut, "CHUNK_MAIN funnet!\n");

	//fortsett � lese chunkene.
	LesMainBlokka(mainchunk);*/
	fclose(filpeker);

	fprintf(filut, "%i", object.material[0].glossiness);
	fclose(filut);

	return true;
/*

	chunk3ds mainchunk;

	//saa lenge filpeker posisjonen er mindre enn filst�rrelsen utf�rer vi while l�kka.
	while (ftell(filpeker)<filelength(fileno(filpeker)))
	{
		LesChunk(mainchunk);

		//tilslutt analyserer vi chunk-id'en.
		switch(mainchunk.id)
		{
		case CHUNK_MAIN:
			printf("CHUNK_MAIN funnet!\n");
			LesMainBlokka();
			break;
			
		default:
			//flytt filpeker til neste chunk.
			fseek(filpeker, mainchunk.lengde-6, SEEK_CUR);
			//trekker i fra chunk-headeren siden den allerede er lest!
		}
	}
	fclose(filpeker);
	*/
}


/*
bool Scene3DS::LesChunk(char *destinasjonspeker, long antall)
{
	//returnerer aktuelle fil-posisjon for lesing.
	filpeker=fil.tellg();
	
	if (!fil.read(destinasjonspeker, antall) && fil.eof()) return false;
	filpeker+=antall;
	fil.seekg(filpeker);

//	getch();
	Sleep(100);
	static int teller=0;
	teller++;
//	printf("%i\n", teller);
	printf("%i", teller);
	return true;
}

bool Scene3DS::SkippChunk(chunk3ds &chunk)
{
	filpeker+=(chunk.lengde-sizeof(chunk3ds));
	fil.seekg(filpeker);
	if (fil.eof()) return false;
	return true;
}
*/

void Scene3DS::LesChunk(chunk3ds &chunk)
{
	//les chunk-id'en (1 x 2 bytes)
//	chunk.teller=fread(&chunk.id, 2, 1, filpeker);
	fread(&chunk.id, sizeof(ushort), 1, filpeker);

	//les chunk-lengden (1 x 4 bytes)
//	chunk.teller+=fread(&chunk.lengde, 4, 1, filpeker);*/
	fread(&chunk.lengde, sizeof(uint), 1, filpeker);
}

void Scene3DS::lesfil(void *destinasjon, int lengde)
{
	if (fread(destinasjon, lengde, 1, filpeker)!=1)
	{
		printf("Feil ved lesing av fil!\n");
		fprintf(filut, "Feil ved lesing av fil!\n");
	}
}

void Scene3DS::setpos(uint posisjon)
{
	if (fseek(filpeker, (long)posisjon, SEEK_SET)!=0)
	{
		printf("Feil ved flytting av filpeker.");
		fprintf(filpeker, "Feil ved flytting av filpeker.");
	}
}

uint Scene3DS::hentpos()
{
	long posisjon;
	if ((posisjon=ftell(filpeker))==-1L)
	{
		printf("Feil ved lesing av filposisjon.");
		fprintf(filpeker, "Feil ved lesing av filposisjon.");
//		longjmp(mark, 1);
	}
	return (uint)posisjon;
}

void Scene3DS::LesMainBlokka(uint total_lengde)
{
	chunk3ds leschunk;
	uint posisjon;

	while ((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_VERSION:	//0x0002
			printf("CHUNK_VERSION funnet!\n");
			fprintf(filut, "CHUNK_VERSION funnet!\n");
			int versjon;
			fread(&versjon, sizeof(unsigned int), 1, filpeker);
			printf("versjon nummer: %i\n", versjon);
			fprintf(filut, "versjon nummer: %i\n", versjon);
			break;

		case CHUNK_EDITOR:
			printf("CHUNK_EDITOR funnet!\n");
			fprintf(filut, "CHUNK_EDITOR funnet!\n");
			LesObjektMeshBlokka(posisjon+leschunk.lengde);
			break;

		case CHUNK_KEYFRAMER:
			printf("CHUNK_KEYFRAMER funnet!\n");
			fprintf(filut, "CHUNK_KEYFRAMER funnet!\n");
			LesKeyframerBlokka(posisjon+leschunk.lengde);
			break;

			default:
				printf("Ukjent chunk i CHUNK_MAIN:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				fprintf(filut, "Ukjent chunk i CHUNK_MAIN:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesObjektMeshBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	//
	//3D EDITOR CHUNK VARIABLES
	//
	float shadow_map_bias;
	float shadow_map_size;
	float shadow_map_sample_range;
	float raytrace_bias;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
			case CHUNK_MASTERSCALE:	//0x100
				printf("CHUNK_MASTERSCALE funnet!\n");
				fprintf(filut, "CHUNK_MASTERSCALE funnet!\n");
				int masterscale;
				fread(&masterscale, sizeof(int), 1, filpeker);
				break;

			case CHUNK_MESHVERSION:	//0x3d3e
				printf("CHUNK_MESHVERSION funnet!\n");
				fprintf(filut, "CHUNK_MESHVERSION funnet!\n");

				int mesh_versjon;
				fread(&mesh_versjon, sizeof(unsigned int), 1, filpeker);
				printf("mesh versjon nummer: %i\n", mesh_versjon);
				fprintf(filut, "mesh versjon nummer: %i\n", mesh_versjon);
				break;

			case CHUNK_OBJBLOKK:	//0x4000 - father:0x3d3d
				printf("CHUNK_OBJBLOKK funnet!\n");
				fprintf(filut, "CHUNK_OBJBLOKK funnet!\n");
				LesObjektBlokka(posisjon+leschunk.lengde);
				break;

			//
			//Viewport
			//
			case CHUNK_VIEWPORT_LAYOUT:	//0x7001
				printf("CHUNK_VIEWPORT_LAYOUT funnet!\n");
				fprintf(filut, "CHUNK_VIEWPORT_LAYOUT funnet!\n");
				break;

			case CHUNK_SHADOW_MAP_BIAS:
				printf("CHUNK_SHADOW_MAP_BIAS funnet!\n");
				fprintf(filut, "CHUNK_SHADOW_MAP_BIAS funnet!\n");
				fread(&shadow_map_bias, sizeof(float), 1, filpeker);
				break;

			case CHUNK_SHADOW_MAP_SIZE:
				printf("CHUNK_SHADOW_MAP_SIZE funnet!\n");
				fprintf(filut, "CHUNK_SHADOW_MAP_SIZE funnet!\n");
				fread(&shadow_map_size, sizeof(float), 1, filpeker);
				break;

			case CHUNK_SHADOW_SAMPLE_RANGE:
				printf("CHUNK_SHADOW_SAMPLE_RANGE funnet!\n");
				fprintf(filut, "CHUNK_SHADOW_SAMPLE_RANGE funnet!\n");
				fread(&shadow_map_sample_range, sizeof(float), 1, filpeker);
				break;

			case CHUNK_AMBCOLOR:
				printf("CHUNK_AMBCOLOR funnet!\n");
				fprintf(filut, "CHUNK_AMBCOLOR funnet!\n");
				break;

			case CHUNK_BGBITMAP:
				printf("CHUNK_BGBITMAP funnet!\n");
				fprintf(filut, "CHUNK_BGBITMAP funnet!\n");
				break;

			case CHUNK_BGCOLOR:
				printf("CHUNK_BGCOLOR funnet!\n");
				fprintf(filut, "CHUNK_BGCOLOR funnet!\n");
				LesASCII(bgbitmapfilnavn);
				break;

			case CHUNK_BG_GRADIENT_COLORS:
				printf("CHUNK_BG_GRADIENT_COLORS funnet!\n");
				fprintf(filut, "CHUNK_BG_GRADIENT_COLORS funnet!\n");
				break;

			case CHUNK_RAYTRACE_BIAS:
				printf("CHUNK_RAYTRACE_BIAS funnet!\n");
				fprintf(filut, "CHUNK_RAYTRACE_BIAS funnet!\n");
				fread(&raytrace_bias, sizeof(float), 1, filpeker);
				break;

			case CHUNK_FOG:
				printf("CHUNK_FOG funnet!\n");
				fprintf(filut, "CHUNK_FOG funnet!\n");
				break;

			case CHUNK_LAYERED_FOG_OPTIONS:
				printf("CHUNK_LAYERED_FOG_OPTIONS funnet!\n");
				fprintf(filut, "CHUNK_LAYERED_FOG_OPTIONS funnet!\n");
				break;

			case CHUNK_DISTANCE_QUEUE:
				printf("CHUNK_DISTANCE_QUEUE funnet!\n");
				fprintf(filut, "CHUNK_DISTANCE_QUEUE funnet!\n");
				break;
			
			case CHUNK_MATERIAL:
				printf("CHUNK_MATERIAL funnet!\n");
				fprintf(filut, "CHUNK_MATERIAL funnet!\n");
				LesMaterialBlokka(posisjon+leschunk.lengde);
				break;

			default:
				printf("Ukjent chunk i CHUNK_EDITOR:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				fprintf(filut, "Ukjent chunk i CHUNK_EDITOR:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesObjektBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;
	Vector3D lightpos;

	//Les objektnavnet f�rst
	LesASCII(objnavn);
	printf("objekt navn: %s\n", objnavn);
	fprintf(filut, "objekt navn: %s\n", objnavn);

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_TRIMESH:	//0x4100
			printf("CHUNK_TRIMESH funnet!\n");
			fprintf(filut, "CHUNK_TRIMESH funnet!\n");
			LesTriMeshBlokka(posisjon+leschunk.lengde, objnavn);
			break;

		case CHUNK_LIGHT:
			printf("CHUNK_LIGHT funnet!\n");
			fprintf(filut, "CHUNK_LIGHT funnet!\n");

			fread(&lightpos.x, sizeof(float), 1, filpeker);
			fread(&lightpos.y, sizeof(float), 1, filpeker);
			fread(&lightpos.z, sizeof(float), 1, filpeker);
			printf("light position:\t(%.2f,\t%.2f,\t%.2f)\n", lightpos.x, lightpos.y, lightpos.z);
			fprintf(filut, "light position:\t(%.2f,\t%.2f,\t%.2f)\n", lightpos.x, lightpos.y, lightpos.z);
			break;

		case CHUNK_CAMERA:
			printf("CHUNK_CAMERA funnet!\n");
			fprintf(filut, "CHUNK_CAMERA funnet!\n");
			fread(&object.campos.x, sizeof(float), 1, filpeker);
			fread(&object.campos.y, sizeof(float), 1, filpeker);
			fread(&object.campos.z, sizeof(float), 1, filpeker);
			fread(&object.camtar.x, sizeof(float), 1, filpeker);
			fread(&object.camtar.y, sizeof(float), 1, filpeker);
			fread(&object.camtar.z, sizeof(float), 1, filpeker);

			//OBS! cambank leses i grader!
			fread(&object.cambank, sizeof(float), 1, filpeker);
			fread(&object.camlens, sizeof(float), 1, filpeker);

			printf("camera position:\t(%.2f,\t%.2f,\t%.2f)\n", object.campos.x, object.campos.y, object.campos.z);
			printf("camera target:\t(%.2f,\t%.2f,\t%.2f)\n", object.camtar.x, object.camtar.y, object.camtar.z);
			printf("camera bank: %.2f\n", object.cambank);
			printf("camera lens: %.2f\n", object.camlens);
			fprintf(filut, "camera position:\t(%.2f,\t%.2f,\t%.2f)\n", object.campos.x, object.campos.y, object.campos.z);
			fprintf(filut, "camera target:\t(%.2f,\t%.2f,\t%.2f)\n", object.camtar.x, object.camtar.y, object.camtar.z);
			fprintf(filut, "camera bank: %.2f\n", object.cambank);
			fprintf(filut, "camera lens: %.2f\n", object.camlens);
			break;

		default:
			printf("Ukjent chunk i CHUNK_OBJBLOKK:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_OBJBLOKK:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesMaterialBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	//vi fant ett material! fortell objektet om det!
	object.flag_material=1;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
			case CHUNK_MATNAME:
				printf("CHUNK_MATNAME funnet!\n");
				fprintf(filut, "CHUNK_MATNAME funnet!\n");

				LesASCII(matnavn);
				printf("material navn: %s\n", matnavn);
				fprintf(filut, "material navn: %s\n", matnavn);

				object.material_index++;
				break;

			case CHUNK_AMBIENT: //0xa010
				printf("CHUNK_AMBIENT funnet!\n");
				fprintf(filut, "CHUNK_AMBIENT funnet!\n");
				object.material[object.material_index-1].phong_index=MATERIAL_AMBIENT;
				LesColorBlokka(posisjon+leschunk.lengde);
				break;

			case CHUNK_DIFFUSE:	//0xa020
				printf("CHUNK_DIFFUSE funnet!\n");
				fprintf(filut, "CHUNK_DIFFUSE funnet!\n");
				object.material[object.material_index-1].phong_index=MATERIAL_DIFFUSE;
				LesColorBlokka(posisjon+leschunk.lengde);
				break;

			case CHUNK_SPECULAR:	//0xa030
				printf("CHUNK_SPECULAR funnet!\n");
				fprintf(filut, "CHUNK_SPECULAR funnet!\n");
				object.material[object.material_index-1].phong_index=MATERIAL_SPECULAR;
				LesColorBlokka(posisjon+leschunk.lengde);
				break;

			case CHUNK_SHININESS:	//(3dsmax: GLOSSINESS) 0xa040
				printf("CHUNK_SHININESS (GLOSSINESS) funnet!\n");
				fprintf(filut, "CHUNK_SHININESS (GLOSSINESS) funnet!\n");
				parse_flag=0;	//glossiness
				LesProsentBlokka(posisjon+leschunk.lengde);
				break;

			case CHUNK_SHININESSSTRENGTH:	//(3dsmax: SPECULAR LEVEL) 0xa041
				printf("CHUNK_SHININESSSTRENGTH (SPECULAR LEVEL) funnet!\n");
				fprintf(filut, "CHUNK_SHININESSSTRENGTH (SPECULAR LEVEL) funnet!\n");
				parse_flag=1;	//specular_level
				LesProsentBlokka(posisjon+leschunk.lengde);
				break;

			case CHUNK_TRANSPARENCYPERCENT:	//0xa050
				printf("CHUNK_TRANSPARENCYPERCENT funnet!\n");
				fprintf(filut, "CHUNK_TRANSPARENCYPERCENT funnet!\n");
				break;

			case CHUNK_TRANSPARENCYFALLOFFPERCENT:	//0xa052
				printf("CHUNK_TRANSPARENCYFALLOFFPERCENT funnet!\n");
				fprintf(filut, "CHUNK_TRANSPARENCYFALLOFFPERCENT funnet!\n");
				break;

			case CHUNK_REFLECTIONBLURPERCENT:	//0xa053
				printf("CHUNK_REFLECTIONBLURPERCENT funnet!\n");
				fprintf(filut, "CHUNK_REFLECTIONBLURPERCENT funnet!\n");
				break;

			case CHUNK_SELFILLUM:	//0xa084
				printf("CHUNK_SELFILLUM funnet!\n");
				fprintf(filut, "CHUNK_SELFILLUM funnet!\n");
				break;

			case CHUNK_WIRETHICKNESS:	//0xa087
				printf("CHUNK_WIRETHICKNESS funnet!\n");
				fprintf(filut, "CHUNK_WIRETHICKNESS funnet!\n");
				float wirewidth;
				fread(&wirewidth, sizeof(float), 1, filpeker);
				break;

			case CHUNK_RENDERTYPE:	//0xa100
				printf("CHUNK_RENDERTYPE funnet!\n");
				fprintf(filut, "CHUNK_RENDERTYPE funnet!\n");
				//Material shading metod:
				//0 - Wireframe
				//1 - Flat
				//2 - Gouraud
				//3 - Phong
				//4 - Metal
				short shading;
				fread(&shading, sizeof(short), 1, filpeker);
				printf("shading type: %i [%s]\n", shading, shading==0?"WIREFRAME":shading==1?"FLAT":shading==2?"GOURAUD":shading==3?"PHONG":shading==4?"METAL":"");
				fprintf(filut, "shading type: %i [%s]\n", shading, shading==0?"WIREFRAME":shading==1?"FLAT":shading==2?"GOURAUD":shading==3?"PHONG":shading==4?"METAL":"");
				object.material[0].shading_type=shading;
				break;

			case CHUNK_TEXTURE:	//0xa200
				printf("CHUNK_TEXTURE funnet!\n");
				fprintf(filut, "CHUNK_TEXTURE funnet!\n");
				break;
			
			default:
				printf("Ukjent chunk i CHUNK_MATERIAL:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				fprintf(filut, "Ukjent chunk i CHUNK_MATERIAL:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
				break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesTriMeshBlokka(uint total_lengde, char *navn)
{
	chunk3ds leschunk;
	uint posisjon;
	uchar c;
	Vector3D akse[3], origo;
	int i;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_VERTLIST:	//0x4110
			printf("CHUNK_VERTLIST funnet!\n");
			fprintf(filut, "CHUNK_VERTLIST funnet!\n");

			fread(&object.num_vertices, sizeof(short), 1, filpeker);
			printf("antallet vertexer: %i\n", object.num_vertices);
			fprintf(filut, "antallet vertexer: %i\n", object.num_vertices);

			object.vertices_real=(Vector3D *)malloc(sizeof(Vector3D)*object.num_vertices);
			object.vertices_world=(Vector3D *)malloc(sizeof(Vector3D)*object.num_vertices);

			for (i=0; i<object.num_vertices; i++)
			{
				fread(&object.vertices_real[i].x, sizeof(float), 1, filpeker);
				fread(&object.vertices_real[i].y, sizeof(float), 1, filpeker);
				fread(&object.vertices_real[i].z, sizeof(float), 1, filpeker);
				object.vertices_real[i].w=1;
				printf("vertex %i:\t(%.2f,\t%.2f,\t%.2f)\n", i, object.vertices_real[i].x, object.vertices_real[i].y, object.vertices_real[i].z);
				fprintf(filut, "vertex %i:\t(%.2f,\t%.2f,\t%.2f)\n", i, object.vertices_real[i].x, object.vertices_real[i].y, object.vertices_real[i].z);
			}
			break;

		case CHUNK_FACELIST:	//0x4120
			printf("CHUNK_FACELIST funnet!\n");
			fprintf(filut, "CHUNK_FACELIST funnet!\n");

			LesFaceListBlokka(posisjon+leschunk.lengde);
			break;

		case CHUNK_MAPLIST:	//0x4140
			printf("CHUNK_MAPLIST funnet!\n");
			fprintf(filut, "CHUNK_MAPLIST funnet!\n");

			//vi fant maplista! fortell objektet om det!
			object.flag_mapping_coordinates=1;
			//
	
			fread(&object.num_vertices, sizeof(ushort), 1, filpeker);
			printf("antallet vertexer: %i\n", object.num_texture_vertices);
			fprintf(filut, "antallet vertexer: %i\n", object.num_texture_vertices);
	
			for (i=0; i<object.num_texture_vertices; i++)
			{
				fread(&object.vertices_real[i].u, sizeof(float), 1, filpeker);
				fread(&object.vertices_real[i].v, sizeof(float), 1, filpeker);
				printf("vertex %i:\t(%.2f,\t%.2f)\n", i, object.vertices_real[i].u, object.vertices_real[i].v);
				fprintf(filut, "vertex %i:\t(%.2f,\t%.2f)\n", i, object.vertices_real[i].u, object.vertices_real[i].v);
			}
			break;

		case CHUNK_TRI_VERTEX_OPTIONS:
			printf("CHUNK_TRI_VERTEX_OPTIONS funnet!\n");
			fprintf(filut, "CHUNK_TRI_VERTEX_OPTIONS funnet!\n");
			break;

		case CHUNK_TRMATRIX:
			printf("CHUNK_TRMATRIX funnet!\n");
			fprintf(filut, "CHUNK_TRMATRIX funnet!\n");

			for (i=0; i<3; i++)
			{
				fread(&akse[i].x, sizeof(float), 1, filpeker);
				fread(&akse[i].y, sizeof(float), 1, filpeker);
				fread(&akse[i].z, sizeof(float), 1, filpeker);
			}
			fread(&origo.x, sizeof(float), 1, filpeker);
			fread(&origo.y, sizeof(float), 1, filpeker);
			fread(&origo.z, sizeof(float), 1, filpeker);
			break;

		case CHUNK_MESHCOLOR:
			printf("CHUNK_MESHCOLOR funnet!\n");
			fprintf(filut, "CHUNK_MESHCOLOR funnet!\n");
			break;

		default:
			printf("Ukjent chunk i CHUNK_TRIMESH:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_TRIMESH:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesFaceListBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	fread(&object.num_faces, sizeof(short), 1, filpeker);
	printf("antallet faces: %i\n", object.num_faces);
	fprintf(filut, "antallet faces: %i\n", object.num_faces);

	object.faces_real=(Face *)malloc(sizeof(Face)*object.num_faces);

	for (int i=0; i<object.num_faces; i++)
	{
		fread(&object.faces_real[i].a, sizeof(ushort), 1, filpeker);
		fread(&object.faces_real[i].b, sizeof(ushort), 1, filpeker);
		fread(&object.faces_real[i].c, sizeof(ushort), 1, filpeker);
		fread(&object.faces_real[i].flag, sizeof(ushort), 1, filpeker);

		printf("face %i:\t(%i,%i,%i)\n", i, object.faces_real[i].a, object.faces_real[i].b, object.faces_real[i].c);
		fprintf(filut, "face %i:\t(%i,%i,%i)\n", i, object.faces_real[i].a, object.faces_real[i].b, object.faces_real[i].c);
	}

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_FACEMAT:
			printf("CHUNK_FACEMAT funnet!\n");
			fprintf(filut, "CHUNK_FACEMAT funnet!\n");
			break;

		case CHUNK_SMOOTHLIST:
			printf("CHUNK_SMOOTHLIST funnet!\n");
			fprintf(filut, "CHUNK_SMOOTHLIST funnet!\n");

			//
			//Listen bruker en long per triangel(face).
			//Smoothing gruppene er tildelt i bits per byte,
			//hvor hver bit (0-31) representerer en smoothing gruppe.
			//Et triangel(face) kan bare tildeles en smoothing gruppe om gangen.
			//
			//N�yaktige vertex normaler kan ikke lagres i .3ds fila.
			//Istedenfor blir "smoothing grupper" brukt slik at mottaker programmet kan
			//gjenskape en god representasjon av vertex normalene.

			//vi fant ett material! fortell objektet om det!
			object.flag_smoothing_groups=1;

			//
			for (i=0; i<object.num_faces; i++)
			{
				fread(&object.faces_real[i].smooth, sizeof(ulong), 1, filpeker);
				printf("face normal smooth %i:\t(%i)\n", i, object.faces_real[i].smooth);
				fprintf(filut, "face normal smooth %i:\t(%i)\n", i, object.faces_real[i].smooth);
			}
			break;

		default:
			printf("Ukjent chunk i CHUNK_FACELIST:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_FACELIST:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesKeyframerBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	dword frames_start;
	dword frames_end;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_KEYFRAMER_HEADER:
			printf("CHUNK_KEYFRAMER_HEADER funnet!\n");
			fprintf(filut, "CHUNK_KEYFRAMER_HEADER funnet!\n");
			break;

		case CHUNK_FRAMES:
			printf("CHUNK_FRAMES funnet!\n");
			fprintf(filut, "CHUNK_FRAMES funnet!\n");
			fread(&frames_start, sizeof(dword), 1, filpeker);
			fread(&frames_end, sizeof(dword), 1, filpeker);
			printf("frames_start: %i\n", frames_start);
			printf("frames_end:   %i\n", frames_end);
			fprintf(filut, "frames_start: %i\n", frames_start);
			fprintf(filut, "frames_end:   %i\n", frames_end);
			break;

		case CHUNK_KEYFRAMER_CUR_FRAME:
			printf("CHUNK_KEYFRAMER_CUR_FRAME funnet!\n");
			fprintf(filut, "CHUNK_KEYFRAMER_CUR_FRAME funnet!\n");
			long active_frame;
			fread(&active_frame, sizeof(long), 1, filpeker);
			printf("active_frame: %i\n", active_frame);
			fprintf(filut, "active_frame: %i\n", active_frame);
			break;

		case CHUNK_TRACKINFO:
			printf("CHUNK_TRACKINFO funnet!\n");
			fprintf(filut, "CHUNK_TRACKINFO funnet!\n");
			break;

		case CHUNK_TRACKCAMERA:
			printf("CHUNK_TRACKCAMERA funnet!\n");
			fprintf(filut, "CHUNK_TRACKCAMERA funnet!\n");
			LesCameraTrackBlokka(posisjon+leschunk.lengde);
			break;

		default:
			printf("Ukjent chunk i CHUNK_KEYFRAMER:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_KEYFRAMER:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesCameraTrackBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_TRACKROLL:
			printf("CHUNK_TRACKROLL funnet!\n");
			fprintf(filut, "CHUNK_TRACKROLL funnet!\n");
			break;

		default:
			printf("Ukjent chunk i CHUNK_TRACKCAMERA:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_TRACKCAMERA:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesColorBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_RGBB:
			printf("CHUNK_RGBB funnet!\n");
			fprintf(filut, "CHUNK_RGBB funnet!\n");
			byte r,g,b;
			fread(&r, sizeof(byte), 1, filpeker);
			fread(&g, sizeof(byte), 1, filpeker);
			fread(&b, sizeof(byte), 1, filpeker);
			object.material[0].PhongParameters[object.material[0].phong_index]=RGB32(r,g,b);
			printf("RGB: %i, %i, %i\n", r,g,b);
			fprintf(filut, "RGB: %i, %i, %i\n", r,g,b);
			break;

		default:
			printf("Ukjent chunk i CHUNK_MATERIAL:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_MATERIAL:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}

void Scene3DS::LesProsentBlokka(uint total_lengde)
{
	chunk3ds leschunk;
    uint posisjon;
	ushort prosent;

	while((posisjon=hentpos())<total_lengde)
	{
		LesChunk(leschunk);
		switch((int)leschunk.id)
		{
		case CHUNK_PERCENTINT:
			printf("CHUNK_PERCENTINT funnet!\n");
			fprintf(filut, "CHUNK_PERCENTINT funnet!\n");
			ushort prosent;
			fread(&prosent, sizeof(ushort), 1, filpeker);
			printf("prosent: %i\n", prosent);
			fprintf(filut, "prosent: %i\n", prosent);
			if (parse_flag==0) object.material[0].glossiness=prosent;
			if (parse_flag==1) object.material[0].specular_level=prosent;
			break;

		default:
			printf("Ukjent chunk i CHUNK_SHININESS:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			fprintf(filut, "Ukjent chunk i CHUNK_SHININESS:\tlengde(%u)\tid(0x%x)\n",leschunk.lengde, leschunk.id);
			break;
		}
		setpos(posisjon+leschunk.lengde);
	}
}


/*
void Scene3DS::LesRollAngleKeys(uint total_lengde)
{
	ushort n, unknown, frame, flags;
    float val, data[16];

    dread(kflags, 2);
    dsetpos(dgetpos()+8);   // unknown data
    dread(&n, sizeof(n));
    dsetpos(dgetpos()+2);   // unknown data

	for(int i=0; i<n; i++)
	{
		data[0]=0.0;      // default tension
		data[1]=0.0;      // default continuity
		data[2]=0.0;      // default bias
		data[3]=0.0;      // default ease to
		data[4]=0.0;      // default ease from
		dread(&frame, sizeof(frame));
		dread(&unknown, sizeof(unknown));
		dread(&flags, sizeof(flags));
		ReadSplineFlags(data, flags);
		dread(&val, sizeof(val));
		key[t].tens=data[0];
		key[t].cont=data[1];
		key[t].bias=data[2];
		key[t].easeTo=data[3];
		key[t].easeFrom=data[4];
		key[t].frame=frame;
		key[t].flags=flags;
		key[t].v=val;
	}
	return key;
}*/

long Scene3DS::LesASCII(char *destinasjon)
{
	char tegn;
	long teller=0;
	do 
	{
		tegn=fgetc(filpeker);
		destinasjon[teller]=tegn;
		teller++;
	} while (tegn!=0);	//prosesser l�kka s� lenge tegnet er gyldig
	return teller;
}
