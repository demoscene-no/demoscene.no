#ifndef _material
#define _material

#include "../../commonheaders/ypn_common.h"
#include "ypn_objectname.h"

#define MATERIAL_AMBIENT 0
#define MATERIAL_DIFFUSE 1
#define MATERIAL_SPECULAR 2

class Material : public ObjectName
{
public:
	Material();
	~Material();

	// Material shading metode(rendertype):
	//
	// 0 - Wireframe
	// 1 - Flat
	// 2 - Gouraud
	// 3 - Phong
	// 4 - Metal
	short shading_type;

	// Phong parametrene er som f�lger:
	//
	// 0 - Ambient
	// 1 - Diffuse
	// 2 - Specular

	ulong PhongParameters[3];
	int phong_index;
	ushort glossiness;	//(shininess) i prosent. kalles ogs� for phong-eksponenten
	ushort specular_level;	//i prosent
};

#endif