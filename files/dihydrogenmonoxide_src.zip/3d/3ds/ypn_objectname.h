#ifndef _objectname
#define _objectname

#include <stdlib.h>
#include <string.h>

class ObjectName
{
public:
	ObjectName();
	virtual ~ObjectName();

	virtual void SetName(const char *value);
	virtual int GetName(char *buffer, int max_size);

protected:
	char *name;
	int name_len;
};

#endif