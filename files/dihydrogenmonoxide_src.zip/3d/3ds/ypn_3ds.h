/*
 *	DreamWorld 3D-Engine
 *	Reads 3DS Format. This is a part of the DreamFlow Engine.
 *  Copyright (c) Rudi B. Stranden 2005
 */

//#include "ypn_mesh.h"
//#include "ypn_material.h"
//#include "ypn_camera.h"
#include "ypn_3dsdefs.h"
#include "../ypn_object.h"
#include "../ypn_vector3d.h"
#include "../../commonheaders/ypn_common.h"

#include <windows.h>
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

typedef struct
{
	ushort id;		//2 byte id-nummer
//	long
	uint lengde;	//4 byte lengda p� blokka.
//	unsigned int teller;//teller-elementene vi returnerer fra fread.
} chunk3ds;

//------------------------------------------------------------------------------
//Chunk-definitions
//------------------------------------------------------------------------------
enum
{
	CHUNK_MAIN=0x4d4d,
		CHUNK_VERSION=0x0002,
		CHUNK_EDITOR=0x3d3d,
			CHUNK_MESHVERSION=0x3d3e,
		CHUNK_MASTERSCALE=0x100,
			CHUNK_ONEUNIT=0x0100,

	//
	//3D-Editor Chunk
	//
	CHUNK_SHADOW_MAP_BIAS=0x1400,
	CHUNK_SHADOW_MAP_SIZE=0x1420,
	CHUNK_SHADOW_SAMPLE_RANGE=0x1450,

	CHUNK_BGBITMAP=0x1100,
	CHUNK_BGCOLOR=0x1200,
	CHUNK_EDIT_UNKNW02=0x1201,
	CHUNK_BG_GRADIENT_COLORS=0x1300,
	CHUNK_EDIT_UNKNW04=0x1400,
	CHUNK_EDIT_UNKNW05=0x1420,
	CHUNK_EDIT_UNKNW06=0x1450,
	CHUNK_RAYTRACE_BIAS=0x1460,
	CHUNK_EDIT_UNKNW07=0x1500,
	CHUNK_FOG=0x2200,
	CHUNK_AMBCOLOR=0x2100,
	CHUNK_EDIT_UNKNW09=0x2201,
	CHUNK_DISTANCE_QUEUE=0x2300,
	CHUNK_LAYERED_FOG_OPTIONS=0x2302,
	CHUNK_EDIT_UNKNW12=0x2000,
	CHUNK_EDIT_UNKNW13=0x3000,
	CHUNK_TRI_VERTEX_OPTIONS=0x4111,

	//Material chunks
	CHUNK_MATERIAL=0xafff,
		CHUNK_MATNAME=0xa000,
		CHUNK_AMBIENT=0xa010,
		CHUNK_DIFFUSE=0xa020,
		CHUNK_SPECULAR=0xa030,
		CHUNK_SHININESS=0xa040,
		CHUNK_SHININESSSTRENGTH=0xa041,
		CHUNK_TRANSPARENCYPERCENT=0xa050,
		CHUNK_TRANSPARENCYFALLOFFPERCENT=0xa052,
		CHUNK_REFLECTIONBLURPERCENT=0xa053,
		CHUNK_SELFILLUM=0xa084,
		CHUNK_WIRETHICKNESS=0xa087,
		CHUNK_RENDERTYPE=0xa100,
		CHUNK_TEXTURE=0xa200,
		CHUNK_BUMPMAP=0xa230,
		CHUNK_MAPFILE=0xa300,

	//Farge blokker
	CHUNK_RGBF=0x0010,	//RGB (float)
	CHUNK_RGBB=0x0011,	//RGB (byte)
	CHUNK_RGBBG=0x0012,	//RGB (byte) gamma korreksjon
	CHUNK_RGBFG=0x0013,	//RGB (float) gamma korreksjon

	//Prosent blokker
	CHUNK_PERCENTINT=0x0030,
	CHUNK_PERCENTFLOAT=0x0031,

	CHUNK_OBJBLOKK=0x4000,
		CHUNK_TRIMESH=0x4100,
			CHUNK_VERTLIST=0x4110,
			CHUNK_VERTFLAGS=0x4111,
			CHUNK_FACELIST=0x4120,
			CHUNK_FACEMAT=0x4130,
			CHUNK_MAPLIST=0x4140,
			CHUNK_SMOOTHLIST=0x4150,
			CHUNK_TRMATRIX=0x4160,
			CHUNK_MESHCOLOR=0x4165,
			CHUNK_TXTINFO=0x4170,
				CHUNK_LIGHT=0x4600,
				CHUNK_SPOTLIGHT=0x4610,
				CHUNK_CAMERA=0x4700,
				CHUNK_HIERARCHY=0x4F00,

	//Window settings
	CHUNK_VIEWPORT_LAYOUT_OLD=0x7000,
	CHUNK_VIEWPORT_LAYOUT=0x7001,
		CHUNK_VIEWPORT_DATA_OLD=0x7010,
		CHUNK_VIEWPORT_DATA=0x7011,
		CHUNK_VIEWPORT_DATA3=0x7012,
		CHUNK_VIEWPORT_SIZE=0x7020,
		CHUNK_NETWORK_VIEW=0x7030,

	CHUNK_KEYFRAMER=0xb000,
	CHUNK_AMBIENTKEY=0xb001,
	CHUNK_TRACKINFO=0xb002,
	CHUNK_TRACKCAMERA=0xb003,
	CHUNK_TRACKCAMTGT=0xb004,
	CHUNK_TRACKLIGHT=0xb005,
	CHUNK_TRACKLIGTGT=0xb006,
	CHUNK_TRACKSPOTL=0xb007,
	CHUNK_FRAMES=0xb008,
	CHUNK_KEYFRAMER_CUR_FRAME=0xb009,
	CHUNK_KEYFRAMER_HEADER=0xb00a,
	CHUNK_TRACKOBJNAME=0xb010,
	CHUNK_TRACKPIVOT=0xb013,

	CHUNK_TRACKPOS=0xb020,
	CHUNK_TRACKROTATE=0xb021,
	CHUNK_TRACKSCALE=0xb022,
	CHUNK_TRACKFOV=0xb023,
	CHUNK_TRACKROLL=0xb024,
	CHUNK_TRACKMORPH=0xb026,
	CHUNK_TRACKHIDE=0xb029,

	CHUNK_OBJNUMBER=0xb030,
};

typedef struct
{
	unsigned short a,b,c;
	unsigned short flag;
} Face3D;

class Scene3DS
{
public:
	Scene3DS()
	{
		filpeker=0;
		filstoerrelse=0;
	}
//	void Les3DS(string filnavn);
	bool Les3DS(const char *filnavn);

	//3d objektet, som inneholder vertices, faces osv..
	Object object;

private:
	void LesChunk(chunk3ds &chunk);

	void lesfil(void *destinasjon, int lengde);
	void setpos(uint posisjon);
	uint hentpos();

	void LesMainBlokka(uint total_lengde);
	void LesObjektMeshBlokka(uint total_lengde);
	void LesObjektBlokka(uint total_lengde);
	void LesMaterialBlokka(uint total_lengde);
	void LesTriMeshBlokka(uint total_lengde, char *navn);
	void LesFaceListBlokka(uint total_lengde);
	void LesKeyframerBlokka(uint total_lengde);
	void LesCameraTrackBlokka(uint total_lengde);
	void LesColorBlokka(uint total_lengde);
	void LesProsentBlokka(uint total_lengde);

	long LesASCII(char *destinasjon);


	//-------------------------------------------------------

	//triangular mesh variabler
	Vector3D *vertices;
	unsigned short num_vertices;

	Face3D *faces;
	unsigned short num_faces;

//	char *matnavn;
	char matnavn[32];
	char matnavn2[32];
	char mapfilnavn[32];
	char objnavn[32];
	char bgbitmapfilnavn[32];

	char tempbuffer[65536];

	char parse_flag;
protected:
//	long filpeker;
	long filstoerrelse;

	FILE *filut;
	FILE *filpeker;
//	ifstream fil;
};