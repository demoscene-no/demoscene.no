
/*
// Keyframer chunks

#define CHUNK_KEYFRAMER_AMBIENTKEY        0xb001
#define CHUNK_KEYFRAMER_TRACKINFO         0xb002
#define CHUNK_KEYFRAMER_TRACKCAMERAPOS    0xb003
#define CHUNK_KEYFRAMER_TRACKCAMERATARGET 0xb004
#define CHUNK_KEYFRAMER_FRAMES            0xb008
  */
/*
        CHUNK_KEYFRAMER = 0xB000,
            CHUNK_AMBIENTKEY    = 0xB001,
            CHUNK_TRACKINFO = 0xB002,
                CHUNK_TRACKOBJNAME  = 0xB010,
                CHUNK_TRACKPIVOT    = 0xB013,
                CHUNK_TRACKPOS      = 0xB020,
                CHUNK_TRACKROTATE   = 0xB021,
                CHUNK_TRACKSCALE    = 0xB022,
                CHUNK_TRACKMORPH    = 0xB026,
                CHUNK_TRACKHIDE     = 0xB029,
                CHUNK_OBJNUMBER     = 0xB030,
            CHUNK_TRACKCAMERA = 0xB003,
                CHUNK_TRACKFOV  = 0xB023,
                CHUNK_TRACKROLL = 0xB024,
            CHUNK_TRACKCAMTGT = 0xB004,
            CHUNK_TRACKLIGHT  = 0xB005,
            CHUNK_TRACKLIGTGT = 0xB006,
            CHUNK_TRACKSPOTL  = 0xB007,
            CHUNK_FRAMES    = 0xB008,
*/
/*
// Color chunks

#define CHUNK_RGB                         0x010
#define CHUNK_TRU                         0x011

// Object sub-chunks

#define CHUNK_OBJECT_MESH                 0x4100
#define CHUNK_OBJECT_LIGHT                0x4600
#define CHUNK_OBJECT_CAMERA               0x4700
//#define CHUNK_OBJECT_NO_SHADOW            0x4017

// Light sub-chunks

#define CHUNK_OBJECT_LIGHT_SPOT           0x4610
#define CHUNK_OBJECT_LIGHT_STATE          0x4620

// Mesh sub-chunks

#define CHUNK_OBJECT_MESH_VERTICES        0x4110
#define CHUNK_OBJECT_MESH_FACES           0x4120
#define CHUNK_OBJECT_MESH_UV              0x4140
#define CHUNK_OBJECT_MESH_LOCAL           0x4160

// Face sub-chunks

#define CHUNK_OBJECT_FACES_MATERIAL       0x4130
#define CHUNK_OBJECT_FACES_SMOOTH         0x4150

// Material sub-chunks

#define CHUNK_MATERIAL_NAME               0xa000
#define CHUNK_MATERIAL_AMBIENT            0xa010
#define CHUNK_MATERIAL_DIFFUSE            0xa020
#define CHUNK_MATERIAL_SPECULAR           0xa030
#define CHUNK_MATERIAL_MAP                0xa200
#define CHUNK_MATERIAL_FILE               0xa300
#define CHUNK_MATERIAL_SHININESS          0xa040
#define CHUNK_MATERIAL_SHININESS_STRENGTH 0xa041
*/