#include "ypn_objectname.h"

ObjectName::ObjectName()
{
	name=0;
	name_len=0;
}

ObjectName::~ObjectName()
{
	if (name!=0) free(name);
}

void ObjectName::SetName(const char *value)
{
	name_len=strlen(value)+1;
	name=(char *)malloc(name_len);
	strcpy(name, value);
}

int ObjectName::GetName(char *buffer, int max_size)
{
	int i;
	if (name_len >= max_size) i=max_size;
	else i=name_len;
	strncpy(buffer, name, i);
	return i;
}
