#ifndef _mesh
#define _mesh

#include "ypn_objectname.h"
#include "../ypn_face.h"

class Mesh : public ObjectName
{
public:
	Mesh();
	virtual ~Mesh();

	//vertices
//	void AddVertex(Vector3D v);
	virtual void AddVertex(float x, float y, float z);
	virtual void AddUV(int index, float u, float v);
	Vector3D *vertices;
//	Vector3D **vertices;
	int num_vertices;

	//faces
//	void AddFace(unsigned short a, unsigned short b, unsigned short c);
	virtual void AddFace(unsigned short a, unsigned short b, unsigned short c, unsigned short visible);
	Face *faces;
//	Face **faces;
	int num_faces;

	//materials
	virtual void SetMaterialName(const char *name);

protected:
	char *material_name;
	int material_name_size;
};

#endif