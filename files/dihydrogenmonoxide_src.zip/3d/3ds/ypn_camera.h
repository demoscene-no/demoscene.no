#ifndef _camera
#define _camera

#include "ypn_objectname.h"
#include "../ypn_vector3d.h"

class Camera : public ObjectName
{
public:
	Camera();
	~Camera();
/*	virtual void Clear();
	virtual void SetPosition(rVector pos);
	virtual rVector GetPosition();
	virtual void SetTarget(rVector tar);
	virtual rVector GetTarget();
	virtual void SetBank(float value);
	virtual float GetBank();
	virtual void SetLens(float value);
	virtual float GetLens();

	//keys
	virtual void SetKeyPosition(rVector pos);
	virtual void SetKeyTarget(rVector target);
*/
protected:
	Vector3D pos;
	Vector3D target;
	float bank;
	float lens;
	Vector3D keypos;
	Vector3D keytarget;
};

#endif