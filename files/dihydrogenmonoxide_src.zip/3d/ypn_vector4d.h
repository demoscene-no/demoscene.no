#ifndef _vector4d
#define _vector4d

class Vector4D
{
public:
	Vector4D();
	Vector4D(float _x, float _y, float _z, float _w);
	~Vector4D();

	float x;
	float y;
	float z;
	float w;
};

float dot_product(Vector4D a, Vector4D b);

#endif