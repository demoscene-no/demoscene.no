#ifndef _poly
#define _poly

#include "ypn_edge.h"
#include "../layer/ypn_layer.h"

class Layer;

class Poly
{
public:
	Poly();
	~Poly();

	void Reset();
	void AddPoint(int x, int y);
	void AddPoint(int x, int y, int u, int v);

	void InitPoints(int amount);
	void SetPoint(int x, int y, int index);

	void SetUV(int u, int v, int index);
	void AddVertex(Vector3D *v);
	void SetFaceNormal(Vector3D *v);
	void SetVertexNormal(Normal *v, int index);
	void InitVertices(int amount);
//	void InitVertices();//int amount)
	void SetVertex(Vector3D *v, int index);
	void SetVertexUV(int u, int v, int index);
	Vector3D GetVertex(int index);
	void AddEdge(int vertex_num1, int vertex_num2);
	int GetNumPoints();
	void DrawLine(uint *pixel, int col);
	//void DrawTriFill(Layer layer, int col);
	void DrawTriFill(Layer layer, int tobuffer, int col);
//	void DrawTriFill(unsigned int *pixel, int col);
	void DrawGouraud(Layer layer, int tobuffer, int col1, int col2, int col3);
	void DrawDot(Layer layer, int tobuffer, int col);
	//void DrawTexture(uint *pixel, unsigned int *texture);
	void DrawTexture(Layer layer, int tobuffer, int texbuffer);
	void DrawSprite(Layer layer, int tobuffer, int frombuffer, int alpha);

	Vector3D *vertices;
	int num_vertices;

	Coord2D *points;
	int num_points;

	int point_counter;
	int vertex_counter;
	Edge *edges;	// (ny)
	int num_edges;

	int ab,bc,ca;
	Vector3D face_normal;
	Normal vertex_normals[3];

	int color;
	bool perspective_correct;
};

#endif