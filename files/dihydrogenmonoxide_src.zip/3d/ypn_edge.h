#ifndef _edge
#define _edge

class Edge
{
public:
	Edge();
	~Edge();
	
	void Set(int si, int ei);

	int start_point;
	int end_point;
};

#endif