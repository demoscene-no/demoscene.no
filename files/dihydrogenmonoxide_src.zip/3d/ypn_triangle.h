class Triangle
{
public:
	Triangle();
	~Triangle();
};

