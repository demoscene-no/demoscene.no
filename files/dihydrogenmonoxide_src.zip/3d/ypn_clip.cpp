#include "ypn_clip.h"
#include <math.h>

Plane2::Plane2()
{

}

Plane2::Plane2(float _a, float _b, float _c, float _d)
{
	a=_a;
	b=_b;
	c=_c;
	d=_d;
}

Plane2::~Plane2()
{

}

void Plane2::ConstructABCD(Vector3D v1, Vector3D v2, Vector3D v3)
{
	Vector3D q,v;
	q.x=v2.x-v1.x; v.x=v2.x-v3.x;
	q.y=v2.y-v1.y; v.y=v2.y-v3.y;
	q.z=v2.z-v1.z; v.z=v2.z-v3.z;
	normal=cross_product(q,v);
	q.Normalize();
	distance=dot_product(normal,v1);
}

int Plane2::ClipLineAgainstPlane(Vector3D *v1, Vector3D *v2)
{
	Vector3D intersectionpoint;

	distance_plane_to_point_v1=dot_product(*v1, normal) - distance;
	distance_plane_to_point_v2=dot_product(*v2, normal) - distance;

	//if true, both points are on the backside of the plane
	if ((distance_plane_to_point_v1<0) && (distance_plane_to_point_v2<0))
	{
		//remove them
		return 0;
		//v1->Set(0,0,0,0);
		//v2->Set(0,0,0,0);
	}
	else
	//if true, the points are on the foreside of the plane
	if ((distance_plane_to_point_v1>0) && (distance_plane_to_point_v2>0))
	{
		//dont do anything
		return 1;
	}
	else
	//they are different
	if ((distance_plane_to_point_v1>0) && (distance_plane_to_point_v2<0))
	{
		//calculate intersection point of the plane and the line
		float s=distance_plane_to_point_v2/(distance_plane_to_point_v2-distance_plane_to_point_v1);
		intersectionpoint.x=v2->x+s*(v1->x-v2->x);
		intersectionpoint.y=v2->y+s*(v1->y-v2->y);
		intersectionpoint.z=v2->z+s*(v1->z-v2->z);
		v2->x=intersectionpoint.x;
		v2->y=intersectionpoint.y;
		v2->z=intersectionpoint.z;
		return 1;
	}
	else
	if ((distance_plane_to_point_v1<0) && (distance_plane_to_point_v2>0))
	{
		//calculate intersection point of the plane and the line
		float s=distance_plane_to_point_v1/(distance_plane_to_point_v1-distance_plane_to_point_v2);
		intersectionpoint.x=v1->x+s*(v2->x-v1->x);
		intersectionpoint.y=v1->y+s*(v2->y-v1->y);
		intersectionpoint.z=v1->z+s*(v2->z-v1->z);
		v1->x=intersectionpoint.x;
		v1->y=intersectionpoint.y;
		v1->z=intersectionpoint.z;
		return 1;
	}
}

Frustum2::Frustum2()
{

}

Frustum2::~Frustum2()
{

}

void Frustum2::Init(float project_scale, float sx, float sy)
{
	angle_horizontal=atan2(sx/2,project_scale)-0.0001;
	angle_vertical=atan2(sy/2,project_scale)-0.0001;
//	angle_horizontal=atan2(sx/2,DEG2RAD(project_scale))-0.0001;
//	angle_vertical=atan2(sy/2,DEG2RAD(project_scale))-0.0001;
	sh=sin(angle_horizontal);
	sv=sin(angle_vertical);
	ch=cos(angle_horizontal);
	cv=cos(angle_vertical);
	
	// left
	planes[0].normal.x=ch;
	planes[0].normal.y=0;
	planes[0].normal.z=sh;
	planes[0].distance=0;

	// right
	planes[1].normal.x=-ch;
	planes[1].normal.y=0;
	planes[1].normal.z=sh;
	planes[1].distance=0;
	
	// top
	planes[2].normal.x=0;
	planes[2].normal.y=cv;
	planes[2].normal.z=sv;
	planes[2].distance=0;
	
	// bottom
	planes[3].normal.x=0;
	planes[3].normal.y=-cv;
	planes[3].normal.z=sv;
	planes[3].distance=0;

	// z-near clipping plane
	planes[4].normal.x=0;
	planes[4].normal.y=0;
	planes[4].normal.z=1;
//	planes[4].distance=-10;

//	planes[4].distance=-10;
	planes[4].distance=40;
//	planes[4].distance=-140;
}
