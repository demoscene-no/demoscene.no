#ifndef _matrix
#define _matrix

#include "../commonheaders/ypn_common.h"
#include "ypn_vector4d.h"
#include "../particleengine/ypn_particle3d.h"
typedef float Matrix[4][4];

class CMatrix
{
public:
	CMatrix();// {}
	~CMatrix();// {}
	float Matrix[16];

	CMatrix operator*(const CMatrix m) const;

	void operator=(const CMatrix m);

	void PreTranspose(Vector3D *v);
	void LoadIdentity();
	void CreateTranslationMatrix(Vector3D translation);
	void CreateScalingMatrix(Vector3D scaling);
	void CreateRotationMatrix(Vector3D rotation);
	void CreateXRotationMatrix(float xrotation);
	void CreateYRotationMatrix(float yrotation);
	void CreateZRotationMatrix(float zrotation);
	void MultiplyMatrix(CMatrix fromMatrix);
	Vector3D ApplyMatrix(Vector3D in);
	Particle3D *ApplyMatrixP3D(Particle3D *in);
	Normal ApplyMatrix(Normal in);
	Vector4D ApplyMatrixW(Vector3D in);
	Vector3D ApplyMatrix_W(Vector3D in);
	void Update3DSCameraMatrix(Vector3D pos, Vector3D tar, Vector3D up, float roll);
	void CreateCameraMatrix(Vector3D eye, Vector3D center, Vector3D up);
	void LookAt(Vector3D eye, Vector3D lookat, Vector3D up);
	void CreateOrthographicProjectionMatrix();
	void CreateProjectionMatrix(float znear, float zfar, float aspect, float fovx, float fovy);
	void CreatePerspectiveProjectionMatrix(float dist);
	void CreateOpenglFrustumMatrix(float l, float r, float b, float t, float n, float f);
	void CreateTestMatrix(float fov, float zn, float zf);
	void CreatePerspectiveProjectionMatrix2(float l, float r, float b, float t, float n);
	void CreateOpenglFrustumMatrix2(float l, float r, float b, float t, float n, float f);
	void PerspectiveMatrix(Vector3D eye);
	void ViewPlaneWindow(int width, int height);
	void CPPM(int d);
};

void matrix_identity(Matrix m);
void vector_times_matrix(Vector3D *v, Matrix m);
void matrix_times_matrix(Matrix m, Matrix m2);
void matrix_copy(Matrix m, Matrix m2);
void matrix_translate(Matrix m, Vector3D v);
void matrix_rotate_x(Matrix m, float rx);
void matrix_rotate_y(Matrix m, float ry);
void matrix_rotate_z(Matrix m, float rz);
void matrix_rotate(Matrix matrix, Vector3D r);
void matrix_scale(Matrix m, Vector3D sc);

void matrix_perspective(Matrix m, float yfov, float aspect, float ndist, float fdist);

void matrix_perspectivediv(Vector3D *v, Matrix m);

void matrix_perspective_projection(Matrix m, float d);
//void matrix_perspective_projection(Matrix m, float fov, float n, float f);
//void matrix_perspective_projection(Matrix m, float fov);
//void matrix_perspective_projection(Matrix m, float fov, float znear, float zfar);
//void matrix_perspective_projection(Matrix m, float xfov, float yfov, float znear, float zfar);
void matrix_frustum(Matrix m, float l, float r, float b, float t, float zn, float zf);

void matrix_orthographic_projection(Matrix m);

void matrix_lookat(Matrix m, Vector3D eye, Vector3D lookat, Vector3D up);


void matrix_projection(Matrix m, float d);
//void matrix_projection(Matrix m, float d, float s, float f);


void matrix_clip_coord(Matrix m, float d, float s);

void matrix_perspective_proj(Matrix m, float fov, float znear, float zfar);


#endif