#ifndef _object
#define _object

#include "../layer/ypn_layer.h"
#include "../2d/ypn_vector2d.h"
#include "ypn_face.h"
#include "ypn_clip.h"
#include "ypn_poly.h"
#include "ypn_zbuffer.h"
#include "ypn_matrix.h"
#include "3ds/ypn_material.h"

#define R3D_FLAT_FIXED 0
#define R3D_FLAT_SHADE 1


//
//Desc: A plane is a infinitely wide flat polygon-type surface.
//A plane is defined by a normal <nx,ny,nz> and a scalar value k.
//Plane equation: uses the dot product: <x,y,z> * <nx,ny,nz> = k
//<x,y,z> * <nx,ny,nz> = k		Point is on plane
//<x,y,z> * <nx,ny,nz> > k		Point is on one side of plane
//<x,y,z> * <nx,ny,nz> < k		Point is on other side of plane
//
//
//The Plane Equation:
//Ax + By + Cz + D = 0		where A, B, C and D are known constants and (x,y,z) specifies any point in 3D.
//
//positive value:	the point is said to be "in front of the plane"
//negative value:	the point is said to be "behind the plane"
//exact zero:		the point is said to be "on the plane"
//
typedef struct
{
	Vector3D normal;
	float distance;
} Plane;
/*
typedef struct
{
	Plane planes[5];
} Frustum;*/

typedef struct
{
	float u;
	float v;
	float w;
} TextureCoord;

#define RENDERMODE_WIREFRAME 0
#define RENDERMODE_FLAT 1
#define RENDERMODE_GOURAUD 2
#define RENDERMODE_PHONG 3
#define RENDERMODE_METAL 4

#define RENDERMODE_TEXTURE 5

Coord2D project3d(Vector3D v, float zscale);
Coord2D project3d(Vector3D v, float zscale, int xresh, int yresh);
Coord2D project3d_new(Vector3D v, float zscale, int xresh, int yresh);
int compare(const void *_a, const void *_b);

class Vertex
{
public:
	Vector3D verts_fixed;
	Vector3D verts_world;
	Vector3D verts_clipped;
//	Screen2D coords;
	int color;
};

class Layer;
class Poly;

class Object
{
public:
	Object();
	~Object();


	void InitZBuffer(int width, int height);
	void ParseASE(char *filename);
	void ParseASC(char *filename);

	void MakeTriangle();
	void MakeTestObject();
	void MakeGrid(int x, int y);
	void CreateCube();

	void SetZSCALE(float _zscale);
	void FrustumSetup(float sx, float sy);
	void Show(Layer layer, int tobuffer, int texture, int frombuffer);
	void Rotate(float xrot, float yrot, float zrot);
	void Rotate(Vector3D rot);
	void Translate(Vector3D tra);

	void Morph(Object fromObject, float factor);
	void Copy(Object fromObject);

	//---------------------------------------
	//Clipping
	//---------------------------------------

	void SetClipArea(int x1, int y1, int x2, int y2);
	void DrawClipArea(Layer layer, int tobuffer, int col);
	int GetBitCode(int x, int y);
	int Inside(int x, int y);
	int InsideLEFT(int x);
	int InsideRIGHT(int x);
	int InsideTOP(int y);
	int InsideBOTTOM(int y);
	int InsideNEAR(float z);

	Coord2D screenarea[2];
	float znear;
	float zfar;

	void SetClippedVertex(Vector3D *v, int index);
	Vector3D *vertices_zclipped;

	//---------------------------------------
	//object variables:
	//---------------------------------------

	//vertices
	Vector3D *vertices_real;	//Real vertices:  Never changed. (the object's parsed vertices)
	Vector3D *vertices_world;	//World vertices: 3D rotated, translated etc..
	int num_vertices;
	int num_texture_vertices;

	//vector slime
	float *distance_buffer;
	Vector3D *rotation_buffer;

	//faces
	Face *faces_real;
	Face *faces_new;
	int num_faces;
	int num_faces_new;

	void InitNewFaces(int amount);
	void SetNewFace(int index, int vertnum1, int vertnum2, int vertnum3);
	void SetNewFaceColor(int index, int color);

	//normals:
	Vector3D *face_normals;
	Normal *vertex_normals[3];

	//texture variables
	TextureCoord *vertices_texture;
	int num_tvertices;
	int num_tfaces;

	//projection
	void SetProjectedPoints(Vector3D *v, Coord2D midpoint, int index);
	Coord2D *points_project;

	///
	///
	///
	///

	Poly *polygons_real;
	Poly *polygons_temp;
	Poly *polygons_clipped;

	///
	///
	///
	///

//	Frustum frustum;
	Frustum2 frustum2;

	//---------------------------------------
	//Z-Buffer sorting
	//---------------------------------------

	void addZbuffer();
	Zbuffer *zBuffer;
	int zBuffer_num;

	//---------------------------------------
	///Materials
	//---------------------------------------

	Material material[8];
	int material_index;

	///
	///
	///

	int zscale;

	//---------------------------------------
	//colors
	//---------------------------------------
	int color_dot_fixed;
	int color_dot_shading;
	int color_wireframe_fixed;
	int color_wireframe_shading;
	int color_flat_fixed;
	int color_flat_shading;

	void SetColor(int flag, int col);
	int color_flag;

	//---------------------------------------
	//Camera
	//---------------------------------------
	Vector3D campos, camtar;
	float cambank, camlens;
	CMatrix Cameramatrix;

	//---------------------------------------
	//Matrices
	//---------------------------------------
	void mLoadIdentity();
	void mTranslate(Vector3D translation);
	void mRotate(Vector3D rotation);
	void mLoadIdentityN();
	void mTranslateN(Vector3D translation);
	void mRotateN(Vector3D rotation);
	void mCameraLookAt(Vector3D eye, Vector3D center, Vector3D up);

	CMatrix Currentmatrix, CurrentmatrixN; //N for Normals
	CMatrix Objectmatrix;

	CMatrix Processmatrix,ProcessmatrixN;
	CMatrix Rotationmatrix;
	CMatrix Translationmatrix;

	CMatrix Finalmatrix;
	CMatrix Normalsmatrix;

	void SetLight(Vector3D l);
	Vector3D light;

	//---------------------------------------
	//Object world variables
	//---------------------------------------

	Vector3D rotate,translate;

	//---------------------------------------
	//flags and stuff
	//---------------------------------------
	bool flag_vertex_and_face_normals;
	bool flag_uv_texture;
	int flag_mapping_coordinates;
	int flag_smoothing_groups;
	int flag_material;

	bool perspective_correct;

	int rendermode;
	int culling;
	bool envmap;

	int parsemode;
	int transmode;

	void Free();
};

#endif