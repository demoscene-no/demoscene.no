
/******************************************************************************
 *
 *  FILE:           YPN_VECTOR3D.CPP
 *
 *  MODULE OF:      3D LIBRARY (YPN3D.LIB?)
 *
 *  DESCRIPTION:    Vector class for adding, substracting, multiplying vectors.
 *
 *					You can return dot-product and cross-product through
 *					functions outside the class.
 *
 *					Additional functions in the class:
 *					- Return distance squared or length (square root of	distance).
 *					- Normalize a vector
 *					- Linear interpolate a vector with another vector.
 *
 *	TODO:			Implement Dot Product and Cross Product inside the class.
 *					Make operators for the mathematical operations.
 *
 *  WRITTEN BY:     Rudi B. Stranden
 *
 ******************************************************************************/

#include "../commonheaders/ypn_common.h"
#include "ypn_vector3d.h"

Vector3D::Vector3D()
{

}

Vector3D::Vector3D(float _x, float _y, float _z)
{
	x=_x;
	y=_y;
	z=_z;
}

Vector3D::Vector3D(float _x, float _y, float _z, float _w)
{
	x=_x;
	y=_y;
	z=_z;
	w=_w;
}

Vector3D::~Vector3D()
{

}

//the dot product is a value (or "scalar"). its a function of two vectors.
//aka scalar product
float dot_product(Vector3D a, Vector3D b)
{
	return ((a.x*b.x)+(a.y*b.y)+(a.z*b.z));
}

//the cross product returns a vector that is orthogonal to a and b.
Vector3D cross_product(Vector3D a, Vector3D b)
{
	Vector3D v((a.y*b.z)-(b.y*a.z),(a.z*b.x)-(b.z*a.x),(a.x*b.y)-(b.x*a.y));
	return v;
}

void Vector3D::Set(float _x, float _y, float _z)
{
	x=_x;
	y=_y;
	z=_z;
}

void Vector3D::Set(float _x, float _y, float _z, float _w)
{
	x=_x;
	y=_y;
	z=_z;
	w=_w;
}

void Vector3D::Add(Vector3D a)
{
	x+=a.x;
	y+=a.y;
	z+=a.z;
}

void Vector3D::Substract(Vector3D a)
{
	x-=a.x;
	y-=a.y;
	z-=a.z;
}

void Vector3D::Multiply(Vector3D a)
{
	x*=a.x;
	y*=a.y;
	z*=a.z;
}

void Vector3D::Multiply(float scalar)
{
	x*=scalar;
	y*=scalar;
	z*=scalar;
}

void Vector3D::RotateX(float theta)
{
	Vector3D n;
	n.y=cos(theta)*y-sin(theta)*z;
	n.z=sin(theta)*y+cos(theta)*z;
	n.x=x;
	x=n.x;
	y=n.y;
	z=n.z;
}

void Vector3D::RotateY(float theta)
{
	Vector3D n;
	n.x=cos(theta)*x-sin(theta)*z;
	n.z=sin(theta)*x+cos(theta)*z;
	n.y=y;
	x=n.x;
	y=n.y;
	z=n.z;
}

void Vector3D::RotateZ(float theta)
{
	Vector3D n;
	n.y=cos(theta)*y-sin(theta)*x;
	n.x=sin(theta)*y+cos(theta)*x;
	n.z=z;
	x=n.x;
	y=n.y;
	z=n.z;
}

float Vector3D::DistanceSqr()
{
	return (float)(SQR(x)+SQR(y)+SQR(z));
}

float Vector3D::Length()
{
	return (float)sqrt(SQR(x)+SQR(y)+SQR(z));
}

void Vector3D::Normalize()
{
	float unit_length=1.f/sqrt(SQR(x)+SQR(y)+SQR(z));// /Length();
	x*=unit_length;
	y*=unit_length;
	z*=unit_length;
//	length=sqrt(x*x+y*y);
//	x/=length;
//	y/=length;
//	z/=length;
}

void Vector3D::LinearInterpolate(Vector3D a, float u)
{
	Vector3D v(x,y,z);
	x=v.x+u*(a.x-v.x);
	y=v.y+u*(a.y-v.y);
	z=v.z+u*(a.z-v.z);
}

void Vector3D::CosineInterpolate(Vector3D a, Vector3D b, float x)
{
	float ft=x*M_PI;
	float f=(1-cos(ft))*.5;
	float f1=(1-f);

	Vector3D af(a.x,a.y,a.z);
	Vector3D bt(b.x,b.y,b.z);

	Vector3D ret;
	ret.x=af.x*f1+bt.x*f;
	ret.y=af.y*f1+bt.y*f;
	ret.z=af.z*f1+bt.z*f;
	x=ret.x;
	y=ret.y;
	z=ret.z;
}

Vector3D Vector3D::CosineInterpolateR(Vector3D a, Vector3D b, float x)
{
	float f=(1-cos(x*M_PI))*.5;
	float finv=(1-f);

	Vector3D ret;
	ret.x=a.x*finv+b.x*f;
	ret.y=a.y*finv+b.y*f;
	ret.z=a.z*finv+b.z*f;
	return ret;
}

void Vector3D::CubicInterpolate(Vector3D v0, Vector3D v1, Vector3D v2, Vector3D v3, float x)
{
	Vector3D p((v3.x-v2.x)-(v0.x-v1.x), (v3.y-v2.y)-(v0.y-v1.y), (v3.z-v2.z)-(v0.z-v1.z));
	Vector3D q((v0.x-v1.x)-p.x, (v0.y-v1.y)-p.y, (v0.z-v1.z)-p.z);
	Vector3D r(v2.x-v0.x,v2.y-v0.y,v2.z-v0.z);
	Vector3D s(v1.x,v1.y,v1.z);
	Vector3D ret;

	float x2=x*x;
	float x3=x*x*x;
	ret.x=p.x*x3+q.x*x2+r.x*x+s.x;
	ret.y=p.y*x3+q.y*x2+r.y*x+s.y;
	ret.z=p.z*x3+q.z*x2+r.z*x+s.z;
	x=ret.x;
	y=ret.y;
	z=ret.z;
}

void Vector3D::Negate()
{
	x=-x;
	y=-y;
	z=-z;
}




Point::Point()
{

}

Point::Point(float _x, float _y, float _z)
{
	x=_x;
	y=_y;
	z=_z;
}

Point::~Point()
{

}