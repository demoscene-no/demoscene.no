#include "ypn_triangle.h"

Triangle::Triangle()
{

}

Triangle::~Triangle()
{

}
