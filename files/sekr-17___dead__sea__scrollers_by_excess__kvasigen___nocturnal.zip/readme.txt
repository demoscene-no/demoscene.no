sekr-17: .dead .sea .scrollers
------------------------------
   a 64k intro presented at 
        dreamhack 2001
             by
 excess, kvasigen & nocturnal
------------------------------
      code: sesse & neon
       music: lug00ber

     additional credits:
      fonts ripped from 
http://www.algonet.se/~guld1/
     player by firelight
      tinyptc by gaffer
------------------------------
       www.demoscene.no
------------------------------
