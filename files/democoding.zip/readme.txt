Hi there

I have decided to release some example-sourcecode so that people wanting to get started with
democoding can get an idea about how to do so. This is NOT very optimized code, and is written
for educational purposes. More sourcecode might follow.

The sourcecode is written in C using msvc6. The package contains a grid-expander, some
blending-routines, an imageloader, some basic filewrappers and a ddraw-handling lib. The
imageloader uses OLE to load JPEG, GIF and BMP images.

Only one walter was harmed during the production of these sources.

The sourcecode may be freely used for non-comerceal as long as you give me credit for it.

-Erik Faye-Lund
aka kusma/excess
eflund@online.no
