
                                 Nocturnal & Excess 

                                      presents

                                    (a bit late)

                              Norvegia 2001 Partyreport

     >----------------------------------------------------------------------------<

                                       Credits

                                    Text - cherox

                            Pictures - lug00ber & cherox

                                Music - dent & cherox
 
                                  Graphics - kusma

                                     Code - neon

     >----------------------------------------------------------------------------<

                                     neon greets
          alv, calvin, cherox, cpix, darkman, dent, docjones, fuglemat, gloom, 
       guardian, izm, krav, leia, lug00ber, peaky, sesse, silmaril, sinny, tecon, 
       raiden, tick, tmk, torgman, twaddler, xhale, yithzaq, #scene.no, #coders, 
                      #daskmig, #pixel, #gbadev, #bafh etc.

                                    kusma greets
         kvasigen, progress, spaceballs, haujobb, array, unique, contraz, inf, 
                            therapii, tls, valium!design


