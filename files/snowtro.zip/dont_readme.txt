a quick shit-xmasintro from
kusma and irvin

datadir due to complete lazyness
(hey, I need sleep!)

if it works, it works
